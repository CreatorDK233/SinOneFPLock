#ifndef fingerprint_h
#define fingerprint_h

#include "StdTypes.h"
	
	
#define DEF_FpmLedColor_Red 0x04
#define DEF_FpmLedColor_Green 0x02
#define DEF_FpmLedColor_Blue 0x01
#define DEF_FpmLedColor_All 0x00

	
#define DEF_FpmLedMode_Breath	0x01
#define DEF_FpmLedMode_Flash	0x02
#define DEF_FpmLedMode_On		0x03
#define DEF_FpmLedMode_Off		0x04
	
void FPcmd_Init(void);
extern void FPM_SendGetImageCmd(void);
extern void FPM_SendGetEnrollImageCmd(void);
extern void FPM_SendGenCharCmd(uint8_t BufferID);
extern void FPM_SendRegModelCmd(void);
extern void FPM_SendStoreCharCmd(uint8_t BufferID,uint16_t UserID);
extern void FPM_SendSearchCmd(uint8_t BufferID,uint16_t StartPage,uint16_t PageNum);
extern void FPM_DeleteCharCmd(uint16_t StartPageID,uint16_t CharNum);
extern void FPM_DeleteAllCharCmd(void);
extern void FPM_GetValidTempleteNumCmd(void);
extern void FPM_SendReadIndexTableCmd(void);
extern void FPM_SendGetSerialNumberCmd(void);
extern void FPM_SendAutoRegisterCmd(uint16_t UserID);
extern void FPM_SetBreathingLED(uint8_t mode,uint8_t startcolor,uint8_t endcolor,uint8_t looptimes);
extern void FPM_SetSecurityLevel(uint8_t Level);			//from 1 ~5
extern void FPM_TurnOffAntiFakeFp(void);
extern void FPM_SendSleepCmd(void);
extern void FPM_SendGetChipSerialNumberCmd(void);
extern void FPMcmd_Excute(void);
extern void FPM_Mgr_Task(void);
extern void GUI_SetFPM_LED(uint8_t mode,uint8_t startcolor,uint8_t stopcolor,uint8_t cycles );

#endif
