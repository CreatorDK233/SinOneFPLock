#ifndef _FaceRecognition_H
#define _FaceRecognition_H

extern FrmMgr_t FrmMgr;
extern FaceIdentifyMgr_t FaceIdentifyMgr;
extern void FaceRecognition_HardwarePowerOn(void);
extern void FaceRecognition_Reset(void);
extern void FaceRecognition_GetStatus(void);
//extern status_t UART0_Write_TxBUFFER(unsigned char *buff,unsigned char len);
extern void UART0_TX_Task(void);
extern void UART0_CLEAR_TXBUFF(void);
extern void FaceRecognition_GetStatus(void);
extern void FRM_Cmd_Excute(void);
extern status_t  FRM_SendEnableDemoCmd(void);
extern status_t  FRM_SendDisableDemoCmd(void);
extern status_t FRM_SendRegisterMultiTimesCmd(void);
extern status_t FRM_SendRegisterSingleTimesCmd(void);
extern status_t FRM_SendVerifyCmd(void);
extern status_t FRM_SendDeleteUserCmd(void);
extern status_t FRM_SendDeleteAllCmd(void);
extern status_t FRM_SendGetAllUserIdCmd(void);
extern status_t FRM_SendResetCmd(void);
extern status_t FRM_SendGetStatusCmd(void);
extern status_t FRM_SendFaceResetCmd(void);
extern status_t FRM_SendPownDownCmd(void);
extern status_t FRM_SendGetVersionCmd(void);
extern void FaceRecognition_EnableDemoMode(void);
extern void FaceRecognition_DisableDemoMode(void);
extern void FaceRecognition_RegisterTemplateMultiTimesStart(FaceDirrect_t facedirrect);
extern void FaceRecognition_RegisterTemplateSingleTimesStart(void);
extern void FaceRecognition_VerifyStart(void);
extern void FaceRecognition_DeleteTemplateStart(uint16_t UserID);
extern void FaceRecognition_DeleteAllTemplateStart(void);
extern void FaceRecognition_UpdateUserIdList(void);
extern void FaceRecognition_FaceReset(void);
extern void FaceRecognition_Reset(void);
extern void FaceRecognition_PowerDown(void);
extern void FaceRecognition_GetVerionNumber(void);
extern void FaceRecognitionMgr_Init(void);
extern void FaceRecognition_HardwarePowerOn(void);
extern void FaceRecognition_HardwarePowerOff(void);
extern void FaceRecognitionMgr_Task(void);













#endif

