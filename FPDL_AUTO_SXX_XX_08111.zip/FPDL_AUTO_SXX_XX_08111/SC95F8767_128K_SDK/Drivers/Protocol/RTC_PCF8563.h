#ifndef PCF8563_h
#define PCF8563_h

extern void PCF8563_Init(void);
extern void PCF8563_ReadTime(void);

extern void PCF8563_WriteTime(void);

extern void PCF8563_Test(void);

#endif