#include "Key_SinOne.h"
#include "KeyScan.h"
#include "SensorMethod.h"
#include "Project.h"
#include "Basic_Function.h"
#include "usart.h"

#ifdef Function_DynamicSensitivity

	#ifdef ProjectIs_BarLock_S101Z01
		#define SOCAPI_SET_TOUCHKEY_TOTAL 14
		uint8_t SleepSensitivityVariation[SOCAPI_SET_TOUCHKEY_TOTAL] = 
		{0x20,0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x40,0x20};
	#endif
	
	#if defined ProjectIs_BarLock_S64Z24 || defined ProjectIs_BarLock_S64Z61
		#define SOCAPI_SET_TOUCHKEY_TOTAL 14
		uint8_t SleepSensitivityVariation[SOCAPI_SET_TOUCHKEY_TOTAL] = 
		{0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20};
	#endif
		
	#if defined ProjectIs_BarLock_S64Z31 || defined ProjectIs_BarLock_S64Z48
		#define SOCAPI_SET_TOUCHKEY_TOTAL 14
		uint8_t SleepSensitivityVariation[SOCAPI_SET_TOUCHKEY_TOTAL] = 
		{0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30};
	#endif

	#if (defined ProjectIs_BarLock_S15Z07) || (defined ProjectIs_BarLock_S15Z08) || (defined ProjectIs_BarLock_S15Z09) 
		#define SOCAPI_SET_TOUCHKEY_TOTAL 12
		#if (defined ProjectIs_BarLock_S15Z07)
		uint8_t SleepSensitivityVariation[SOCAPI_SET_TOUCHKEY_TOTAL] = 
		{0x50,0x50,0x50,0x50,0x50,0x50,0x50,0x50,0x50,0x50,0x50,0x50};
		
		#elif (defined ProjectIs_BarLock_S15Z09)
		uint8_t SleepSensitivityVariation[SOCAPI_SET_TOUCHKEY_TOTAL] = 
//		{0x70,0x70,0x70,0x70,0x70,0x70,0x70,0x70,0x70,0x70,0x70,0x70};
		{0x60,0x68,0x40,0x48,0x58,0x68,0x28,0x28,0x18,0x28,0x20,0x10};	//sp
//	   #    9    3    6    0    *    8    7    5    4    1    2
		#else
		uint8_t SleepSensitivityVariation[SOCAPI_SET_TOUCHKEY_TOTAL] = 
		{0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30};
		#endif
		
	#endif
	#if (defined ProjectIs_BarLock_S06Z10) 
		#define SOCAPI_SET_TOUCHKEY_TOTAL 13
		uint8_t SleepSensitivityVariation[SOCAPI_SET_TOUCHKEY_TOTAL] = 
		{0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10};
	#endif
extern unsigned char TKChannelCfg[SOCAPI_SET_TOUCHKEY_TOTAL][8];
#endif

uint8_t TouchKeyBuff[4]={0};
	
#if (defined ProjectIs_BarLock_S64Z24) || (defined ProjectIs_BarLock_S64Z31)\
|| (defined ProjectIs_BarLock_S64Z48) || (defined ProjectIs_BarLock_S64Z61)
//0 1 2 3 4 5 6 7 8 9 * # bell close
uint32_t ValidKeyValue[]={KeyValueTK14,KeyValueTK7,KeyValueTK8,KeyValueTK6,KeyValueTK10,KeyValueTK5,	\
KeyValueTK12,KeyValueTK4,KeyValueTK13,KeyValueTK3,KeyValueTK2,KeyValueTK15,KeyValueTK1,KeyValueTK18};

#elif (defined ProjectIs_BarLock_S15Z07)||(defined ProjectIs_BarLock_S15Z08)||(defined ProjectIs_BarLock_S15Z09)
//0 1 2 3 4 5   6 7 8 9 * #
uint32_t ValidKeyValue[]={KeyValueTK6,KeyValueTK14,KeyValueTK15,KeyValueTK4,KeyValueTK13,KeyValueTK12, \
KeyValueTK5,KeyValueTK10,KeyValueTK8,KeyValueTK3,KeyValueTK7,KeyValueTK2,NoTKChannel,NoTKChannel};

#elif defined ProjectIs_BarLock_S06Z09
//0 1 2 3 4 5 6 7 8 9 * #
uint32_t ValidKeyValue[]={KeyValueTK10,KeyValueTK12,KeyValueTK1,KeyValueTK3,KeyValueTK13,KeyValueTK2, \
KeyValueTK4,KeyValueTK14,KeyValueTK8,KeyValueTK5,KeyValueTK15,KeyValueTK6,NoTKChannel,NoTKChannel};

#elif defined ProjectIs_BarLock_S06Z10
//0 1 2 3 4 5 6 7 8 9 * # [] close
uint32_t ValidKeyValue[]={KeyValueTK13,KeyValueTK6,KeyValueTK7,KeyValueTK5,KeyValueTK8,KeyValueTK4, \
KeyValueTK10,KeyValueTK3,KeyValueTK12,KeyValueTK2,KeyValueTK1,KeyValueTK14,NoTKChannel,KeyValueTK18};

#elif defined ProjectIs_BarLock_S101Z01
//0 1 2 3 4 5 6 7 8 9 * # bell close
uint32_t ValidKeyValue[]={KeyValueTK10,KeyValueTK5,KeyValueTK6,KeyValueTK12,KeyValueTK4,KeyValueTK7,	\
KeyValueTK13,KeyValueTK3,KeyValueTK8,KeyValueTK14,KeyValueTK2,KeyValueTK15,KeyValueTK1,KeyValueTK18};

#elif defined ProjectIs_BarLock_S111Z01
//0 1 2 3 4 5 6 7 8 9 * # bell close
uint32_t ValidKeyValue[]={KeyValueTK12,KeyValueTK18,KeyValueTK2,KeyValueTK3,KeyValueTK14,KeyValueTK5,	\
KeyValueTK4,KeyValueTK13,KeyValueTK6,KeyValueTK7,KeyValueTK15,KeyValueTK8,NoTKChannel,KeyValueTK10};


#endif

uint32_t KeyScanDrive()
{
	uint32_t TK_Value = 0;
	uint8_t i;
	
	if( SOCAPI_TouchKeyStatus & 0x40 )	// bit6-����ɨ����ɱ�־  1:��� 	0��δ���
	{
		SOCAPI_TouchKeyStatus &= 0xBF;	//�����ɨ���־λ
		TouchKeyRestart();
	}
	else
	{
		if( SOCAPI_TouchKeyStatus & 0x80 )	//bit7-һ��ɨ����ɱ�־  1:��� 	0��δ���
		{
			TK_Value = TouchKeyScan();
			SOCAPI_TouchKeyStatus &= 0x7F;		//��һ��ɨ���־λ
			for(i=0; i<4; i++)
			{
				TouchKeyBuff[i] = TK_Value >> (24-(8*i));
			}
//			if(TK_Value!=0)
//			{
//				Uart1SendStr(TouchKeyBuff,4);
//			}
			TouchKeyRestart();
		}
	}
		return TK_Value;
}

void KeyPressedJudge(uint32_t InputKeyValue)
{
	uint32_t InputValidKeyValue;
	uint8_t i;
	uint8_t TK_Flag;
	
	InputValidKeyValue = InputKeyValue;
	
	for(i=0;i<14;i++)
	{
		TK_Flag = 0;
		if( (InputValidKeyValue & ValidKeyValue[i]) > 0 )
		{
			TK_Flag = 1;
		}
		switch(i)
		{
			case 0:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_ZERO_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_ZERO_Pressed = bFALSE;
				}
				break;
					
			case 1:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_ONE_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_ONE_Pressed = bFALSE;
				}
				break;
					
			case 2:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_TWO_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_TWO_Pressed = bFALSE;
				}
				break;
					
			case 3:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_THREE_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_THREE_Pressed = bFALSE;
				}
				break;
					
			case 4:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_FOUR_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_FOUR_Pressed = bFALSE;
				}
				break;
					
			case 5:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_FIVE_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_FIVE_Pressed = bFALSE;
				}
				break;
					
			case 6:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_SIX_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_SIX_Pressed = bFALSE;
				}
				break;
					
			case 7:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_SEVEN_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_SEVEN_Pressed = bFALSE;
				}
				break;
					
			case 8:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_EIGHT_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_EIGHT_Pressed = bFALSE;
				}
				break;
					
			case 9:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_NINE_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_NINE_Pressed = bFALSE;
				}
				break;
					
			case 10:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_ASTERISK_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_ASTERISK_Pressed = bFALSE;
				}
				break;
					
			case 11:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_POUNDSIGN_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_POUNDSIGN_Pressed = bFALSE;
				}
				break;

				case 12:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_DOORBELL_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_DOORBELL_Pressed = bFALSE;
				}
				break;
				
				case 13:
				if( TK_Flag )
				{
					TouchKeyStatus.KEY_DOORCLOSE_Pressed = bTRUE;
				}
				else
				{
					TouchKeyStatus.KEY_DOORCLOSE_Pressed = bFALSE;
				}
				break;
				
			default:
				break;
		}
	}
}

void Touch_Init(void)
{
	TouchKeyInit();
}

void SetTouchSleepSensitivity(void)
{
	#ifdef Function_DynamicSensitivity
	uint8_t i = 0;
	uint16_t TempTKChannelCfg;
	for(i=0;i<SOCAPI_SET_TOUCHKEY_TOTAL;i++)
	{
		TempTKChannelCfg = TKChannelCfg[i][6];
		TempTKChannelCfg <<= 8;
		TempTKChannelCfg += TKChannelCfg[i][7];
		TempTKChannelCfg += SleepSensitivityVariation[i];
		TKChannelCfg[i][6] = TempTKChannelCfg>>8;
		TKChannelCfg[i][7] = TempTKChannelCfg;
	}
	#endif
}
void SetTouchAwakeSensitivity(void)
{
	#ifdef Function_DynamicSensitivity 
	uint8_t i = 0;
	uint16_t TempTKChannelCfg;
	for(i=0;i<SOCAPI_SET_TOUCHKEY_TOTAL;i++)
	{
		TempTKChannelCfg = TKChannelCfg[i][6];
		TempTKChannelCfg <<= 8;
		TempTKChannelCfg += TKChannelCfg[i][7];
		TempTKChannelCfg -= SleepSensitivityVariation[i];
		TKChannelCfg[i][6] = TempTKChannelCfg>>8;
		TKChannelCfg[i][7] = TempTKChannelCfg;
	}
	#endif
}

void SET_TOUCH_AWAKE_SENSITIVITY(void)
{

}
