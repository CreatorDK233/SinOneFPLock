#ifndef EEPROM_h
#define EEPROM_h

#include "StdTypes.h"

#define IAP_EEPROM 0x02

#define ManagerPasscodeMemoryStartAddr		0x0000

#define CardUserMemoryStartAddr				0x0020		//100 card user, 6 bytes for one user  = 600 bytes
#define PasscodeUserMemoryStartAddr			(0x0020+(6*DEF_MAX_CARDUSER)) /* if DEF_MAX_PASSCODEUSER = 20, 8 bytes for one passcode user,  0x0278 ~  0x317 */

#define FaceUserMemoryStartAddr				(0x0318)//0x0400		/* 6 bytes per Face user,if DEF_MAX_FACEUSER = 100, 0x0320~0x056F*/

#define FPMserialNumberStartAddr			(0x0570)//(0x0660)	//32 bytes, from 0x0570~0x058F
#define FPuserIDListStartAddr				(0x0590)//(0x0680)	//33 bytes, from 0x0590~0x05B0

#define LockBrandStartAddr					(0x05B1)	//from 0x05B1 to 0x07B0 ,512 bytes

/*************  from 0x07B0 ~ 0x07F1 is Spare  *****************/

#define	AutoMotorMgrUnlockTimeAddr      (0x07F2)	// 1 byte
#define	AutoMotorMgrAutoLockTimeAddr    (0x07F3)	// 1 byte
#define	AutoMotorMgrLockDirectionAddr   (0x07F4)	// 1 byte
#define	AutoMotorMgrTorqueAddr          (0x07F5)	// 1 byte
#define AutoMotorMgrBoltLockTimeAddr    (0x07F6)	// 1 byte
#define AutoMotorMgrLockingTravelAddr   (0x07F7)	// 1 byte
#define AutoMotorMgrAutoEjectAddr      	(0x07F8)	// 1 byte
#define FrmFunctionConfigAddr      			(0x07F9)	// 1 byte
#define BodyInductionStartAddr					(0x07FA)	// 1 byte
#define SystemLanguageStartAddr					(0x07FB)	// 1 byte
#define PickAlarmSwitchStartAddr				(0x07FC)	// 1 byte
#define UnlockModeStartAddr							(0x07FD)	// 1 byte	
#define VolumeValueStartAddr						(0x07FE)	// 1 byte		
#define SelfTestMemoryStartAddr					(0x07FF)	//last byte

extern void EEPROM_ReadSequential(uint16_t StartAddr,uint8_t *BUFF,uint16_t Num);

extern void EEPROM_WriteSequential(uint16_t StartAddr,uint8_t *BUFF,uint16_t Num);

extern void EEPROM_PageWrite(uint16_t StartAddr,uint8_t *BUFF,uint16_t Num);

extern void EEPROM_TESTING(void);



#endif
