#ifndef MFC_h
#define MFC_h

#include "StdTypes.h"

extern void MFC_Init(void);
extern status_t MFC_Auto_Reader(uint8_t *Point);
extern status_t Find_Card(void);
extern status_t MFC_ReadLockBrandData(uint8_t *buff);
extern void MFC_POWERDOWN(void);
extern void MFC_Test(void);
extern void PcdAntennaOff(void);
extern void SetBitMask(uint8_t reg,uint8_t mask); 
extern void WriteRawRC(uint8_t Address,uint8_t value);

extern sint8_t PcdAnticoll(uint8_t *pSnr);
extern sint8_t PcdSelect(uint8_t *pSnr);
extern sint8_t Read_Block(uint8_t Block,uint8_t *Buf);

extern status_t MFC_FrmFunctionConfigSwitch(void);


#endif
