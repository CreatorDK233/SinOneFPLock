#ifndef PIR_H
#define PIR_H
#include "StdTypes.h"

extern BodyInductionMgr_t BodyInductionMgr;
extern PIRmgr_t PIRmgr;

extern void PIR_IOs_Init(void);
extern void PIR_IOs_DeInit(void);
extern void PIR_Init(void);
extern void PIR_SensitivityDecrease(void);
extern void PIR_Task(void);





#endif
