#ifndef _KeyScanDrive_h
#define _KeyScanDrive_h

#define uint32_t unsigned long int
	
#define NoTKChannel		0x00000000	//���ڳ�ʼ������
//�����ṩTKͨ����Чʱ�ļ�ֵ
#define KeyValueTK0 	0x00000001
#define KeyValueTK1 	0x00000002
#define KeyValueTK2 	0x00000004
#define KeyValueTK3 	0x00000008
#define KeyValueTK4 	0x00000010
#define KeyValueTK5 	0x00000020
#define KeyValueTK6 	0x00000040
#define KeyValueTK7 	0x00000080
#define KeyValueTK8 	0x00000100
#define KeyValueTK9		0x00000200
#define KeyValueTK10	0x00000400
#define KeyValueTK11	0x00000800
#define KeyValueTK12	0x00001000
#define KeyValueTK13	0x00002000
#define KeyValueTK14	0x00004000
#define KeyValueTK15	0x00008000
#define KeyValueTK16	0x00010000
#define KeyValueTK17	0x00020000
#define KeyValueTK18	0x00040000

extern uint32_t KeyScanDrive(void);
extern void KeyPressedJudge(uint32_t InputKeyValue);
extern void Touch_Init(void);
extern void SetTouchSleepSensitivity(void);
extern void SetTouchAwakeSensitivity(void);
extern void SET_TOUCH_AWAKE_SENSITIVITY(void);

#endif
