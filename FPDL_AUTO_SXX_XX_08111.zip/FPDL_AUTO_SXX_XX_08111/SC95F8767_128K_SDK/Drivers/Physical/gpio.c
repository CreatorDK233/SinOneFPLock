#include "gpio.h"
#include "Project.h"
#include "global_variable.h"
#include "SC95F876x_C.H"
#include "IO.H"

uint8_t AwakeFlag = NoAwake;
extern bit HostIntEnable;
LastIOStatus_t LastIOStatus;

void GPIO_Config(GPIO_Port_type Port,Pin_type Pin,GPIO_Mode_type Mode)
{
	if((Port>=0&&Port<=5&&Pin>=0&&Pin<8)!=1)return;
	switch (Port)
	{
	case 0:
		switch (Mode)
        {
        case GPIO_Mode_OUT_PP:
	        P0CON |=(1<<Pin);
	        P0PH  &=~(1<<Pin);
	        break;
        case GPIO_Mode_INPUT_PU:
            P0CON &=~(1<<Pin);
	        P0PH  |= (1<<Pin);
	        break;
        case GPIO_Mode_INPUT_HZ:
          P0CON &=~(1<<Pin);
	        P0PH  &=~(1<<Pin);
	        break;
        default:
	        break;
        }
		break;
	case 1:
		switch (Mode)
        {
        case GPIO_Mode_OUT_PP:
	        P1CON |=(1<<Pin);
	        P1PH  &=~(1<<Pin);
	        break;
        case GPIO_Mode_INPUT_PU:
          P1CON &=~(1<<Pin);
	        P1PH  |= (1<<Pin);
	        break;
        case GPIO_Mode_INPUT_HZ:
            P1CON &=~(1<<Pin);
	        P1PH  &=~(1<<Pin);
	        break;
        default:
	        break;
        }
		break;
	case 2:
		switch (Mode)
        {
        case GPIO_Mode_OUT_PP:
	        P2CON |=(1<<Pin);
	        P2PH  &=~(1<<Pin);
	        break;
        case GPIO_Mode_INPUT_PU:
            P2CON &=~(1<<Pin);
	        P2PH  |= (1<<Pin);
	        break;
        case GPIO_Mode_INPUT_HZ:
            P2CON &=~(1<<Pin);
	        P2PH  &=~(1<<Pin);
	        break;
        default:
	        break;
        }
		break;
	
	case 3:
		switch (Mode)
        {
        case GPIO_Mode_OUT_PP:
	        P3CON |=(1<<Pin);
	        P3PH  &=~(1<<Pin);
	        break;
        case GPIO_Mode_INPUT_PU:
            P3CON &=~(1<<Pin);
	        P3PH  |= (1<<Pin);
	        break;
        case GPIO_Mode_INPUT_HZ:
            P3CON &=~(1<<Pin);
	        P3PH  &=~(1<<Pin);
	        break;
        default:
	        break;
        }
		break;
	
	case 4:
		switch (Mode)
        {
        case GPIO_Mode_OUT_PP:
	        P4CON |=(1<<Pin);
	        P4PH  &=~(1<<Pin);
	        break;
        case GPIO_Mode_INPUT_PU:
            P4CON &=~(1<<Pin);
	        P4PH  |= (1<<Pin);
	        break;
        case GPIO_Mode_INPUT_HZ:
            P4CON &=~(1<<Pin);
	        P4PH  &=~(1<<Pin);
	        break;
        default:
	        break;
        }
		break;
	
	case 5:
		switch (Mode)
        {
        case GPIO_Mode_OUT_PP:
	        P5CON |=(1<<Pin);
	        P5PH  &=~(1<<Pin);
	        break;
        case GPIO_Mode_INPUT_PU:
          P5CON &=~(1<<Pin);
	        P5PH  |= (1<<Pin);
	        break;
        case GPIO_Mode_INPUT_HZ:
          P5CON &=~(1<<Pin);
	        P5PH  &=~(1<<Pin);
	        break;
        default:
	        break;
        }
		break;

	default:
		break;
	}
}

void MX_GPIO_Init(void)
{
	P0CON = 0x8F;  //����P0Ϊǿ����ģʽ
	P0PH  = 0x00;
	P1CON = 0xF5;  //����P1Ϊǿ����ģʽ
	P1PH  = 0x00;
	P2CON = 0xF7;  //����P2Ϊǿ����ģʽ
	P2PH  = 0x00;
	P3CON = 0x7F;  //����P3Ϊǿ����ģʽ
	P3PH  = 0x00;
	P4CON = 0xF1;  //����P4Ϊǿ����ģʽ
	P4PH  = 0x00;
	#ifdef Function_USE_Internal_RTC
	P5CON = 0x3B;  //����P5Ϊǿ����ģʽ
	#else
	P5CON = 0x3F;  //����P5Ϊǿ����ģʽ
	#endif
	P5PH  = 0x00;
	//AD���
	GPIO_Config(PORT3,PIN7,GPIO_Mode_INPUT_HZ);
	//Anti-Prying INT
	GPIO_Config(PORT4,PIN1,GPIO_Mode_INPUT_PU);
	//IR_INT
	GPIO_Config(PORT4,PIN2,GPIO_Mode_OUT_PP);
	IO_IR_INT = 0;
	//FPM TOUCH INT
	GPIO_Config(PORT4,PIN3,GPIO_Mode_INPUT_HZ);
	
	//P41(INT11)�½����ж�
	#if (defined ProjectIs_BarLock_S15Z08)//�������
	INT1R |= 0x02;
	#else
	INT1F |= 0x02;
	#endif	
	//�������ж�
	//INT1R |= 0x00;
	IE  |= 0x04;	//�ⲿ�ж�1�ж�ʹ��
	IP  |= 0X00;	//�����ж����ȼ�
	IP1 |= 0X00;
	EA = 1;
	DisableNFCIRQ_Interrupt();
}

void MX_GPIO_DeInit(void)
{
	P0CON = 0xff;  //����P0Ϊǿ����ģʽ
	P0PH  = 0x00;
	P1CON = 0xff;  //����P1Ϊǿ����ģʽ//f5
	P1PH  = 0x02;
	P2CON = 0xc7;  //����P2Ϊǿ����ģʽ
	P2PH  = 0x08;
	P3CON = 0xff;  //����P3Ϊǿ����ģʽ//3f
	P3PH  = 0x00;
	P4CON = 0xf0;  //����P4Ϊǿ����ģʽ
	P4PH  = 0x00;
	P5CON = 0xfb;  //����P5Ϊǿ����ģʽ
	P5PH  = 0x00;
	P0=0x00;
	P1=0x00;
	P2=0x00;
	P3=0x00;
	P4=0x00;
	P5=0x00;
	GPIO_Config(PORT1,PIN1,GPIO_Mode_INPUT_HZ);
	GPIO_Config(PORT1,PIN3,GPIO_Mode_OUT_PP);
	P13 = 1;
}

void Enable_EX_Interrupt(void)
{
	//HOST AWAKE INT
	GPIO_Config(PORT4,PIN0,GPIO_Mode_INPUT_HZ);
	//PRYING INT
	GPIO_Config(PORT4,PIN1,GPIO_Mode_INPUT_HZ);
	//IR INT
	GPIO_Config(PORT4,PIN2,GPIO_Mode_OUT_PP);
	IO_IR_INT = 0;
	//TOUCH INT
	GPIO_Config(PORT4,PIN3,GPIO_Mode_INPUT_HZ);
	//MFC INT
	GPIO_Config(PORT2,PIN3,GPIO_Mode_INPUT_PU);
	//P40(INT10)P41(INT11)�½����ж�
	#if (defined ProjectIs_BarLock_S15Z08)
	INT1R |= 0x02;
	INT1F |= 0x01;
	#else
	INT1F |= 0x03;
	#endif	
	//P23(INT23)�½����ж�
	//INT2F |= 	0x08;
	IE  |= 0x04;	//�ⲿ�ж�1�ж�ʹ��
	IE1 |= 0x08;	//�ⲿ�ж�2�ж�ʹ��
	IP  |= 0X00;	//�����ж����ȼ�
	IP1 |= 0X00;
	EA = 1;
}

void EnableAntiPrying_Interrupt(void)
{
	GPIO_Config(PORT4,PIN1,GPIO_Mode_INPUT_HZ);
	INT1F |= 0x02;
}

void DisableAntiPrying_Interrupt(void)
{
	GPIO_Config(PORT4,PIN1,GPIO_Mode_INPUT_HZ);
	INT1F &= (~0x02);
}

void EnableTouch_Interrupt(void)
{
//	GPIO_Config(PORT4,PIN3,GPIO_Mode_INPUT_HZ);
//	INT1R |= 0x08;
}

void DisableTouch_Interrupt(void)
{
//	GPIO_Config(PORT4,PIN3,GPIO_Mode_INPUT_HZ);
//	INT1R &= (~0x08);
}

void EnablePIR_Interrupt(void)
{
	GPIO_Config(PORT4,PIN2,GPIO_Mode_INPUT_PU);
	INT1F |= 0x04;
}	

void DisablePIR_Interrupt(void)
{
	GPIO_Config(PORT4,PIN2,GPIO_Mode_OUT_PP);
	INT1F &= (~0x04);
	IO_IR_INT = 0;
}

void EnableRADAR_Interrupt(void)
{
	GPIO_Config(PORT4,PIN2,GPIO_Mode_INPUT_HZ);
//	INT1R |= 0x04;
	//GPIO_Config(PORT4,PIN2,GPIO_Mode_INPUT_PU);
	INT1F |= 0x04;
}	

void DisableRADAR_Interrupt(void)
{
//	GPIO_Config(PORT4,PIN2,GPIO_Mode_INPUT_HZ);
//	INT1R &= (~0x04);
	GPIO_Config(PORT4,PIN2,GPIO_Mode_OUT_PP);
	INT1F &= (~0x04);
	IO_IR_INT = 0;
}

void EnableNFCIRQ_Interrupt(void)
{
	GPIO_Config(PORT2,PIN3,GPIO_Mode_INPUT_PU);
	//P23(INT23)�½����ж�
	INT2F |= 0x08;
	INT2R |= 0x08;
}	

void DisableNFCIRQ_Interrupt(void)
{
	GPIO_Config(PORT2,PIN3,GPIO_Mode_INPUT_PU);
	//P23(INT23)�ر��½����ж�
	INT2F &= (~0x08);
	INT2R &= (~0x08);
}

void INT1Interrupt() interrupt	2
{
	if( ( PINMACRO_HOST_AWAKE_INT_STATUS == 0 ) && \
		( PINMACRO_HOST_AWAKE_INT_STATUS != LastIOStatus.HostAwakeInt ) )
	{
		if ( HostIntEnable == 1 )
		{
			AwakeFlag = HostAwake; //INT10�����ж�
		}
	}
	if (
		#if (defined ProjectIs_BarLock_S15Z08)
		( PINMACRO_PICKLOCK_STATUS == 1 )
		#else
		( PINMACRO_PICKLOCK_STATUS == 0 )
		#endif	
		&&( PINMACRO_PICKLOCK_STATUS != LastIOStatus.AntiPryingInt ) )
	{
		//AwakeFlag = AntiPryingAwake; //INT11�����ж�
		if( PickAlarmEnableMgr.Enable == bTRUE )
		{
			AntiPryingMgr.AntiPryingTrigger = bTRUE;
		}
	}
	#ifdef Function_BodyInductionByIR
	if( PINMACRO_IR_INT_STATUS == 0 )
		PIRmgr.RecPulse++;
	#endif
}

void INT2Interrupt() interrupt	10
{
  //if ( PINMACRO_NFC_IRQ_STATUS == 0 )
	{
		AwakeFlag = MFCAwake;
	}
}


