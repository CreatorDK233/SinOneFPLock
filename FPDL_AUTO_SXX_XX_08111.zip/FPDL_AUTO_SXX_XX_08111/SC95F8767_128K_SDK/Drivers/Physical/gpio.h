#ifndef __gpio_H
#define __gpio_H
#ifdef __cplusplus
 extern "C" {
#endif
	 
#include "StdTypes.h"
	 
#define GPIO_Port_type uint8_t
#define Pin_type uint8_t
#define GPIO_Mode_type uint8_t
#define GPIO_Mode_OUT_PP 0   //�������,����10mA
#define GPIO_Mode_INPUT_PU 1 //��������
#define GPIO_Mode_INPUT_HZ 2 //����������
#define PORT0 0 
#define PORT1 1 
#define PORT2 2 
#define PORT3 3 
#define PORT4 4 
#define PORT5 5
#define PIN0 0 
#define PIN1 1 
#define PIN2 2 
#define PIN3 3 
#define PIN4 4 
#define PIN5 5 
#define PIN6 6 
#define PIN7 7 

#define NoAwake 0x00
#define HostAwake 0x10 
#define AntiPryingAwake 0x20 
#define MFCAwake 0x30
#define PINMACRO_NFC_IRQ PORT2,PIN3

typedef struct
{
	uint8_t HostAwakeInt:1;
	uint8_t AntiPryingInt:1;
	uint8_t RadarInt:1;
}LastIOStatus_t;

extern LastIOStatus_t LastIOStatus;
extern uint8_t AwakeFlag;

extern void GPIO_Config(GPIO_Port_type Port,Pin_type Pin,GPIO_Mode_type Mode);
extern void MX_GPIO_Init(void);
extern void MX_GPIO_DeInit(void);
extern void Enable_EX_Interrupt(void);
extern void EnableAntiPrying_Interrupt(void);
extern void DisableAntiPrying_Interrupt(void);

extern void EnableTouch_Interrupt(void);
extern void DisableTouch_Interrupt(void);
extern void EnablePIR_Interrupt(void);
extern void DisablePIR_Interrupt(void);
extern void EnableRADAR_Interrupt(void);
extern void DisableRADAR_Interrupt(void);
extern void EnableNFCIRQ_Interrupt(void);
extern void DisableNFCIRQ_Interrupt(void);

#ifdef __cplusplus
}
#endif
#endif /*__ pinoutConfig_H */

