#ifndef _PWM_H_
#define _PWM_H_

extern void MX_PWM_Init(unsigned int PWM);
extern void SET_IR_PwmStop(void);
extern void SET_IR_PwmStar(void);
#endif