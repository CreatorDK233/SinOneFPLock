#ifndef __usart_H
#define __usart_H
#ifdef __cplusplus
 extern "C" {
#endif

#include "StdTypes.h"
	 
#define UART0_MAX_LEN 128
	 
extern void Uart1_Init(uint Freq,unsigned long int baud);
extern void UARTX_Init(uint Freq, unsigned long int baud);
extern uint8_t SSIxx_Select;
extern uint8_t SSIxx_Mode;

extern void MX_USART1_UART_Init(void); 
extern void MX_USART1_DeInit(void);	 
extern void MX_USART2_UART_Init(void);
extern void MX_UART2_DeInit(void);

extern void Uart0SendByte(uint8_t dat);
extern status_t Uart0SendStr(uint8_t *pstr,uint16_t strlen);
extern void Uart0ReadByte(uint8_t *dat);
extern void Uart1SendByte(uint8_t dat);
extern void Uart1SendStr(uint8_t *pstr,uint16_t strlen);	 
extern void Uart1ReadByte(uint8_t *dat);
extern void Uart2SendByte(uint8_t dat);
extern void Uart2SendStr(uint8_t *pstr,uint16_t strlen);
extern void Uart2ReadByte(uint8_t *dat);

extern void Uart0_Init(uint Freq,unsigned long int baud);
extern void Uart0_DeInit();
extern void Uart_Test1(void);

#ifdef __cplusplus
}
#endif
#endif /*__ usart_H */

