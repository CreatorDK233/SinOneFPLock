#ifndef IO_H
#define IO_H

/* ************************ FILE HEADER *************************************/
/* ***************************************************************************
*  INCLUDE FILES
*/
#include "gpio.h"
#include "Project.h"
/* MASS MICROELECTRONICS TARGET BOARD I/O SETTINGS */
/***************8767 ��Ԫȫ�Զ�IO����*******************/
//#ifdef Function_USE_Internal_RTC
//#define IO_Changed
//#endif

#define IO_EX_DEVICE_EN     P55

//#ifdef IO_Changed
#define IO_IR_PWM           P53
#define IO_IR_POWER_EN      P27
#define IO_LOG_LED_R        P47
#define IO_LOG_LED_G        P46
#define IO_LOG_LED_B        
#define IO_FACE_EN        	P54
#define IO_LED_POWER_EN
//#else
//#define IO_IR_PWM           P50
//#define IO_IR_POWER_EN      P51
//#define IO_LOG_LED_R        P54
//#define IO_LOG_LED_G        P46
//#define IO_LOG_LED_B        P47
//#define IO_FACE_EN        	P53
//#define IO_LED_POWER_EN 		P26
//#endif

#define IO_HOST_AWEAK_INT   P40
#define IO_ANTI_PRYING_INT  P41
#define IO_IR_INT           P42
#define IO_FPM_TOUCH_INT    P43

#define IO_MF_NRST          P00
#define IO_MF_IRQ           P23   	

#define IO_OLED_CS          P01
#define IO_OLED_RES         P02
#define IO_OLED_DC          P03

#ifndef Function_MainBoardWithoutVoicePlayer
#define IO_VOICE_DATA       P26
#define IO_VOICE_BUSY       P52
#endif

/*****************************************************/

#define SET_LCD_DS_H 		IO_OLED_DC = 1 
#define SET_LCD_DS_L 		IO_OLED_DC = 0 

#define SET_LCD_CS_H 		IO_OLED_CS = 1 
#define SET_LCD_CS_L 		IO_OLED_CS = 0 

#define SET_LCD_RST_H 	IO_OLED_RES = 1 
#define SET_LCD_RST_L 	IO_OLED_RES = 0 


#define SET_MFC_RST_H			IO_MF_NRST = 1 
#define SET_MFC_RST_L			IO_MF_NRST = 0 

#define SET_MFC_CS_L	
#define SET_MFC_CS_H	

#define PINMACRO_NFC_IRQ_STATUS 		IO_MF_IRQ
#define PINMACRO_FPM_TOUCH_STATUS 	IO_FPM_TOUCH_INT

#define SET_FLASH_CS_H	
#define SET_FLASH_CS_L	

#define SET_OLEDPOWER_ON
#define SET_OLEDPOWER_OFF		

#define SET_HOST_AWAKE_INT_H			IO_HOST_AWEAK_INT = 1
#define SET_HOST_AWAKE_INT_L			IO_HOST_AWEAK_INT = 0	
#define PINMACRO_HOST_AWAKE_INT_STATUS  IO_HOST_AWEAK_INT

#define PINMACRO_IR_INT_STATUS  IO_IR_INT
#define PINMACRO_RADAR_INT_STATUS  IO_IR_INT

#define PINMACRO_ONBOARD_BUTTON_STATUS  1//��� ����
#define PINMACRO_CASINGOPEN_STATUS		


#ifndef Function_MainBoardWithoutVoicePlayer
#define SET_VOICEDATA_H			IO_VOICE_DATA = 1
#define SET_VOICEDATA_L 		IO_VOICE_DATA = 0
#define STATUS_PINMACRO_VOICEDATA				IO_VOICE_DATA
#define STATUS_PINMACRO_VOICEBUSY				IO_VOICE_BUSY
#endif

#define SET_MOTOR_INA_H				 
#define SET_MOTOR_INA_L				 
#define SET_MOTOR_INB_H				 
#define SET_MOTOR_INB_L				

#define SET_LOGLED_ON					
#define SET_LOGLED_OFF				
#define SET_LEDKEYs_ON				
#define SET_LEDKEYs_OFF				//IO_LOG_LED_R = 1;IO_LOG_LED_G = 1;IO_LOG_LED_B = 1;
#define SET_LEDRGB_R_ON				IO_LOG_LED_R = 0 
#define SET_LEDRGB_R_OFF			IO_LOG_LED_R = 1 
#define SET_LEDRGB_G_ON				IO_LOG_LED_G = 0 
#define SET_LEDRGB_G_OFF			IO_LOG_LED_G = 1 

//#ifdef IO_Changed
#define SET_LEDRGB_B_ON
#define SET_LEDRGB_B_OFF
#define SET_LEDPOWER_ON				
#define SET_LEDPOWER_OFF
//#else
//#define SET_LEDRGB_B_ON				IO_LOG_LED_B = 0 
//#define SET_LEDRGB_B_OFF			IO_LOG_LED_B = 1
//#define SET_LEDPOWER_ON				IO_LED_POWER_EN = 1
//#define SET_LEDPOWER_OFF			IO_LED_POWER_EN = 0
//#endif

#define SET_LED_RB_R_ON				IO_LOG_LED_R = 0
#define SET_LED_RB_R_OFF			IO_LOG_LED_R = 1
#define	SET_LED_RB_B_ON				IO_LOG_LED_G = 0
#define	SET_LED_RB_B_OFF			IO_LOG_LED_G = 1

#define SET_FPMPOWER_ON				 
#define SET_FPMPOWER_OFF			

#define SET_SPEEKERPOWER_ON			
#define SET_SPEEKERPOWER_OFF		

#define SET_FACEPOWER_ON			IO_FACE_EN = 1
#define SET_FACEPOWER_OFF			IO_FACE_EN = 0

#define SET_PIRPOWER_ON				IO_IR_POWER_EN = 1
#define SET_PIRPOWER_OFF			IO_IR_POWER_EN = 0

#define SYSPOWER_ON				IO_EX_DEVICE_EN = 1 
#define SYSPOWER_OFF			IO_EX_DEVICE_EN = 0 

#define PINMACRO_PICKLOCK_STATUS 		IO_ANTI_PRYING_INT
#define PINMACRO_TurnOnVbatToADC

#define SET_DOORBELLAWAKE_L		
#define SET_DOORBELLAWAKE_H		
#define SET_WIFIPOWER_ON			
#define SET_WIFIPOWER_OFF		


#endif /* #ifndef IO_H */
/* ****************************** END OF FILE ****************************** */
