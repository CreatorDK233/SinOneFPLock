/* ͷ�ļ����� INCLUDES */
#include "Project.h"
#include "IO.h"
#include "global_variable.h"
#include "BeepMgr.h"
#include "usart.h"
#include "HostUart.h"
#include <string.h>
//#include "YouzhiyunjiaWifi.h"

#define DEF_FRMFlowChartTimeOutDelay		64

uint16_t TimeCunt1024Hz;
uint8_t UART0_RXBUFFER[2];
uint8_t UART1_RXBUFFER[2];
uint8_t UART2_RXBUFFER[2];
uint8_t UART3_RXBUFFER[2];

void SysTick_ISR(void)
{
		G_tflagbits.T1024Hz =1;
		TimeCunt1024Hz++;

		//SET_DEBUG_TX_TOGGLE;
	
		if ( TimeCunt1024Hz%4==0 )
		{
			G_tflagbits.T256Hz =1;
			
			if ( TimeCunt1024Hz%8 ==0 )
			{
				G_tflagbits.T128Hz =1;
				if ( TimeCunt1024Hz%16 ==0 )
				{
					G_tflagbits.T64Hz =1;
					if ( TimeCunt1024Hz%64 ==0 )
					{
						G_tflagbits.T16Hz =1;
						if ( TimeCunt1024Hz%128==0 )
						{
							G_tflagbits.T8Hz =1;
							if ( TimeCunt1024Hz%512==0 )
							{
								G_tflagbits.T2Hz =1;	
								if ( TimeCunt1024Hz==1024 )
								{	
									TimeCunt1024Hz = 0;
									G_tflagbits.T1Hz =1;
								}
							}
						}
					}	
				}
			}
		}
		DEBUG_MARK;
		return;
  /* USER CODE END SysTick_IRQn 1 */
}


//void TIM1_ISR(void)
//{
//	DEBUG_MARK;
//	UART2_TX_Task();
//}

void TIM3_ISR(void)	//300us interval
{
		DEBUG_MARK;
	BeepMgrTask();
}

void UART2_ISR(void)
{
	Uart2ReadByte(UART2_RXBUFFER);
	//UART2_RXBUFFER[0]= USXCON3;
	if (	UART2_Mgr.Status == GotNewCmd )
	{
		//do nothing
	}
	else if ( (UART2_Mgr.Status == Idle )&&(UART2_RXBUFFER[0]==0xEF) )
	{
		UART2_Mgr.RX_Buffer[UART2_Mgr.RX_DataPoint] = UART2_RXBUFFER[0];
		UART2_Mgr.RX_DataPoint++;
		UART2_Mgr.Status = ReceivingData;
	}
	else if (UART2_Mgr.Status == ReceivingData)
	{
		UART2_Mgr.RX_Buffer[UART2_Mgr.RX_DataPoint] = UART2_RXBUFFER[0];
		UART2_Mgr.RX_DataPoint++;
		if ((UART2_Mgr.RX_Buffer[0]==0xEF)&&( UART2_Mgr.RX_DataPoint == (UART2_Mgr.RX_Buffer[8]+9))&&( UART2_Mgr.RX_DataPoint >9 ))
		{
			UART2_Mgr.Status = GotNewCmd;
		}
		else if ( UART2_Mgr.RX_DataPoint > 50)
		{
			UART2_Mgr.RX_DataPoint = 0x00;
			UART2_Mgr.Status = Idle;
		}
	}
			
	return;
}


void UART1_ISR(void)
{
	Uart1ReadByte(UART1_RXBUFFER);
	if (	UART1_Mgr.Status == GotNewCmd )
	{
		DEBUG_MARK;	//do nothing
	}
	else if ( (UART1_Mgr.Status == Idle )&&(UART1_RXBUFFER[0]==0xCA) )
	{
		UART1_Mgr.RX_Buffer[UART1_Mgr.RX_DataPoint] = UART1_RXBUFFER[0];
		UART1_Mgr.RX_DataPoint++;
		UART1_Mgr.DataStreamTimeCnt = DEF_WifiFlowChartTimeOutDelay;
		UART1_Mgr.Status = ReceivingData;
	}
	else if (UART1_Mgr.Status == ReceivingData)
	{
		UART1_Mgr.RX_Buffer[UART1_Mgr.RX_DataPoint] = UART1_RXBUFFER[0];
		UART1_Mgr.RX_DataPoint++;
		if ( UART1_Mgr.RX_DataPoint >= 12  )
		{
			UART1_Mgr.Status = GotNewCmd;
			
			if ( ComportMgr.Flag_RxBuff1IsFull == bFALSE )
			{
				memcpy(ComportMgr.RxBuff1, UART1_Mgr.RX_Buffer,12);
				ComportMgr.Flag_RxBuff1IsFull=bTRUE;
				UART1_Mgr.RX_DataPoint = 0x00;
				UART1_Mgr.Status = Idle;
			}
			else if ( ComportMgr.Flag_RxBuff2IsFull == bFALSE )
			{
				memcpy(ComportMgr.RxBuff2, UART1_Mgr.RX_Buffer,12);
				ComportMgr.Flag_RxBuff2IsFull=bTRUE;
				UART1_Mgr.RX_DataPoint = 0x00;
				UART1_Mgr.Status = Idle;
			}
		}
		else if ( UART1_Mgr.RX_DataPoint > 13)
		{
			UART1_Mgr.RX_DataPoint = 0x00;
			UART1_Mgr.Status = Idle;
		}
	}
	else{

	}
	
	return;
}
 
#ifdef Function_FaceRecoginition
void UART0_ISR(void)
{	
    uint8_t i;
	Uart0ReadByte(UART0_RXBUFFER);
	
	if (UART0_Mgr.Status == GotNewCmd )
	{
		DEBUG_MARK;	//do nothing
	}
	else if ( (UART0_Mgr.Status == Idle )&&(UART0_RXBUFFER[0]==0xEF) )
	{
		UART0_Mgr.RX_DataPoint=0x00;
		UART0_Mgr.RX_Buffer[UART0_Mgr.RX_DataPoint] = UART0_RXBUFFER[0];
		UART0_Mgr.RX_DataPoint++;
		UART0_Mgr.DataStreamTimeCnt = DEF_FRMFlowChartTimeOutDelay;
		UART0_Mgr.Status = ReceivingData;
	}
	
	else if (UART0_Mgr.Status == ReceivingData)
	{
		UART0_Mgr.RX_Buffer[UART0_Mgr.RX_DataPoint] = UART0_RXBUFFER[0];

		if ((UART0_Mgr.RX_DataPoint == 0x01)&&(UART0_Mgr.RX_Buffer[UART0_Mgr.RX_DataPoint]!=0xAA))
		{
			UART0_Mgr.RX_DataPoint = 0x00;
			UART0_Mgr.Status = Idle;
		}
		else if (( UART0_Mgr.RX_DataPoint>4 )&&( UART0_Mgr.RX_DataPoint >= (UART0_Mgr.RX_Buffer[3]*256+UART0_Mgr.RX_Buffer[4]+5)))
		{
			UART0_Mgr.Status = GotNewCmd;
      if(UART0_EXD.Buffer1IsFull_flag == bFALSE)
			{
				UART0_EXD.CmdLenth1 = UART0_Mgr.RX_Buffer[3]*256+UART0_Mgr.RX_Buffer[4]+6;
				for(i=0;i<UART0_EXD.CmdLenth1;i++)
				{
					UART0_EXD.Buffer1[i] = UART0_Mgr.RX_Buffer[i];
				}
				UART0_EXD.Buffer1IsFull_flag = bTRUE;
				UART0_Mgr.Status = Idle;
			}
			else if(UART0_EXD.Buffer2IsFull_flag == bFALSE)
			{
				UART0_EXD.CmdLenth2 = UART0_Mgr.RX_Buffer[3]*256+UART0_Mgr.RX_Buffer[4]+6;
				for(i=0;i<UART0_EXD.CmdLenth2;i++)
				{
					UART0_EXD.Buffer2[i] = UART0_Mgr.RX_Buffer[i];
				}
				UART0_EXD.Buffer2IsFull_flag = bTRUE;
				UART0_Mgr.Status = Idle;
			}
		}
		else if ( UART0_Mgr.RX_DataPoint > 95)
		{
			UART0_Mgr.RX_DataPoint = 0x00;
			UART0_Mgr.Status = Idle;
		}
		
		UART0_Mgr.RX_DataPoint++;
	}
	else{

	}
	
	return;
}
#endif


#ifdef Function_YouzhiyunjiaWifi

void UART3_ISR(void)
{
	Uart3ReadByte(UART3_RXBUFFER);
	if (UART3_Mgr.Status == GotNewCmd )
	{
		DEBUG_MARK;	//do nothing
	}
	else if ( (UART3_Mgr.Status == Idle )&&(UART3_RXBUFFER[0]==0xAA) )
	{
		UART3_Mgr.RX_DataPoint=0x00;
		UART3_Mgr.RX_Buffer[UART3_Mgr.RX_DataPoint] = UART3_RXBUFFER[0];
		UART3_Mgr.RX_DataPoint++;
		UART3_Mgr.DataStreamTimeCnt = DEF_WifiFlowChartTimeOutDelay;
		UART3_Mgr.Status = ReceivingData;
	}
	
	else if (UART3_Mgr.Status == ReceivingData)
	{
		UART3_Mgr.RX_Buffer[UART3_Mgr.RX_DataPoint] = UART3_RXBUFFER[0];
		UART3_Mgr.RX_DataPoint++;

		if ( UART3_Mgr.RX_DataPoint >= WifiMgr.Ack.AckLenth )
		{
			UART3_Mgr.Status = GotNewCmd;
		}
		else if ( UART3_Mgr.RX_DataPoint > 99)
		{
			UART3_Mgr.RX_DataPoint = 0x00;
			UART3_Mgr.Status = Idle;
		}
	}
	else{

	}
	
	return;
	
}
#endif




