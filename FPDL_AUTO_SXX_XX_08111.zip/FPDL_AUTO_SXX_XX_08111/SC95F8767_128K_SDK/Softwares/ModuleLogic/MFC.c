#include "MFC.h"
#include "GUI_Function.h"
#include "LCD.h"
#include "Font_Menu.h"
#include "Log.h"
#include "global_variable.h"
#include "Basic_Function.h"

#include "EEPROM.h"
#include "BeepMgr.h"
#include "MFC_MF17622.h"

#define Def_UserSwingCardTimeDelay	Def_GuiTimeDelayCnt5s

void ReadCardUserMemoryFromEEPROM(void)
{
	EEPROM_ReadSequential(CardUserMemoryStartAddr,&CardMemoryMgr[0].UserID,(6*DEF_MAX_CARDUSER));
}

void WriteCardUserMemoryToEEPROM(void)
{
	EEPROM_WriteSequential(CardUserMemoryStartAddr,&CardMemoryMgr[0].UserID,(6*DEF_MAX_CARDUSER));
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void CardUserIdentify(void)
{
	status_t GetCardID;
	uint8_t UserID;

	if (CardIdentifyMgr.Status == ReadingCardID)
	{
		GetCardID = MFC_Auto_Reader(CardIdentifyMgr.CID);
		if ( GetCardID == S_SUCCESS )
		{
			UserID = CompareCardIDwithMemory(CardIdentifyMgr.CID); 
			if ( UserID == 0x00 )		//Card ID is not registered
			{
				CardIdentifyMgr.Status = Fail;
				CardIdentifyMgr.TimeCnt = Def_IdendtifyFailScreenTimeDelay;
			}
			else
			{
				CardIdentifyMgr.UserID = UserID;
				CardIdentifyMgr.Status = Success;	
				CardIdentifyMgr.TimeCnt = Def_IdendtifySuccessScreenTimeDelay;
			}
		}
	}
}

uint8_t CompareCardIDwithMemory(uint8_t *Point)
{
	uint8_t i;
	uint8_t CardUserID;

	for (i=0;i<DEF_MAX_CARDUSER;i++)
	{
		if ( CardMemoryMgr[i].Status == CIDisValid )
		{
			if (  (CardMemoryMgr[i].CID[0] == *Point)
				&&(CardMemoryMgr[i].CID[1] == *(Point+1))
				&&(CardMemoryMgr[i].CID[2] == *(Point+2))
				&&(CardMemoryMgr[i].CID[3] == *(Point+3))
				//&&(CardMemoryMgr[i].CID[4] == *(Point+4))
				 )
			{
				CardUserID = CardMemoryMgr[i].UserID;
				return CardUserID;
			}
		}
	}
	return 0;
}

uint8_t Get_Availabe_CardUserID(void)//��ȡ��ע��Ŀ�ƬID
{
	uint8_t i;
	for (i=0;i<DEF_MAX_CARDUSER;i++)
	{
		if ( CardMemoryMgr[i].Status != CIDisValid ){
			return (i+1);
		}
	}
	return 0;
}

status_t SaveCardUserToMemory(uint8_t *Point,uint8_t UserID)
{
	uint8_t j;
	//uint8_t CardUserID;

	for (j=0;j<4;j++)
	{
		CardMemoryMgr[UserID-1].CID[j] = *(Point+j);
	}
	CardMemoryMgr[UserID-1].UserID = UserID;
	CardMemoryMgr[UserID-1].Status = CIDisValid;
	
	WriteCardUserMemoryToEEPROM();
	return S_SUCCESS;
}

void DeleteCardUserfromMemory(uint8_t UserID)
{
	uint8_t j;

	CardMemoryMgr[UserID-1].Status = CIDisInvalid;
	CardMemoryMgr[UserID-1].UserID = 0xFF;
	for (j=0;j<4;j++)
	{
		CardMemoryMgr[UserID-1].CID[j] = 0xFF;
	}
	WriteCardUserMemoryToEEPROM();
}

void DeleteAllCardUserfromMemory(void)
{
	uint8_t i,j;

	for (i=0;i<DEF_MAX_CARDUSER;i++)
	{

		CardMemoryMgr[i].Status = CIDisInvalid;
		CardMemoryMgr[i].UserID = 0xFF;
		for (j=0;j<4;j++)
		{
			CardMemoryMgr[i].CID[j] = 0xFF;
		}

	}	
	WriteCardUserMemoryToEEPROM();
}

bool_t IfCardUserIDisRegistered(uint8_t CardUserID)
{
	uint8_t i;

	for (i=0;i<DEF_MAX_CARDUSER;i++)
	{
		if ( CardMemoryMgr[i].Status == CIDisValid )
			{
				if (  CardMemoryMgr[i].UserID == CardUserID)
				{
					return bTRUE;
				}
			}
	}
	return bFALSE;
}

uint8_t CheckHowManyRegisteredCardUser( void )
{
	uint8_t i,UserNum;
	UserNum =0;
	for (i=0;i<DEF_MAX_CARDUSER;i++)
	{
		if ( CardMemoryMgr[i].Status == CIDisValid )
		{
			UserNum++;
		}
	}
	return UserNum;
}

