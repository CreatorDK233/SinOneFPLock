#ifndef _FACE_GUI_H_
#define _FACE_GUI_H_
#include "StdTypes.h"

extern uint8_t Get_Availabe_FACEmasterID(void);
extern uint8_t Get_Availabe_FACEuserID(void);
extern bool_t CheckIfFaceUserIsRegistered(uint16_t USERID);
extern status_t SaveFaceUserToMemory(void);
extern void WriteFaceUserMemoryToEEPROM(void);
extern void ReadFaceUserMemoryFromEEPROM(void);
extern void DeleteFaceUserfromMemory(uint8_t UserID);
extern void DeleteAllFaceUserfromMemory(void);
extern uint8_t GetUserIDbyFaceTemplateID(uint16_t TemplateID);
extern uint8_t CheckHowManyRegisteredFaceMaster(void);
extern uint8_t CheckHowManyRegisteredFaceUser(void);
extern bool_t IfSystemIsNoFaceUser(void);

extern void RegisterFace(void);
extern void FaceUserIdentify(void);
extern void DeleteAllFaceTemplate(void);

#endif