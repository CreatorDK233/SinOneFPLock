#ifndef _HallSlide_H_
#define _HallSlide_H_

#if defined ProjectIs_BarLock_S5514 || defined ProjectIs_BarLock_S9201
extern void HallSlideCover_Init(void);
extern void HallSleep_Task(void);
extern void HallAwakeupDispose(void);
#endif

#endif