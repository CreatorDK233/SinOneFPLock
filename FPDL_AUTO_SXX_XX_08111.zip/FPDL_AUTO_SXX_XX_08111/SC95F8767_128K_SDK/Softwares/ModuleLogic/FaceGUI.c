//Protocol layer
#include "BeepMgr.h"
#include "EEPROM.h"
#include "FingerPrint.h"
#include "HostUart.h"
#include "FaceRecoginitionMgr.h"
//Logic layer
#include "LCD.h"
#include "Log.h"
#include "FaceGUI.h"
//Application layer
#include "GUI.h"
#include "GUI_Function.h"
#include "Project.h"
//Basic
#include "Font.h"
#include "Font_Menu.h"
#include "global_variable.h"
#include "StdTypes.h"

/*******************************************************/
uint8_t Get_Availabe_FACEmasterID(void)
{
	uint8_t i;
	for (i=0;i<(DEF_MAX_FACEMASTER);i++)
	{
		if ( FaceUserMemoryMgr[i].RegisterStatus != Registered ){
			return (i+1);
		}
	}
	return 0;
}

/*******************************************************/

uint8_t Get_Availabe_FACEuserID(void)
{
	uint8_t i;
	for (i=(DEF_MAX_FACEMASTER);i<(DEF_MAX_FACEUSER+DEF_MAX_FACEMASTER);i++)
	{
		if ( FaceUserMemoryMgr[i].RegisterStatus != Registered ){
			return (i+1);
		}
	}
	return 0;
}

bool_t CheckIfFaceUserIsRegistered(uint16_t USERID)
{
	//uint8_t FPindexTable[32];
	//uint8_t ByteOffset,BitOffset;
	
	if ( FaceUserMemoryMgr[USERID-1].RegisterStatus == Registered )
	{
		return bTRUE;
	}
	else
	{
		return bFALSE;
	}
}

#ifdef Function_FaceRecoginition	

status_t SaveFaceUserToMemory(void)
{
	return S_SUCCESS;
}

void WriteFaceUserMemoryToEEPROM(void)
{
	EEPROM_WriteSequential(FaceUserMemoryStartAddr,&FaceUserMemoryMgr[0].UserPriority, sizeof(FaceUserMemoryMgr[0])*(DEF_MAX_FACEMASTER+DEF_MAX_FACEUSER));
}

void ReadFaceUserMemoryFromEEPROM(void)
{
	EEPROM_ReadSequential(FaceUserMemoryStartAddr,&FaceUserMemoryMgr[0].UserPriority, sizeof(FaceUserMemoryMgr[0])*(DEF_MAX_FACEMASTER+DEF_MAX_FACEUSER));
}

void DeleteFaceUserfromMemory(uint8_t UserID)
{

	FaceUserMemoryMgr[UserID-1].RegisterStatus = UnRegistered;
	FaceUserMemoryMgr[UserID-1].FaceTemplateID = 0xFFFF;
	FaceUserMemoryMgr[UserID-1].UserPriority = Undefined;
	WriteFaceUserMemoryToEEPROM();
}

/*******************************************************/
/*******************************************************/
void DeleteAllFaceUserfromMemory(void)
{
	uint8_t i;

	for (i=0;i<(DEF_MAX_FACEMASTER+DEF_MAX_FACEUSER);i++)
	{
		FaceUserMemoryMgr[i].RegisterStatus = UnRegistered;
		FaceUserMemoryMgr[i].FaceTemplateID = 0xFFFF;
		FaceUserMemoryMgr[i].UserPriority = Undefined;
	}
	WriteFaceUserMemoryToEEPROM();
}

uint8_t GetUserIDbyFaceTemplateID(uint16_t TemplateID)
{
	uint8_t i;
	for (i=0;i<(DEF_MAX_FACEMASTER+DEF_MAX_FACEUSER);i++)
	{
		if ( (FaceUserMemoryMgr[i].FaceTemplateID == TemplateID)
			&&(FaceUserMemoryMgr[i].RegisterStatus == Registered)
			)
		{
			return i+1;
		}
	}
	return 0;
}

uint8_t CheckHowManyRegisteredFaceMaster(void)
{
	uint8_t i,FaceMasterNum;
	
	FaceMasterNum=0;
	
	for (i=0;i<(DEF_MAX_FACEMASTER);i++)
	{
		if ( FaceUserMemoryMgr[i].RegisterStatus == Registered)
		{
			FaceMasterNum++;
		}
	}
	return FaceMasterNum;
}

uint8_t CheckHowManyRegisteredFaceUser(void)
{
	uint8_t i,FaceUserNum;
	
	FaceUserNum=0;
	
	for (i=DEF_MAX_FACEMASTER;i<(DEF_MAX_FACEMASTER+DEF_MAX_FACEUSER);i++)
	{
		if ( FaceUserMemoryMgr[i].RegisterStatus == Registered)
		{
			FaceUserNum++;
		}
	}
	return FaceUserNum;
}

bool_t IfSystemIsNoFaceUser(void)
{
	uint8_t i;
	for (i=0;i<(DEF_MAX_FACEMASTER+DEF_MAX_FACEUSER);i++)
	{
		if ( FaceUserMemoryMgr[i].RegisterStatus == Registered)
		{
			return bFALSE;
		}
	}
	return bTRUE;
}

void RegisterFace(void)
{
	FaceDirrect_t FaceDirrect;
			
	code uint8_t PleasePutMiddleFace[]={HZ_qing,HZ_shu,HZ_ru,HZ_zhengque,HZ_lianbu,HZ_end};
	code uint8_t PleasePutMiddleFaceEn[]={"PLS put face"};	
	
	code uint8_t PleasePutRightFace[]={HZ_qing,HZ_xiang,HZ_youbian,HZ_weiwei,HZ_weiwei,HZ_qingxie,HZ_xielv,HZ_end};
	code uint8_t PleasePutRightFaceEn[]={"PLS put Right Face"};	

	code uint8_t PleasePutLeftFace[]={HZ_qing,HZ_xiang,HZ_zuobian,HZ_weiwei,HZ_weiwei,HZ_qingxie,HZ_xielv,HZ_end};
	code uint8_t PleasePutLeftFaceEn[]={"PLS put Left Face"};

	code uint8_t PleasePutLowerFace[]={HZ_qing,HZ_xiang,HZ_xia,HZ_weiwei,HZ_weiwei,HZ_di,HZ_tou,HZ_end};
	code uint8_t PleasePutLowerFaceEn[]={"PLS put Lower Face"};
	
	code uint8_t PleasePutUpperFace[]={HZ_qing,HZ_xiang,HZ_shang,HZ_weiwei,HZ_weiwei,HZ_taitou,HZ_tou,HZ_end};
	code uint8_t PleasePutUpperFaceEn[]={"PLS put Upper Face"};

	
	if ( GUI_FaceTemplateRegisterMgr.Status == StartFaceRegister )
	{
		GUI_RefreshSleepTime();
		
		PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseInputFace);
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(3,32,PleasePutMiddleFace,NormalDisplay);
		}
		else{
			DisEN16x8Str(3,4,PleasePutMiddleFaceEn,NormalDisplay);
		}

		GUI_FaceTemplateRegisterMgr.EnrollSuccessTimes = 0;
		GUI_FaceTemplateRegisterMgr.EnrollFailTimes=0;
		GUI_FaceTemplateRegisterMgr.DuplicateCheck = bTRUE;
		if ( FrmMgr.PowerStatus == FRM_PowerOff ) 
		{
			FaceRecognition_HardwarePowerOn();
			GUI_FaceTemplateRegisterMgr.Status = PowerOnForFrmForRegister;
			GUI_FaceTemplateRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt2s; 	
		}
		else
		{
			GUI_FaceTemplateRegisterMgr.Status = FaceResetForRegister;
			GUI_FaceTemplateRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt1s; 
		}

		
	}
	else if (GUI_FaceTemplateRegisterMgr.Status == FaceResetForRegister)
	{
		FaceRecognition_Reset();
		GUI_FaceTemplateRegisterMgr.Status = WaitForFaceResetFinishedForRegister;
		GUI_FaceTemplateRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt4s; 
	}
	else if (GUI_FaceTemplateRegisterMgr.Status == WaitForFaceResetFinishedForRegister)
	{
		if ( FrmMgr.PostFlag_ResetResult == bTRUE)
		{
			GUI_FaceTemplateRegisterMgr.Status = InfoUserPutFace;
		}
		if (--GUI_FaceTemplateRegisterMgr.TimeCnt < 1 )
		{
			if (GUI_FaceTemplateRegisterMgr.EnrollFailTimes < 3 )
			{
				GUI_FaceTemplateRegisterMgr.EnrollFailTimes++;
				GUI_FaceTemplateRegisterMgr.Status = PowerOffForFrmForRegister;
				FaceRecognition_HardwarePowerOff();
				GUI_FaceTemplateRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt01s; 
			}
			else
			{
				GUI_FaceTemplateRegisterMgr.Status = RegisterFaceTemplateFail;
				GUI_FaceTemplateRegisterMgr.ErrorType = TimeOut;
			}
		}
	}
	else if (GUI_FaceTemplateRegisterMgr.Status == PowerOffForFrmForRegister)
	{
		if (--GUI_FaceTemplateRegisterMgr.TimeCnt < 1 )
		{
			GUI_FaceTemplateRegisterMgr.Status = PowerOnForFrmForRegister;
			GUI_FaceTemplateRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt1s5; 
			FaceRecognition_HardwarePowerOn();
		}
	}
	else if (GUI_FaceTemplateRegisterMgr.Status == PowerOnForFrmForRegister)
	{
		if (--GUI_FaceTemplateRegisterMgr.TimeCnt < 1 )
		{
			GUI_FaceTemplateRegisterMgr.Status = FaceResetForRegister;
		}
	}
	else if (GUI_FaceTemplateRegisterMgr.Status == InfoUserPutFace)
	{
		GUI_FaceTemplateRegisterMgr.Status = WaitForRegisterFaceResult;
		GUI_FaceTemplateRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt25s;
		GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt=0x0000;	
		
		if (GUI_FaceTemplateRegisterMgr.EnrollSuccessTimes == 0)
		{
			FaceDirrect = FaceDirrect_MIDDLE;	
		}
		else if (GUI_FaceTemplateRegisterMgr.EnrollSuccessTimes == 1)
		{
			FaceDirrect = FaceDirrect_RIGH;
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseMoveFaceToRight);
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,16,PleasePutRightFace,NormalDisplay);
			}
			else{
				DisEN16x8Str(3,4,PleasePutRightFaceEn,NormalDisplay);
			}	
		}
		else if (GUI_FaceTemplateRegisterMgr.EnrollSuccessTimes == 2)
		{
			FaceDirrect = FaceDirrect_LEFT;
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseMoveFaceToLeft);
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,16,PleasePutLeftFace,NormalDisplay);
			}
			else{
				DisEN16x8Str(3,4,PleasePutLeftFaceEn,NormalDisplay);
			}
		}
		else if (GUI_FaceTemplateRegisterMgr.EnrollSuccessTimes == 3)
		{
			FaceDirrect = FaceDirrect_DOWN;
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseMoveFaceToDown);
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,16,PleasePutLowerFace,NormalDisplay);
			}
			else{
				DisEN16x8Str(3,4,PleasePutLowerFaceEn,NormalDisplay);
			}
		}
		else if (GUI_FaceTemplateRegisterMgr.EnrollSuccessTimes == 4)
		{
			FaceDirrect = FaceDirrect_UP;
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseMoveFaceToUp);
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,16,PleasePutUpperFace,NormalDisplay);
			}
			else{
				DisEN16x8Str(3,4,PleasePutUpperFaceEn,NormalDisplay);
			}
		}
		#ifdef Function_FaceRegisterMultiTimes
			FaceRecognition_RegisterTemplateMultiTimesStart(FaceDirrect);
		#elif defined Function_FaceRegisterSingleTimes
			FaceRecognition_RegisterTemplateSingleTimesStart();
		#else
			//DEFINE FAIL
		#endif
		
		DEBUG_MARK;
	}
	else if ( GUI_FaceTemplateRegisterMgr.Status == WaitForRegisterFaceResult)
	{
		GUI_RefreshSleepTime();

		if ( GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt < 1000 )
		{
			GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt++;
		}
		
		if (FrmMgr.PostFlag_FaceState == bTRUE)//算法执行成功，并且返回人脸信息
		{
			FrmMgr.PostFlag_FaceState = bFALSE;
			
			if ( FrmMgr.FaceState == NOFACE )
			{
				if ( GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt > Def_GuiTimeDelayCnt4s )
				{
					GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt=0x0000;				
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_NoFaceDetected);
				}
			}
			else if ( FrmMgr.FaceState == TOOUP )
			{
				if ( GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt > Def_GuiTimeDelayCnt2s )
				{
					GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt=0x0000;	
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooUp);
				}
			}
			else if ( FrmMgr.FaceState == TOODOWN )
			{
				if ( GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt > Def_GuiTimeDelayCnt2s )
				{
					GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt=0x0000;
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooLow);
				}
			}	
			else if ( FrmMgr.FaceState == TOOLEFT )
			{
				if ( GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt > Def_GuiTimeDelayCnt2s )
				{
					GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt=0x0000;
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooLeft);
				}
			}
			else if ( FrmMgr.FaceState == TOORIGHT )
			{
				if ( GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt > Def_GuiTimeDelayCnt2s )
				{
					GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt=0x0000;
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooRight);
				}
			}
			else if ( FrmMgr.FaceState == TOOFAR )
			{
				if ( GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt > Def_GuiTimeDelayCnt2s )
				{
					GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt=0x0000;
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooAway);
				}
			}
			else if ( FrmMgr.FaceState == TOOCLOSE )
			{
				if ( GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt > Def_GuiTimeDelayCnt2s )
				{
					GUI_FaceTemplateRegisterMgr.ReportFaceStatusTimeCnt=0x0000;
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooClose);
				}
			}
			
			DEBUG_MARK;

		}
		if (FrmMgr.PostFlag_RegisterResult == bTRUE)
		{
			FrmMgr.PostFlag_RegisterResult = bFALSE;

			if (FrmMgr.ErrorType == MR_SUCCESS )
			{
				#ifdef Function_FaceRegisterMultiTimes
				if (++GUI_FaceTemplateRegisterMgr.EnrollSuccessTimes < 5 )
				#elif defined Function_FaceRegisterSingleTimes
				if (++GUI_FaceTemplateRegisterMgr.EnrollSuccessTimes < 1 )
				#else
				if (1)
				#endif
				{
					GUI_FaceTemplateRegisterMgr.Status = InfoUserPutFace;
					GUI_FaceTemplateRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt1s; 
				}
				else
				{
					GUI_FaceTemplateRegisterMgr.Status = RegisterFaceTemplateSuccess;
					GUI_FaceTemplateRegisterMgr.UserID = FrmMgr.UserID;
					DEBUG_MARK;
				}
			}
			else
			{
				GUI_FaceTemplateRegisterMgr.Status = RegisterFaceTemplateFail;
				if ( FrmMgr.ErrorType == MR_FAILED4_FACEENROLLED )
				{
					GUI_FaceTemplateRegisterMgr.ErrorType = RepeatFace;
				}
				else
				{
					GUI_FaceTemplateRegisterMgr.ErrorType = FaceRegisterFail;
				}
			}
		}
		
		if (--GUI_FaceTemplateRegisterMgr.TimeCnt < 1 )
		{
			GUI_FaceTemplateRegisterMgr.Status = RegisterFaceTemplateFail;
			GUI_FaceTemplateRegisterMgr.ErrorType = TimeOut;
		}
	}

}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void FaceUserIdentify(void)
{
	if ( FaceIdentifyMgr.Status == FrmIdentifyStart )
	{
		if ( FrmMgr.PowerStatus == FRM_PowerOff )
		{
			FaceRecognition_HardwarePowerOn();
		}
		FaceIdentifyMgr.Status = GetFrmStatus;
		FaceIdentifyMgr.TimeCnt = Def_GuiTimeDelayCnt1s; 
	}
	else if (FaceIdentifyMgr.Status == GetFrmStatus)
	{
		if (--FaceIdentifyMgr.TimeCnt < 1 )
		{	
			FaceRecognition_GetStatus();
			FaceIdentifyMgr.Status = WaitForGetFrmStatusAck;
			FaceIdentifyMgr.TimeCnt = Def_GuiTimeDelayCnt05s; 
		}
		if (FrmMgr.PostFlag_Ready == bTRUE )
		{
			if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
			{
				FaceIdentifyMgr.Status = SendFrmEnableDemoModeCmd;	
			}
			else if ( FaceIdentifyMgr.DemoModeIsEnabled == bTRUE )
			{
				FaceIdentifyMgr.Status = SendFrmDisableDemoModeCmd;	
			}
			else
			{
				FaceIdentifyMgr.Status = SendFaceIdentifyCmd;
			}
		}
	}
	else if (FaceIdentifyMgr.Status == WaitForGetFrmStatusAck)
	{
		if ( FrmMgr.PostFlag_Status == bTRUE)
		{
			if ( FrmMgr.ErrorType == MR_SUCCESS )
			{
				if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
				{
					FaceIdentifyMgr.Status = SendFrmEnableDemoModeCmd;	
				}
				else if ( FaceIdentifyMgr.DemoModeIsEnabled == bTRUE )
				{
					FaceIdentifyMgr.Status = SendFrmDisableDemoModeCmd;	
				}
				else
				{
					FaceIdentifyMgr.Status = SendFaceIdentifyCmd;
				}
			}
			else
			{
				FaceIdentifyMgr.Status = PowerOffForFrmHardwareReset;
				FaceIdentifyMgr.TimeCnt = Def_GuiTimeDelayCnt01s;
			}
		}
		if (--FaceIdentifyMgr.TimeCnt < 1 )
		{
				FaceIdentifyMgr.Status = PowerOffForFrmHardwareReset;
				FaceIdentifyMgr.TimeCnt = Def_GuiTimeDelayCnt01s; 
				DEBUG_MARK;
		}
	} 
	else if (FaceIdentifyMgr.Status == PowerOffForFrmHardwareReset)
	{
		FaceRecognition_HardwarePowerOff();
		if (--FaceIdentifyMgr.TimeCnt < 1 )
		{
			FaceIdentifyMgr.Status = PowerOnForFrmHardwareReset;
		}
	} 
	else if (FaceIdentifyMgr.Status == PowerOnForFrmHardwareReset)
	{
		FaceRecognition_HardwarePowerOn();
		FaceIdentifyMgr.Status = WaitForFrmReadyForIdentify;
		FaceIdentifyMgr.TimeCnt = Def_GuiTimeDelayCnt2s; 
	} 
	else if (FaceIdentifyMgr.Status == WaitForFrmReadyForIdentify)
	{
		if ( FrmMgr.PostFlag_Ready == bTRUE)
		{
			if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
			{
				FaceIdentifyMgr.Status = SendFrmEnableDemoModeCmd;	
			}
			else if ( FaceIdentifyMgr.DemoModeIsEnabled == bTRUE )
			{
				FaceIdentifyMgr.Status = SendFrmDisableDemoModeCmd;	
			}
			else
			{
				FaceIdentifyMgr.Status = SendFaceIdentifyCmd;
			}
		}
		if (--FaceIdentifyMgr.TimeCnt < 1 )
		{
			FaceIdentifyMgr.Status = FaceIdentifyFail;
		}
	}
	else if ( FaceIdentifyMgr.Status == SendFrmEnableDemoModeCmd )
	{
		FaceIdentifyMgr.DemoModeIsEnabled = bTRUE;
		FaceRecognition_EnableDemoMode();
		FaceIdentifyMgr.TimeCnt = Def_GuiTimeDelayCnt2s; 
		FaceIdentifyMgr.Status = WaitForFrmEnableDemoModeAck;
	}	
	else if ( FaceIdentifyMgr.Status == WaitForFrmEnableDemoModeAck )
	{
		if (--FaceIdentifyMgr.TimeCnt < 1)
		{
			DEBUG_MARK;
			FaceIdentifyMgr.Status = FrmIdentifyStart;
		}
		if (FrmMgr.PostFlag_EnableDemoResult == bTRUE )
		{
			FaceIdentifyMgr.Status = SendFaceIdentifyCmd;
			FaceIdentifyMgr.DemoModeIsEnabled = bTRUE;
		}
	}	
	else if ( FaceIdentifyMgr.Status == SendFrmDisableDemoModeCmd )
	{
		FaceRecognition_DisableDemoMode();
		FaceIdentifyMgr.TimeCnt = Def_GuiTimeDelayCnt2s; 
		FaceIdentifyMgr.Status = WaitForFrmDisableDemoModeAck;
	}	
	else if ( FaceIdentifyMgr.Status == WaitForFrmDisableDemoModeAck )
	{
		if (--FaceIdentifyMgr.TimeCnt < 1)
		{
			DEBUG_MARK;
			FaceIdentifyMgr.Status = FrmIdentifyStart;
		}
		if (FrmMgr.PostFlag_DisableDemoResult == bTRUE )
		{
			FaceIdentifyMgr.Status = SendFaceIdentifyCmd;
			FaceIdentifyMgr.DemoModeIsEnabled = bFALSE;
		}
	}
	else if ( FaceIdentifyMgr.Status == SendFaceIdentifyCmd )
	{
		FaceIdentifyMgr.Status = WaitForFaceIdentifyResult;
		FaceIdentifyMgr.TimeCnt = Def_GuiTimeDelayCnt10s;
		FaceIdentifyMgr.ReportFaceStatusTimeCnt = Def_GuiTimeDelayCnt3s;
		FaceRecognition_VerifyStart();
		DEBUG_MARK;
	}
	else if ( FaceIdentifyMgr.Status == WaitForFaceIdentifyResult)
	{
		if ( FaceIdentifyMgr.ReportFaceStatusTimeCnt > 0 )
		{
			FaceIdentifyMgr.ReportFaceStatusTimeCnt--;
		}

		#ifdef Function_VoiceReportFaceStatusWhileIdendify
		if (FrmMgr.PostFlag_FaceState == bTRUE)
		{
			FrmMgr.PostFlag_FaceState = bFALSE;

			if (  FaceIdentifyMgr.ReportFaceStatusTimeCnt == 0x0000)
			{
				if (( FrmMgr.FaceState == NOFACE )&&(SystemPowerMgr.SleepDelayTimerCnt > Def_GuiTimeDelayCnt2s) )
				{
					FaceIdentifyMgr.ReportFaceStatusTimeCnt = Def_GuiTimeDelayCnt3s;	
					#if defined ProjectIs_BarLock_S101Z01
//						if ( (CurrentScreen != SCREEN_PickLockAlarm) && (IfSystemIsInFactoryDefaultStatus()==bTRUE) )
//						{
//							PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_NoFaceDetected);
//						}
					#else
						if ( CurrentScreen != SCREEN_PickLockAlarm )
						{
							PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_NoFaceDetected);
						}	
					#endif
				}
				else if ( FrmMgr.FaceState == TOOUP )	//
				{
					FaceIdentifyMgr.ReportFaceStatusTimeCnt = Def_GuiTimeDelayCnt2s;	
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooUp);
				}
				else if ( FrmMgr.FaceState == TOODOWN )//
				{
					FaceIdentifyMgr.ReportFaceStatusTimeCnt = Def_GuiTimeDelayCnt2s;
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooLow);
				}	
				else if ( FrmMgr.FaceState == TOOLEFT )//
				{
					FaceIdentifyMgr.ReportFaceStatusTimeCnt = Def_GuiTimeDelayCnt2s;
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooLeft);
				}
				else if ( FrmMgr.FaceState == TOORIGHT )//
				{
					FaceIdentifyMgr.ReportFaceStatusTimeCnt = Def_GuiTimeDelayCnt2s;
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooRight);
				}
				else if ( FrmMgr.FaceState == TOOFAR )//
				{
					FaceIdentifyMgr.ReportFaceStatusTimeCnt = Def_GuiTimeDelayCnt2s;
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooAway);
				}
				else if ( FrmMgr.FaceState == TOOCLOSE )//
				{
					FaceIdentifyMgr.ReportFaceStatusTimeCnt = Def_GuiTimeDelayCnt2s;
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FaceTooClose);
				}
			}
			
			DEBUG_MARK;
		}
		#endif
		if (FrmMgr.PostFlag_VerifyResult == bTRUE)
		{
			if ( FrmMgr.ErrorType == MR_SUCCESS )
			{
				if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
				{
					FaceIdentifyMgr.Status = FaceIdentifySuccess_NoUser;
				}
				else
				{
					FaceIdentifyMgr.Status = FaceIdentifySuccess;
				}
			}
			else
			{
				FaceIdentifyMgr.Status = FaceIdentifyFail;
				DEBUG_MARK;
			}
		}
		if (--FaceIdentifyMgr.TimeCnt < 1)
		{
				DEBUG_MARK;
				FaceIdentifyMgr.Status = FaceIdentifyFail;
		}
	}
}

/*******************************************************/
void DeleteAllFaceTemplate(void)
{
	if ( DeleteAllFaceTemplateMgr.Status == StartAllFaceTemplateDelete)
	{
		DeleteAllFaceTemplateMgr.Status = PowerOffFrmForDeleteAllTemplate;
		FaceRecognition_HardwarePowerOff();
		DeleteAllFaceTemplateMgr.TimeCnt  = Def_GuiTimeDelayCnt05s;
	}
	else if (DeleteAllFaceTemplateMgr.Status == PowerOffFrmForDeleteAllTemplate)
	{
		if ( DeleteAllFaceTemplateMgr.TimeCnt-- < 1 )
		{
			DeleteAllFaceTemplateMgr.Status = PowerOnFrmForDeleteAllTemplate;
			FaceRecognition_HardwarePowerOn();
			DeleteAllFaceTemplateMgr.TimeCnt  = Def_GuiTimeDelayCnt2s;
		}
	}
	else if (DeleteAllFaceTemplateMgr.Status == PowerOnFrmForDeleteAllTemplate)
	{
		if ( FrmMgr.PostFlag_Ready == bTRUE )
		{
			DeleteAllFaceTemplateMgr.Status = SendDeleteAllFaceTemplateCmdToFRM;
		}
		if ( DeleteAllFaceTemplateMgr.TimeCnt-- < 1 )
		{
			DeleteAllFaceTemplateMgr.Status = SendDeleteAllFaceTemplateCmdToFRM;
			DEBUG_MARK;
		}
	}
	
    else if ( DeleteAllFaceTemplateMgr.Status == SendDeleteAllFaceTemplateCmdToFRM )
	{
		FaceRecognition_DeleteAllTemplateStart();
		DeleteAllFaceTemplateMgr.Status = WaitForDeleteAllFaceTemplateCmdACKfromFRM;
		DeleteAllFaceTemplateMgr.TimeCnt = Def_GuiTimeDelayCnt4s;
	}
	
	else if ( DeleteAllFaceTemplateMgr.Status == WaitForDeleteAllFaceTemplateCmdACKfromFRM )
	{
		if (FrmMgr.PostFlag_DeleteAllResult == bTRUE)
		{
			FrmMgr.PostFlag_DeleteAllResult = bFALSE;

			if (FrmMgr.ErrorType == MR_SUCCESS )
			{
				DeleteAllFaceTemplateMgr.Status = DeleteAllFaceTemplateSuccess;
				DeleteAllFaceUserfromMemory();
			}
			else
			{
				DeleteAllFaceTemplateMgr.Status = DeleteAllFaceTemplateFail;
				DEBUG_MARK;
			}
		}
		
		if ( DeleteAllFaceTemplateMgr.TimeCnt-- < 1 )
		{
			DeleteAllFaceTemplateMgr.Status = DeleteAllFaceTemplateFail;
			DEBUG_MARK;
		}
	}

}
#endif
