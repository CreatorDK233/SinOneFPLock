#ifndef _RTC_H_
#define _RTC_H_

#include "StdTypes.h"
extern uint8_t BCD_to_Hex(uint8_t num);
extern uint8_t Hex_to_BCD(uint8_t num);
extern systemtime_t UTCToSystemtime(uint32_t UTC);
extern uint32_t SystemTimeToUTC(systemtime_t Time);
extern void MX_RTC_Init(void);
extern void SystemTimeUpdate(void);
#endif