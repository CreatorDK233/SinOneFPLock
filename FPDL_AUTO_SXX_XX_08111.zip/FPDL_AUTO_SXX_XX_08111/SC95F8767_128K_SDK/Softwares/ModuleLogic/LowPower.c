#include "adc.h"
#include "IO.h"
#include "i2c.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "Basic_Function.h"
#include "SensorMethod.h"
//Protocol layer
#include "PIR.h"
#include "Radar.h"
#include "Fingerprint.h"
#include "MFC_MF17622.h"
#include "RTC_PCF8563.h"
#include "LCD_HFG12864.h"
#include "Key_SinOne.h"
#include "BeepMgr.h"
#include "LEDsMgr.h"
#include "HostUart.h"
#include "FaceRecoginitionMgr.h"
//Logic layer
#include "Battery.h"
#include "LowPower.h"
#include "LCD.h"
#include "HallSlide.h"
#include "KeyScan.h"
#include "FP.h"
//Application layer
#include "GUI_Function.h"
#include "Project.h"
#include "GUI.h"
//Basic
#include "global_variable.h"

extern bool_t IfSystemIsInFactoryDefaultStatus(void);

extern bit Touch_WakeUpFlag;
#if defined ProjectIs_BarLock_S5514 || defined ProjectIs_BarLock_S9201
extern 	bit SleepingHallState; 	//����ʱ��������io�ڵĵ�λֵ
extern bit HallSleepFlag;				//�������߱�־
#endif

#ifdef Function_USE_Internal_RTC
unsigned	char  SecondCount = 0;
#endif

uint8_t LastWakeUpKeyValue;
int8_t KeyWakeUpKeyWaitTime = 0;
bit 		KeyJustWakeUp = 0;
bit 		HostIntEnable = 0;
bool_t  BodyInductionScanEnable = bFALSE;
bool_t  RadarEnable = bFALSE;

/**************************************************
*�������ƣ�void IntoLowPowerMode_Init(void)
*�������ܣ�����͹���ģʽǰ�ĵĳ�ʼ��
*��ڲ�����void
*���ڲ�����void  
*��ע˵�����ڽ���͹���ǰ���Բ������ݽ��д��� 
**************************************************/
void IntoLowPowerMode_Init(void)
{
    /*����͹���ǰ����*/
	SetTouchSleepSensitivity();
	KeyWakeUpKeyWaitTime = 8;//8*125ms = 1s
	#if defined ProjectIs_BarLock_S5514 || defined ProjectIs_BarLock_S9201
	SleepingHallState = PINMACRO_HALLSENSOR_STATUS;
	HallSleepFlag = 0;
	#endif
	HostIntEnable = 1;
	
	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		#ifdef Function_BodyInductionByIR
		if ( BodyInductionMgr.SensingDistanceLevel != SensingDistanceL0 )
		{
			BodyInductionScanEnable = bTRUE;	
			DEBUG_MARK;
		}
		else
		{
			BodyInductionScanEnable = bFALSE;
			DEBUG_MARK;
		}
		#elif defined Function_BodyInductionByRadar
		if ( BodyInductionMgr.SensingDistanceLevel != SensingDistanceL0 )
		{
			if ( BodyInductionMgr.BodyInductionDelayTimeCnt > 0 )
			{
				BodyInductionScanEnable = bTRUE;
				RadarAwake_TurnOff();
			}
			else
			{
				BodyInductionScanEnable = bFALSE;
				RadarAwake_TurnOn();
			}	
		}
		else
		{
			BodyInductionScanEnable = bFALSE;
			RadarAwake_TurnOff();
		}
		#endif
	}
//	#ifdef Function_YouzhiyunjiaWifi
//	EnableWifiRx_Interrupt();
//	#endif
}

/**************************************************
*�������ƣ�void MX_QuitLowPowerMode(uint8_t Source)
*�������ܣd�˳��͹���ģʽ
*��ڲ�����void
*���ڲ�����void  
**************************************************/
void MX_QuitLowPowerMode(uint8_t Source)
{
	TouchKey_QuitLowPowerMode();
	SetTouchAwakeSensitivity();	
	Touch_WakeUpFlag = 1;
	HostIntEnable = 0;
	AwakeFlag = NoAwake;
	SystemPowerMgr.AwakeSource = Source;
}

/**************************************************
*�������ƣ�void AntiMisAwakeup(uint8_t KeyValue)
*�������ܣd��ֹżȻ��������Զ�����
*��ڲ�����uint8_t KeyValue
*���ڲ�����void  
**************************************************/
void AntiMisAwakeup(uint8_t KeyValue)
{
	if( KeyWakeUpKeyWaitTime <= 0 )
	{
		if( LastWakeUpKeyValue == KeyValue )
		{
			#if defined ProjectIs_BarLock_S5514 || defined ProjectIs_BarLock_S9201
				if( PINMACRO_HALLSENSOR_STATUS == 0 )
				{
					MX_QuitLowPowerMode(KeyBoardTouch);
					AwakeSystemKeyMgr.IsDoorColseKeyAwake = bFALSE;
					AwakeSystemKeyMgr.IsDoorBellKeyAwake = bFALSE;
					AwakeSystemKeyMgr.IsPoundsignKeyAwake = bFALSE;
					KeyJustWakeUp = 1;
				}
				LastWakeUpKeyValue = 0xff;
			#else
				MX_QuitLowPowerMode(KeyBoardTouch);
				AwakeSystemKeyMgr.IsDoorColseKeyAwake = bFALSE;
				AwakeSystemKeyMgr.IsDoorBellKeyAwake = bFALSE;
				AwakeSystemKeyMgr.IsPoundsignKeyAwake = bFALSE;
			#if (defined ProjectIs_BarLock_S64Z24) || (defined ProjectIs_BarLock_S64Z31) \
				|| (defined ProjectIs_BarLock_S64Z48) || (defined ProjectIs_BarLock_S64Z61)	
					if( KeyValue == 0x0D )
					{
						AwakeSystemKeyMgr.IsDoorColseKeyAwake = bTRUE;
					}
					else if( KeyValue == 0x00 )
					{
						AwakeSystemKeyMgr.IsDoorBellKeyAwake = bTRUE;
					}
					#endif
					#if (defined ProjectIs_BarLock_S15Z07) || (defined ProjectIs_BarLock_S15Z08) \
					|| (defined ProjectIs_BarLock_S15Z09)
					if( KeyValue == 0x05 )
					{
						AwakeSystemKeyMgr.IsDoorColseKeyAwake = bTRUE;
					}
					else if( KeyValue == 0x00 )
					{
						AwakeSystemKeyMgr.IsDoorBellKeyAwake = bTRUE;
					}
					#endif
					#if defined ProjectIs_BarLock_S06Z09
					if( KeyValue == 0x0B )
					{
						AwakeSystemKeyMgr.IsDoorColseKeyAwake = bTRUE;
					}
					else if( KeyValue == 0x05 )
					{
						AwakeSystemKeyMgr.IsDoorBellKeyAwake = bTRUE;
					}
					#endif
					#if defined ProjectIs_BarLock_S06Z10
					if( KeyValue == 0x0C )
					{
						AwakeSystemKeyMgr.IsDoorColseKeyAwake = bTRUE;
					}
					else if( KeyValue == 0x0B )
					{
						AwakeSystemKeyMgr.IsDoorBellKeyAwake = bTRUE;
					}
					#endif
					#if defined ProjectIs_BarLock_S101Z01
					if( KeyValue == 0x0D )
					{
						AwakeSystemKeyMgr.IsDoorColseKeyAwake = bTRUE;
					}
					else if( KeyValue == 0x00 )
					{
						AwakeSystemKeyMgr.IsDoorBellKeyAwake = bTRUE;
					}
					#endif
				KeyJustWakeUp = 1;
				LastWakeUpKeyValue = 0xff;
			#endif
		}
		else{
			LastWakeUpKeyValue = KeyValue;
		}
	}
	else{
		LastWakeUpKeyValue = 0xff;
	}
}

/**************************************************
*�������ƣ�void LowPowerAwakeupDispose(void)
*�������ܣd�͹��Ļ��Ѽ�⣨��������������⣩
*��ڲ�����void
*���ڲ�����void  
**************************************************/
uint8_t BodyInductionScanCnt = 0;
void LowPowerAwakeupDispose(void)
{
	SystemPowerMgr.Status = SLEEP;
	SystemPowerMgr.AwakeSource = DoNotCare;
	//���˻���
	if( PickAlarmEnableMgr.Enable == bTRUE )
	{
		if(
			#if (defined ProjectIs_BarLock_S15Z08)
			( PINMACRO_PICKLOCK_STATUS == 1 )
			#else
			( PINMACRO_PICKLOCK_STATUS == 0 )
			#endif
			&&( AntiPryingMgr.AntiPryingTrigger == bTRUE ))
		{
			MX_QuitLowPowerMode(AntiPrying);
		}
	}
	//ˢ������
	#ifdef Function_FM17622_LPCD
	if ( AwakeFlag == MFCAwake )
	{
		MX_QuitLowPowerMode(NFCIrq);
	}
	#endif
	//ָ�ƻ���
	if( PINMACRO_FPM_TOUCH_STATUS == 1 )
	{
		MX_QuitLowPowerMode(FingerTouch);
	}
	//��廽���ж�
	if( AwakeFlag == HostAwake )
	{
		MX_QuitLowPowerMode(DoNotCare);
	}
	//���˻����жϣ��˴���ֹ©�ж�
	if( AwakeFlag == AntiPryingAwake )
	{
		MX_QuitLowPowerMode(AntiPrying);
		
	}

	if( BodyInductionScanEnable == bTRUE )
	{
		if( ++BodyInductionScanCnt >= 6 )
		{
			BodyInductionScanCnt = 0;
			#ifdef Function_BodyInductionByIR
			if ( BodyInductionMgr.BodyInductionDelayTimeCnt > 0 )
			{
				BodyInductionMgr.BodyInductionDelayTimeCnt--;
			}
			else
			{
				PIR_Task();
				if ( PIRmgr.FaceDetected == bTRUE )
				{
					MX_QuitLowPowerMode(BodyInduction);
				}
			}
			#elif defined Function_BodyInductionByRadar
			DEBUG_MARK;
			if ( BodyInductionMgr.BodyInductionDelayTimeCnt > 0 )
			{
				BodyInductionMgr.BodyInductionDelayTimeCnt--;
			}
			else
			{
				//BodyInductionScanEnable = bFALSE;
				RadarAwake_TurnOn();
			}
			#else
			DEBUG_MARK;
			#endif
		}
	}
	
	#ifdef Function_BodyInductionByRadar
	if( PINMACRO_RADAR_INT_STATUS == 0 )
	{
		LastIOStatus.RadarInt = 0;
	}
	if(( BodyInductionMgr.RadarBodyInductionEnable == bTRUE )&&( BodyInductionMgr.SensingDistanceLevel != SensingDistanceL0 ))
	{
		if( BodyInductionMgr.BodyInductionDelayTimeCnt <= 0 )
		{
			if(( PINMACRO_RADAR_INT_STATUS == 1 )&&( LastIOStatus.RadarInt == 0 ))
			{
				MX_QuitLowPowerMode(BodyInduction);
				AwakeSystemKeyMgr.IsDoorColseKeyAwake = bFALSE;
				AwakeSystemKeyMgr.IsDoorBellKeyAwake = bFALSE;
				RadarAwake_TurnOff();
			}
		}
	}
	#endif
		
	//��������
	#if defined ProjectIs_BarLock_S5514 || defined ProjectIs_BarLock_S9201
	HallAwakeupDispose();
	#endif
}

/**************************************************
*�������ƣ�void System_PowerDown(void)
*�������ܣdϵͳ���߿�ʼ
*��ڲ�����void
*���ڲ�����void  
**************************************************/
void System_PowerDown(void)
{
    uint8_t i;
	uint8_t j=0,k=0;
	uint32_t Awake_key=0;
	
	static uint16_t FPtimeout_times,FP_SleepFailedTimes;
	
	CLRWDT();
	DEBUG_MARK;
	
	Clear_Screen();
	
	ComportMgr.RestoreFactoryDefaultTrig = bFALSE;
	
	SET_LEDPOWER_OFF;
	SET_LED_RGB_OFF();
	
	#ifndef Function_MainBoardWithoutVoicePlayer
	STOP_VOICEPLAY();
	#endif
	
	Hardware_DelayMs(10);
	
	#ifdef Function_FaceRecoginition			
	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		if (FrmMgr.PowerStatus != FRM_PowerOff)
		{
			FaceRecognition_PowerDown();
			for (i=0;i<100;i++)
			{
				Hardware_DelayMs(10);
				FaceRecognitionMgr_Task();
				CLRWDT();
				if ( FrmMgr.PostFlag_PownDown == bTRUE )
				{
					DEBUG_MARK;
					break;
				}
			}
		}
		FaceRecognition_HardwarePowerOff();
	}
	#endif		
	//Uart0_Init(32,115200);
	Uart0_DeInit(); 
	
	ADC_DeInit();
	MX_TIM_DeInit();
	SPI0_DeInit();
	MFC_POWERDOWN();	
	GUI_SetFPM_LED(DEF_FpmLedMode_Off,DEF_FpmLedColor_All,DEF_FpmLedColor_All,255);
	CLRWDT();
	#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
	//HAL_UART_DeInit(&huart3);
	SET_WIFIPOWER_OFF;
	WifiMgr.Power.Status = PowerOff;
	#endif

	FPtimeout_times=0;
	FP_SleepFailedTimes=0;
	while(1)
	{
		FpmAckMgr.Status = WaitACK;
		FpmAckMgr.TimeOutCnt = DEF_FpmAckTimeoutTime;
		FPM_SendSleepCmd();
		for (i=0;i<25;i++)
		{
			CLRWDT();
			Hardware_DelayMs(20);
			FPM_Mgr_Task();
			if ( FpmAckMgr.Status == GotACK )
			{
				if (  ( FpmAckMgr.ErrorCode == Error_NONE)
					&&(PINMACRO_FPM_TOUCH_STATUS == 0 )
					)
				{
					FPMpowerMgr.Status = FPMpowerDown;	
					DEBUG_MARK;
					break;
				}
				else
				{
					FP_SleepFailedTimes++;
					DEBUG_MARK;
					
					if (FP_SleepFailedTimes>350)		//FP not released more than 10s
					{
						FPMpowerMgr.Status = FPMpowerDown;	
					}
					break;
				}
				
			}
			else
			{
				if (i>23)		//time out,FP failed
				{
					FPtimeout_times++;
					if (FPtimeout_times>2)
					{
						FPMpowerMgr.Status = FPMpowerDown;	
						break;
					}
				}
			}
		}
		CLRWDT();
		if ( FPMpowerMgr.Status == FPMpowerDown)
		{
			DEBUG_MARK;
			MX_UART2_DeInit();
			SYSPOWER_OFF;
			Hardware_DelayMs(3);//Wait for Power line lost power
			break;
		}
	}
	
		//wait for user release touch button
	if ( SystemPowerMgr.SleepSource == UserForced )
	{
		for (i=0;i<10;i++)
		{
			CLRWDT();
			Hardware_DelayMs(1);
		}
	}
	#ifdef Function_BodyInductionByRadar
	if (Radar_SelfTest() == S_SUCCESS)
	{
		BodyInductionMgr.RadarBodyInductionEnable = bTRUE;
	}
	else
	{
		BodyInductionMgr.RadarBodyInductionEnable = bFALSE;
	}
	LastIOStatus.RadarInt = PINMACRO_RADAR_INT_STATUS;
	#endif
	
	MX_USART1_DeInit();

	MX_GPIO_DeInit();
	Enable_EX_Interrupt();
	IntoLowPowerMode_Init();
	TouchKey_IntoLowPowerMode();
	i=0;
	while(i!=1)
	{
		if(GetLowPowerScanFlag() == 0)	//��������ģʽ 
		{
			i=1;
		}
		else						//�͹�������ģʽ
		{
			LowPower_Touchkey_Scan();
		}	
	}
	if (SystemPowerMgr.AwakeSource == BodyInduction)
	{	
		#ifdef Function_BodyInductionByIR
		if ( BodyInductionMgr.BodyInductionInvalidTimes < DEF_IrBodyInductionInvalidTimesLimited )
		{
			BodyInductionMgr.BodyInductionInvalidTimes++;
			DEBUG_MARK;
		}
		if ( BodyInductionMgr.BodyInductionInvalidTimes >= DEF_IrBodyInductionInvalidTimesLimited )
		{
			PIR_SensitivityDecrease();
			BodyInductionMgr.BodyInductionDelayTimeCnt = 0;
			DEBUG_MARK;
		}
		#endif
	}
	else
	{
		//BodyInductionMgr.BodyInductionInvalidTimes = 0;
		//BodyInductionMgr.BodyInductionBeLimited = bFALSE;
		BodyInductionMgr.BodyInductionDelayTimeCnt = 0;
		DEBUG_MARK;
	}
}

/**************************************************
*�������ƣ�void System_Awake(void)
*�������ܣdϵͳ���ѿ�ʼ
*��ڲ�����void
*���ڲ�����void  
**************************************************/
void System_Awake(void)
{
	uint8_t i;
	
	CLRWDT();

	Hardware_DelayMs(1);		//wait for system clock stable//
	
	MX_GPIO_Init();
	
	Hardware_Awake_Driver();
	
	MX_I2C_Init();
	
	MX_ADC1_Init();
	
	MX_TIM_Init();
	
	MX_SPI0_Init();
	
	MFC_WAKEUP();
	
	VOICE_Init();
	
	#ifndef DEBUG_MODE
	SET_LOGLED_ON;
	#endif
	
	SET_LEDRGB_R_OFF;
	SET_LEDRGB_G_OFF;
	
	MX_USART1_UART_Init();
	MX_USART2_UART_Init();
	#ifdef Function_FaceRecoginition	
	Uart0_Init(32,115200);
	#endif
	
	SYSPOWER_ON;
	SET_LEDPOWER_ON;
	FPMpowerMgr.Status = FPMpowerOn;
	Hardware_DelayMs(5);		//wait for OLED Driver power on reset
	
	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		if (( SystemPowerMgr.AwakeSource == KeyBoardTouch )
		||(SystemPowerMgr.AwakeSource == DriverBoard)
		)
		{
			FaceIdentifyMgr.IndentifyDelayTimeCnt = Def_GuiTimeDelayCnt2s;
		}	
		else
		{
			FaceIdentifyMgr.IndentifyDelayTimeCnt = 0x0000;
		}
		
		FaceRecognitionMgr_Init();

		if ( FaceIdentifyMgr.IndentifyDelayTimeCnt == 0x0000 )	//��ǰ��������ģ�飬���ʶ���ٶ�
		{
			FaceRecognition_HardwarePowerOn();
		}
	}
	
	ComPort_Init();
	
	MFC_Init();
	Hardware_DelayMs(5);	
	
	TouchKeyRestart();
	Key_Init();
	
	GUI_Init();	

//	SET_VOLUME(VoiceMgr.volume);

	Hardware_DelayMs(1);
	
	for (i=0;i<20;i++)
	{
		if( i%10 == 0 )CLRWDT();
		Hardware_Task_Analog_Battery();
		HardwareBatteryMgr_Task();
	}
	if (( BatteryMgr.BatteryLevel == LEVEL_1 )||( BatteryMgr.BatteryLevel == LEVEL_0 ))
	{
		Hardware_DelayMs(100);CLRWDT();
		Hardware_DelayMs(100);CLRWDT();
		Hardware_DelayMs(100);CLRWDT();//wait 7916 init
		PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseReplaceTheBattery);
		BatteryMgr.TimeCnt = Def_MessageBoxTimeDelay;
		CurrentScreen = SCREEN_LowBattery;
		
		ComPort_SetPost_Info(DEF_WifiInfo_LowBattery,0x00,0x00);
		#if  (defined ProjectIs_BarLock_S15Z07) || (defined ProjectIs_BarLock_S15Z08) \
					|| (defined ProjectIs_BarLock_S15Z09)
		if( BatteryMgr.BatteryLevel == LEVEL_0 )
		{
			BatteryMgr.PowerSavingMode = bTRUE;
		}
		else{
			BatteryMgr.PowerSavingMode = bFALSE;
		}
		#endif
		
		#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
		Wifi_PostEvent(DEF_WifiEvent_LowBattery,0x00,0x00);
		#endif
	}
	else
	{
		GoIntoMainScreen_WithIdentifyInit();
		if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
		{
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseAddMasterFirst);
		}
		else
		{
			if ( (SystemPowerMgr.AwakeSource == KeyBoardTouch)
				&&(AwakeSystemKeyMgr.IsDoorBellKeyAwake !=bTRUE)
				)
			{
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_POWERON);	
			}
			
		}
	}
	
	SystemPowerMgr.SleepSource = SleepTimer;

	#ifdef Function_FPMBreathingLed
	for(i=0;i<25;i++)
	{
		CLRWDT();
		FpmAckMgr.Status = WaitACK;
		FPM_SetBreathingLED(1,1,1,255);		//Blue LED breathing
		Hardware_DelayMs(20);
		FPM_Mgr_Task();
		if ( FpmAckMgr.Status == GotACK )
		{
			break;
		}
	}
  #endif
	
}

/**************************************************
*�������ƣ�void LowPowerTimer_ISR(void)
*�������ܣd�͹���ģʽ�¶�ʱ���жϷ�������125ms����һ�Σ�
*��ڲ�����void
*���ڲ�����void  
**************************************************/
void LowPowerTimer_ISR(void) 
{
	LastIOStatus.HostAwakeInt = PINMACRO_HOST_AWAKE_INT_STATUS;
	LastIOStatus.AntiPryingInt = PINMACRO_PICKLOCK_STATUS;
	//LastIOStatus.RadarInt = PINMACRO_RADAR_INT_STATUS;
	#ifdef Function_USE_Internal_RTC
	SecondCount += 1;
	if( SecondCount >= 8 )
	{
		SecondCount = 0;
		G_SystemUTCTime += 1;
	}
	#endif
	if ( KeyWakeUpKeyWaitTime > 0 )
	{
		KeyWakeUpKeyWaitTime--;
	}
}

void Hardware_Awake_Driver(void)
{
	SET_HOST_AWAKE_INT_H;
	Hardware_DelayMs(2);
	SET_HOST_AWAKE_INT_L;
	Hardware_DelayMs(2);
}

