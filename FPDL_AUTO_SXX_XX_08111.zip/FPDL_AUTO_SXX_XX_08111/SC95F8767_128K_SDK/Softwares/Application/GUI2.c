#include "IO.h"
#include "usart.h"
//Protocol layer
#include "BeepMgr.h"
#include "EEPROM.h"
#include "Key_SinOne.h"
#include "LEDsMgr.h"
#include "RTC_PCF8563.h"
#include "Fingerprint.h"
#include "FaceRecoginitionMgr.h"
#include "HostUart.h"
#include "LCD_HFG12864.h"
#include "MFC_MF17622.h"
#include "PIR.h"
#include "Radar.h"
#ifdef Function_YouzhiyunjiaWifi 
#include "YouzhiyunjiaWifi.h"
#endif
//Logic layer
#include "AppUnlock.h"
#include "KeyScan.h"
#include "Motor.h"
#include "Log.h"
#include "FP.h"
#include "LCD.h"
#include "MFC.h"
#include "RTC.h"
#include "FaceGUI.h"
#include "LowPower.h"
//Application layer
#include "GUI.h"
#include "GUI2.h"
#include "GUI_Function.h"
#include "Basic_Function.h"
#include "Voice_Menu.h"
#include "Font_Menu.h"
#include "Font.h"

extern bool_t GUI_Flag_RefreshLCD;

/*******************************************************/
/*******************************************************/
bool_t IfSystemIsNoMaster(void)
{
	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		if ((CheckMemoryMgr.FpMasterNum == 0x00 )
			&&(CheckMemoryMgr.PasscodeMasterNum == 0x00 )
			&&(CheckMemoryMgr.FaceMasterNum == 0x00 )
			)
		{
			return bTRUE;
		}
		else
		{
			return bFALSE;
		}
	}
	else
	{
		if ( (CheckMemoryMgr.FpMasterNum == 0x00 )
			&&(CheckMemoryMgr.PasscodeMasterNum == 0x00 )
			)
		{
			return bTRUE;
		}
		else
		{
			return bFALSE;
		}
	}
}
/*******************************************************/
void ShowManagerIdentify(void)
{
	code uint8_t ManagerIdentifyStr[]={HZ_yan,HZ_zheng,HZ_guan,HZ_li,HZ_yuan,HZ_end};
	code uint8_t ManagerIdentifyStrEn1[]={"Authentication"};
	code uint8_t ManagerIdentifyStrEn2[]={"administrator"};
	code uint8_t TitleStr1[]={HZ_zhi,HZ_wen,HZ_ying,HZ_jianshu,HZ_bu,HZ_pi,HZ_pei,HZ_end};
	code uint8_t TitleStr2[]={HZ_qing,HZ_hui,HZ_fu,HZ_chu,HZ_chang,HZ_end};
	#ifdef ProjectIs_BarLock_S101Z01
	code uint16_t IdentifyMasterStr[]={VOICE_WaterDrop,VOICE_IdentifyMaster,DEF_VoiceSegmentEndFlag};
	code uint16_t IdentifyMasterStrEn[]={VOICE_WaterDrop-1,VOICE_IdentifyMaster,DEF_VoiceSegmentEndFlag};
	#endif
	uint8_t i;

	if ( ManagerIdentifyMgr.Status == StartManagerIdentify )
	{
		if ( IfSystemIsNoMaster() == bTRUE )
		{
			CurrentScreen = SCREEN_RegisterPasscodeUser;
			PasscodeUserRegisterMgr.Status = InputFirstPasscode;
			DataInputMgr.Status = InputIdle;
			PasscodeUserRegisterMgr.UserID = 0x01;
			PasscodeUserRegisterMgr.UserPriority = Master;
			#ifdef Function_FaceRecoginition			
			if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
			{
				FaceRecognition_PowerDown();
				//FaceRecognition_HardwarePowerOff();
			}
			#endif		
			
			PasscodeInputMgr.Point = 0x00;
			PasscodeInputMgr.PasscodeLen = 12;
			PasscodeInputMgr.Status = PasscodeInputStart;
			for (i=0;i<12;i++)
			{
				PasscodeInputMgr.InputBuff[i] = 0xFF;		//Initial passcode buffer
			}
			PasscodeUserRegisterMgr.TimeCnt = Def_WaitUserInputPasscodeTimeDelay;		
			GUI_Flag_RefreshLCD = bTRUE;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_AddNewMasterPleaseInputPasscode);
			
		}
		else
		{
			PasscodeInputMgr.Point = 0x00;
			PasscodeInputMgr.PasscodeLen = 16;
			PasscodeInputMgr.Status = PasscodeInputStart;
			PasscodeUserIdentifyMgr.Status = PasscodeIdentifyPasscodeInput;
			PasscodeUserIdentifyMgr.TimeCnt = 240;	//
			for (i=0;i<PasscodeInputMgr.PasscodeLen;i++)
			{
				PasscodeInputMgr.InputBuff[i]=0xff;
			}
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(2,28,ManagerIdentifyStr,NormalDisplay);
			}
			else
			{
				DisEN16x8Str(0,8,ManagerIdentifyStrEn1,NormalDisplay);
				DisEN16x8Str(2,12,ManagerIdentifyStrEn2,NormalDisplay);
			}
			
			//DisHZ16x14Str(4,16,Str2,NormalDisplay);
			ManagerIdentifyMgr.Status = IdentifyingManager;
			FpIdentifyMgr.Status = FPMcmdStart;
			#ifdef ProjectIs_BarLock_S101Z01
			if (SystemLanguage == Chinese){
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,IdentifyMasterStr);
			}
			else
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,IdentifyMasterStrEn);
			}
			#else
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_IdentifyMaster);
			#endif
		}
	}
	else if ( ManagerIdentifyMgr.Status == IdentifyingManager )
	{

		GUI_PasscodeInputCreat(6,16);
		
		if (PasscodeInputMgr.Status == PasscodeInputEnd)
		{
			ManagerIdentifyMgr.Status = ManagerIdentifyFail;	
			ManagerIdentifyMgr.PasscodeUserID = PasscodeIdendify( PasscodeInputMgr.InputBuff);
			if ( (ManagerIdentifyMgr.PasscodeUserID != 0x00 )
				&&(ManagerIdentifyMgr.PasscodeUserID < (DEF_MAX_PASSCODEMASTER+1) )
			   )
			{
				ManagerIdentifyMgr.Status = ManagerIdentifySuccess;
				GUI_SetFPM_LED(DEF_FpmLedMode_Flash,DEF_FpmLedColor_Green,DEF_FpmLedColor_Green,1);
				ManagerIdentifyMgr.MasterType = PASSCODEUSER;
				ManagerIdentifyMgr.TimeCnt = Def_GuiTimeDelayCnt01s;	
				//ManagerIdentifyMgr.PasscodeUserID = ManagerIdentifyMgr.PasscodeUserID;
			}
			GUI_Flag_RefreshLCD = bTRUE;
			PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;

			if ( ManagerIdentifyMgr.Status == ManagerIdentifyFail )
			{
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_IdentifyFail);
				GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Red,DEF_FpmLedColor_Red,255);
				ManagerIdentifyMgr.TimeCnt = Def_MessageBoxTimeDelay;	
				if ( SafetyMonitorMgr.ManagerPasscodeIdentifyFailedTimes < DEF_ManagerPasscodeIdentifyFailedTimesLimited )
				{
					SafetyMonitorMgr.ManagerPasscodeIdentifyFailedTimes++;
				}	
			}
			else
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_VerifySuccess);
			}
			
		}
		else if (PasscodeInputMgr.Status == PasscodeInputExit)
		{
			ManagerIdentifyMgr.Status = ManagerIdentifyExit;
			PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
		}

		FpUserIdentify();
		if ( (FpIdentifyMgr.Status == success)
			&&(FpIdentifyMgr.UserID < (DEF_MAX_FPMASTER) )
			)
		{
				ManagerIdentifyMgr.Status = ManagerIdentifySuccess;
				GUI_SetFPM_LED(DEF_FpmLedMode_Flash,DEF_FpmLedColor_Green,DEF_FpmLedColor_Green,1);
				ManagerIdentifyMgr.MasterType = FPUSER;
				ManagerIdentifyMgr.FpUserID = FpIdentifyMgr.UserID+1;
				ManagerIdentifyMgr.TimeCnt = Def_GuiTimeDelayCnt01s;
				FpIdentifyMgr.Status = FPMcmdStart;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_VerifySuccess);
		}
		else if (( FpIdentifyMgr.Status == fail)
				||( (FpIdentifyMgr.Status == success)&&((FpIdentifyMgr.UserID+1) > DEF_MAX_FPMASTER ))
			)
		{
			if (FpIdentifyMgr.ErrorType == Error_SerialNumberMismatched ){
				ManagerIdentifyMgr.ErrorType = FPMserialNumberMismatched;
			}
			else{
				ManagerIdentifyMgr.ErrorType = MasterMismatched;
			}
			FpIdentifyMgr.Status = FPMcmdStart;
			ManagerIdentifyMgr.Status = ManagerIdentifyFail;
			ManagerIdentifyMgr.TimeCnt = Def_MessageBoxTimeDelay;
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Red,DEF_FpmLedColor_Red,255);
			GUI_Flag_RefreshLCD = bTRUE;
			if ( SafetyMonitorMgr.ManagerFpIdentifyFailedTimes < DEF_ManagerFpIdentifyFailedTimesLimited )
			{
				SafetyMonitorMgr.ManagerFpIdentifyFailedTimes++;
			}	
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_IdentifyFail);
		}

		#ifdef Function_FaceRecoginition			
		if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
		{
			if ( PasscodeInputMgr.Point > 0 )
			{
				FaceIdentifyMgr.IndentifyDelayTimeCnt = Def_GuiTimeDelayCnt2s;
			}
			
			if ( FaceIdentifyMgr.IndentifyDelayTimeCnt > 0 )
			{
				 FaceIdentifyMgr.IndentifyDelayTimeCnt--;	 
			}
			if ((IfSystemIsNoFaceUser() == bFALSE )			//system is has face user
				&&( FaceIdentifyMgr.IndentifyDelayTimeCnt <= 0x0000 )			//
				)
			{
				FaceUserIdentify();
				if ( FaceIdentifyMgr.Status == FaceIdentifySuccess )
				{
					if ( GetUserIDbyFaceTemplateID(FrmMgr.UserID) <= DEF_MAX_FACEMASTER )
					{
						ManagerIdentifyMgr.Status = ManagerIdentifySuccess;
						ManagerIdentifyMgr.MasterType = FACEUSER;
						ManagerIdentifyMgr.FaceUserID = GetUserIDbyFaceTemplateID(FrmMgr.UserID);
						ManagerIdentifyMgr.TimeCnt = Def_GuiTimeDelayCnt01s;
						FaceIdentifyMgr.Status = FrmIdentifyStart;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_VerifySuccess);
						GUI_SetFPM_LED(DEF_FpmLedMode_Flash,DEF_FpmLedColor_Green,DEF_FpmLedColor_Green,1);
					}
				}
				else if ( FaceIdentifyMgr.Status == FaceIdentifyFail )
				{
					FaceIdentifyMgr.Status = FrmIdentifyStart;
					DEBUG_MARK;
				}
			}
			else
			{
				if ( FrmMgr.PowerStatus != FRM_PowerOff )
				{
					FaceRecognition_HardwarePowerOff();
				}	
			}
		}
		#endif			
		
	}
	else if ( ManagerIdentifyMgr.Status == ManagerIdentifySuccess )
	{
		if (ManagerIdentifyMgr.TimeCnt > 0 )
		{
			ManagerIdentifyMgr.TimeCnt--;
		}
		else
		{
			#ifdef Function_FaceRecoginition			
			if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
			{
				//FaceRecognition_PowerDown();
				FaceRecognition_HardwarePowerOff();
			}
			#endif		
			GoIntoMainMenu_Init();
			GUI_RefreshSleepTime();
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
			SafetyMonitorMgr.ManagerPasscodeIdentifyFailedTimes = 0x00;
			SafetyMonitorMgr.ManagerFpIdentifyFailedTimes = 0x00;
		}
		
	}
	else if ( ManagerIdentifyMgr.Status == ManagerIdentifyFail )
	{
		if (SystemLanguage == Chinese)
		{
			if (ManagerIdentifyMgr.ErrorType == FPMserialNumberMismatched ){
				DisHZ16x14Str(1,14,TitleStr1,NormalDisplay);
				DisHZ16x14Str(4,20,TitleStr2,NormalDisplay);
			}
			else{
				DisImage(1,52,24,24,Icon_Incorrect,NormalDisplay);
				DisHZ16x14Str(5,34,IdentifyFailStr,NormalDisplay);
			}
		}
		else
		{
			DisImage(1,52,24,24,Icon_Incorrect,NormalDisplay);
			DisEN16x8Str(5,18,IdentifyFailStrEn,NormalDisplay);
		}
		if (--ManagerIdentifyMgr.TimeCnt < 1 )
		{
			if ( SafetyMonitorMgr.ManagerPasscodeIdentifyFailedTimes >= DEF_ManagerPasscodeIdentifyFailedTimesLimited )
			{
				SafetyMonitorMgr.SystemLocked = bTRUE;
				SafetyMonitorMgr.SystemLockedTimeDelay = DEF_SystemLockedTime;
				ComPort_SetPost_Alarm(DEF_WifiAlarm_PasswordUnlockAlarm,PASSCODEUSER,0x00);
			}
			else if ( SafetyMonitorMgr.ManagerFpIdentifyFailedTimes >= DEF_ManagerFpIdentifyFailedTimesLimited )
			{
				SafetyMonitorMgr.SystemLocked = bTRUE;
				SafetyMonitorMgr.SystemLockedTimeDelay = DEF_SystemLockedTime;
				ComPort_SetPost_Alarm(DEF_WifiAlarm_FpUnlockAlarm,FPUSER,0x00);
			}
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
			GoIntoMainScreen_WithIdentifyInit();
		}
	}
	else if ( ManagerIdentifyMgr.Status == ManagerIdentifyExit )
	{
		GoIntoMainScreen_WithIdentifyInit();
	}

}

unsigned long mktime(unsigned int year0, unsigned int mon0,
        unsigned int day, unsigned int hour,
        unsigned int min, unsigned int sec)
{
    unsigned int mon = mon0, year = year0;

    /* 1..12 -> 11,12,1..10 */
    if (0 >= (int) (mon -= 2)) {
        mon += 12;    /* Puts Feb last since it has leap day */
        year -= 1;
    }

    return ((((unsigned long)
          (year/4 - year/100 + year/400 + 367*mon/12 + day) +
          year*365 - 719499
        )*24 + hour /* now have hours */
      )*60 + min /* now have minutes */
    )*60 + sec; /* finally seconds */
}

void ShowIdentifySuccessPage(void)
{
	code uint8_t DoorLockedStr[]={ZF_xiaoyuhao,HZ_yi,HZ_guanbi,HZ_suomen,ZF_dayuhao,HZ_end};//�ѹ���
	code uint8_t DoorLockedStrEn[]={"<Closed>"};	
	code uint8_t DoorUnlockedStr[]={ZF_xiaoyuhao,HZ_yi,HZ_kai,HZ_suomen,ZF_dayuhao,HZ_end};//�ѿ���
	code uint8_t DoorUnlockedStrEn[]={"<Opened>"}; 
	
	code uint8_t DoorLockingStr[]={HZ_zhengque,HZ_zaima,HZ_shang,HZ_suomen,HZ_end};//��������
	code uint8_t DoorLockingStrEn[]={"<Closing>"}; 
	code uint8_t DoorUnlockingStr[]={HZ_zhengque,HZ_zaima,HZ_kai,HZ_suomen,HZ_end};//���ڿ���
	code uint8_t DoorUnlockingStrEn[]={"Opening"};	
	
	code uint8_t InitialStatusStr[]={HZ_chuzhong,HZ_shizhong,HZ_zhuang,HZ_tai,HZ_end};//��ʼ״̬
	code uint8_t InitialStatusStrEn[]={"Initial"}; 

	code uint8_t RemoteUnlockStr[]={HZ_yuanchu,HZ_chengxu,HZ_kai,HZ_suomen,HZ_end};//Զ�̿���
	code uint8_t RemoteUnlockStrEn[]={"Remote"};

	code uint8_t ButtonUnlockStr[]={HZ_kai,HZ_suomen,HZ_anya,HZ_niu,HZ_end};//������ť
	code uint8_t ButtonUnlockStrEn[]={"Button"};

	if ( DisplayDoorStatusMgr.Status == DoorOpenInit )
	{
		if (UserIdentifyResultMgr.IdentifyType != InsideOpenDoor)
		{
			StrongUnlockMgr.CurrentUTCtime = mktime(2000+BCD_to_Hex(SystemTime.year), BCD_to_Hex(SystemTime.month),
			BCD_to_Hex(SystemTime.date), BCD_to_Hex(SystemTime.hour),
			BCD_to_Hex(SystemTime.minute), BCD_to_Hex(SystemTime.second));

			if ((StrongUnlockMgr.CurrentUTCtime > StrongUnlockMgr.LastUTCtime )
				&&((StrongUnlockMgr.CurrentUTCtime-StrongUnlockMgr.LastUTCtime)<DEF_StrongUnlockingIntervalLimited)
				)
			{
				StrongUnlockMgr.TrigStrongUnlocking = bTRUE;
				DEBUG_MARK;
			}
			else
			{
				StrongUnlockMgr.TrigStrongUnlocking = bFALSE;
				DEBUG_MARK;
			}
		}
		else
		{
			StrongUnlockMgr.TrigStrongUnlocking = bFALSE;
		}
		#ifdef Function_FaceRecoginition			
		if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
		{
			FaceRecognition_PowerDown();
			//FaceRecognition_HardwarePowerOff();
		}
		#endif
	
		if (  ( UserIdentifyResultMgr.IdentifyType != RemoteUnlock )
		&&( UserIdentifyResultMgr.IdentifyType != InsideOpenDoor)  )
		{
			DEBUG_MARK;
			
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_VerifySuccess);
			
			GUI_CreatNewLog(OpenDoor);//for posting info to host
			if (LogMgr.NewLog.LogOrType._Bit.UserType == ONLINEPASSCODEUSER )
			{
				ComPort_SetPost_OpenDoor(LogMgr.NewLog.LogOrType._Bit.UserType,WifiMgr.WifiOnlinePasswordVerifyMgr.UserID);
			}
			else
			{
				ComPort_SetPost_OpenDoor(LogMgr.NewLog.LogOrType._Bit.UserType,LogMgr.NewLog.UserID);
			}
		}

		DisplayDoorStatusMgr.Status = OpenDoorWaitForMotorStatusChangeFromStandby;
		DisplayDoorStatusMgr.MotorStatusIsChangedFromStandby = bFALSE;
		DisplayDoorStatusMgr.TimeCnt = Def_GuiTimeDelayCnt4s;
		UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;

		//GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Green,DEF_FpmLedColor_Green,255);	
	}

	
	else if (DisplayDoorStatusMgr.Status == DoorCloseInit)
	{
		#ifdef Function_FaceRecoginition			
		if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
		{
			FaceRecognition_PowerDown();
			//FaceRecognition_HardwarePowerOff();
		}
		#endif		
		
		if ( UserIdentifyResultMgr.IdentifyType == OutsideCloseDoor )
		{
			ComPort_SetPost_CloseDoor();
		}
		DisplayDoorStatusMgr.Status = CloseDoorWaitForMotorStatusChangeFromStandby;
		DisplayDoorStatusMgr.MotorStatusIsChangedFromStandby = bFALSE;
		DisplayDoorStatusMgr.TimeCnt = Def_GuiTimeDelayCnt4s;
		UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;
	}
	
	else if (( DisplayDoorStatusMgr.Status == OpenDoorWaitForMotorStatusChangeFromStandby )
		||( DisplayDoorStatusMgr.Status == CloseDoorWaitForMotorStatusChangeFromStandby ))
	{
		if ( ComportMgr.DoorStatus != Standby)
		{
			DisplayDoorStatusMgr.MotorStatusIsChangedFromStandby = bTRUE;
		}
		if ( DisplayDoorStatusMgr.TimeCnt >0 )
		{
			DisplayDoorStatusMgr.TimeCnt--;
			if( ( DisplayDoorStatusMgr.Status == OpenDoorWaitForMotorStatusChangeFromStandby )&&
				( DisplayDoorStatusMgr.TimeCnt == Def_GuiTimeDelayCnt2s ) )
			{
				GUI_CreatAndSaveLog(OpenDoor);
			}
		}
		else
		{
			DisplayDoorStatusMgr.MotorStatusIsChangedFromStandby = bTRUE;
			if ( DisplayDoorStatusMgr.Status == OpenDoorWaitForMotorStatusChangeFromStandby )
			{
				DisplayDoorStatusMgr.Status = DoorOpenning;
			}
			else
			{
				DisplayDoorStatusMgr.Status = DoorClosing;
			}
		}
	}
		
	if (DisplayDoorStatusMgr.MotorStatusIsChangedFromStandby == bTRUE)
	{
		if (ComportMgr.DoorStatus == Openning) 
		{
			DisplayDoorStatusMgr.Status = DoorOpenning;
		}
		else if (ComportMgr.DoorStatus == Open) 
		{
			if ( DisplayDoorStatusMgr.Status == DoorOpenning )
			{
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_DoorOpened);
				GUI_SetFPM_LED(DEF_FpmLedMode_Off,DEF_FpmLedColor_All,DEF_FpmLedColor_All,1);
			}
			DisplayDoorStatusMgr.Status = DoorOpened;
		}
		else if (ComportMgr.DoorStatus == OpenedWaitClose) 
		{
			if ( DisplayDoorStatusMgr.Status == DoorOpenning )
			{
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_DoorOpened);
				GUI_SetFPM_LED(DEF_FpmLedMode_Off,DEF_FpmLedColor_All,DEF_FpmLedColor_All,1);
			}
			DisplayDoorStatusMgr.Status = DoorOpenedWaitClose;
		}
		else if (ComportMgr.DoorStatus == Closing) 
		{
			if ( DisplayDoorStatusMgr.Status != DoorClosing )
			{
				DisplayDoorStatusMgr.Status = DoorClosing;
				if (BatteryMgr.BatteryType == LiBattery)
				{
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_DoingLock);
				}
			}
		}
		else if (ComportMgr.DoorStatus == Close) 
		{
			DisplayDoorStatusMgr.Status = DoorClosed;
		}
		else if (ComportMgr.DoorStatus == Standby) 
		{
			if ( (DisplayDoorStatusMgr.Status == DoorClosing)
				||( DisplayDoorStatusMgr.Status == DoorClosed))
			{
				if (DisplayDoorStatusMgr.Status == DoorClosing)
				{
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_DoorClosed);
				}
				UserIdentifyResultMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
				SystemPowerMgr.SleepDelayTimerCnt = Def_GuiTimeDelayCnt3s;			
				DisplayDoorStatusMgr.Status = DisplayCloseDoorEnd;
	
			}
			else if (( DisplayDoorStatusMgr.Status == DoorOpenning)
					||( DisplayDoorStatusMgr.Status == DoorOpened)
					||( DisplayDoorStatusMgr.Status == DoorOpenedWaitClose)
					)
			{
				//PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_DoorOpened);
				UserIdentifyResultMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
				SystemPowerMgr.SleepDelayTimerCnt = Def_GuiTimeDelayCnt3s;	
				DisplayDoorStatusMgr.Status = DisplayOpenDoorEnd;
			}
			else
			{
				DEBUG_MARK;
			}
			
		}
		else
		{
			DEBUG_MARK;
		}
	}

	if (( AwakeDisplayMgr.DisplayType != DisplayHide)
			&&(BatteryMgr.BatteryType == LiBattery)
		)
	{
		GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Green,DEF_FpmLedColor_Green,255);
	}
	else
	{
		GUI_SetFPM_LED(DEF_FpmLedMode_Off,DEF_FpmLedColor_All,DEF_FpmLedColor_All,255);
	}

	if (( AwakeDisplayMgr.DisplayType != DisplayHide)
		||(BatteryMgr.BatteryType == LiBattery)
		)
	{
		if ( ( DisplayDoorStatusMgr.Status == OpenDoorWaitForMotorStatusChangeFromStandby )
			||( DisplayDoorStatusMgr.Status == DoorOpenning )
			||( DisplayDoorStatusMgr.Status == DoorOpened )
			||( DisplayDoorStatusMgr.Status == DoorOpenedWaitClose )
			||( DisplayDoorStatusMgr.Status == DisplayOpenDoorEnd )
			)
		{

			DisImage(0,72,52,40,Icon_Unlocked,NormalDisplay);
			
			if ( UserIdentifyResultMgr.IdentifyType == CARD )
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(2,0,CardUserStr,NormalDisplay);
					DisHZ16x14Str(4,0,IDStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(2,0,CardUserStrEn,NormalDisplay);
					DisEN16x8Str(4,0,IDStrEn,NormalDisplay);
				}
			
				DisDigital16x8Str(4,36,UserIdentifyResultMgr.CardUserID,NormalDisplay);
			}
			else if ( UserIdentifyResultMgr.IdentifyType == FINGERPRINT )
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(2,0,FpUserStr,NormalDisplay);
					DisHZ16x14Str(4,0,IDStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(2,0,FpUserStrEn,NormalDisplay);
					DisEN16x8Str(4,0,IDStrEn,NormalDisplay);
				}
			
				DisDigital16x8Str(4,36,UserIdentifyResultMgr.FPUserID,NormalDisplay);
			}
			else if (UserIdentifyResultMgr.IdentifyType == PASSCODE )
			{

				if (SystemLanguage == Chinese){
					DisHZ16x14Str(2,0,PasscodeUserStr,NormalDisplay);
					DisHZ16x14Str(4,0,IDStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(2,0,PasscodeUserStrEn,NormalDisplay);
					DisEN16x8Str(4,0,IDStrEn,NormalDisplay);
				}
				
				DisDigital16x8Str(4,36,UserIdentifyResultMgr.PasscodeUserID,NormalDisplay);
			}
			else if (UserIdentifyResultMgr.IdentifyType == FACE )
			{

				if (SystemLanguage == Chinese){
					DisHZ16x14Str(2,0,FaceUserStr,NormalDisplay);
					DisHZ16x14Str(4,0,IDStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(2,0,FaceUserStrEn,NormalDisplay);
					DisEN16x8Str(4,0,IDStrEn,NormalDisplay);
				}
				
				DisDigital16x8Str(4,36,UserIdentifyResultMgr.FaceUserID,NormalDisplay);
			}
			else if (UserIdentifyResultMgr.IdentifyType == ONLINEPASSCODE )
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(2,0,TemporaryPasswordStr,NormalDisplay);
					DisHZ16x14Str(4,0,IDStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(2,0,TemporaryPasswordStrEn,NormalDisplay);
					DisEN16x8Str(4,0,IDStrEn,NormalDisplay);
				}

				DisDigital16x8Str(4,36,UserIdentifyResultMgr.PasscodeUserID,NormalDisplay);
			}
			
			else if (UserIdentifyResultMgr.IdentifyType == FINGERPRINTandCARD ){
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(0,0,FpUserStr,NormalDisplay);
					DisHZ16x14Str(2,0,IDStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(0,0,FpUserStrEn,NormalDisplay);
					DisEN16x8Str(2,0,IDStrEn,NormalDisplay);
				}
				DisDigital16x8Str(2,36,UserIdentifyResultMgr.FPUserID,NormalDisplay);
				
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(4,0,CardUserStr,NormalDisplay);
					DisHZ16x14Str(6,0,IDStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(4,0,CardUserStrEn,NormalDisplay);
					DisEN16x8Str(6,0,IDStrEn,NormalDisplay);
				}
				DisDigital16x8Str(6,36,UserIdentifyResultMgr.CardUserID,NormalDisplay); 	
			}
			else if (UserIdentifyResultMgr.IdentifyType == FINGERPRINTandPASSCODE ){
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(0,0,FpUserStr,NormalDisplay);
					DisHZ16x14Str(2,0,IDStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(0,0,FpUserStrEn,NormalDisplay);
					DisEN16x8Str(2,0,IDStrEn,NormalDisplay);
				}
				DisDigital16x8Str(2,36,UserIdentifyResultMgr.FPUserID,NormalDisplay);
				
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(4,0,PasscodeUserStr,NormalDisplay);
					DisHZ16x14Str(6,0,IDStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(4,0,PasscodeUserStrEn,NormalDisplay);
					DisEN16x8Str(6,0,IDStrEn,NormalDisplay);
				}
				DisDigital16x8Str(6,36,UserIdentifyResultMgr.PasscodeUserID,NormalDisplay); 
			}
			else if (UserIdentifyResultMgr.IdentifyType == CARDandPASSCODE ){
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(0,0,CardUserStr,NormalDisplay);
					DisHZ16x14Str(2,0,IDStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(0,0,CardUserStrEn,NormalDisplay);
					DisEN16x8Str(2,0,IDStrEn,NormalDisplay);
				}
				DisDigital16x8Str(2,36,UserIdentifyResultMgr.CardUserID,NormalDisplay);
				
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(4,0,PasscodeUserStr,NormalDisplay);
					DisHZ16x14Str(6,0,IDStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(4,0,PasscodeUserStrEn,NormalDisplay);
					DisEN16x8Str(6,0,IDStrEn,NormalDisplay);
				}
				DisDigital16x8Str(6,36,UserIdentifyResultMgr.PasscodeUserID,NormalDisplay); 
			}
			else if (UserIdentifyResultMgr.IdentifyType == INITIALSTATUS ){
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(2,0,InitialStatusStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(2,0,InitialStatusStrEn,NormalDisplay);
				}
			}
			else if (UserIdentifyResultMgr.IdentifyType == RemoteUnlock )
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(2,0,RemoteUnlockStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(2,0,RemoteUnlockStrEn,NormalDisplay);
				}
			}
			else //if (UserIdentifyResultMgr.IdentifyType == InsideOpenDoor)
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(2,0,ButtonUnlockStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(2,0,ButtonUnlockStrEn,NormalDisplay);
				}
			}
			
			if (  ( DisplayDoorStatusMgr.Status == DoorOpened )  
				||( DisplayDoorStatusMgr.Status == DoorOpenedWaitClose )
				||( DisplayDoorStatusMgr.Status == DisplayOpenDoorEnd )
				)
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(6,64,DoorUnlockedStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(6,60,DoorUnlockedStrEn,NormalDisplay);
				}
			}
			else
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(6,64,DoorUnlockingStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(6,60,DoorUnlockingStrEn,NormalDisplay);
				}
			}		
		}
		else if (( DisplayDoorStatusMgr.Status == CloseDoorWaitForMotorStatusChangeFromStandby) 
				||( DisplayDoorStatusMgr.Status == DoorClosing )	
				)
		{
			GUI_Flag_RefreshLCD = bTRUE;
			DisImage(0,44,40,40,Icon_Locked,NormalDisplay);
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(6,36,DoorLockingStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(6,32,DoorLockingStrEn,NormalDisplay);
			}
		}
		else if (( DisplayDoorStatusMgr.Status == DoorClosed )
				||( DisplayDoorStatusMgr.Status == DisplayCloseDoorEnd )
				)
		{
			GUI_Flag_RefreshLCD = bTRUE;
			DisImage(0,44,40,40,Icon_Locked,NormalDisplay);

			if (SystemLanguage == Chinese){
				DisHZ16x14Str(6,36,DoorLockedStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(6,32,DoorLockedStrEn,NormalDisplay);
			}	
		}
	}
	
	if ( UserIdentifyResultMgr.TimeCnt > 0 )
	{
		UserIdentifyResultMgr.TimeCnt--;
	}
	else 
	{
		if (UserIdentifyResultMgr.IdentifyType != InsideOpenDoor)
		{
			StrongUnlockMgr.LastUTCtime = mktime(2000+BCD_to_Hex(SystemTime.year), BCD_to_Hex(SystemTime.month),
			BCD_to_Hex(SystemTime.date), BCD_to_Hex(SystemTime.hour),
			BCD_to_Hex(SystemTime.minute), BCD_to_Hex(SystemTime.second));
		}
				
		SystemPowerMgr.SleepDelayTimerCnt = 0x0000; //go to sleep

		BodyInductionMgr.BodyInductionDelayTimeCnt = Def_BodyInductionDelayTime_AntiTurningBack;
		BodyInductionMgr.BodyInductionInvalidTimes = 0;
		BodyInductionMgr.BodyInductionBeLimited = bFALSE;
		
		UserIdentifyResultMgr.CardIdentifyStatus = S_FAIL;
		UserIdentifyResultMgr.FPIdentifyStatus = S_FAIL;
		UserIdentifyResultMgr.PasscodeIdentifyStatus = S_FAIL;
		UserIdentifyResultMgr.FaceIdentifyStatus = S_FAIL;
		
		//GoIntoMainScreen_WithIdentifyInit();		

		GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
		
		GoIntoMainScreen_WithIdentifyInit();
	}

}


void ShowIdentifyFailPage(void)//��֤ʧ��ҳ��
{
	code uint8_t TitleStr1[]={HZ_zhi,HZ_wen,HZ_ying,HZ_jianshu,HZ_bu,HZ_pi,HZ_pei,HZ_end};
	code uint8_t TitleStr2[]={HZ_qing,HZ_hui,HZ_fu,HZ_chu,HZ_chang,HZ_end};

	DisImage(0,52,24,24,Icon_Incorrect,NormalDisplay);
	
	if ( UserIdentifyResultMgr.IdentifyType == CARD )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(5,36,IdentifyFailStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(5,12,IdentifyFailStrEn,NormalDisplay);
		}
	}
	else if ( UserIdentifyResultMgr.IdentifyType == FINGERPRINT )
	{
		if (SystemLanguage == Chinese)
		{
			if ( UserIdentifyResultMgr.ErrorType == FPMserialNumberMismatched ){
				DisHZ16x14Str(4,14,TitleStr1,NormalDisplay);
				DisHZ16x14Str(6,20,TitleStr2,NormalDisplay);
			}
			else{
				DisHZ16x14Str(5,36,IdentifyFailStr,NormalDisplay);
			}
		}
		else{
			DisEN16x8Str(5,12,IdentifyFailStrEn,NormalDisplay);
		}
	}
	else if (UserIdentifyResultMgr.IdentifyType == PASSCODE )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(5,36,IdentifyFailStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(5,12,IdentifyFailStrEn,NormalDisplay);
		}
	}
	
	if ( UserIdentifyResultMgr.TimeCnt > 0 )
	{
		if ( UserIdentifyResultMgr.TimeCnt == Def_MessageBoxTimeDelay )
		{
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Red,DEF_FpmLedColor_Red,255);
		}
		
		UserIdentifyResultMgr.TimeCnt--;
	}
	else
	{
		GoIntoMainScreen_WithIdentifyInit();
		GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
	}
}























void ShowInitialization(void)
{
	
	//DisHZ16x14Str(2,16,Str,NormalDisplay);
	uint8_t i;
	code uint8_t SystenRebootStr[]={HZ_xi,HZ_tong,HZ_qidong,HZ_dong,HZ_end};
	code uint8_t SystenRebootStr_En[]={"[Rebooting]"};
	code uint8_t FingprintStr[]={HZ_zhi,HZ_wen,HZ_end}; 
	code uint8_t FingprintStr_En[]={"Fingerprint"}; 
	code uint8_t CardReaderStr[]={HZ_du,HZ_ka,HZ_end}; 
	code uint8_t CardReaderStr_En[]={"Card Reader"}; 	
	code uint8_t EepromStr[]={HZ_nei,HZ_cun,HZ_end}; 
	code uint8_t EepromStr_En[]={"Memory"}; 
	code uint8_t TouchStr[]={HZ_chumo,HZ_motou,HZ_end}; 
	code uint8_t TouchStr_En[]={"Touch"}; 
	code uint8_t SystemCheckPassStr[]={HZ_xi,HZ_tong,HZ_zhengque,HZ_changchang,HZ_end}; 
	code uint8_t SystemCheckPassStr_En[]={"System OK"}; 
	code uint8_t SystemCheckFailStr[]={HZ_xi,HZ_tong,HZ_bu,HZ_zhengque,HZ_changchang,HZ_end}; 
	code uint8_t SystemCheckFailStr_En[]={"System NG"}; 	

	if ( InitializationMgr.Status == StartInitialization )
	{
		//SystemConfigLoad();
		if ( SystemLanguage == Chinese ){
			DisEN16x8Str(1,28,"[",NormalDisplay);	//display "["
			DisHZ16x14Str(1,36,SystenRebootStr,NormalDisplay);	//display "reboot"
			DisEN16x8Str(1,92,"]",NormalDisplay);	//display "]"
		}
		else{
			DisEN16x8Str(1,20,SystenRebootStr_En,NormalDisplay);	//display "reboot"
		}		
		CheckMemoryMgr.Status = StartCheckMemory;
		InitializationMgr.Status = MemoryCheck;
	}
	else if ( InitializationMgr.Status == MemoryCheck )
	{
	
		if ( SystemLanguage == Chinese ){
			DisHZ16x14Str(4,36,EepromStr,NormalDisplay);//display "EEPROM TEST"
		}
		else{
			DisEN16x8Str(4,40,EepromStr_En,NormalDisplay);
		}
		//SystemConfigLoad();
		ReadLockBrand();

		InitializationMgr.MemoryCheckPass = bTRUE;
		InitializationMgr.Status = MemoryCheckWait;
		InitializationMgr.TimeCnt = Def_GuiTimeDelayCnt1s5;
		PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_Beep);
	}
	else if ( InitializationMgr.Status == MemoryCheckWait )
	{
		if (InitializationMgr.MemoryCheckPass == bTRUE)
		{	
			DisImage(4,105,16,16,Icon_Pass,NormalDisplay);
		}
		else
		{
			DisImage(4,105,16,16,Icon_Fail,NormalDisplay);
		}
		if (--InitializationMgr.TimeCnt < 1 )
		{	
			InitializationMgr.Status = FingerPrintCheck;
			Clear_Screen_Page(4);
			Clear_Screen_Page(5);
			if ( SystemLanguage == Chinese ){
				DisHZ16x14Str(4,36,FingprintStr,NormalDisplay);	//display "FPM TEST"
			}
			else{
				DisEN16x8Str(4,4,FingprintStr_En,NormalDisplay);
			}
		}
	}

	else if ( InitializationMgr.Status == FingerPrintCheck )
	{
		GUI_GetUserNumList();		//read user number
		if ( CheckMemoryMgr.Status == CheckMemorySuccess )
		{
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);

			FpmAckMgr.Status = WaitACK;
			FpmAckMgr.TimeOutCnt = DEF_FpmAckTimeoutTime;
			FPM_TurnOffAntiFakeFp();
			for (i=0;i<25;i++)
			{
				Hardware_DelayMs(10);
				FPM_Mgr_Task();
				if ( FpmAckMgr.Status == GotACK )
				{
					break;
				}
			}

			InitializationMgr.FingerPrintCheckPass = bTRUE;
			InitializationMgr.Status = FingerPrintCheckWait;
			InitializationMgr.TimeCnt = Def_GuiTimeDelayCnt1s;
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_Beep);
			
		}
		else if  ( CheckMemoryMgr.Status == CheckMemoryFail )
		{	
			InitializationMgr.FingerPrintCheckPass = bFALSE;
			InitializationMgr.Status = FingerPrintCheckWait;
			InitializationMgr.TimeCnt = Def_GuiTimeDelayCnt1s;
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_FailVoice);
		}
	}
	else if  ( InitializationMgr.Status == FingerPrintCheckWait )
	{
		if (InitializationMgr.FingerPrintCheckPass == bTRUE)
		{	
			DisImage(4,105,16,16,Icon_Pass,NormalDisplay);
		}
		else
		{
			DisImage(4,105,16,16,Icon_Fail,NormalDisplay);
		}
		if (--InitializationMgr.TimeCnt < 1 )
		{
			InitializationMgr.Status = CardReaderCheck;
			Clear_Screen_Page(4);
			Clear_Screen_Page(5);	
			DisHZ16x14Str(4,36,CardReaderStr,NormalDisplay); 
			if ( SystemLanguage == Chinese ){
				DisHZ16x14Str(4,36,CardReaderStr,NormalDisplay); 
			}
			else{
				DisEN16x8Str(4,4,CardReaderStr_En,NormalDisplay);
			}
		}
	}
	else if ( InitializationMgr.Status == CardReaderCheck )
	{
		InitializationMgr.CardReaderCheckPass = bTRUE;
		InitializationMgr.Status = CardReaderCheckWait;
		InitializationMgr.TimeCnt = Def_GuiTimeDelayCnt1s;
		PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_Beep);
	}
	else if ( InitializationMgr.Status == CardReaderCheckWait )
	{
		if (InitializationMgr.CardReaderCheckPass == bTRUE)
		{	
			DisImage(4,105,16,16,Icon_Pass,NormalDisplay);
		}
		else
		{
			DisImage(4,105,16,16,Icon_Fail,NormalDisplay);
		}
		if (--InitializationMgr.TimeCnt < 1 )
		{
			InitializationMgr.Status = TouchCheck;
			Clear_Screen_Page(4);
			Clear_Screen_Page(5);	
			if ( SystemLanguage == Chinese ){
				DisHZ16x14Str(4,36,TouchStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,36,TouchStr_En,NormalDisplay);
			}
		}
	}
	else if ( InitializationMgr.Status == TouchCheck )
		{
			InitializationMgr.TouchCheckPass = bTRUE;
			InitializationMgr.Status = TouchCheckWait;
			InitializationMgr.TimeCnt = Def_GuiTimeDelayCnt1s;
 
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_Beep);
		}
	else if ( InitializationMgr.Status == TouchCheckWait )
		{
			if (InitializationMgr.TouchCheckPass == bTRUE)
			{	
				DisImage(4,105,16,16,Icon_Pass,NormalDisplay);
			}
			else
			{
				DisImage(4,105,16,16,Icon_Fail,NormalDisplay);
			}
			if (--InitializationMgr.TimeCnt < 1 )
			{
				Clear_Screen_Page(4);
				Clear_Screen_Page(5);
				InitializationMgr.Status = CheckFinished;
				InitializationMgr.TimeCnt = Def_GuiTimeDelayCnt1s;
				if( (InitializationMgr.FingerPrintCheckPass == bTRUE )
					&&(InitializationMgr.MemoryCheckPass == bTRUE )
					&&(InitializationMgr.CardReaderCheckPass == bTRUE )
					&&(InitializationMgr.TouchCheckPass == bTRUE )
				)
				{
					if ( SystemLanguage == Chinese ){
						DisHZ16x14Str(4,36,SystemCheckPassStr,NormalDisplay);
					}
					else{
						DisEN16x8Str(4,24,SystemCheckPassStr_En,NormalDisplay);
					}
				}
				else{
					if ( SystemLanguage == Chinese ){
						DisHZ16x14Str(4,28,SystemCheckFailStr,NormalDisplay);
					}
					else{
						DisEN16x8Str(4,24,SystemCheckFailStr_En,NormalDisplay);
					}
				}
			}
		}

	
	else if ( InitializationMgr.Status == CheckFinished )
	{
		if (--InitializationMgr.TimeCnt < 1 )
		{
			ComportMgr.TimeSyncWithNetwork = bTRUE;
			if (( BatteryMgr.BatteryLevel == LEVEL_0 )||( BatteryMgr.BatteryLevel == LEVEL_1 ))
			{
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseReplaceTheBattery);
				BatteryMgr.PostLowBattery = bFALSE;
				BatteryMgr.TimeCnt = Def_MessageBoxTimeDelay;
				CurrentScreen = SCREEN_LowBattery;	
				
				ComPort_SetPost_Info(DEF_WifiInfo_LowBattery,0x00,0x00);
				
				#if (defined ProjectIs_BarLock_S15Z07) || (defined ProjectIs_BarLock_S15Z08) \
					|| (defined ProjectIs_BarLock_S15Z09)
				if( BatteryMgr.BatteryLevel == LEVEL_0 )
				{
					BatteryMgr.PowerSavingMode = bTRUE;
				}
				else{
					BatteryMgr.PowerSavingMode = bFALSE;
				}
				#endif
		
				#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
				Wifi_PostEvent(DEF_WifiEvent_LowBattery,0x00,0x00);
				#endif
			
			}
			else
			{
				GoIntoMainScreen_WithIdentifyInit();
              	PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_POWERON);
			}
		}
	}
		
}

void ShowLowBattery(void)
{
		if ( SystemLanguage == Chinese ){
			DisImage(0,50,27,24,Icon_Warning,NormalDisplay);
			DisImage(5,4,120,24,Icon_ReplaceBattery,NormalDisplay);
		}
		else{
			DisImage(0,50,27,24,Icon_Warning,NormalDisplay);
			DisEN16x8Str(4,0,ReplaceBatteryStr1En,NormalDisplay); 
			DisEN16x8Str(6,0,ReplaceBatteryStr2En,NormalDisplay); 
		}	
	
	if ( BatteryMgr.LowBatteryProtectionEnabled == bFALSE)
	{
		if (--BatteryMgr.TimeCnt < 1 )
		{
			GoIntoMainScreen_WithIdentifyInit();
			if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
			{
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseAddMasterFirst);
				
				GUI_RefreshSleepTime();
				Clear_Screen();
				//DisHZ16x14Str(3,14,AddMasterStr,NormalDisplay);
			}
			else
			{
				Clear_Screen();
				//PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleasePutFingerOrCardOrPasscode);
			}
		}
	}
	
	
	
	
}

void ShowSelfTest(void)
{
	
	code uint8_t Str1[]={"LEDs,KEY,Voice"}; 
	code uint8_t Str2[]={HZ_zhi,HZ_wen,HZ_end};  
	code uint8_t Str3[]={HZ_ren,HZ_lianbu,HZ_end};  
	code uint8_t Str4[]={HZ_ren,HZ_tiyan,HZ_gan,HZ_yingda,HZ_end};  
	code uint8_t Str5[]={HZ_nei,HZ_cun,HZ_end}; 
	code uint8_t Str6[]={HZ_tongyong,HZ_xunfei,HZ_end};
	code uint8_t Str7[]={HZ_ka,HZ_pian,HZ_end};
	code uint8_t Str8[]={"Voltage"}; 
	code uint8_t Str9[]={"LOW POWER TEST"}; 
	
	//code uint8_t PASSstr[]={"PASS"}; 
	code uint8_t S_FAILstr[]={"S_FAIL"}; 
  uint8_t TestByte;
	status_t GetCardID;
	uint8_t TestCardCID[5];
	//keycode_t TestKeyCode;
	
	if ( SelfTestMgr.Status == SELFTEST_START )
	{
    SelfTestMgr.Status = VoiceAndTouchAndLEDs_TEST;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_ZERO_OK = bFALSE;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_ONE_OK = bFALSE;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_TWO_OK = bFALSE;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_THREE_OK = bFALSE;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_FOUR_OK = bFALSE;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_FIVE_OK = bFALSE;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_SIX_OK = bFALSE;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_SEVEN_OK = bFALSE;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_EIGHT_OK = bFALSE;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_NINE_OK = bFALSE;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_ASTERISK_OK = bFALSE;
		SelfTestMgr.TouchKeySelfTestStatus.KEY_POUNDSIGN_OK = bFALSE;
		
		#ifdef  Function_IndependentDoorBellKey
		SelfTestMgr.TouchKeySelfTestStatus.KEY_DOORBELL_OK = bFALSE;
		#else
		SelfTestMgr.TouchKeySelfTestStatus.KEY_DOORBELL_OK = bTRUE;
		#endif
		
		#ifdef  Function_IndependentLockKey
		SelfTestMgr.TouchKeySelfTestStatus.KEY_DOORCLOSE_OK = bFALSE;
		#else
		SelfTestMgr.TouchKeySelfTestStatus.KEY_DOORCLOSE_OK = bTRUE;
		#endif
		
		SET_ALLKEYLED_ON();
		SET_LEDRGB_R_ON;
		SET_LEDRGB_G_ON;
		SET_LEDRGB_B_ON;
		SET_LED_RB_R_ON;
		SET_LED_RB_B_ON;
		DisEN16x8Str(2,8,Str1,NormalDisplay);
		
	}
	else if ( SelfTestMgr.Status == VoiceAndTouchAndLEDs_TEST )
	{

		if ((SelfTestMgr.TouchKeySelfTestStatus.KEY_ZERO_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_ONE_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_TWO_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_THREE_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_FOUR_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_FIVE_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_SIX_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_SEVEN_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_EIGHT_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_NINE_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_ASTERISK_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_POUNDSIGN_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_DOORCLOSE_OK == bTRUE )
			&&( SelfTestMgr.TouchKeySelfTestStatus.KEY_DOORBELL_OK == bTRUE)
			)
			{
				SET_LEDRGB_R_OFF;
				SET_LEDRGB_G_OFF;
				SET_LEDRGB_B_OFF;
				SET_LED_RB_R_OFF;
				SET_LED_RB_B_OFF;
				SelfTestMgr.Status = Display_TEST;
				SelfTestMgr.TimeCnt = Def_GuiTimeDelayCnt5s;
				PLAY_VOICE_MULTISEGMENTS(3,VoiceStr_OperationSuccess);
				Display_FullScreen();
			}
	}
	
	else if ( SelfTestMgr.Status == Display_TEST )
	{
		SelfTestMgr.TimeCnt--;
		if ( SelfTestMgr.TimeCnt > Def_GuiTimeDelayCnt2s )
		{
			Display_FullScreen();
			
		}
		else if ( SelfTestMgr.TimeCnt > 0 )
		{
			Clear_Screen();
		}
		else
		{
			PLAY_VOICE_ONESEGMENT(3,VOICE_PleasePutFinger);
			SelfTestMgr.Status = FPM_TEST;
		}
	}
	else if ( SelfTestMgr.Status == FPM_TEST )
	{
		DisHZ16x14Str(3,50,Str2,NormalDisplay);
		FPMcmd_Excute();
		if (FpmAckMgr.Status == GotACK)
		{
			if ( FpmAckMgr.ErrorCode == Error_NONE)
			{
				if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
				{
					SelfTestMgr.Status = FRM_TEST;
					SelfTestMgr.TimeCnt = 0x0000;
					PLAY_VOICE_ONESEGMENT(3,VOICE_FaceVerifyInProgress);
					GUI_Flag_RefreshLCD = bTRUE;
				}
				else
				{
					SelfTestMgr.Status = RFID_TEST;
					PLAY_VOICE_ONESEGMENT(3,VOICE_PleaseSwingCard);
					GUI_Flag_RefreshLCD = bTRUE;
				}
			}
		}
		if ( SelfTestMgr.TimeCnt > 0)
		{
			SelfTestMgr.TimeCnt--;
		}
		else {
			FPM_SendGetImageCmd();
			FpmAckMgr.Status = WaitACK;
			FpmAckMgr.TimeOutCnt = DEF_FpmAckTimeoutTime;
			SelfTestMgr.TimeCnt = Def_GuiTimeDelayCnt05s;
		}
		
	}

	else if ( SelfTestMgr.Status == FRM_TEST )
	{
		DisHZ16x14Str(3,50,Str3,NormalDisplay);
		if ( SelfTestMgr.TimeCnt > 0)
		{
			SelfTestMgr.TimeCnt--;
			#ifdef Function_FaceRecoginition					
			if (SelfTestMgr.TimeCnt == Def_GuiTimeDelayCnt2s)
			{
				FaceRecognition_Reset();
			}
			#endif			
		}
		else
		{
			if ( FrmMgr.PostFlag_ResetResult == bTRUE)
			{
				PLAY_VOICE_ONESEGMENT(3,VOICE_BodyInduction);
				GUI_Flag_RefreshLCD = bTRUE;
				SelfTestMgr.Status = BODYINDUCTION_TEST;
				SelfTestMgr.TimeCnt = Def_GuiTimeDelayCnt1s;
			}
			else
			{
				#ifdef Function_FaceRecoginition			
				FaceRecognition_HardwarePowerOff();
				Hardware_DelayMs(100);
				FaceRecognition_HardwarePowerOn();
				SelfTestMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
				#endif			
			}
		}
	}
	else if ( SelfTestMgr.Status == BODYINDUCTION_TEST )
	{
		DisHZ16x14Str(3,32,Str4,NormalDisplay);

		#ifdef Function_BodyInductionByIR
		PIR_Task();
		if ( SelfTestMgr.TimeCnt > 0)
		{
			SelfTestMgr.TimeCnt--;
		}
		else
		{
			if ( PIRmgr.FaceDetected == bTRUE )
			{
				SelfTestMgr.Status = RFID_TEST;
				PLAY_VOICE_ONESEGMENT(3,VOICE_PleaseSwingCard);
				GUI_Flag_RefreshLCD = bTRUE;
			}
		}
		#elif defined Function_BodyInductionByRadar
		if (Radar_SelfTest() == S_SUCCESS)
		{
			SelfTestMgr.Status = RFID_TEST;
			PLAY_VOICE_ONESEGMENT(3,VOICE_PleaseSwingCard);
			GUI_Flag_RefreshLCD = bTRUE;
		}
		#else
		SelfTestMgr.Status = RFID_TEST;
		PLAY_VOICE_ONESEGMENT(3,VOICE_PleaseSwingCard);
		GUI_Flag_RefreshLCD = bTRUE;
		#endif
	}	
	else if ( SelfTestMgr.Status == RFID_TEST )
	{
		DisHZ16x14Str(3,50,Str7,NormalDisplay);
		GetCardID = MFC_Auto_Reader(TestCardCID);
		if ( GetCardID == S_SUCCESS )
		{
			PLAY_VOICE_ONESEGMENT(3,VOICE_AntiSkidAlarm);
			GUI_Flag_RefreshLCD = bTRUE;
			SelfTestMgr.Status = ANTIPRYING_TEST;
			SelfTestMgr.TimeCnt = Def_GuiTimeDelayCnt10s;
		}
	}
	else if ( SelfTestMgr.Status == ANTIPRYING_TEST )
	{
		DisHZ16x14Str(3,32,AntiPryingAlarmStr,NormalDisplay);
		if ( SelfTestMgr.TimeCnt > 0 )
		{
			SelfTestMgr.TimeCnt--;
		}
		else
		{
			GUI_Flag_RefreshLCD = bTRUE;
			SelfTestMgr.Status = EEPROM_TEST;
			SelfTestMgr.TimeCnt = Def_GuiTimeDelayCnt4s;
		}
		if ( 			
			#if (defined ProjectIs_BarLock_S15Z08)
			( PINMACRO_PICKLOCK_STATUS == 1 )
			#else
			( PINMACRO_PICKLOCK_STATUS == 0 )
			#endif
		)
		{
			PLAY_VOICE_ONESEGMENT(3,VOICE_Alarm);
			GUI_Flag_RefreshLCD = bTRUE;
			SelfTestMgr.Status = EEPROM_TEST;
			SelfTestMgr.TimeCnt = Def_GuiTimeDelayCnt4s;
		}	
	}
	else if ( SelfTestMgr.Status == EEPROM_TEST )
	{
		DisHZ16x14Str(2,48,Str5,NormalDisplay);
		if ( SelfTestMgr.TimeCnt == Def_GuiTimeDelayCnt2s )
		{
			PLAY_VOICE_ONESEGMENT(3,VOICE_MemoryUsage);
		}
		if ( SelfTestMgr.TimeCnt-- < 1)
		{
			EEPROM_ReadSequential(SelfTestMemoryStartAddr,&TestByte,1);
			TestByte = 0x5B;
			EEPROM_WriteSequential(SelfTestMemoryStartAddr,&TestByte,1);
			TestByte = 0x00;
			EEPROM_ReadSequential(SelfTestMemoryStartAddr,&TestByte,1);
			if (TestByte == 0x5B)
			{
				SelfTestMgr.TestResult = Passed;
				PLAY_VOICE_ONESEGMENT(3,VOICE_Beep);
				SelfTestMgr.Status = COMMUNICATION_TEST;
				SelfTestMgr.ComOkFlag = bFALSE;
				SelfTestMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
			}
			else
			{
				SelfTestMgr.TestResult = Failed;
				PLAY_VOICE_MULTISEGMENTS(3,VoiceStr_OperationFail);
				DisEN16x8Str(6,48,S_FAILstr,NormalDisplay);
				while(1)
				{
					CLRWDT();
				}
			}
		}
	}
	else if ( SelfTestMgr.Status == COMMUNICATION_TEST )
	{
		GUI_Flag_RefreshLCD = bTRUE;
		DisHZ16x14Str(3,40,Str6,NormalDisplay);

		if ( SelfTestMgr.TimeCnt-- < 1)
		{
			if ( SelfTestMgr.ComOkFlag == bTRUE )
			{
				PLAY_VOICE_ONESEGMENT(3,VOICE_Beep);
				SelfTestMgr.Status = VOLTAGE_TEST;
			}
			else
			{
				SelfTestMgr.TestResult = Failed;
				PLAY_VOICE_MULTISEGMENTS(3,VoiceStr_OperationFail);
				DisEN16x8Str(6,48,S_FAILstr,NormalDisplay);
				while(1)
				{
					CLRWDT();
				}
			}
		}
	}
	else if ( SelfTestMgr.Status == VOLTAGE_TEST )
	{
		GUI_Flag_RefreshLCD = bTRUE;
		SET_KEYLED_ON(KEY_POUNDSIGN);
		DisEN16x8Str(3,40,Str8,NormalDisplay);
		DisOneDigital16x8(6,56,BatteryMgr.BatteryVoltage/10,NormalDisplay);
		DisOneDigital16x8(6,64,BatteryMgr.BatteryVoltage%10,NormalDisplay);
	}
	else if ( SelfTestMgr.Status == LOWPOWER_TEST )
	{
		GUI_Flag_RefreshLCD = bTRUE;
		DisEN16x8Str(2,24,Str9,NormalDisplay);
		Hardware_DelayMs(200);
		CLRWDT();
		Hardware_DelayMs(200);
		CLRWDT();
		Hardware_DelayMs(200);
		CLRWDT();
		System_PowerDown();
		
		System_Awake();

		GUI_RefreshSleepTime();
		
		SystemPowerMgr.AwakeTimerCnt=0x0000;
	}	
}

void ShowAgingTest(void)
{
	code uint8_t AgingTestStr[]={HZ_lao,HZ_hua,HZ_mo,HZ_si,HZ_end}; 
	code uint8_t AgingTestStrEn[]={"AGING MODE"}; 
	code uint8_t CyclesStr[]={"Cycles:"}; 
	code uint8_t VoltageStr[]={"Voltage:  . V"};

	if ( SystemLanguage == Chinese )
	{
		DisHZ16x14Str(0,36,AgingTestStr,NormalDisplay);
	}
	else
	{
		DisEN16x8Str(0,16,AgingTestStrEn,NormalDisplay);
	}


	if ( ComportMgr.DoorStatus == Standby )
	{
		if ( AgingTestMgr.MotorRunTimes < 100000 )		//100,000 times
		{
			if	( AgingTestMgr.TestFlag == bFALSE )
			{
				AgingTestMgr.MotorRunTimes++;
				AgingTestMgr.TestFlag = bTRUE;
				PLAY_VOICE_DOORBELL();
				ComPort_SetPost_OpenDoor(AGINGTESTUSER,0x00);
				ComPort_SetPost_RemoteUnlcok();
				//Enable_KEYLED_WATERLIGHT(); 	
			}
		}
	}
	else
	{
		AgingTestMgr.TestFlag = bFALSE;
	}

	FpUserIdentify();
	if (AgingTestMgr.TimeCnt < (12*64))
	{
		AgingTestMgr.TimeCnt++;
		if ( AgingTestMgr.TimeCnt < (4*64) )
		{
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Red,DEF_FpmLedColor_Red,1); 
		}
		else if ( AgingTestMgr.TimeCnt < (8*64) )
		{
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Green,DEF_FpmLedColor_Green,1); 
		}
		else
		{
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,1); 
		}	
	}
	else
	{
		AgingTestMgr.TimeCnt = 0x0000;
	}
	
	DisEN16x8Str(3,0,CyclesStr,NormalDisplay);
	DisOneDigital16x8(3,64,AgingTestMgr.MotorRunTimes%1000000/100000,NormalDisplay);
	DisOneDigital16x8(3,72,AgingTestMgr.MotorRunTimes%100000/10000,NormalDisplay);
	DisOneDigital16x8(3,80,AgingTestMgr.MotorRunTimes%10000/1000,NormalDisplay);
	DisOneDigital16x8(3,88,AgingTestMgr.MotorRunTimes%1000/100,NormalDisplay);
	DisOneDigital16x8(3,96,AgingTestMgr.MotorRunTimes%100/10,NormalDisplay);
	DisOneDigital16x8(3,104,AgingTestMgr.MotorRunTimes%10,NormalDisplay);

	DisEN16x8Str(5,0,VoltageStr,NormalDisplay);	
	DisOneDigital16x8(5,64,BatteryMgr.BatteryVoltage%1000/100,NormalDisplay);
	DisOneDigital16x8(5,72,BatteryMgr.BatteryVoltage%100/10,NormalDisplay);
	DisOneDigital16x8(5,88,BatteryMgr.BatteryVoltage%10,NormalDisplay);
	
	
//	DisOneDigital16x8(6,8,ComportMgr.DoorStatus%1000/100,NormalDisplay);
//	DisOneDigital16x8(6,16,ComportMgr.DoorStatus%100/10,NormalDisplay);
//	DisOneDigital16x8(6,24,ComportMgr.DoorStatus%10,NormalDisplay);
}


void ShowSystemLocked(void)
{
	uint16_t Temp;
	if ( SafetyMonitorMgr.SystemLockedTimeDelay > 0x0000 )
	{
		if(SafetyMonitorMgr.SystemLockedTimeDelay > (DEF_SystemLockedTime-128))
		{
			if ( SafetyMonitorMgr.SystemLockedTimeDelay == DEF_SystemLockedTime  )
			{
				PLAY_VOICE_ONESEGMENT(3,VOICE_SystemLocked);
			}
		}else if ( SafetyMonitorMgr.SystemLockedTimeDelay > (DEF_SystemLockedTime-640))
		{
			if ( SafetyMonitorMgr.SystemLockedTimeDelay%128 == 0  )
			{
				PLAY_VOICE_ONESEGMENT(3,VOICE_Alarm);
			}
		}
		SafetyMonitorMgr.SystemLockedTimeDelay--;
	}
	else
	{
		SafetyMonitorMgr.FpIdentifyFailedTimes = 0x00;
    SafetyMonitorMgr.CardIdentifyFailedTimes = 0x00;
    SafetyMonitorMgr.PasscodeIdentifyFailedTimes = 0x00;
		SafetyMonitorMgr.ManagerPasscodeIdentifyFailedTimes = 0x00;
		SafetyMonitorMgr.ManagerFpIdentifyFailedTimes = 0x00;
		SafetyMonitorMgr.SystemLocked = bFALSE;
		GoIntoMainScreen_WithIdentifyInit();
		STOP_VOICEPLAY();
	}

	DisImage(0,50,27,24,Icon_Warning,NormalDisplay);

	if (SystemLanguage == Chinese){
		DisHZ16x14Str(4,36,SystemLockedStr,NormalDisplay);
	}
	else{
		DisEN16x8Str(4,16,SystemLockedStrEn,NormalDisplay);
	}
	
	Temp = SafetyMonitorMgr.SystemLockedTimeDelay/62;
	
	DisOneDigital16x8(6,52,Temp/100,NormalDisplay);
	DisOneDigital16x8(6,60,(Temp%100)/10,NormalDisplay);
	DisOneDigital16x8(6,68,Temp%10,NormalDisplay);
}

void ShowUnlockingModeSetting(void)//����ģʽ
{

	if (SystemLanguage == Chinese)
	{
		if( UserIdentifyResultMgr.UnlockingMode == SingalMode )
			{
		DisHZ16x14Str(0,4,SingalModeStr,InverseDisplay);
		DisHZ16x14Str(2,4,DoubleModeStr,NormalDisplay);
			}
		else{
			DisHZ16x14Str(0,4,SingalModeStr,NormalDisplay);
			DisHZ16x14Str(2,4,DoubleModeStr,InverseDisplay);

			}
	}
	else
	{
		if( UserIdentifyResultMgr.UnlockingMode == SingalMode )
		{
			DisEN16x8Str(0,4,SingalModeStrEn,InverseDisplay);
			DisEN16x8Str(2,4,DoubleModeStrEn,NormalDisplay);
		}
		else{
			DisEN16x8Str(0,4,SingalModeStrEn,NormalDisplay);
			DisEN16x8Str(2,4,DoubleModeStrEn,InverseDisplay);
		}
	}
	
	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,UnlockModeSetVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

}


void ShowInfoInquiryMenu(void)
{
	uint8_t i;

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,InfoInquiryMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}
	
	for (i=0;i<4;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,InfoInquiryMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,InfoInquiryMenuStrEn[i],NormalDisplay);
		}
	}			
}


void ShowEventLogBySequence(void)
{
	static uint16_t VoiceReportLogBuff[][5]=
	{	
		{VOICE_Press,VOICE_Two,VOICE_Previous,DEF_VoiceSegmentEndFlag},
		{VOICE_Press,VOICE_Eight,VOICE_Next,DEF_VoiceSegmentEndFlag},
		{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
		{VOICE_Mute20ms,DEF_VoiceSegmentEndFlag},
	};

	if ( CheckEventLogBySequenceMgr.Status == SearchEventLogWithSequence)
	{	
		SearchEventLogBySequence();
		CheckEventLogBySequenceMgr.TimeCnt=Def_GuiTimeDelayCnt3s;
		//Clear_Screen();
		
		if ( CheckEventLogBySequenceMgr.MatchedEventLogNum > 0x0000 )
		{
			LogMgr.DisplayPoint = CheckEventLogBySequenceMgr.StartEventLogPoint;
			LogMgr.SavedDisplayPoint = LogMgr.DisplayPoint+1;	//for reload Display Log
			CheckEventLogBySequenceMgr.OffsetEventLogNum = 0x0000;
			CheckEventLogBySequenceMgr.Status = ShowEventLogWithSequence;
			VoiceMenuMgr.MenuPoint = 0;
			VoiceMenuMgr.TotalMenuNum = 4;	
		}
		else
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,NoLogVoiceStr);
			CheckEventLogBySequenceMgr.Status = ShowEventLogWithSequence;
		}
	}
	else if ( CheckEventLogBySequenceMgr.Status == VoiceReportOperation )
	{
		if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
		{
			if ( VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceReportLogBuff[VoiceMenuMgr.MenuPoint]);
				VoiceMenuMgr.MenuPoint++;
			}
			else
			{
				CheckEventLogBySequenceMgr.Status = ShowEventLogWithSequence;
			}
		}
	}
	else if (CheckEventLogBySequenceMgr.Status == ShowEventLogWithSequence )
	{
		if ( CheckEventLogBySequenceMgr.MatchedEventLogNum == 0x0000 )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,40,NoEventLogStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(3,40,NoEventLogStrEn,NormalDisplay);
			}
      if(CheckEventLogBySequenceMgr.TimeCnt>0)
			{
				CheckEventLogBySequenceMgr.TimeCnt--;
			}
			else
			{
				GoIntoLogMenu_Init();
			}
		}
		else
		{
			LogMgr_ReadLog(LogMgr.DisplayPoint,&LogMgr.DisplayLog.FlagHighByte);
			if ( LogMgr.SavedDisplayPoint != LogMgr.DisplayPoint )
			{
				LogMgr.SavedDisplayPoint = LogMgr.DisplayPoint;
				VoiceReportLogMgr.Status = ReportLogInit;
				Clear_Screen();
			}
			
			DisplayOneEventLog(CheckEventLogBySequenceMgr.OffsetEventLogNum+1);

			if ( VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
			{
				if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
				{
					PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceReportLogBuff[VoiceMenuMgr.MenuPoint]);
					VoiceMenuMgr.MenuPoint++;
					GUI_RefreshSleepTime();
				}
			}
			else
			{
				VoiceReportOneEventLog(CheckEventLogBySequenceMgr.OffsetEventLogNum+1);
			}

		}
	}
	
}

void ShowClearEventLog(void)
{
	//code uint8_t TitleStr[]={HZ_shan,HZ_chufa,HZ_ji,HZ_lu,ZF_xiaoshudian,ZF_xiaoshudian,ZF_xiaoshudian,HZ_end};
	//uint8_t PercentageStr[]={ZF_baifenhao,HZ_end};
	//DisHZ16x14Str(0,24,TitleStr,NormalDisplay);

	if (LogDeleteMgr.Status == LogDeleteStart)
	{
		LogDeleteMgr.DeleteSectorNum = 0;
		LogDeleteMgr.Percentage = 0;
		LogDeleteMgr.Status = WaitforLogDeleteCofirm;
		LogDeleteMgr.Selection = NO;
		SET_UDandConfirmLED_ON();
		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_ConfirmOrExitDelete);
	}
	else if (LogDeleteMgr.Status == WaitforLogDeleteCofirm)
	{
		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(2,16,ConfirmDeleteStr,NormalDisplay);
			DisHZ16x14Str(4,16,AbortDeleteStr,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(2,0,ConfirmDeleteStrEn,NormalDisplay);
			DisEN16x8Str(4,0,AbortDeleteStrEn,NormalDisplay);
		}
	}
	else if (LogDeleteMgr.Status == LogDeleting)
	{
		GUI_Flag_RefreshLCD = bTRUE;
		
		if ( LogDeleteMgr.Percentage < 100 )
		{
			if ( LogDeleteMgr.Percentage == 0 )
			{		
				if ( DeleteAllLog() != S_SUCCESS )
				{
					if ( DeleteAllLog() != S_SUCCESS )
					{
						DeleteAllLog();
					}
				}
			}
			if (LogDeleteMgr.Percentage>99)
			{
				DisOneDigital16x8(3,40,1,NormalDisplay);
				DisOneDigital16x8(3,48,0,NormalDisplay);
				DisOneDigital16x8(3,56,0,NormalDisplay);
			}
			else
			{
				DisOneDigital16x8(3,48,LogDeleteMgr.Percentage/10,NormalDisplay);
				DisOneDigital16x8(3,56,LogDeleteMgr.Percentage%10,NormalDisplay);
			}
			DisEN16x8Str(3,64,"%",NormalDisplay);
			
			LogDeleteMgr.Percentage++;
			GUI_RefreshSleepTime();
		}
		else
		{
			LogDeleteMgr.Status = LogDeleteSuccess;	
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationSuccess);
			LogDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt2s;
		}
	}
	else if (LogDeleteMgr.Status == LogDeleteSuccess)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(3,36,OperationSuccessStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(3,36,OperationSuccessStrEn,NormalDisplay);
		}

		if ( LogDeleteMgr.TimeCnt-- < 1 )
		{
			LogDeleteMgr.Status = LogDeleteIdle;
		}
	}
	else
	{
		DEBUG_MARK;

		LogMgr.LastPoint = 0x0000;
		LogMgr.DisplayPoint = 0x0000;
		LogMgr.NewLog.LogOrType._Bit.LogIDmajor = 0x00;
		
		GoIntoLogMenu_Init();
		
	}

}

void ShowPickLockAlarm(void)
{
	bool_t Flag_ExitPickLockAlarm;

	GUI_RefreshSleepTime();		//reset system sleep time

	if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyIdle )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(0,36,AntiPryingAlarmStr,NormalDisplay);
			DisHZ16x14Str(3,16,RemovalAlarmStr1,NormalDisplay);
			DisHZ16x14Str(5,50,RemovalAlarmStr2,NormalDisplay); 
		}
		else{
			DisEN16x8Str(0,44,AntiPryingAlarmStrEn,NormalDisplay);
			DisEN16x8Str(3,12,RemovalAlarmStr1En,NormalDisplay);
			DisEN16x8Str(5,24,RemovalAlarmStr2En,NormalDisplay); 
		}

	}

	Flag_ExitPickLockAlarm = bFALSE;
	if (/*( UART1_Mgr.TxLength == 0x00 )&& */( CardIdentifyMgr.CardDetectIntervalTimeCnt ==0 ) )	//FPM Cmd is sent out
	{
		CardIdentifyMgr.CardDetectIntervalTimeCnt = Def_CardDetectIntervalTime;
		
		CardUserIdentify();
	}
		
	if ( CardIdentifyMgr.Status == Success)
	{
		Flag_ExitPickLockAlarm = bTRUE;
	}
	else if ( CardIdentifyMgr.Status == Fail)
	{
		if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
		{
			Flag_ExitPickLockAlarm = bTRUE;
		}
		else
		{
			CardIdentifyMgr.Status = ReadingCardID;
		}
	}

	FpUserIdentify();
	if ( FpIdentifyMgr.Status == success)
	{
		Flag_ExitPickLockAlarm = bTRUE;	
	}
	else if ( FpIdentifyMgr.Status == fail)
	{
		if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
		{
			Flag_ExitPickLockAlarm = bTRUE;		
		}
		else
		{
			FpIdentifyMgr.Status = FPMcmdStart;
		}
	}

	PasscodeUserIdentify();
	if (PasscodeUserIdentifyMgr.Status == PasscodeIdentifySuccess)
	{
		Flag_ExitPickLockAlarm = bTRUE;
	}
	else if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyFail )
	{
		if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
		{
			Flag_ExitPickLockAlarm = bTRUE;
		}
		else
		{
			PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
		}
	}
	
	#ifdef Function_FaceRecoginition	
	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		if ( PasscodeInputMgr.Point > 0 )
		{
			FaceIdentifyMgr.IndentifyDelayTimeCnt = Def_GuiTimeDelayCnt2s;
		}
		
		if ( FaceIdentifyMgr.IndentifyDelayTimeCnt > 0 )
		{
			 FaceIdentifyMgr.IndentifyDelayTimeCnt--;	 
		}
		if ( (IfSystemIsNoFaceUser() == bFALSE )			//system is has face user
			&&( FaceIdentifyMgr.IndentifyDelayTimeCnt == 0x0000 )
			)
		{
			FaceUserIdentify();
			if ( FaceIdentifyMgr.Status == FaceIdentifySuccess )
			{
				Flag_ExitPickLockAlarm = bTRUE;
			}
			else if ( FaceIdentifyMgr.Status == FaceIdentifySuccess_NoUser)
			{
				Flag_ExitPickLockAlarm = bTRUE;	
			}
			else if ( FaceIdentifyMgr.Status == FaceIdentifyFail )
			{
				FaceIdentifyMgr.Status = FrmIdentifyStart;
				DEBUG_MARK;
			}
		}
		else
		{
			if ( FrmMgr.PowerStatus != FRM_PowerOff )
			{
				FaceRecognition_HardwarePowerOff();
			}	
		}
	}
	#endif	
	
	if ( AntiPryingMgr.TimeCnt%128 == 0  )
	{
		PLAY_VOICE_ONESEGMENT(3,VOICE_Alarm);
	}

	if ( AntiPryingMgr.TimeCnt > 0 ){
		AntiPryingMgr.TimeCnt--;
	}
	else{
		Flag_ExitPickLockAlarm = bTRUE;
	}
	
	if ( Flag_ExitPickLockAlarm == bTRUE )
	{
		ComPort_SetPost_Alarm(DEF_WifiAlarm_RemoveAlarm,UNDEFINEDUSER,0x00);
		GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
		AntiPryingMgr.AntiPryingTrigger = bFALSE;
		GoIntoMainScreen_WithIdentifyInit();
		GUI_RefreshSleepTime();		//reset system sleep time
 		STOP_VOICEPLAY();
	}
}

void ShowDoorLockSettingMenu(void)
{
	uint8_t i,MenuNum;

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,DoorLockSettingVoiceBuff_WithFRM[VoiceMenuMgr.MenuPoint]);
			}
			else
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,DoorLockSettingVoiceBuff[VoiceMenuMgr.MenuPoint]);
			}
			VoiceMenuMgr.MenuPoint++;
		}
	}

	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		MenuNum = 3;
	}
	else
	{
		MenuNum = 2;
	}
	
	for (i=0;i<MenuNum;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,DoorLockSettingMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,DoorLockSettingMenuStrEn[i],NormalDisplay);
		}
	}
				
}

void ShowBodyInductionSetting(void)
{
	uint8_t i;
	
	if (SystemLanguage == Chinese)
	{
		for (i=0;i<3;i++)
		{
			if ( BodyInductionMgr.SensingDistanceLevel == i )
			{
				DisHZ16x14Str(2*i,4,BodyInductionAdjustStr[i],InverseDisplay);
			}
			else
			{
				DisHZ16x14Str(2*i,4,BodyInductionAdjustStr[i],NormalDisplay);
			}
		}
	}
	else
	{
		for (i=0;i<3;i++)
		{
			if ( BodyInductionMgr.SensingDistanceLevel == i )
			{
				DisEN16x8Str(2*i,4,BodyInductionAdjustStrEn[i],InverseDisplay);
			}
			else
			{
				DisEN16x8Str(2*i,4,BodyInductionAdjustStrEn[i],NormalDisplay);
			}
		}
	}

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,BodyInductionVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

}


void ShowSystemVersion(void)
{

	code uint8_t SystemVersionStr[]={HZ_xi,HZ_tong,HZ_ban,HZ_ben,HZ_end};
	code uint8_t SystemVersionStrEn[]={"System Version"};
	//code uint8_t FPM_Version[]={"FPM:126"};
	uint8_t ModelStr[]={"SxxxZxxx"};
	uint8_t VersionStr[]={"100.100.100.100"};


	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,SystemVersionVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	if (SystemLanguage == Chinese){
		DisHZ16x14Str(0,32,SystemVersionStr,NormalDisplay);
	}
	else{
		DisEN16x8Str(0,10,SystemVersionStrEn,NormalDisplay);
	}

	ModelStr[1]=DEF_CustomerNumber/100+0x30;
	ModelStr[2]=DEF_CustomerNumber%100/10+0x30;
	ModelStr[3]=DEF_CustomerNumber%10+0x30;
	ModelStr[5]=DEF_ModelNumber/100+0x30;
	ModelStr[6]=DEF_ModelNumber%100/10+0x30;
	ModelStr[7]=DEF_ModelNumber%10+0x30;	
	DisEN16x8Str(3,24,ModelStr,NormalDisplay);
	
	//Main Board Hardware Version
	VersionStr[0]=DEF_HardwareVerion/100+0x30;
	VersionStr[1]=DEF_HardwareVerion%100/10+0x30;
	VersionStr[2]=DEF_HardwareVerion%10+0x30;
	//Main Board Firmware Version
	VersionStr[4]=DEF_FirmwareVerion/100+0x30;
	VersionStr[5]=DEF_FirmwareVerion%100/10+0x30;
	VersionStr[6]=DEF_FirmwareVerion%10+0x30;

	//Driver Board Hardware Version
	VersionStr[8]=DriverBoardVersion.HWversion/100+0x30;
	VersionStr[9]=DriverBoardVersion.HWversion%100/10+0x30;
	VersionStr[10]=DriverBoardVersion.HWversion%10+0x30;
	//Driver Board Firmware Version
	VersionStr[12]=DriverBoardVersion.FWversion/100+0x30;
	VersionStr[13]=DriverBoardVersion.FWversion%100/10+0x30;
	VersionStr[14]=DriverBoardVersion.FWversion%10+0x30;
	DisEN16x8Str(5,0,VersionStr,NormalDisplay);

	//DisEN16x8Str(6,0,FPM_Version,NormalDisplay);
}

void ShowRemoteUnlockRequest(void)
{
	code uint8_t RemoteUnlockRequestStr1[]={HZ_zhengque,HZ_zaima,HZ_qing,HZ_qiu,HZ_yuanchu,HZ_chengxu,HZ_kai,HZ_suomen,HZ_end};
	code uint8_t RemoteUnlockRequestStr2[]={HZ_qing,HZ_shao,HZ_houniao,HZ_end};
	code uint8_t RemoteUnlockRequestStr1En[]={"Request Remote Un-"};
	code uint8_t RemoteUnlockRequestStr2En[]={"lock Please wait"};

	if ( WifiMgr.RemoteUnlockMgr.Status == RemoteUnlockRequestInit )
	{
		WifiMgr.RemoteUnlockMgr.TimeCnt = 60*64;
		WifiMgr.RemoteUnlockMgr.Status = RemoteUnlcokDisplayDoorBell;
		WifiMgr.RemoteUnlockMgr.Result = IsUnknow;
		SystemPowerMgr.SleepDelayTimerCnt = Def_GuiTimeDelayCnt10s;
		#ifdef Function_FaceRecoginition			
		if ( FrmMgr.PowerStatus != FRM_PowerOff )
		{
			FaceRecognition_HardwarePowerOff();
		}
		#endif
		
		#ifdef Function_MainBoardWithoutVoicePlayer
			//do nothing
		#else
		ComPort_SetPost_RemoteUnlcok();
		#endif
	}
	else if (WifiMgr.RemoteUnlockMgr.Status == RemoteUnlcokDisplayDoorBell ) 
	{
		DisImage(1,33,61,40,Icon_DoorBell,NormalDisplay);
		#ifdef Function_MainBoardWithoutVoicePlayer
		if ( WifiMgr.RemoteUnlockMgr.TimeCnt == (58*64))
		{
			ComPort_SetPost_RemoteUnlcok();
		}
		else if ( WifiMgr.RemoteUnlockMgr.TimeCnt < (55*64) )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_RequestingRemoteUnlock);
			WifiMgr.RemoteUnlockMgr.Status = RemoteUnlockRequestWait;
		}
		#else
		if ( WifiMgr.RemoteUnlockMgr.TimeCnt < (58*64) )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_RequestingRemoteUnlock);
			WifiMgr.RemoteUnlockMgr.Status = RemoteUnlockRequestWait;
		}
		#endif
	}
	else if (WifiMgr.RemoteUnlockMgr.Status == RemoteUnlockRequestWait )
	{
		GUI_Flag_RefreshLCD = bTRUE;

		SystemPowerMgr.SleepDelayTimerCnt = Def_GuiTimeDelayCnt10s;
		
		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(1,8,RemoteUnlockRequestStr1,NormalDisplay);
			DisHZ16x14Str(4,42,RemoteUnlockRequestStr2,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(2,0,RemoteUnlockRequestStr1En,NormalDisplay);
			DisEN16x8Str(4,0,RemoteUnlockRequestStr2En,NormalDisplay);
		}

		if ( WifiMgr.RemoteUnlockMgr.Result == IsSuccess )
		{
			GUI_RefreshSleepTime();
			UserIdentifyResultMgr.IdentifyType = RemoteUnlock;
			Enable_KEYLED_WATERLIGHT();	
			CurrentScreen = SCREEN_IdentifySuccess;
			DisplayDoorStatusMgr.Status = DoorOpenInit;
			UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;
			WifiMgr.RemoteUnlockMgr.Status = RemoteUnlockDisplayResult;
			
		}
		else if ( WifiMgr.RemoteUnlockMgr.Result == IsFail )
		{
			if ( WifiMgr.RemoteUnlockMgr.errorcode == 0x02 )//wifi not connected
			{
				WifiMgr.RemoteUnlockMgr.TimeCnt = 0x00;
			}
			else
			{
				GUI_Flag_RefreshLCD = bTRUE;
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(3,36,OperationFailStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(3,8,OperationFailStrEn,NormalDisplay);
				}
				WifiMgr.RemoteUnlockMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
			}
			
			WifiMgr.RemoteUnlockMgr.Status = RemoteUnlockDisplayResult;
			
		}

		if ( WifiMgr.RemoteUnlockMgr.TimeCnt < 3 )
		{
			WifiMgr.RemoteUnlockMgr.Result = IsFail;
			WifiMgr.RemoteUnlockMgr.errorcode = 0x01;
		}
	}
	else if ( WifiMgr.RemoteUnlockMgr.Status == RemoteUnlockExit )
	{
		WifiMgr.RemoteUnlockMgr.TimeCnt = 0x00;
		SystemPowerMgr.SleepDelayTimerCnt = Def_GuiTimeDelayCnt3s;
		ComPort_SetPost_ExitRemoteUnlcok();
	}
	
	if ( ComportMgr.DoorStatus != Standby )
	{
		GoIntoMainScreen_WithIdentifyInit();
	}

	if (WifiMgr.RemoteUnlockMgr.TimeCnt > 0)
	{
		WifiMgr.RemoteUnlockMgr.TimeCnt--;
	}
	else
	{
		GoIntoMainScreen_WithIdentifyInit();
	}
}

void ShowEngineeringModeMenu(void)
{
	uint8_t i,j,StartMenuNum,StopMenuNum;
	
	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,EngineeringModeMenuVoiceBuff_WithFRM[VoiceMenuMgr.MenuPoint]);
			}
			else
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,EngineeringModeMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			}
			VoiceMenuMgr.MenuPoint++;
		}
	}

	if ( VoiceMenuMgr.MenuPoint < 5 )
	{
		StartMenuNum = 0;
		StopMenuNum = 4;
	}
	else
	{
		StartMenuNum = 4;
		if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
			{
		StopMenuNum = 7;
			}
		else{
		StopMenuNum = 6;
			}
	}

	j=0;
	for (i=StartMenuNum;i<StopMenuNum;i++)
	{
		if (SystemLanguage == Chinese)
		{
			if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
			{
				DisHZ16x14Str(2*j,0,EngineeringModeMenuStr_WithFRM[i],NormalDisplay);
			}
			else{
				DisHZ16x14Str(2*j,0,EngineeringModeMenuStr[i],NormalDisplay);
			}
		}
		else
		{	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
			{
				DisEN16x8Str(2*j,0,EngineeringModeMenuStrEN_WithFRM[i],NormalDisplay);
			}
			else{
				DisEN16x8Str(2*j,0,EngineeringModeMenuStrEN[i],NormalDisplay);
			}
		}
		j++;
	}		
	GUI_Flag_RefreshLCD = bTRUE;
}

void ShowAutoMotorUnlockTimeSetting(void)
{
	code uint8_t TitleStr[]={HZ_guanbi,HZ_men,HZ_shi,HZ_jian,HZ_end};							
	code uint8_t TitleStrEN[]={"Unlock time"};	
    //code uint8_t TimeUnitStr[]={HZ_miao,HZ_end};							
	code uint8_t TimeUnitStrEN[]={"S"};	

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,UnlockTimeSettingVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

    if (SystemLanguage == Chinese)
     {
	   DisHZ16x14Str(0,32,TitleStr,NormalDisplay);

	}
	else
	{
       DisEN16x8Str(0,24,TitleStrEN,NormalDisplay);
	}
	DisOneDigital16x8(4,48,AutoMotorMgr.UnlockTime/10,InverseDisplay);
	DisOneDigital16x8(4,56,AutoMotorMgr.UnlockTime%10,InverseDisplay);
	DisEN16x8Str(4,68,TimeUnitStrEN,NormalDisplay);	
}

void ShowAutoMotorAutoLockTimeSetting(void)
{
	code uint8_t TitleStr[]={HZ_zhidong,HZ_dong,HZ_shang,HZ_suomen,HZ_shi,HZ_jian,HZ_end};							
	code uint8_t TitleStrEN[]={"AutoLockTime"};	
	//code uint8_t TimeUnitStr[]={HZ_miao,HZ_end};							
	code uint8_t TimeUnitStrEN[]={"S"};	

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,AutoLockDelayTimeSettingVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	if (SystemLanguage == Chinese)
	{
		DisHZ16x14Str(0,16,TitleStr,NormalDisplay);
	}
	else
	{
		DisEN16x8Str(0,16,TitleStrEN,NormalDisplay);
	}

	DisOneDigital16x8(4,40,AutoMotorMgr.AutoLockTime/10,InverseDisplay);
	DisOneDigital16x8(4,48,AutoMotorMgr.AutoLockTime%10,InverseDisplay);
	DisEN16x8Str(4,64,TimeUnitStrEN,NormalDisplay);

}

void ShowAutoMotorLockDirectionSetting(void)
{

	code  uint8_t LockDirectionStr[][5]=
		{			
			{ZF_1,ZF_xiaoshudian,HZ_zuobian,HZ_kai,HZ_end},																
			{ZF_2,ZF_xiaoshudian,HZ_youbian,HZ_kai,HZ_end},
		};
	code  uint8_t LockDirectionStrEN[][8]=
		{			
			{"1.Left  "},																
			{"2.Right "}
		};

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,UnlockDirrectionSettingVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

    if (SystemLanguage == Chinese)
    {
    	if ( AutoMotorMgr.LockDirection == LEFTOPEN )
    	{
	     	DisHZ16x14Str(1,4,LockDirectionStr[0],InverseDisplay);		
			DisHZ16x14Str(4,4,LockDirectionStr[1],NormalDisplay);	
    	}
		else
		{
			DisHZ16x14Str(1,4,LockDirectionStr[0],NormalDisplay);		
			DisHZ16x14Str(4,4,LockDirectionStr[1],InverseDisplay);	
		}
	}
	else
	{
    	if ( AutoMotorMgr.LockDirection == LEFTOPEN )
    	{
	     	DisEN16x8Str(1,4,LockDirectionStrEN[0],InverseDisplay);		
			DisEN16x8Str(4,4,LockDirectionStrEN[1],NormalDisplay);	
    	}
		else
		{
			DisEN16x8Str(1,4,LockDirectionStrEN[0],NormalDisplay);		
			DisEN16x8Str(4,4,LockDirectionStrEN[1],InverseDisplay);	
		}	
	}

}

void ShowAutoMotorTorqueSetting(void)
{					
	code uint8_t TorqueStr[][6]={								
									{ZF_1,ZF_xiaoshudian,HZ_xiao,HZ_niu,HZ_niuli,HZ_end},									
									{ZF_2,ZF_xiaoshudian,HZ_zhong,HZ_niu,HZ_niuli,HZ_end},
									{ZF_3,ZF_xiaoshudian,HZ_da,HZ_niu,HZ_niuli,HZ_end},
							 };

	code uint8_t TorqueStrEN[][9]={
		
								{"1.Little "},									
								{"2.Middle "},
								{"3.Big    "},
						 };
	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,MotorTorqueSettingVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	 if (SystemLanguage == Chinese)
     {
     	if (AutoMotorMgr.TorqueLevel == LowTorque)
     	{
			DisHZ16x14Str(1,4,TorqueStr[0],InverseDisplay);
			DisHZ16x14Str(3,4,TorqueStr[1],NormalDisplay);	
			DisHZ16x14Str(5,4,TorqueStr[2],NormalDisplay);
     	}
		else if  (AutoMotorMgr.TorqueLevel == MiddleTorque)
		{
			DisHZ16x14Str(1,4,TorqueStr[0],NormalDisplay);
			DisHZ16x14Str(3,4,TorqueStr[1],InverseDisplay);	
			DisHZ16x14Str(5,4,TorqueStr[2],NormalDisplay);
     	}
		else
		{
			DisHZ16x14Str(1,4,TorqueStr[0],NormalDisplay);
			DisHZ16x14Str(3,4,TorqueStr[1],NormalDisplay);	
			DisHZ16x14Str(5,4,TorqueStr[2],InverseDisplay);
     	}
	 }
	 else
	 {
		if (AutoMotorMgr.TorqueLevel == LowTorque)
     	{
			DisEN16x8Str(1,4,TorqueStrEN[0],InverseDisplay);
			DisEN16x8Str(3,4,TorqueStrEN[1],NormalDisplay);	
			DisEN16x8Str(5,4,TorqueStrEN[2],NormalDisplay);
     	}
		else if  (AutoMotorMgr.TorqueLevel == MiddleTorque)
		{
			DisEN16x8Str(1,4,TorqueStrEN[0],NormalDisplay);
			DisEN16x8Str(3,4,TorqueStrEN[1],InverseDisplay);	
			DisEN16x8Str(5,4,TorqueStrEN[2],NormalDisplay);
     	}
		else
		{
			DisEN16x8Str(1,4,TorqueStrEN[0],NormalDisplay);
			DisEN16x8Str(3,4,TorqueStrEN[1],NormalDisplay);	
			DisEN16x8Str(5,4,TorqueStrEN[2],InverseDisplay);
     	}
	 }
    
}

void ShowBoltLockTimeSetting(void)
{
	code uint8_t TitleStr[]={HZ_suomen,HZ_se,HZ_huijia,HZ_Zhuan,HZ_shi,HZ_jian,HZ_end};	//б�෴��ʱ��		
	code uint8_t TitleStrEN[]={"Bolt Lock Time"};	//б�෴��ʱ��												
	code uint8_t TimeUnitStrEN[]={"S"};	

	uint16_t temp_BoltLockTime;

	temp_BoltLockTime = AutoMotorMgr.BoltLockTime/2;

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,BoltLockTimeSettingVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}
    if (SystemLanguage == Chinese)
    {
		DisHZ16x14Str(0,16,TitleStr,NormalDisplay);
	}
	else
	{
		DisEN16x8Str(0,0,TitleStrEN,NormalDisplay);
	}
	DisOneDigital16x8(4,48,temp_BoltLockTime/10,InverseDisplay);
	DisZF16x8(4,56,ZF_xiaoshudian,InverseDisplay);
	DisOneDigital16x8(4,64,temp_BoltLockTime%10,InverseDisplay);
	DisEN16x8Str(4,76,TimeUnitStrEN,NormalDisplay);
}

void ShowLockingTravelSetting(void)
{
	code uint8_t TitleStr[]={HZ_fanzheng,HZ_suomen,HZ_xing,HZ_chengxu,HZ_end};	
	code uint8_t TitleStrEN[]={"Locking Travel"};	

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,LockingTravelSettingVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	 if (SystemLanguage == Chinese)
     { 
		DisHZ16x14Str(0,32,TitleStr,NormalDisplay);
	 }
	 else
	 {    
		DisEN16x8Str(0,20,TitleStrEN,NormalDisplay);
	 }
     DisOneDigital16x8(3,48,AutoMotorMgr.LockingTravel,InverseDisplay);
}


void ShowAutoEjectSetting(void)
{		
	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,AutoEjectSettingVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	if (SystemLanguage == Chinese)
	{
		if (AutoMotorMgr.AutoEject == 0x01)
		{
			DisHZ16x14Str(1,4,AutoEjectEnableStr,InverseDisplay);
			DisHZ16x14Str(3,4,AutoEjectDisableStr,NormalDisplay);
		}
		else
		{
			DisHZ16x14Str(1,4,AutoEjectEnableStr,NormalDisplay);
			DisHZ16x14Str(3,4,AutoEjectDisableStr,InverseDisplay);
		}
	}
	else
	{
		if (AutoMotorMgr.AutoEject == 0x01)
		{
			DisEN16x8Str(1,4,AutoEjectEnableStrEn,InverseDisplay);
			DisEN16x8Str(3,4,AutoEjectDisableStrEn,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(1,4,AutoEjectEnableStrEn,NormalDisplay);
			DisEN16x8Str(3,4,AutoEjectDisableStrEn,InverseDisplay);
		}
	}
			
}



void ShowAutoMotorSelfTest(void)
{
	code uint8_t TitleStr[]={HZ_dian,HZ_jiqi,HZ_zhidong,HZ_xue,HZ_xiguan,HZ_end};	
	code uint8_t TitleStrEN[]={"Motor Test"};	
	code uint8_t Title1Str[]={HZ_qing,HZ_shao,HZ_houniao,HZ_end};	
	code uint8_t Title1StrEN[]={"Please Wait"};

	code uint8_t SelfTestSuccessStr[]={HZ_xue,HZ_xiguan,HZ_cheng,HZ_gong,HZ_end};	
	code uint8_t SelfTestSuccessStrEN[]={"Success"};	
	code uint8_t SelfTestFailStr[]={HZ_xue,HZ_xiguan,HZ_shibai,HZ_bai,HZ_end};	
	code uint8_t SelfTestFailStrEN[]={"Fail"};	
	code uint8_t MotorWithHallStr[]={HZ_dian,HZ_jiqi,HZ_you,HZ_huoer,HZ_erhou,HZ_end};	
	code uint8_t MotorWithHallStrEN[]={"With Hall"};	
	code uint8_t MotorWithoutHallStr[]={HZ_dian,HZ_jiqi,HZ_wu,HZ_huoer,HZ_erhou,HZ_end};	
	code uint8_t MotorWithoutHallStrEN[]={"Without Hall"};

	
	//if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,MotorSelfTestVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}
	if (SystemLanguage == Chinese)
	 {
		DisHZ16x14Str(0,32,TitleStr,NormalDisplay);
	 }
	 else
	 {
		DisEN16x8Str(0,20,TitleStrEN,NormalDisplay);
	 }

	if ( AutoMotorMgr.SelfTest.Status == SelfTestStart )
	{
		if (SystemLanguage == Chinese)
		 {
			DisHZ16x14Str(3,48,Title1Str,NormalDisplay);
		 }
		 else
		 {
			DisEN16x8Str(3,20,Title1StrEN,NormalDisplay);
		 }
		AutoMotorMgr.SelfTest.TimeLimitedCnt = 30*64;	
		AutoMotorMgr.SelfTest.Status = SelfTestWait;
		GUI_RefreshSleepTime();
	}
	else if ( AutoMotorMgr.SelfTest.Status == SelfTestWait )
	{

	}
	else if (AutoMotorMgr.SelfTest.Status == SelfTestSuccess )
	{
		 Clear_Screen();
		 if (SystemLanguage == Chinese)
	     {
			DisHZ16x14Str(3,40,SelfTestSuccessStr,NormalDisplay);
			if ( AutoMotorMgr.SelfTest.ErrorCode == 0x00 )
			{
				DisHZ16x14Str(5,32,MotorWithHallStr,NormalDisplay);
			}
			else if ( AutoMotorMgr.SelfTest.ErrorCode == 0x01 )
			{
				DisHZ16x14Str(5,32,MotorWithoutHallStr,NormalDisplay);
			}	
		 }
		 else
		 {
			DisEN16x8Str(3,32,SelfTestSuccessStrEN,NormalDisplay);
			if ( AutoMotorMgr.SelfTest.ErrorCode == 0x00 )
			{
				DisEN16x8Str(5,28,MotorWithHallStrEN,NormalDisplay);
			}
			else if ( AutoMotorMgr.SelfTest.ErrorCode == 0x01 )
			{
				DisEN16x8Str(5,16,MotorWithoutHallStrEN,NormalDisplay);
			}
		 }
		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationSuccess); 
		AutoMotorMgr.SelfTest.Status = SelfTestDisplayResult;
		AutoMotorMgr.SelfTest.TimeLimitedCnt = Def_GuiTimeDelayCnt3s;
		
	}
	else if (AutoMotorMgr.SelfTest.Status == SelfTestFail )
	{
		Clear_Screen();
		if (SystemLanguage == Chinese)
		{
		   DisHZ16x14Str(3,32,SelfTestFailStr,NormalDisplay);
		}
		else
		{
		   DisEN16x8Str(3,16,SelfTestFailStrEN,NormalDisplay);
		}
		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationFail);
		AutoMotorMgr.SelfTest.Status = SelfTestDisplayResult;
		AutoMotorMgr.SelfTest.TimeLimitedCnt = Def_GuiTimeDelayCnt3s;
	}
	else if (AutoMotorMgr.SelfTest.Status == SelfTestDisplayResult )
	{	
		if (AutoMotorMgr.SelfTest.TimeLimitedCnt > 0 )
	 	{
			AutoMotorMgr.SelfTest.TimeLimitedCnt--;
	 	}
		else
	 	{
	 		if ( AutoMotorMgr.SelfTest.Status == SelfTestWait )
	 		{
				AutoMotorMgr.SelfTest.Status = SelfTestFail;
	 		}
			else
			{
				GoIntoMainScreen_WithIdentifyInit();	
			}
	 	}
	}
}

void ShowWifiManufactureTest(void)
{
	//code uint8_t LinkingStr[]={HZ_lian,HZ_wang,HZ_zhong,ZF_douhao,HZ_qing,HZ_shao,HZ_houniao,HZ_end};		//�����У����Ժ�
	code uint8_t wifiMFTStrEn[]={"Wifi MFT"};						//
	//code uint8_t LinkSuccessStr[]={HZ_lian,HZ_wang,HZ_cheng,HZ_gong,HZ_end};		//�����ɹ�
	code uint8_t WifiMFTSuccessStrEn[]={"PASS!"};	
	//code uint8_t LinkFailStr[]={HZ_lian,HZ_wang,HZ_shibai,HZ_bai,HZ_end};		//����ʧ��
	code uint8_t WifiMFTFailStrEn[]={"FAIL!"};	

	if ( WifiMgr.MFT.Status == MFTStart )
	{
		ComPort_SetPost_WifiMFT();
		WifiMgr.MFT.Status = MFTWait;
		WifiMgr.MFT.TimeCnt = 15*64;	//15s
		SET_ALLKEYLED_OFF();
	}
	else if ( WifiMgr.MFT.Status == MFTWait )
	{
		DisEN16x8Str(3,32,wifiMFTStrEn,NormalDisplay);
		GUI_RefreshSleepTime();
		KEYLED_ASTERISK_Flash();
	}

	else if ( WifiMgr.MFT.Status == MFTSuccess )
	{
		SET_ALLKEYLED_OFF();
		Clear_Screen();
		DisEN16x8Str(3,42,WifiMFTSuccessStrEn,NormalDisplay);

		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationSuccess);

		WifiMgr.MFT.Status = MFTIdle;
		WifiMgr.MFT.TimeCnt = Def_GuiTimeDelayCnt3s;
	}
	else  if ( WifiMgr.MFT.Status == MFTFail )
	{
		SET_ALLKEYLED_OFF();
		Clear_Screen();
		if ( WifiMgr.MFT.errorcode == 0x02 )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,36,NoNetworkDeviceStr,NormalDisplay);
			}
			else{

				DisEN16x8Str(3,8,NoNetworkDeviceStrEn,NormalDisplay);
			}
		}
		else
		{
			DisEN16x8Str(3,42,WifiMFTFailStrEn,NormalDisplay);
		}
		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationFail);
		WifiMgr.MFT.Status = MFTIdle;
		WifiMgr.MFT.TimeCnt = Def_GuiTimeDelayCnt3s;
	}
		
	if (WifiMgr.MFT.TimeCnt > 0){
		WifiMgr.MFT.TimeCnt--;
	}
	else
	{
		if ( WifiMgr.MFT.Status == MFTWait )
		{
			WifiMgr.MFT.Status = MFTFail;
			WifiMgr.MFT.errorcode = 0x01;
		}
		else
		{
			GoIntoMainScreen_WithIdentifyInit();
		}
	}

	
}




void ShowErrorMessage(void)
{
	code uint8_t CommunicationErrorStr[]={HZ_tongyong,HZ_xunfei,HZ_shibai,HZ_bai,HZ_end};
	code uint8_t CommunicationErrorStr1En[]={"Communication"};
	code uint8_t CommunicationErrorStr2En[]={"Fail"};

	code uint8_t SystemErrorStr[]={"System Error"};
	code uint8_t UnkownErrorStr[]={"ERROR"};

	if (ErrorMessageMgr.ErrorType == CommunicationError)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(3,36,CommunicationErrorStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(3,12,CommunicationErrorStr1En,NormalDisplay);
			DisEN16x8Str(5,12,CommunicationErrorStr2En,NormalDisplay);
		}
		
	}
	else if  ( ErrorMessageMgr.ErrorType == SystemError )
	{
		DisEN16x8Str(3,12,SystemErrorStr,NormalDisplay);
	}
	else
	{
		DisEN16x8Str(3,12,UnkownErrorStr,NormalDisplay);
	}

	if ( ErrorMessageMgr.TimeCnt % 32 == 0 )
	{
		SET_ALLKEYLED_ON();
	}
	else if ( ErrorMessageMgr.TimeCnt % 32 == 16 )
	{
		SET_ALLKEYLED_OFF();
	}
	if ( ErrorMessageMgr.TimeCnt % 64 == 0 )
	{
		DEF_Fail_Beep;
	}
	
	if ( ErrorMessageMgr.TimeCnt > 1 )
	{
		ErrorMessageMgr.TimeCnt--;
	}
	else
	{
		GoIntoMainScreen_WithIdentifyInit();
	}

}



