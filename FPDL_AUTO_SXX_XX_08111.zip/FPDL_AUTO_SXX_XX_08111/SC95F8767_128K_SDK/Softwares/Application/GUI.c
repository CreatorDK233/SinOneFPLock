#include "IO.h"
#include "usart.h"
//Protocol layer
#include "BeepMgr.h"
#include "EEPROM.h"
#include "Key_SinOne.h"
#include "LEDsMgr.h"
#include "RTC_PCF8563.h"
#include "FingerPrint.h"
#include "FaceRecoginitionMgr.h"
#include "HostUART.h"
#include "LCD_HFG12864.h"
#include "MFC_MF17622.h"
#include "PIR.h"
#include "Radar.h"
#ifdef Function_YouzhiyunjiaWifi 
#include "YouzhiyunjiaWifi.h"
#endif
//Logic layer
#include "AppUnlock.h"
#include "KeyScan.h"
#include "Motor.h"
#include "Log.h"
#include "FP.h"
#include "LCD.h"
#include "MFC.h"
#include "RTC.h"
#include "FaceGUI.h"
#include "LowPower.h"
//Application layer
#include "GUI.h"
#include "GUI2.h"
#include "GUI_Function.h"
#include "Basic_Function.h"
#include "Voice_Menu.h"
#include "Font_Menu.h"
#include "Font.h"

uint8_t textnum = 0;

screen_t LastScreen;
uint8_t GUI_TimeCnt;
uint8_t GUI_ToggleFlag_1s;
uint8_t GUI_ToggleFlag_05s;
bool_t GUI_Flag_RefreshLCD;

keycode_t gui_keycode = KEY_NONE;

uint8_t PasscodeBUFF1[12];

uint8_t BcdCode_Plus(uint8_t BcdCode)
{
	uint8_t temp;
	if ((BcdCode&0x0F)==9)
	{
		temp = (BcdCode&0xF0)+0x10;
	}
	else
	{
		temp = BcdCode+1;
	}
	return temp;
}

uint8_t BcdCode_Minus(uint8_t BcdCode)
{
	uint8_t temp;
	if (BcdCode==0)
	{
		return 0;
	}
	if ((BcdCode&0x0F)==0)
	{
		temp = (BcdCode&0xF0)-0x10 + 9;
	}
	else
	{
		temp = BcdCode-1;
	}
	return temp;
}

uint8_t BcdMaxDays_in_Month(uint8_t year, uint8_t month)
{
       	uint8_t monttbuffer[12] = {0x31, 0x28, 0x31, 0x30, 0x31, 0x30, 0x31, 0x31, 0x30, 0x31, 0x30, 0x31};
		uint16_t y;
		uint8_t m;
		y=((year/16)*10)+(year%16)+2000;
		m = ((month/16)*10)+(month%16);
        if (((y % 4 == 0) && (y % 100 != 0)) 
			|| (y % 400 == 0)
			)
        {
                monttbuffer[1] = 0x29; 
		}
			
        return monttbuffer[m-1];
}






void UnlockModeAutoCalculate(void)
{
	if	( IfSystemWithoutSecondIdentity() == bTRUE )
	{
		UserIdentifyResultMgr.UnlockingMode = SingalMode;
		EEPROM_WriteSequential(UnlockModeStartAddr,&UserIdentifyResultMgr.UnlockingMode,1);
	}
}

void AutoMotorMgrConfigSave(void)
{
	EEPROM_WriteSequential(AutoMotorMgrUnlockTimeAddr,&AutoMotorMgr.UnlockTime,1);
	EEPROM_WriteSequential(AutoMotorMgrAutoLockTimeAddr,&AutoMotorMgr.AutoLockTime,1);
	EEPROM_WriteSequential(AutoMotorMgrLockDirectionAddr,&AutoMotorMgr.LockDirection,1);
	EEPROM_WriteSequential(AutoMotorMgrTorqueAddr,&AutoMotorMgr.TorqueLevel,1);
	EEPROM_WriteSequential(AutoMotorMgrBoltLockTimeAddr,&AutoMotorMgr.BoltLockTime,1);
}

void ReadAutoMotorMgrConfig(void)
{
	uint8_t temp;
	
	EEPROM_ReadSequential(AutoMotorMgrUnlockTimeAddr,&temp,1);
	if ((temp<2)||(temp>10))
	{
		#ifdef ProjectIs_AutoBarLock_S58Z07
		AutoMotorMgr.UnlockTime=0x03;//default is 5s
		#else
		AutoMotorMgr.UnlockTime=0x05;//default is 5s
		#endif
		
	}else{
		AutoMotorMgr.UnlockTime = temp;
	}	
	EEPROM_ReadSequential(AutoMotorMgrAutoLockTimeAddr,&temp,1);
	
		#ifdef ProjectIs_BarLock_S101Z01
		if (((temp>0x00)&&(temp<5))||(temp>60)){
		#else
		if (((temp>0x00)&&(temp<5))||(temp>20)){
		#endif
		AutoMotorMgr.AutoLockTime=0x00;//default is 5s
		DEBUG_MARK;
	}else{
		AutoMotorMgr.AutoLockTime = temp;
		DEBUG_MARK;
	}
	EEPROM_ReadSequential(AutoMotorMgrLockDirectionAddr,&temp,1);
	if ((temp!=LEFTOPEN)&&(temp!=RIGHTOPEN)){
		AutoMotorMgr.LockDirection=LEFTOPEN;//default is 
	}else{
		AutoMotorMgr.LockDirection = temp;
	}
	EEPROM_ReadSequential(AutoMotorMgrTorqueAddr,&temp,1);
	if ((temp<LowTorque)||(temp>LargeTorque)){
		AutoMotorMgr.TorqueLevel=MiddleTorque;//default is 5s
	}else{
		AutoMotorMgr.TorqueLevel = temp;
	}
	EEPROM_ReadSequential(AutoMotorMgrBoltLockTimeAddr,&temp,1);
	if ((temp<2)||(temp>24)){
		AutoMotorMgr.BoltLockTime=0x06;//default is 300ms
	}else{
		AutoMotorMgr.BoltLockTime = temp;
	}

	EEPROM_ReadSequential(AutoMotorMgrLockingTravelAddr,&temp,1);
	if ((temp>0)&&(temp<9)){
		AutoMotorMgr.LockingTravel=temp;
	}else{
		AutoMotorMgr.LockingTravel = 5;	//default is 8
	}

	EEPROM_ReadSequential(AutoMotorMgrAutoEjectAddr,&temp,1);
	if (temp == 0x01){
		AutoMotorMgr.AutoEject=temp;
	}else{
		AutoMotorMgr.AutoEject = 0x00;	//default is bfalse
	}
	
	
}
/****************************************************************/
/****************************************************************/
/****************************************************************/
/****************************************************************/

void AutoMotorMgrInitConfigReset(void)
{
    AutoMotorMgr.UnlockTime=2;
	AutoMotorMgr.AutoLockTime=5;
	AutoMotorMgr.LockDirection=LEFTOPEN;
	AutoMotorMgr.TorqueLevel = MiddleTorque;
	AutoMotorMgr.BoltLockTime=6;	

	AutoMotorMgrConfigSave();

	ComPort_SetPost_Parameter();
}
	
void ShowDoorBell(void)
{
	DisImage(33,12,61,40,Icon_DoorBell,NormalDisplay);
	
	if ( DoorBellMgr.TimeCnt > 0 )
	{
		DoorBellMgr.TimeCnt--;
	}
	else
	{
		GoIntoMainScreen_WithIdentifyInit();
	}

}
/*******************************************************/
/*******************************************************/
/*******************************************************/
void DisplayMainPage(void)//��ʾ��ҳ��
{
	code uint8_t YearMonthDay[]={ZF_2,ZF_0,ZF_0,ZF_0,ZF_hengan,ZF_0,ZF_1,ZF_hengan,ZF_0,ZF_1,HZ_end};
	//code uint8_t Frame[]={ZF_1,ZF_8,ZF_hengan,ZF_0,ZF_1,ZF_hengan,ZF_0,ZF_1,HZ_end};
	code uint8_t Str1[]={HZ_weihe,HZ_le,HZ_nin,HZ_de,HZ_an,HZ_quan,HZ_end};
	code uint8_t Str1En[]={"Sys without"};
	code uint8_t Str2[]={HZ_qing,HZ_tian,HZ_jia,HZ_guan,HZ_li,HZ_yuan,HZ_end};
	code uint8_t Str2En[]={"admin."};
	code uint8_t Str3[]={HZ_qing,HZ_shu,HZ_ru,HZ_di,HZ_er,HZ_shen,HZ_fen,HZ_end};
	code uint8_t Str3En[]={"Input 2nd ID"};
	#if (defined Function_IndependentDoorBellKey) || (defined Function_IndependentLockKey)
	 uint8_t Str4[]={HZ_anya,ZF_xiaoyuhao,ZF_jinghao,ZF_dayuhao,HZ_jinru,HZ_ru,HZ_guan,HZ_li,HZ_mo,HZ_si,HZ_end};
	 uint8_t Str4En[]={"Press # to menu"};
	#endif
	code uint8_t PleaseAddAdminStr[]={HZ_qing,HZ_tian,HZ_jia,HZ_guan,HZ_li,HZ_yuan,HZ_end};
	code uint8_t PleaseAddAdminStrEn[]={"Pls add admin."};

	if (AwakeDisplayMgr.TimeCnt > 0 )
	{
		AwakeDisplayMgr.TimeCnt--;
	}

	if ((AwakeDisplayMgr.DisplayType == DisplayHide)
		&&(AwakeDisplayMgr.TimeCnt > 0 )
		)
	{
		SET_ALLKEYLED_OFF();
		return;
	}

	SET_ALLKEYLED_ON();
	GUI_SetFPM_LED(DEF_FpmLedMode_On,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
	
	DisImage(0,92,25,16,IconBetteryLevel[BatteryMgr.BatteryLevel],NormalDisplay);

	if ( ( LockBrand.BrandType == BigBrand )
		||( LockBrand.BrandType == DefaultBigBrand )
		)
	{
	
		DisBcdDigital16x8(0,8,SystemTime.hour,NormalDisplay);//��Ļ����ʾ��û��
		if (GUI_ToggleFlag_05s == 0 )
		{
			DisZF16x8(0,24,ZF_kongge,NormalDisplay);
		}
		else
		{
			DisZF16x8(0,24,ZF_maohao,NormalDisplay);
		}
		DisBcdDigital16x8(0,32,SystemTime.minute,NormalDisplay);

		if ( WifiMgr.WifiConfigStatus.Status == ConnectedToRooter )
		{
			DisImage(0,66,16,16,Icon_WifiConnected,NormalDisplay);
		}
		else
		{
			Clear_PartyScreen(0,66,16,16);
			//DisImage(0,66,16,16,Icon_WifiNoSignal,NormalDisplay);
		}
		
		if (	( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyIdle )
			)
		{
			if	( (UserIdentifyResultMgr.UnlockingMode == DoubleMode )&&
					((UserIdentifyResultMgr.FPIdentifyStatus == S_SUCCESS )
					||(UserIdentifyResultMgr.CardIdentifyStatus == S_SUCCESS )
					||(UserIdentifyResultMgr.PasscodeIdentifyStatus == S_SUCCESS ))
				)
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(3,16,Str3,NormalDisplay); //please input sencond identity
				}
				else{
					DisEN16x8Str(3,8,Str3En,NormalDisplay); //please input sencond identity
				}
				
				GUI_Flag_RefreshLCD = bTRUE;
			}
				
			#if (defined Function_IndependentDoorBellKey) || (defined Function_IndependentLockKey)
			else if ( g_ASTERISK_PressedOnMainScreen == bTRUE )
			{
				GUI_Flag_RefreshLCD = bTRUE;
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(6,4,Str4,NormalDisplay);
				}
				else{
					DisEN16x8Str(6,4,Str4En,NormalDisplay);
				}						
			}
			#endif

			else if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
			{
				if (SystemLanguage == Chinese)
				{
					DisHZ16x14Str(6,20,PleaseAddAdminStr,NormalDisplay);
				}
				else
				{			
					DisEN16x8Str(6,8,PleaseAddAdminStrEn,NormalDisplay);
				}	
				GUI_Flag_RefreshLCD = bTRUE;
			}
			else
			{
				GUI_Flag_RefreshLCD = bTRUE;

				DisHZ16x14Str(6,24,YearMonthDay,NormalDisplay);
				DisBcdDigital16x8(6,40,SystemTime.year,NormalDisplay);
				DisBcdDigital16x8(6,64,SystemTime.month,NormalDisplay);
				DisBcdDigital16x8(6,88,SystemTime.date,NormalDisplay);
			}
			//DisHZ16x14Str(6,16,FPDLLog,NormalDisplay);
			ShowLockBrand();
		}
	}
	else
	{
		DisHZ16x14Str(0,8,YearMonthDay,NormalDisplay);
		DisBcdDigital16x8(0,24,SystemTime.year,NormalDisplay);
		DisBcdDigital16x8(0,48,SystemTime.month,NormalDisplay);
		DisBcdDigital16x8(0,72,SystemTime.date,NormalDisplay);
		
		if (	( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyIdle ) )
		{
			if 	( (UserIdentifyResultMgr.UnlockingMode == DoubleMode )&&
					((UserIdentifyResultMgr.FPIdentifyStatus == S_SUCCESS )
					||(UserIdentifyResultMgr.CardIdentifyStatus == S_SUCCESS )
					||(UserIdentifyResultMgr.PasscodeIdentifyStatus == S_SUCCESS ))
				)
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(3,16,Str3,NormalDisplay);	//please input sencond identity
				}
				else{
					DisEN16x8Str(3,8,Str3En,NormalDisplay);	//please input sencond identity
				}
				GUI_Flag_RefreshLCD = bTRUE;
			}
				
				
			#if (defined Function_IndependentDoorBellKey) || (defined Function_IndependentLockKey)
			else if ( g_ASTERISK_PressedOnMainScreen == bTRUE )
			{
				GUI_Flag_RefreshLCD = bTRUE;
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(3,4,Str4,NormalDisplay);
				}
				else{
					DisEN16x8Str(3,4,Str4En,NormalDisplay);
				}						
			}
			#endif
			
			else if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
			{
				DisImage(3,2,27,24,Icon_Warning,NormalDisplay);
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(2,40,Str1,NormalDisplay);
					DisHZ16x14Str(4,40,Str2,NormalDisplay);
				}
				else{			
					DisEN16x8Str(2,38,Str1En,NormalDisplay);
					DisEN16x8Str(4,38,Str2En,NormalDisplay);
				}
				
				GUI_Flag_RefreshLCD = bTRUE;
			}
			else
			{
				GUI_Flag_RefreshLCD = bTRUE;
				DisBcdDigital32x20(2,14,SystemTime.hour,NormalDisplay);
				DisBcdDigital32x20(2,74,SystemTime.minute,NormalDisplay);
					
				if (GUI_ToggleFlag_05s == 0 )
				{
					DisImage(2,54,20,32,ZF32x20[11],NormalDisplay);
				}
				else
				{
					DisImage(2,54,20,32,ZF32x20[10],NormalDisplay);
				}
				
			}
			
			//DisHZ16x14Str(6,16,FPDLLog,NormalDisplay);
			ShowLockBrand();
		}
	}
	
}
/*******************************************************/
/*******************************************************/
/*******************************************************/
void GUI_UpadteMain(void)
{
	if ( (ComportMgr.DoorStatus == Closing )
		||(ComportMgr.DoorStatus == Close)
		)
	{
		UserIdentifyResultMgr.IdentifyType = InsideCloseDoor;
		Enable_KEYLED_WATERLIGHT();	
		CurrentScreen = SCREEN_IdentifySuccess;
		DisplayDoorStatusMgr.Status = DoorCloseInit;
		UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;
	}
	else if (( ComportMgr.DoorStatus == Openning )
			||( ComportMgr.DoorStatus == Open )
			||( ComportMgr.DoorStatus == OpenedWaitClose )
			)
	{
		if( WifiMgr.RemoteUnlockMgr.UnlockResult == UnlockSoon )
		{
			WifiMgr.RemoteUnlockMgr.UnlockResult = UnlockIdle;
			UserIdentifyResultMgr.IdentifyType = RemoteUnlock;
		}
		else
		{
			UserIdentifyResultMgr.IdentifyType = InsideOpenDoor;
		}
		Enable_KEYLED_WATERLIGHT();	
		CurrentScreen = SCREEN_IdentifySuccess;
		DisplayDoorStatusMgr.Status = DoorOpenInit;
		UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;
	}

	if ( ComportMgr.TimeOutTimes > 5 )
	{
		ErrorMessageMgr.ErrorType = CommunicationError;
		ErrorMessageMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
		CurrentScreen = SCREEN_ErrorMessage;
	}

	if ( SafetyMonitorMgr.SystemLocked == bTRUE )
	{
		CurrentScreen = SCREEN_SystemLocked;
		GUI_SetFPM_LED(DEF_FpmLedMode_Off,DEF_FpmLedColor_All,DEF_FpmLedColor_All,255);
		SET_LED_RGB_OFF();
		SET_LED_RB_OFF();
	}
	
	if (/*( UART1_Mgr.TxLength == 0x00 )&& */( CardIdentifyMgr.CardDetectIntervalTimeCnt ==0 ) )	//FPM Cmd is sent out
	{
		CardIdentifyMgr.CardDetectIntervalTimeCnt = Def_CardDetectIntervalTime;
		CardUserIdentify();
	}
	
	if ( CardIdentifyMgr.Status == Success)
	{
		UserIdentifyResultMgr.CardIdentifyStatus = S_SUCCESS;
		UserIdentifyResultMgr.CardUserID = CardIdentifyMgr.UserID;
		GUI_RefreshSleepTime();
		SafetyMonitorMgr.FpIdentifyFailedTimes = 0x00;
        SafetyMonitorMgr.CardIdentifyFailedTimes = 0x00;
        SafetyMonitorMgr.PasscodeIdentifyFailedTimes = 0x00;
		SafetyMonitorMgr.FaceIdentifyFailedTimes = 0x00;

		if (UserIdentifyResultMgr.UnlockingMode == SingalMode )
		{
			UserIdentifyResultMgr.IdentifyType = CARD;
			Enable_KEYLED_WATERLIGHT();	
			CurrentScreen = SCREEN_IdentifySuccess;
			DisplayDoorStatusMgr.Status = DoorOpenInit;
			UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
			//SafetyMonitorMgr.CardIdentifyFailedTimes = 0x00;
		}
		else if (UserIdentifyResultMgr.UnlockingMode == DoubleMode )
		{
			if (( UserIdentifyResultMgr.PasscodeIdentifyStatus == S_SUCCESS ))
			{
				UserIdentifyResultMgr.IdentifyType = CARDandPASSCODE;	
				Enable_KEYLED_WATERLIGHT();	
				CurrentScreen = SCREEN_IdentifySuccess;
				DisplayDoorStatusMgr.Status = DoorOpenInit;
				UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
				//SafetyMonitorMgr.CardIdentifyFailedTimes = 0x00;
			}
			else if (( UserIdentifyResultMgr.FPIdentifyStatus == S_SUCCESS ))
			{
				UserIdentifyResultMgr.IdentifyType = FINGERPRINTandCARD;	
				Enable_KEYLED_WATERLIGHT();	
				CurrentScreen = SCREEN_IdentifySuccess;
				DisplayDoorStatusMgr.Status = DoorOpenInit;
				UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
				//SafetyMonitorMgr.CardIdentifyFailedTimes = 0x00;
			}
			else{
				if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
				{
					textnum = textnum+1; 
					PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PleaseInputSecondIdentity);
					CardIdentifyMgr.Status = ReadingCardID;
				}
			}
		}
	}
	else if ( CardIdentifyMgr.Status == Fail)
	{
		if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
		{
			if ( (CardIdentifyMgr.CID[0] == 0x16)
				&&(CardIdentifyMgr.CID[1] == 0xD4)
				&&(CardIdentifyMgr.CID[2] == 0xDB)
				&&(CardIdentifyMgr.CID[3] == 0x3C)
				)
			{
				DEBUG_MARK;
				if ( LockBrand.BrandChangeTimeDelay == 0 )
				{
					WriteLockBrand();
					if ( LockBrand.GotBrandData == bTRUE )
					{
						DEBUG_MARK;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationSuccess);
						LockBrand.BrandChangeTimeDelay = Def_GuiTimeDelayCnt3s;
						GUI_RefreshSleepTime();
					}
				}
				CardIdentifyMgr.Status = ReadingCardID;
			}
				
			#ifdef Function_FaceRecoginitionSwitchedByNFC
			else if ( (CardIdentifyMgr.CID[0] == 0x20)
				&&(CardIdentifyMgr.CID[1] == 0xA8)
				&&(CardIdentifyMgr.CID[2] == 0x35)
				&&(CardIdentifyMgr.CID[3] == 0x7B)
				)
			{
				if ( FrmMgr.FrmFunctionSwitchTimeDelay == 0 )
				{
					if ( MFC_FrmFunctionConfigSwitch() == S_SUCCESS )
					{
						FrmMgr.FrmFunctionSwitchTimeDelay = Def_GuiTimeDelayCnt3s;
						GUI_RefreshSleepTime();
						if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
						{
							FrmMgr.FrmFunctionConfig = FRM_Disabled;
							PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_FrmFunctionDisbled);
						}
						else
						{
							FrmMgr.FrmFunctionConfig = FRM_Enabled;
							PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_FrmFunctionEnabled);
						}
						FrmFunctionConfigSave();	
					}
				}
			}
			#endif
			else
			{
				UserIdentifyResultMgr.IdentifyType = INITIALSTATUS;
				Enable_KEYLED_WATERLIGHT(); 
				CurrentScreen = SCREEN_IdentifySuccess;
				DisplayDoorStatusMgr.Status = DoorOpenInit;
				GUI_RefreshSleepTime();
				UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;
			}		
		}
		else
		{
			SafetyMonitorMgr.CardIdentifyFailedTimes++;
			GUI_RefreshSleepTime();		//refresh to 10s
			UserIdentifyResultMgr.CardIdentifyStatus = S_FAIL;
			UserIdentifyResultMgr.IdentifyType = CARD;
			UserIdentifyResultMgr.CardUserID = 0x00;
			CurrentScreen = SCREEN_IdentifyFail;
			UserIdentifyResultMgr.TimeCnt = Def_MessageBoxTimeDelay;
			SET_RBLED_R_Flash(3);
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_IdentifyFail);	

			if ( SafetyMonitorMgr.CardIdentifyFailedTimes > DEF_CardIdentifyFailedTimesLimited )
			{
				SafetyMonitorMgr.SystemLocked = bTRUE;
				SafetyMonitorMgr.SystemLockedTimeDelay = DEF_SystemLockedTime;
				ComPort_SetPost_Alarm(DEF_WifiAlarm_CardUnlockAlarm,CARDUSER,0x00);
				#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
				Wifi_PostEvent(DEF_WifiEvent_CardUnlockAlarm,CARDUSER,0x00);
				#endif
			}
		}
	}

	FpUserIdentify();
	if ( FpIdentifyMgr.Status == success)
	{
		UserIdentifyResultMgr.FPIdentifyStatus = S_SUCCESS;
		UserIdentifyResultMgr.FPUserID = FpIdentifyMgr.UserID+1;
		SafetyMonitorMgr.FpIdentifyFailedTimes = 0x00;
        SafetyMonitorMgr.CardIdentifyFailedTimes = 0x00;
        SafetyMonitorMgr.PasscodeIdentifyFailedTimes = 0x00;
		SafetyMonitorMgr.FaceIdentifyFailedTimes = 0x00;

		if (UserIdentifyResultMgr.UnlockingMode == SingalMode )
		{
			UserIdentifyResultMgr.IdentifyType = FINGERPRINT;
			Enable_KEYLED_WATERLIGHT();	
			CurrentScreen = SCREEN_IdentifySuccess;
			DisplayDoorStatusMgr.Status = DoorOpenInit;
			UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
			//SafetyMonitorMgr.IdentifyFailedTimes = 0x00;
		}
		else if (UserIdentifyResultMgr.UnlockingMode == DoubleMode )
		{
			if (( UserIdentifyResultMgr.CardIdentifyStatus == S_SUCCESS))
			{	
				UserIdentifyResultMgr.IdentifyType = FINGERPRINTandCARD;
				Enable_KEYLED_WATERLIGHT();	
				CurrentScreen = SCREEN_IdentifySuccess;
				DisplayDoorStatusMgr.Status = DoorOpenInit;
				UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
				//SafetyMonitorMgr.IdentifyFailedTimes = 0x00;
			}
			else if (( UserIdentifyResultMgr.PasscodeIdentifyStatus == S_SUCCESS ))
			{	
				UserIdentifyResultMgr.IdentifyType = FINGERPRINTandPASSCODE;	
				Enable_KEYLED_WATERLIGHT();	
				CurrentScreen = SCREEN_IdentifySuccess;
				DisplayDoorStatusMgr.Status = DoorOpenInit;
				UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
				//SafetyMonitorMgr.IdentifyFailedTimes = 0x00;
			}
			else
			{
				FpIdentifyMgr.Status = FPMcmdStart;
				if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
				{
					PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PleaseInputSecondIdentity);
				}
			}
		}
		
	}
	else if ( FpIdentifyMgr.Status == fail)
	{
		if ( FpIdentifyMgr.ErrorType == Error_SerialNumberMismatched )
		{
			UserIdentifyResultMgr.ErrorType = FPMserialNumberMismatched;
		}
		else{
			UserIdentifyResultMgr.ErrorType = UserUnregistered;
		}
		
		if ( ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
			//&& (UserIdentifyResultMgr.ErrorType != FPMserialNumberMismatched)
			)
		{
			//UserIdentifyResultMgr.FPIdentifyStatus = S_SUCCESS;
			UserIdentifyResultMgr.IdentifyType = INITIALSTATUS;
			Enable_KEYLED_WATERLIGHT();	
			CurrentScreen = SCREEN_IdentifySuccess;
			DisplayDoorStatusMgr.Status = DoorOpenInit;
			UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;
			
		}
		else
		{
			UserIdentifyResultMgr.FPIdentifyStatus = S_FAIL;
			UserIdentifyResultMgr.IdentifyType = FINGERPRINT;
			UserIdentifyResultMgr.FPUserID = 0x00;
			CurrentScreen = SCREEN_IdentifyFail;
			UserIdentifyResultMgr.TimeCnt = Def_MessageBoxTimeDelay;
			SET_RBLED_R_Flash(3);
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_IdentifyFail);
			
			if ( SafetyMonitorMgr.FpIdentifyFailedTimes < DEF_FpIdentifyFailedTimesLimited )
			{
				SafetyMonitorMgr.FpIdentifyFailedTimes++;
			}
			else
			{
				SafetyMonitorMgr.SystemLocked = bTRUE;
				SafetyMonitorMgr.SystemLockedTimeDelay = DEF_SystemLockedTime;
				ComPort_SetPost_Alarm(DEF_WifiAlarm_FpUnlockAlarm,FPUSER,0x00);
				#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
				Wifi_PostEvent(DEF_WifiEvent_FpUnlockAlarm,FPUSER,0x00);
				#endif
			}
		
		}

	}

	PasscodeUserIdentify();
	if (PasscodeUserIdentifyMgr.Status == PasscodeIdentifySuccess)
	{
		UserIdentifyResultMgr.PasscodeIdentifyStatus = S_SUCCESS;
		UserIdentifyResultMgr.PasscodeUserID = PasscodeUserIdentifyMgr.UserID;
		SafetyMonitorMgr.FpIdentifyFailedTimes = 0x00;
        SafetyMonitorMgr.CardIdentifyFailedTimes = 0x00;
        SafetyMonitorMgr.PasscodeIdentifyFailedTimes = 0x00;
		SafetyMonitorMgr.FaceIdentifyFailedTimes = 0x00;

		if ( UserIdentifyResultMgr.PasscodeType == AppPasscode )
		{
			UserIdentifyResultMgr.IdentifyType = PASSCODE;
			Enable_KEYLED_WATERLIGHT(); 
			CurrentScreen = SCREEN_IdentifySuccess;
			DisplayDoorStatusMgr.Status = DoorOpenInit;
			UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
		}
		else if ( UserIdentifyResultMgr.PasscodeType == OnlinePasscode )
		{
			UserIdentifyResultMgr.IdentifyType = ONLINEPASSCODE;
			Enable_KEYLED_WATERLIGHT(); 
			CurrentScreen = SCREEN_IdentifySuccess;
			DisplayDoorStatusMgr.Status = DoorOpenInit;
			UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;
		}
		else
		{
			if (UserIdentifyResultMgr.UnlockingMode == SingalMode )
			{
				UserIdentifyResultMgr.IdentifyType = PASSCODE;
				Enable_KEYLED_WATERLIGHT();	
				CurrentScreen = SCREEN_IdentifySuccess;
				DisplayDoorStatusMgr.Status = DoorOpenInit;
				UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
			}
			else if (UserIdentifyResultMgr.UnlockingMode == DoubleMode )
			{
				if (( UserIdentifyResultMgr.CardIdentifyStatus == S_SUCCESS ))
				{	
					UserIdentifyResultMgr.IdentifyType = CARDandPASSCODE;
					Enable_KEYLED_WATERLIGHT();	
					CurrentScreen = SCREEN_IdentifySuccess;
					DisplayDoorStatusMgr.Status = DoorOpenInit;
					UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
					//SafetyMonitorMgr.IdentifyFailedTimes = 0x00;
				}
				else if (( UserIdentifyResultMgr.FPIdentifyStatus == S_SUCCESS ))
				{	
					UserIdentifyResultMgr.IdentifyType = FINGERPRINTandPASSCODE;	
					Enable_KEYLED_WATERLIGHT();	
					CurrentScreen = SCREEN_IdentifySuccess;
					DisplayDoorStatusMgr.Status = DoorOpenInit;
					UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
					//SafetyMonitorMgr.IdentifyFailedTimes = 0x00;
				}
				else{	
						PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseInputSecondIdentity);
						PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
				}
			}
		}
	}
	else if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyFail )
	{
		if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
		{
			//UserIdentifyResultMgr.FPIdentifyStatus = S_SUCCESS;
			UserIdentifyResultMgr.IdentifyType = INITIALSTATUS;
			Enable_KEYLED_WATERLIGHT(); 
			CurrentScreen = SCREEN_IdentifySuccess;
			DisplayDoorStatusMgr.Status = DoorOpenInit;
			UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;
		}
		else
		{
			UserIdentifyResultMgr.PasscodeIdentifyStatus = S_FAIL;
			UserIdentifyResultMgr.IdentifyType = PASSCODE;
			UserIdentifyResultMgr.PasscodeUserID = 0x00;
			CurrentScreen = SCREEN_IdentifyFail;
			UserIdentifyResultMgr.TimeCnt = Def_MessageBoxTimeDelay;
			SET_RBLED_R_Flash(3);
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_IdentifyFail);	
			if ( SafetyMonitorMgr.PasscodeIdentifyFailedTimes < DEF_PasscodeIdentifyFailedTimesLimited )
			{
				SafetyMonitorMgr.PasscodeIdentifyFailedTimes++;
			}
			else
			{
				SafetyMonitorMgr.SystemLocked = bTRUE;
				SafetyMonitorMgr.SystemLockedTimeDelay = DEF_SystemLockedTime;
				ComPort_SetPost_Alarm(DEF_WifiAlarm_PasswordUnlockAlarm,PASSCODEUSER,0x00);
				#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
				Wifi_PostEvent(DEF_WifiEvent_PasswordUnlockAlarm,PASSCODEUSER,0x00);
				#endif
			}
		}
	}
	else if (PasscodeUserIdentifyMgr.Status == PasscodeIdentifyAgingTestSuccess )
	{
		AgingTestMgr.MotorRunTimes=0x00000000;		
		AgingTestMgr.SlideRunTimes=0x0000;	
		AgingTestMgr.TestFlag = bFALSE;
		
		AutoMotorMgr.UnlockTime=2;
		AutoMotorMgr.AutoLockTime=5;
		ComPort_SetPost_Parameter();
		
		CurrentScreen = SCREEN_AgingTest;
		
	}
	else if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyEngineeringModeSuccess )
	{
		GoIntoEngineeringModeMenu_Init();	
		GUI_RefreshSleepTime();
	}
	else if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyWifiMFTSuccess)
	{
		WifiMgr.MFT.Status = MFTStart;
		CurrentScreen = SCREEN_WifiMFT;	
		PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
	}
	else if (PasscodeUserIdentifyMgr.Status == PasscodeIdentifyRemoteUnlockRequestSuccess)
	{
		CurrentScreen = SCREEN_RemoteUnlockRequest;
		WifiMgr.RemoteUnlockMgr.Status = RemoteUnlockRequestInit;
		PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
	}
	else if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifySelfTestSuccess )
	{
		SelfTestMgr.Status = SELFTEST_START;
		CurrentScreen = SCREEN_SelfTest;	
		PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
	}
	else if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyFastVersionCheckSuccess )
	{
		GoIntoShowSystemVersion();	
		PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
		GUI_RefreshSleepTime();
	}
	else if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyLanguageSetToEnglishSuccess )
	{
		PasscodeInputMgr.Point = 0x00;
		PasscodeInputMgr.PasscodeLen = 16;
		PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
		
		SystemLanguage = English;
		SystemConfigSave();
		VoiceReportCurrentLanguage();
	}
	else if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyLanguageSetToChineseSuccess )
	{
		PasscodeInputMgr.Point = 0x00;
		PasscodeInputMgr.PasscodeLen = 16;
		PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
	
		SystemLanguage = Chinese;
		SystemConfigSave();
		VoiceReportCurrentLanguage();			
	}
	else if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyIntoMainMenuSuccess )
	{
		CurrentScreen = SCREEN_ManagerIdentify;
		ManagerIdentifyMgr.Status = StartManagerIdentify;
	}
	else if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifySwitchPryingEnable )
	{
		if( PickAlarmEnableMgr.Enable == bTRUE )
		{
			PickAlarmEnableMgr.Enable = bFALSE;
		}
		else{
			PickAlarmEnableMgr.Enable = bTRUE;
		}
		AntiPryingMgr.AntiPryingTrigger = bFALSE;
		VoiceReportCurrentPickAlarmEnableSetting();
		GoIntoMainScreen_WithIdentifyInit();
	}
		else if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyNetWorkLinkSuccess )
	{
		CurrentScreen = SCREEN_NetWorkLink;
		WifiMgr.Link.Status = LinkStart;
		
	}
		
	#ifdef Function_FaceRecoginition	
	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		if ( PasscodeInputMgr.Point > 0 )
		{
			FaceIdentifyMgr.IndentifyDelayTimeCnt = Def_GuiTimeDelayCnt1s;
		}
		
		if ( FaceIdentifyMgr.IndentifyDelayTimeCnt > 0x0000 )
		{
			 FaceIdentifyMgr.IndentifyDelayTimeCnt--;	 
		}
		
		if ((( IfSystemIsInFactoryDefaultStatus() == bTRUE )		//Face identify Demo mode is enabled
			||( IfSystemIsNoFaceUser() == bFALSE ))		//system is has face user
			&&( FaceIdentifyMgr.IndentifyDelayTimeCnt <= 0x0000 )
			&&( g_ASTERISK_PressedOnMainScreen == bFALSE )		//wait user press # into manager identify screen
		#if  (defined ProjectIs_BarLock_S15Z07) || (defined ProjectIs_BarLock_S15Z08) \
					|| (defined ProjectIs_BarLock_S15Z09)
			&&( BatteryMgr.PowerSavingMode == bFALSE )
		#endif
			)
		{
			FaceUserIdentify();
			if ( FaceIdentifyMgr.Status == FaceIdentifySuccess )
			{
				UserIdentifyResultMgr.FaceIdentifyStatus = S_SUCCESS;
				UserIdentifyResultMgr.FaceUserID = GetUserIDbyFaceTemplateID(FrmMgr.UserID);
				SafetyMonitorMgr.FpIdentifyFailedTimes = 0x00;
		        SafetyMonitorMgr.CardIdentifyFailedTimes = 0x00;
		        SafetyMonitorMgr.PasscodeIdentifyFailedTimes = 0x00;
				SafetyMonitorMgr.FaceIdentifyFailedTimes = 0x00;
				//if (UserIdentifyResultMgr.UnlockingMode == SingalMode )
				{
					UserIdentifyResultMgr.IdentifyType = FACE;
					Enable_KEYLED_WATERLIGHT();	
					CurrentScreen = SCREEN_IdentifySuccess;
					DisplayDoorStatusMgr.Status = DoorOpenInit;
					UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
				}
			}
			else if ( FaceIdentifyMgr.Status == FaceIdentifySuccess_NoUser)
			{
				UserIdentifyResultMgr.IdentifyType = INITIALSTATUS;
				Enable_KEYLED_WATERLIGHT(); 
				CurrentScreen = SCREEN_IdentifySuccess;
				DisplayDoorStatusMgr.Status = DoorOpenInit;
				UserIdentifyResultMgr.TimeCnt = Def_IdentifySuccessScreenTimeLimited;	
			}
			else if ( FaceIdentifyMgr.Status == FaceIdentifyFail )
			{
				FaceIdentifyMgr.Status = FrmIdentifyStart;
				DEBUG_MARK;
			}
		}
		else
		{
			if ( FrmMgr.PowerStatus != FRM_PowerOff )
			{
				FaceRecognition_HardwarePowerOff();
			}	
		}
	}
	#endif
	
	DisplayMainPage();

	if (SystemPowerMgr.SleepDelayTimerCnt == 0x0000)
	{
		Clear_Screen();
		SET_ALLKEYLED_OFF();
	}

}




/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowMainMenu(void)//��ʾ���˵�
{
	uint8_t i;

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,MainMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}
	for (i=0;i<4;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,MainMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,MainMenuStrEn[i],NormalDisplay);
		}
	}		
	GUI_Flag_RefreshLCD = bTRUE;
}




/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowUserManagementMenu(void)
{
	uint8_t i;
	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
		{
			if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,UserManagementMenuVoiceBuff_WithFRM[VoiceMenuMgr.MenuPoint]);
				VoiceMenuMgr.MenuPoint++;
			}
		}
		for (i=0;i<4;i++)
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(2*i,0,UserManagementMenuStr_WithFRM[i],NormalDisplay);
			}
			else{
				DisEN16x8Str(2*i,0,UserManagementMenuStrEn_WithFRM[i],NormalDisplay);
			}
		}
	}
	else
	{
		if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
		{
			if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,UserManagementMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
				VoiceMenuMgr.MenuPoint++;
			}
		}
		for (i=0;i<3;i++)
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(2*i,0,UserManagementMenuStr[i],NormalDisplay);
			}
			else{
				DisEN16x8Str(2*i,0,UserManagementMenuStrEn[i],NormalDisplay);
			}
		}
	}
	GUI_Flag_RefreshLCD = bTRUE;
}


/*******************************************************/
/*******************************************************/
/*******************************************************/

void ShowFaceMenu(void)
{
	uint8_t i;

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,FaceMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	for (i=0;i<3;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,FaceMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,FaceMenuStrEn[i],NormalDisplay);
		}

	}		
}

void GoIntoFpMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_FpMenu;
	//DEF_MenuSwitchDelayTime;
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowFpMenu(void)
{
	uint8_t i;

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,FpMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}


	for (i=0;i<4;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,FpMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,FpMenuStrEn[i],NormalDisplay);
		}
	}


	
	GUI_Flag_RefreshLCD = bTRUE;
}


/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowFpDeleteMenu(void)
{
	uint8_t i;

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,FpDeleteMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	for (i=0;i<3;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,FpDeleteMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,FpDeleteMenuStrEn[i],NormalDisplay);
		}
	}

	GUI_Flag_RefreshLCD = bTRUE;
}



/*******************************************************/
/*******************************************************/
/*******************************************************/
void GoIntoPasscodeMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_PasscodeMenu;
	//DEF_MenuSwitchDelayTime;
}

void ShowPasscodeMenu(void)
{
	uint8_t i;

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,PasscodeMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	for (i=0;i<4;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,PassCodeMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,PassCodeMenuStrEn[i],NormalDisplay);
		}

	}		
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void GoIntoCardMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 5;
	CurrentScreen = SCREEN_CardUserMenu;
	//DEF_MenuSwitchDelayTime;
}
void ShowCardMenu(void)
{
	uint8_t i;
	
	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,CardMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	for (i=0;i<3;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,CardUserMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,CardUserMenuStrEn[i],NormalDisplay);
		}
	}				
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void GoIntoInfoInquiryMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_InfoInquiryMenu;
	//DEF_MenuSwitchDelayTime;
}

/*******************************************************/
/*******************************************************/
/*******************************************************/



/*******************************************************/
/*******************************************************/
/*******************************************************/
void GoIntoLogMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 4;
	CurrentScreen = SCREEN_EventLogMenu;
	//DEF_MenuSwitchDelayTime;
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowEventLogMenu(void)
{
	uint8_t i;

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,LogMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	for (i=0;i<2;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,EventLogMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,EventLogMenuStrEn[i],NormalDisplay);
		}
	}			
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void GoIntoSystemConfigMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_SystemConfigMenu;
	//DEF_MenuSwitchDelayTime;
}
void ShowSystemConfigMenu(void)//��ʾϵͳ���ò˵�
{

	uint8_t i;
	
	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,SystemConfigMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	for (i=0;i<4;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,SytemConfigMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,SytemConfigMenuStrEn[i],NormalDisplay);
		}
	}		
	GUI_Flag_RefreshLCD = bTRUE;
}

/*******************************************************/
/*******************************************************/
/*******************************************************/

void ShowVoiceSettingMenu(void)
{
	uint8_t i;
	
	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceSettingMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	for (i=0;i<2;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,VoiceSettingMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,VoiceSettingMenuStrEn[i],NormalDisplay);
		}
	}				
}


/*******************************************************/
/*******************************************************/
/*******************************************************/


/*******************************************************/
/*******************************************************/
/*******************************************************/

void ShowAutoMotorSettingMenu(void)
{
	uint8_t i,j;
	
	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,MotorSettingMenuVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	for (i=0;i<4;i++)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2*i,0,AutoMotorSetingMenuStr[i],NormalDisplay);
		}
		else{
			DisEN16x8Str(2*i,0,AutoMotorSetingMenuStrEN[i],NormalDisplay);
		}
		j++;
	}		
	GUI_Flag_RefreshLCD = bTRUE;
}

/*******************************************************/
/*******************************************************/
/*******************************************************/



/*******************************************************/
/*******************************************************/
/*******************************************************/

/*******************************************************/

/*******************************************************/
/*******************************************************/



void VoiceReportUserID(uint16_t Value)
{
	uint16_t VoiceStr[7];
	VoiceStr[0]=VOICE_Current;
	VoiceStr[1]=VOICE_User;
	VoiceStr[2]=VOICE_ID;
	VoiceStr[3]=TranslateNumberToVoice(Value%1000/100);
	VoiceStr[4]=TranslateNumberToVoice(Value%100/10);
	VoiceStr[5]=TranslateNumberToVoice(Value%10);
	VoiceStr[6]=DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}


/*******************************************************/
/*******************************************************/

/*******************************************************/
/*******************************************************/


/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowRegisterUserFace(void)
{
	#ifdef Function_FaceRecoginition			
	//uint8_t i;
	//uint16_t UserID;
	code uint8_t AddUserFaceStr[]={HZ_tian,HZ_jia,HZ_ren,HZ_lianbu,HZ_yong,HZ_hu,HZ_end};  	
	code uint8_t AddUserFaceStrEn[]={"Add Face user"};  	
	code uint8_t AddMasterFaceStr[]={HZ_tian,HZ_jia,HZ_guan,HZ_li,HZ_yuan,HZ_ren,HZ_lianbu,HZ_end};  	
	code uint8_t AddMasterFaceStrEn[]={"Add Face Admin."};  

		
	if (SystemLanguage == Chinese)
	{
		if (FaceUserRegisterMgr.FaceUserType == FaceMaster){
			DisHZ16x14Str(0,16,AddMasterFaceStr,NormalDisplay);
		}else{
			DisHZ16x14Str(0,20,AddUserFaceStr,NormalDisplay);
		}
	}
	else
	{
		if (FaceUserRegisterMgr.FaceUserType == FaceMaster){
			DisEN16x8Str(0,12,AddMasterFaceStrEn,NormalDisplay);
		}else{
			DisEN16x8Str(0,12,AddUserFaceStrEn,NormalDisplay);
		}
	}

	if ( FaceUserRegisterMgr.Status == StartFaceUserRegister )
	{
		if (((FaceUserRegisterMgr.FaceUserType == FaceMaster)&&(CheckMemoryMgr.FaceMasterNum >= DEF_MAX_FACEMASTER))
			||((FaceUserRegisterMgr.FaceUserType == FaceUser)&&(CheckMemoryMgr.FaceUserNum >= DEF_MAX_FACEUSER))
				)
		{
			FaceUserRegisterMgr.Status = RegisterUserFail;
			FaceUserRegisterMgr.ErrorType = MemoryIsFull;
			FaceUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_UsersAreFull);
		}
		else 
		{
			FaceUserRegisterMgr.Status = InputFaceUserID;
		}
	}
	else if ( FaceUserRegisterMgr.Status == InputFaceUserID )
	{
		if ( FaceUserRegisterMgr.FaceUserType == FaceMaster )
		{
			FaceUserRegisterMgr.UserID = Get_Availabe_FACEmasterID();
		}
		else if ( FaceUserRegisterMgr.FaceUserType == FaceUser )
		{
			FaceUserRegisterMgr.UserID = Get_Availabe_FACEuserID();
		}

		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(3,20,UserIDStr,NormalDisplay);
			DisOneDigital16x8(3,84,FaceUserRegisterMgr.UserID/100,NormalDisplay);
			DisOneDigital16x8(3,92,FaceUserRegisterMgr.UserID%100/10,NormalDisplay);
			DisOneDigital16x8(3,100,FaceUserRegisterMgr.UserID%10,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(2,20,UserIDStrEn,NormalDisplay);
			DisOneDigital16x8(2,84,FaceUserRegisterMgr.UserID/100,NormalDisplay);
			DisOneDigital16x8(2,92,FaceUserRegisterMgr.UserID%100/10,NormalDisplay);
			DisOneDigital16x8(2,100,FaceUserRegisterMgr.UserID%10,NormalDisplay);
		}
		
		

		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(6,0,PressAsteriskKeyToReturnStr,NormalDisplay);
			DisHZ16x14Str(6,76,PressPoundKeyToConfirmStr,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(4,0,PressPoundKeyToConfirmStrEn,NormalDisplay);
			DisEN16x8Str(6,0,PressAsteriskKeyToReturnStrEn,NormalDisplay);
		}
		
		FaceUserRegisterMgr.Status = ReportFaceUserID;
	
		VoiceReportUserIDWithUserConfirm(FaceUserRegisterMgr.UserID);
		
		FaceUserRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt15s;
			
	}
		
	else if ( FaceUserRegisterMgr.Status == ReportFaceUserID )
	{
		if ( FaceUserRegisterMgr.TimeCnt-- <1 )
		{
			//FaceRecognition_FaceReset();
			FaceRecognition_HardwarePowerOff();
			GoIntoFaceMenu_Init();
		}
	}
//	else if ( FaceUserRegisterMgr.Status == WaitForConfirmAddFaceUser )
//	{
//		if ( FaceUserRegisterMgr.TimeCnt-- <1 )
//		{
//			FaceUserRegisterMgr.Status = RegisterUserFail;	
//			FaceUserRegisterMgr.ErrorType = TimeOut;
//			GUI_Flag_RefreshLCD = bTRUE;
//		}
//	}
	else if (FaceUserRegisterMgr.Status == AddUserToFRM)
	{
		RegisterFace();
		
		if (GUI_FaceTemplateRegisterMgr.Status == RegisterFaceTemplateSuccess)
		{
			
			FaceUserRegisterMgr.Status = RegisterUserSuccess;
			FaceUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationSuccess);
			GUI_Flag_RefreshLCD = bTRUE;
			
			ComPort_SetPost_Info(DEF_WifiInfo_AddUser,FACEUSER,FaceUserRegisterMgr.UserID);

			FaceRecognition_UpdateUserIdList();
			
			if ( FaceUserRegisterMgr.FaceUserType == FaceMaster )
			{
				CheckMemoryMgr.FaceMasterNum+=1;
				FaceUserMemoryMgr[FaceUserRegisterMgr.UserID-1].FaceTemplateID = GUI_FaceTemplateRegisterMgr.UserID;
				FaceUserMemoryMgr[FaceUserRegisterMgr.UserID-1].RegisterStatus = Registered;
				FaceUserMemoryMgr[FaceUserRegisterMgr.UserID-1].UserPriority = Master;
			}
			else
			{
				CheckMemoryMgr.FaceUserNum+=1;
				FaceUserMemoryMgr[FaceUserRegisterMgr.UserID-1].FaceTemplateID = GUI_FaceTemplateRegisterMgr.UserID;
				FaceUserMemoryMgr[FaceUserRegisterMgr.UserID-1].RegisterStatus = Registered;
				FaceUserMemoryMgr[FaceUserRegisterMgr.UserID-1].UserPriority = User;
			}

			WriteFaceUserMemoryToEEPROM();


			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Green,DEF_FpmLedColor_Green,255);

		}
		else if (GUI_FaceTemplateRegisterMgr.Status == RegisterFaceTemplateFail )
		{
			FaceRecognition_PowerDown();
			
			FaceUserRegisterMgr.Status = RegisterUserFail;
			FaceUserRegisterMgr.ErrorType = GUI_FaceTemplateRegisterMgr.ErrorType;
			FaceUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
			if ( FaceUserRegisterMgr.ErrorType == RepeatFace ){
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_RepeatedFace);
			}
			else{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationFail);
			}
			GUI_Flag_RefreshLCD = bTRUE;

			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Red,DEF_FpmLedColor_Red,255);
		}
	}

	else if ( FaceUserRegisterMgr.Status == RegisterUserSuccess )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
		}

		if ( FaceUserRegisterMgr.TimeCnt > 0 )
		{
			FaceUserRegisterMgr.TimeCnt--;
			if ( FaceUserRegisterMgr.TimeCnt == Def_GuiTimeDelayCnt1s )
			{
				FaceRecognition_PowerDown();
			}
			else if ( FaceUserRegisterMgr.TimeCnt == Def_GuiTimeDelayCnt01s )
			{
				FaceRecognition_HardwarePowerOff();
			}
		}
		else	
		{		
			FaceUserRegisterMgr.Status = StartFaceUserRegister;
			GUI_Flag_RefreshLCD = bTRUE;
			GUI_RefreshSleepTime();
			GUI_CreatAndSaveLog(AddFaceUser);
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
		}
		DEBUG_MARK;
	}
	else if ( FaceUserRegisterMgr.Status == RegisterUserFail )
	{		
		if ( FaceUserRegisterMgr.ErrorType == UserIDisRegistered )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,10,IDisRegisteredStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,10,IDisRegisteredStrEn,NormalDisplay);
			}
		}
		else if ( FaceUserRegisterMgr.ErrorType == RepeatFace )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,FaceRepeated,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,12,FaceRepeatedEn,NormalDisplay);
			}
		}
		else if ( FaceUserRegisterMgr.ErrorType == MemoryIsFull )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,32,UserIsFullStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,4,UserIsFullStrEn,NormalDisplay);
			}
		}
		else
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationFailStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,48,OperationFailStrEn,NormalDisplay);
			}
		}
		if (FaceUserRegisterMgr.TimeCnt-- < 1 )		
		{
			FaceRecognition_HardwarePowerOff();
			GoIntoFaceMenu_Init();
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
		}
		DEBUG_MARK;
	}
	#endif
}


/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowDeleteUserFace(void)
{
	#ifdef Function_FaceRecoginition			
	//uint8_t i;
	code uint8_t DelUserFaceStr[]={HZ_shan,HZ_chufa,HZ_ren,HZ_lianbu,HZ_yong,HZ_hu,HZ_end};  	
	code uint8_t DelUserFaceStrEn[]={"Del Face user"};  
 
	//code uint8_t DelMasterFaceStr[]={HZ_shan,HZ_chufa,HZ_guan,HZ_li,HZ_yuan,HZ_ren,HZ_lianbu,HZ_end};  	
	//code uint8_t DelMasterFaceStrEn[]={"Del Face Admin."};  

	if (SystemLanguage == Chinese)
	{
		DisHZ16x14Str(0,20,DelUserFaceStr,NormalDisplay);
	}
	else
	{
		DisEN16x8Str(0,12,DelUserFaceStrEn,NormalDisplay);
	}

	if ( FaceUserDeleteMgr.Status == StartFaceUserDelete )
	{
		FaceUserDeleteMgr.Status = InputFaceUserID;
		DataInputMgr.Status = InputIdle;
		PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseInputID);
	}
	
	else if ( FaceUserDeleteMgr.Status == InputFaceUserID )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(3,32,InputUserIDStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(3,32,InputUserIDStrEn,NormalDisplay);
		}

		GUI_DataInputCreat(5,56,3,0x0000);

		if (DataInputMgr.Status == InputEnd)
		{
			FaceUserDeleteMgr.UserID = DataInputMgr.Value;			
			FaceUserDeleteMgr.Status = ReportFaceUserID;
			DataInputMgr.Status = InputIdle;
			VoiceReportUserID(FaceUserDeleteMgr.UserID);
			FaceUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt4s;
		}			
		else if  (DataInputMgr.Status == InputExit)
		{
			FaceUserDeleteMgr.Status = DeleteFaceUserFail;
			FaceUserDeleteMgr.ErrorType = QUIT;
			FaceUserDeleteMgr.TimeCnt = 0;
		}
	}

	else if ( FaceUserDeleteMgr.Status == ReportFaceUserID )
	{
		if (--FaceUserDeleteMgr.TimeCnt < 1 )
		{
			FaceUserDeleteMgr.Status = CheckIfFaceUserIDisBeUsed;
			GUI_Flag_RefreshLCD = bTRUE;
		}
	}
	else if (FaceUserDeleteMgr.Status == CheckIfFaceUserIDisBeUsed)
	{
		if ( CheckIfFaceUserIsRegistered(FaceUserDeleteMgr.UserID) == bTRUE )
		{
			if ( (ManagerIdentifyMgr.MasterType == FACEUSER )
				&&(ManagerIdentifyMgr.FaceUserID == FaceUserDeleteMgr.UserID)
				)
				
			{
				FaceUserDeleteMgr.Status = DeleteFaceUserFail;
				//PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteFail);
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_AdminIsLoginCannotbeDelete);
				FaceUserDeleteMgr.ErrorType = ManagerHasLogin;
				FaceUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
				GUI_Flag_RefreshLCD = bTRUE;
			}
			else
			{
				if (SystemLanguage == Chinese)
				{
					DisHZ16x14Str(4,40,PleaseWaitStr,NormalDisplay);
				}
				else
				{
					DisEN16x8Str(4,12,PleaseWaitStrEn,NormalDisplay);
				}
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseWait);

				if ( FrmMgr.PowerStatus == FRM_PowerOff )  //�����￪ʼ���ֱ仯
				{
					FaceUserDeleteMgr.Status = PowerOnForFrmForDeleteTemplate;
					FaceRecognition_HardwarePowerOn();
					FaceUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
				} 
				else
				{
					FaceUserDeleteMgr.Status = FaceResetForDeleteTemplate;	
					DataInputMgr.Status = InputIdle;	
					FaceUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt05s;
				}
			}
		}
		else
		{
			FaceUserDeleteMgr.Status = DeleteFaceUserFail;
			FaceUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
			FaceUserDeleteMgr.ErrorType = UserIDisNotRegistered;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_UserIdIsNotExist);
			GUI_Flag_RefreshLCD = bTRUE;
		}
	}
	else if ( FaceUserDeleteMgr.Status == FaceResetForDeleteTemplate)
	{
		FaceRecognition_Reset();   //����EF AA 10

		FaceUserDeleteMgr.Status = WaitForFaceResetFinishedForDeleteTemplate;
		FaceUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt4s; 
	}
	else if (FaceUserDeleteMgr.Status == WaitForFaceResetFinishedForDeleteTemplate)
	{
		if ( FrmMgr.PostFlag_ResetResult == bTRUE)
		{
			FaceUserDeleteMgr.Status = DeleteUserFromFRM;
		}
		if (--FaceUserDeleteMgr.TimeCnt < 1 )
		{
			FaceUserDeleteMgr.Status = PowerOffForFrmForDeleteTemplate;
			FaceRecognition_HardwarePowerOff();
			FaceUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt05s; 
		}
	}

	else if ( FaceUserDeleteMgr.Status == PowerOffForFrmForDeleteTemplate)
	{
		if (--FaceUserDeleteMgr.TimeCnt < 1 )
		{
			FaceUserDeleteMgr.Status = PowerOnForFrmForDeleteTemplate;
			FaceRecognition_HardwarePowerOn();
			FaceUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
		} 
	}
	else if ( FaceUserDeleteMgr.Status == PowerOnForFrmForDeleteTemplate)
	{
		if ( FrmMgr.PostFlag_Ready == bTRUE)   //ɾ��ʧ�ܵ�ԭ������Ϊ  FrmMgr.PostFlag_Readyû�б���ֵΪTRUE       
		{
			FaceUserDeleteMgr.Status = DeleteUserFromFRM;
		} 
		if (--FaceUserDeleteMgr.TimeCnt < 1 )
		{
			FaceUserDeleteMgr.Status = DeleteFaceUserFail;
			FaceUserDeleteMgr.ErrorType = TimeOut;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteFail);
		} 
	}
	else if ( FaceUserDeleteMgr.Status == DeleteUserFromFRM)
	{
		FaceRecognition_DeleteTemplateStart(FaceUserMemoryMgr[FaceUserDeleteMgr.UserID-1].FaceTemplateID);
		FaceUserDeleteMgr.Status = WaitForDeleteUserACKfromFRM;
		FaceUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
		//FrmAckMgr.Status = WaitACK;
		FpmAckMgr.TimeOutCnt = DEF_FpmAckTimeoutTime;
	}
	else if (FaceUserDeleteMgr.Status == WaitForDeleteUserACKfromFRM)
	{
		if (FrmMgr.PostFlag_FaceState == bTRUE)
		{
			FrmMgr.PostFlag_FaceState = bFALSE;
			DEBUG_MARK;
		}
		
		if (FrmMgr.PostFlag_DeleteTemplateResult == bTRUE)
		{
			FrmMgr.PostFlag_DeleteTemplateResult = bFALSE;
			FaceUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
			
			if (FrmMgr.ErrorType == MR_SUCCESS )
			{
				FaceUserDeleteMgr.Status = DeleteFaceUserSuccess;

				ComPort_SetPost_Info(DEF_WifiInfo_DeleteUser,FACEUSER,FaceUserDeleteMgr.UserID);

				if ( FaceUserDeleteMgr.UserID <= DEF_MAX_FACEMASTER )
				{
					if ( CheckMemoryMgr.FaceMasterNum > 0 )
					{
						CheckMemoryMgr.FaceMasterNum-=1;
						FaceUserMemoryMgr[FaceUserDeleteMgr.UserID-1].FaceTemplateID = 0xFFFF;
						FaceUserMemoryMgr[FaceUserDeleteMgr.UserID-1].RegisterStatus = UnRegistered;
						FaceUserMemoryMgr[FaceUserDeleteMgr.UserID-1].UserPriority = Undefined;
					}
				}
				else  
				{
					if ( CheckMemoryMgr.FaceUserNum > 0 )
					{
						CheckMemoryMgr.FaceUserNum-=1;
						FaceUserMemoryMgr[FaceUserDeleteMgr.UserID-1].FaceTemplateID = 0xFFFF;
						FaceUserMemoryMgr[FaceUserDeleteMgr.UserID-1].RegisterStatus = UnRegistered;
						FaceUserMemoryMgr[FaceUserDeleteMgr.UserID-1].UserPriority = Undefined;
					}
				}
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteSuccess);
				WriteFaceUserMemoryToEEPROM();
			}
			else
			{
				FaceUserDeleteMgr.Status = DeleteFaceUserFail;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteFail);
			}
		}
		
		if (--FaceUserDeleteMgr.TimeCnt < 1 )
		{
			FaceUserDeleteMgr.Status = DeleteFaceUserFail;
			//FrmAckMgr.ErrorCode = Error_TimeOut;
			GUI_Flag_RefreshLCD = bTRUE;
			FaceUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteFail);
		}

	}
	else if ( FaceUserDeleteMgr.Status == DeleteFaceUserSuccess )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
		}
		if (--FaceUserDeleteMgr.TimeCnt < 1 )		
		{
			FaceUserDeleteMgr.Status = StartFaceUserDelete;
			GUI_RefreshSleepTime();
			GUI_Flag_RefreshLCD = bTRUE;
			UnlockModeAutoCalculate();
			GUI_CreatAndSaveLog(DeleteFaceUser);
		}
		DEBUG_MARK;
	}
	else if ( FaceUserDeleteMgr.Status == DeleteFaceUserFail )
	{
		if ( FaceUserDeleteMgr.ErrorType == UserIDisNotRegistered )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,20,IDisNotRegisteredStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,12,IDisNotRegisteredStrEn,NormalDisplay);
			}
		}
		else if ( FaceUserDeleteMgr.ErrorType == ManagerHasLogin )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,15,CanNotDeleteLastOneMasterStr1,NormalDisplay);
				DisHZ16x14Str(5,32,CanNotDeleteLastOneMasterStr2,NormalDisplay);
			}
			else
			{
				DisEN16x8Str(3,4,CanNotDeleteLastOneMasterStr1En,NormalDisplay);
				DisEN16x8Str(5,16,CanNotDeleteLastOneMasterStr2En,NormalDisplay);
			}
		}
		else
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationFailStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,48,OperationFailStrEn,NormalDisplay);
			}
		}
		if (FaceUserDeleteMgr.TimeCnt-- < 1 )		
		{
			GoIntoFaceMenu_Init();
		}
		DEBUG_MARK;
	}
	#endif			
}
/*******************************************************/
/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowRegisterUserFp(void)
{
	//uint8_t i;
	//uint16_t UserID;
	code uint8_t AddUserFpStr[]={HZ_tian,HZ_jia,HZ_zhi,HZ_wen,HZ_yong,HZ_hu,HZ_end};  	
	code uint8_t AddUserFpStrEn[]={"Add FP user"};  	
	code uint8_t AddMasterFpStr[]={HZ_tian,HZ_jia,HZ_guan,HZ_li,HZ_yuan,HZ_zhi,HZ_wen,HZ_end};  	
	code uint8_t AddMasterFpStrEn[]={"Add FP Admin."};  
	code uint8_t AddStressUserFpStr[]={HZ_tian,HZ_jia,HZ_xie,HZ_po,HZ_zhi,HZ_wen,HZ_end};  	
	code uint8_t AddStressUserFpStrEn[]={"Add Special FP"}; 
		
	if (SystemLanguage == Chinese)
	{
		if (FpUserRegisterMgr.FpUserType == FpMaster){
			DisHZ16x14Str(0,16,AddMasterFpStr,NormalDisplay);
		}else if (FpUserRegisterMgr.FpUserType == FpUser){
			DisHZ16x14Str(0,20,AddUserFpStr,NormalDisplay);
		}else {
			DisHZ16x14Str(0,20,AddStressUserFpStr,NormalDisplay);
		}
	}
	else
	{
		if (FpUserRegisterMgr.FpUserType == FpMaster){
			DisEN16x8Str(0,12,AddMasterFpStrEn,NormalDisplay);
		}else if (FpUserRegisterMgr.FpUserType == FpUser){
			DisEN16x8Str(0,12,AddUserFpStrEn,NormalDisplay);
		}else {
			DisEN16x8Str(0,12,AddStressUserFpStrEn,NormalDisplay);
		}
	}

	if ( FpUserRegisterMgr.Status == StartFpUserRegister )
	{
		if (((FpUserRegisterMgr.FpUserType == FpMaster)&&(CheckMemoryMgr.FpMasterNum >= DEF_MAX_FPMASTER))
			||((FpUserRegisterMgr.FpUserType == FpUser)&&(CheckMemoryMgr.FpUserNum >= DEF_MAX_FPUSER))
			||((FpUserRegisterMgr.FpUserType == StressFpUser)&&(CheckMemoryMgr.StressFpUserNum >= DEF_MAX_STRESSFPUSER))
				)
		{
			FpUserRegisterMgr.Status = RegisterUserFail;
			FpUserRegisterMgr.ErrorType = MemoryIsFull;
			FpUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_UsersAreFull);
		}
		else 
		{
			FpUserRegisterMgr.Status = InputUserID;
		}
	}
	else if ( FpUserRegisterMgr.Status == InputUserID )
	{

		if ( FpUserRegisterMgr.FpUserType == FpMaster )
		{
			FpUserRegisterMgr.UserID = Get_Availabe_FPmasterID();
		}
		else if ( FpUserRegisterMgr.FpUserType == FpUser )
		{
			FpUserRegisterMgr.UserID = Get_Availabe_FPuserID();
		}
		else if ( FpUserRegisterMgr.FpUserType == StressFpUser )
		{
			FpUserRegisterMgr.UserID = Get_Availabe_StressFPuserID();
		}


		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(3,20,UserIDStr,NormalDisplay);
			DisOneDigital16x8(3,84,FpUserRegisterMgr.UserID/100,NormalDisplay);
			DisOneDigital16x8(3,92,FpUserRegisterMgr.UserID%100/10,NormalDisplay);
			DisOneDigital16x8(3,100,FpUserRegisterMgr.UserID%10,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(2,20,UserIDStrEn,NormalDisplay);
			DisOneDigital16x8(2,84,FpUserRegisterMgr.UserID/100,NormalDisplay);
			DisOneDigital16x8(2,92,FpUserRegisterMgr.UserID%100/10,NormalDisplay);
			DisOneDigital16x8(2,100,FpUserRegisterMgr.UserID%10,NormalDisplay);
		}



		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(6,0,PressAsteriskKeyToReturnStr,NormalDisplay);
			DisHZ16x14Str(6,76,PressPoundKeyToConfirmStr,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(4,0,PressPoundKeyToConfirmStrEn,NormalDisplay);
			DisEN16x8Str(6,0,PressAsteriskKeyToReturnStrEn,NormalDisplay);
		}

		
		
		FpUserRegisterMgr.Status = ReportFpUserID;

		VoiceReportUserIDWithUserConfirm(FpUserRegisterMgr.UserID);
		
		FpUserRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt15s;
		
		DataInputMgr.Status = InputIdle;
	}

	else if ( FpUserRegisterMgr.Status == ReportFpUserID )
	{
		if ( FpUserRegisterMgr.TimeCnt-- <1 )
		{
			GoIntoFpMenu_Init();
		}
	}
	
	else if (FpUserRegisterMgr.Status == AddUserToFPM)
	{
		RegisterFp(FpUserRegisterMgr.UserID-1);
		
		if (FpRegisterMgr.Status == success)
		{
			FpUserRegisterMgr.Status = RegisterUserSuccess;
			FpUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationSuccess);
			GUI_Flag_RefreshLCD = bTRUE;

			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Green,DEF_FpmLedColor_Green,255);
				
			ComPort_SetPost_Info(DEF_WifiInfo_AddUser,FPUSER,FpUserRegisterMgr.UserID);

			#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
			Wifi_PostEvent(DEF_WifiEvent_AddUser,FPUSER,FpUserRegisterMgr.UserID);
			#endif
			
			if ( FpUserRegisterMgr.FpUserType == FpMaster )
			{
				CheckMemoryMgr.FpMasterNum+=1;
				FpUserMemoryMgr[FpUserRegisterMgr.UserID-1].UserID = FpUserRegisterMgr.UserID;
				FpUserMemoryMgr[FpUserRegisterMgr.UserID-1].RegisterStatus = Registered;
				FpUserMemoryMgr[FpUserRegisterMgr.UserID-1].UserPriority = Master;
			}
			else
			{
				if( FpUserRegisterMgr.FpUserType == FpUser ){
					CheckMemoryMgr.FpUserNum+=1;
				}else{
					CheckMemoryMgr.StressFpUserNum+=1;
				}
				FpUserMemoryMgr[FpUserRegisterMgr.UserID-1].UserID = FpUserRegisterMgr.UserID;
				FpUserMemoryMgr[FpUserRegisterMgr.UserID-1].RegisterStatus = Registered;
				FpUserMemoryMgr[FpUserRegisterMgr.UserID-1].UserPriority = User;
			}
			AddFPuserIdToList(FpUserRegisterMgr.UserID);	
		}
		else if (FpRegisterMgr.Status == fail)
		{
			FpUserRegisterMgr.Status = RegisterUserFail;
			FpUserRegisterMgr.ErrorType = FpRegisterMgr.ErrorType;
			FpUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
			if ( FpUserRegisterMgr.ErrorType == FingerPrintIsRegistered ){
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_RepeatedFingerprint);
			}
			else{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationFail);
			}
			GUI_Flag_RefreshLCD = bTRUE;
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Red,DEF_FpmLedColor_Red,255);
		}
	}

	else if ( FpUserRegisterMgr.Status == RegisterUserSuccess )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
		}
		
		if (--FpUserRegisterMgr.TimeCnt < 1 )		
		{
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
			FpUserRegisterMgr.Status = StartFpUserRegister;
			GUI_Flag_RefreshLCD = bTRUE;
			GUI_RefreshSleepTime();
			GUI_CreatAndSaveLog(AddFpUser);			
		}
		DEBUG_MARK;
	}
	else if ( FpUserRegisterMgr.Status == RegisterUserFail )
	{		
		if ( FpUserRegisterMgr.ErrorType == UserIDisRegistered )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,10,IDisRegisteredStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,10,IDisRegisteredStrEn,NormalDisplay);
			}
		}
		else if ( FpUserRegisterMgr.ErrorType == SystemNoMaster )
		{
			Clear_Screen();
			DisImage(2,50,27,24,Icon_Warning,NormalDisplay);
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(6,14,PleaseAddMasterStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(6,10,PleaseAddMasterStrEn,NormalDisplay);
			}
		}
		else if ( FpUserRegisterMgr.ErrorType == FingerPrintIsRegistered )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,FingerprintRepeated,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,12,FingerprintRepeatedEn,NormalDisplay);
			}
		}
		else if ( FpUserRegisterMgr.ErrorType == MemoryIsFull )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,32,UserIsFullStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,4,UserIsFullStrEn,NormalDisplay);
			}
		}
		else
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationFailStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,48,OperationFailStrEn,NormalDisplay);
			}
		}
		if (FpUserRegisterMgr.TimeCnt-- < 1 )		
		{
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
			
			if (FpUserRegisterMgr.FpUserType == FpMaster)
			{
				GoIntoFpMenu_Init();
			}
			else if (FpUserRegisterMgr.FpUserType == FpUser)
			{
				GoIntoFpMenu_Init();	
			}
			else 
			{
				GoIntoFpMenu_Init();
			}

		}
		DEBUG_MARK;
	}
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowDeleteUserFp(void)
{
	//uint8_t i;
	code uint8_t DelUserFpStr[]={HZ_shan,HZ_chufa,HZ_zhi,HZ_wen,HZ_end};  	
	code uint8_t DelUserFpStrEn[]={"Delete FP"};  	


	if (SystemLanguage == Chinese)
	{
		DisHZ16x14Str(0,32,DelUserFpStr,NormalDisplay);
	}
	else
	{
		DisEN16x8Str(0,12,DelUserFpStrEn,NormalDisplay);
	}

	if ( FpUserDeleteMgr.Status == StartFpUserDelete )
	{
		FpUserDeleteMgr.Status = InputUserID;
		DataInputMgr.Status = InputIdle;
		PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseInputID);
	}
	else if ( FpUserDeleteMgr.Status == InputUserID )
	{

		if (SystemLanguage == Chinese){
			DisHZ16x14Str(3,24,InputUserIDStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(3,24,InputUserIDStrEn,NormalDisplay);
		}

		GUI_DataInputCreat(6,42,3,0x0000);

		if (DataInputMgr.Status == InputEnd)
		{
			FpUserDeleteMgr.UserID = DataInputMgr.Value;	
			FpUserDeleteMgr.Status = ReportFpUserID;
			FpUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt4s;
			CheckIfFpUserIDisRegistered.Status = StartCheckIfFpUserIDisRegistered;
			DataInputMgr.Status = InputIdle;
			VoiceReportUserID(FpUserDeleteMgr.UserID);
		}			
		else if  (DataInputMgr.Status == InputExit)
		{
			FpUserDeleteMgr.Status = DeleteUserFail;
			FpUserDeleteMgr.ErrorType = QUIT;
			FpUserDeleteMgr.TimeCnt = 0;
		}
	}
	else if ( FpUserDeleteMgr.Status == ReportFpUserID )
	{
		if (--FpUserDeleteMgr.TimeCnt < 1 )
		{
			FpUserDeleteMgr.Status = CheckIfFpUserIDisBeUsed;
		}
	}
	else if (FpUserDeleteMgr.Status == CheckIfFpUserIDisBeUsed)
	{
		CheckIfFpUserIsRegistered(FpUserDeleteMgr.UserID-1);
		if ( CheckIfFpUserIDisRegistered.Status == CheckIfFpUserIDisRegisteredSuccess )
		{
			if ( (CheckIfFpUserIDisRegistered.UserIDisRegistered == bTRUE)&&(FpUserDeleteMgr.UserID <= (DEF_MAX_FPMASTER + DEF_MAX_FPUSER + DEF_MAX_STRESSFPUSER)) )		
			{
				if ( (ManagerIdentifyMgr.MasterType == FPUSER )
					&&(ManagerIdentifyMgr.FpUserID == FpUserDeleteMgr.UserID)
					)
					
				{
					FpUserDeleteMgr.Status = DeleteUserFail;
					FpUserDeleteMgr.ErrorType = ManagerHasLogin;
					FpUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
					GUI_Flag_RefreshLCD = bTRUE;
					//PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteFail);
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_AdminIsLoginCannotbeDelete);
				}
				else{

					FpUserDeleteMgr.Status = DeleteUserFromFPM;	
					DataInputMgr.Status = InputIdle;	
					GUI_Flag_RefreshLCD = bTRUE;
				}
			}
			else
			{
				FpUserDeleteMgr.Status = DeleteUserFail;
				FpUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
				FpUserDeleteMgr.ErrorType = UserIDisNotRegistered;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_UserIdIsNotExist);
				GUI_Flag_RefreshLCD = bTRUE;
			}
		}
		else if ( CheckIfFpUserIDisRegistered.Status == CheckIfFpUserIDisRegisteredFail )
		{
			FpUserDeleteMgr.Status = DeleteUserFail;
			FpUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
			FpUserDeleteMgr.ErrorType = QUIT;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteFail);
			GUI_Flag_RefreshLCD = bTRUE;
		}
	}
	else if ( FpUserDeleteMgr.Status == DeleteUserFromFPM)
	{
		FPM_DeleteCharCmd(FpUserDeleteMgr.UserID-1,1);
		FpUserDeleteMgr.Status = WaitForDeleteUserACKfromFPM;
		FpUserDeleteMgr.TimeCnt = Def_FPMcmdTimeOutDelay;
		FpmAckMgr.Status = WaitACK;
		FpmAckMgr.TimeOutCnt = DEF_FpmAckTimeoutTime;
	}
	else if (FpUserDeleteMgr.Status == WaitForDeleteUserACKfromFPM)
	{
		if (FpmAckMgr.Status == GotACK)
		{
			if ( FpmAckMgr.ErrorCode == Error_NONE)
			{
				FpUserDeleteMgr.Status = DeleteUserSuccess;
				GUI_Flag_RefreshLCD = bTRUE;
				FpUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteSuccess);
				
				ComPort_SetPost_Info(DEF_WifiInfo_DeleteUser,FPUSER,FpUserDeleteMgr.UserID);
				
				#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
				Wifi_PostEvent(DEF_WifiEvent_DeleteUser,FPUSER,FpUserDeleteMgr.UserID);
				#endif

				if ( FpUserDeleteMgr.UserID <= DEF_MAX_FPMASTER )
				{
					if ( CheckMemoryMgr.FpMasterNum > 0 )
					{
						CheckMemoryMgr.FpMasterNum-=1;
						FpUserMemoryMgr[FpUserDeleteMgr.UserID-1].UserID = 0xFFFF;
						FpUserMemoryMgr[FpUserDeleteMgr.UserID-1].RegisterStatus = UnRegistered;
						FpUserMemoryMgr[FpUserDeleteMgr.UserID-1].UserPriority = Undefined;
					}
				}
				else if( FpUserDeleteMgr.UserID <= (DEF_MAX_FPMASTER+DEF_MAX_FPUSER) )
				{
					if ( CheckMemoryMgr.FpUserNum > 0 )
					{
						CheckMemoryMgr.FpUserNum-=1;
						FpUserMemoryMgr[FpUserDeleteMgr.UserID-1].UserID = 0xFFFF;
						FpUserMemoryMgr[FpUserDeleteMgr.UserID-1].RegisterStatus = UnRegistered;
						FpUserMemoryMgr[FpUserDeleteMgr.UserID-1].UserPriority = Undefined;
					}
				}
				else
				{
					if ( CheckMemoryMgr.StressFpUserNum > 0 )
					{
						CheckMemoryMgr.StressFpUserNum-=1;
						FpUserMemoryMgr[FpUserDeleteMgr.UserID-1].UserID = 0xFFFF;
						FpUserMemoryMgr[FpUserDeleteMgr.UserID-1].RegisterStatus = UnRegistered;
						FpUserMemoryMgr[FpUserDeleteMgr.UserID-1].UserPriority = Undefined;
					}
				}
				DeleteFPuserIdFromList(FpUserDeleteMgr.UserID);
			}
			else
			{
				FpUserDeleteMgr.Status = DeleteUserFail;
				GUI_Flag_RefreshLCD = bTRUE;
				FpUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteFail);
			}
			DEBUG_MARK;
		}
		else if (--FpUserDeleteMgr.TimeCnt < 1 )
			{
				FpUserDeleteMgr.Status = DeleteUserFail;
				FpmAckMgr.ErrorCode = Error_TimeOut;
				GUI_Flag_RefreshLCD = bTRUE;
				FpUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteFail);
			}

	}
	else if ( FpUserDeleteMgr.Status == DeleteUserSuccess )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
			}
			if (--FpUserDeleteMgr.TimeCnt < 1 )		
			{
				FpUserDeleteMgr.Status = StartFpUserDelete;
				GUI_RefreshSleepTime();
				GUI_Flag_RefreshLCD = bTRUE;
				UnlockModeAutoCalculate();
				GUI_CreatAndSaveLog(DeleteFpUser);
			}
			DEBUG_MARK;
		}
	else if ( FpUserDeleteMgr.Status == DeleteUserFail )
		{
			if ( FpUserDeleteMgr.ErrorType == UserIDisNotRegistered )
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(4,20,IDisNotRegisteredStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(4,12,IDisNotRegisteredStrEn,NormalDisplay);
				}
			}
			else if ( FpUserDeleteMgr.ErrorType == ManagerHasLogin )
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(3,15,CanNotDeleteLastOneMasterStr1,NormalDisplay);
					DisHZ16x14Str(5,32,CanNotDeleteLastOneMasterStr2,NormalDisplay);
				}
				else
				{
					DisEN16x8Str(3,4,CanNotDeleteLastOneMasterStr1En,NormalDisplay);
					DisEN16x8Str(5,16,CanNotDeleteLastOneMasterStr2En,NormalDisplay);
				}
			}
			else
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(4,36,OperationFailStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(4,48,OperationFailStrEn,NormalDisplay);
				}
			}
			if (FpUserDeleteMgr.TimeCnt-- < 1 )		
			{
				GoIntoFpDeleteMenu_Init();
			}
			DEBUG_MARK;
		}
	
}


/*******************************************************/
/*******************************************************/
/*******************************************************/

void ShowDeleteAllUserFp(void)
{
	uint16_t i;
	
	//DisHZ16x14Str(0,0,TitleStr,NormalDisplay);

	
	if ( AllUserFpDeleteMgr.Status == StartAllUserFpDelete )
	{
		AllUserFpDeleteMgr.Status = WaitForUserConfirmDeleteAllFP;
		AllUserFpDeleteMgr.Selection = NO;
		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(2,16,ConfirmDeleteStr,NormalDisplay);
			DisHZ16x14Str(4,16,AbortDeleteStr,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(2,0,ConfirmDeleteStrEn,NormalDisplay);
			DisEN16x8Str(4,0,AbortDeleteStrEn,NormalDisplay);
		}	
		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_ConfirmOrExitDelete);
	}
	else if ( AllUserFpDeleteMgr.Status == WaitForUserConfirmDeleteAllFP )
	{
		
	}
  else if ( AllUserFpDeleteMgr.Status == SendDeleteAllUserFpCmdToFPM )
	{
		if (AllUserFpDeleteMgr.FpUserType == FpUser )
		{
			FPM_DeleteCharCmd(DEF_MAX_FPMASTER,DEF_MAX_FPUSER);
		}
		else if (AllUserFpDeleteMgr.FpUserType == StressFpUser )
		{
			FPM_DeleteCharCmd(DEF_MAX_FPMASTER+DEF_MAX_FPUSER,DEF_MAX_STRESSFPUSER);
		}
		AllUserFpDeleteMgr.Status = WaitForDeleteAllUserFpCmdACKfromFPM;
		AllUserFpDeleteMgr.TimeCnt =Def_FPMcmdTimeOutDelay;
		GUI_Flag_RefreshLCD = bTRUE;
		FpmAckMgr.Status = WaitACK;
		FpmAckMgr.TimeOutCnt = DEF_FpmAckTimeoutTime;
	}
	
	else if ( AllUserFpDeleteMgr.Status == WaitForDeleteAllUserFpCmdACKfromFPM )
		  {
			  if (FpmAckMgr.Status == GotACK)
				{
					if ( FpmAckMgr.ErrorCode == Error_NONE)
					{
						AllUserFpDeleteMgr.Status = DeleteAllFpUserSuccess;
						GUI_Flag_RefreshLCD = bTRUE;
						FpUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteSuccess);

						if (AllUserFpDeleteMgr.FpUserType == FpUser )
						{
							CheckMemoryMgr.FpUserNum=0;
							for (i=DEF_MAX_FPMASTER;i<(DEF_MAX_FPMASTER+DEF_MAX_FPUSER);i++)
							{
								FpUserMemoryMgr[i].UserID = 0xFFFF;
								FpUserMemoryMgr[i].RegisterStatus = UnRegistered;
								FpUserMemoryMgr[i].UserPriority = Undefined;
							}
							DeleteAllFPuserIdFromList();
						}
						else if (AllUserFpDeleteMgr.FpUserType == StressFpUser )
						{
							CheckMemoryMgr.StressFpUserNum=0;
							for (i=(DEF_MAX_FPMASTER+DEF_MAX_FPUSER);i<(DEF_MAX_FPMASTER+DEF_MAX_FPUSER+DEF_MAX_STRESSFPUSER);i++)
							{
								FpUserMemoryMgr[i].UserID = 0xFFFF;
								FpUserMemoryMgr[i].RegisterStatus = UnRegistered;
								FpUserMemoryMgr[i].UserPriority = Undefined;
							}
							DeleteAllStressFPuserIdFromList();
						}
						
					}
					else
					{
						AllUserFpDeleteMgr.Status = DeleteAllFpUserFail;
						GUI_Flag_RefreshLCD = bTRUE;
						AllUserFpDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteFail);
					}
					DEBUG_MARK;
				}
			else if (--FpUserDeleteMgr.TimeCnt < 1 )
				{
					AllUserFpDeleteMgr.Status = DeleteAllFpUserFail;
					FpmAckMgr.ErrorCode = Error_TimeOut;
					GUI_Flag_RefreshLCD = bTRUE;
					AllUserFpDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
					PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteFail);
				}
		  }
	
	else if ( AllUserFpDeleteMgr.Status == DeleteAllFpUserSuccess )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
			}
			if (--AllUserFpDeleteMgr.TimeCnt < 1 )
			{
				UnlockModeAutoCalculate();
				if (AllUserFpDeleteMgr.FpUserType == FpUser )
				{
					GoIntoFpDeleteMenu_Init();	
					GUI_CreatAndSaveLog(DeleteAllFpUser);
				}
				else// if (AllUserFpDeleteMgr.FpUserType == StressFpUser )
				{
					GoIntoFpDeleteMenu_Init();
					GUI_CreatAndSaveLog(DeleteAllStressFpUser);
				}
			}
		}
	else if ( AllUserFpDeleteMgr.Status == DeleteAllFpUserFail )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationFailStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,48,OperationFailStrEn,NormalDisplay);
			}
			if (--AllUserFpDeleteMgr.TimeCnt < 1 )
			{
				GoIntoFpDeleteMenu_Init();	
			}
		}
	else if ( AllUserFpDeleteMgr.Status == EXIT )
		{
			GoIntoFpDeleteMenu_Init();	
		}
	
}

/*******************************************************/
/*******************************************************/
/*******************************************************/




/*******************************************************/
/*******************************************************/
/*******************************************************/


/*******************************************************/
/*******************************************************/
/*******************************************************/



/*******************************************************/
/*****		Input CID[5]; 					   *********/
/*****      OUTPUT S_FAIL- MemoryIsFull, SUCCESS-be saved ****************/
/*******************************************************/



/*******************************************************/
/*******************************************************/
/*******************************************************/

/*******************************************************/
/*******************************************************/
/*******************************************************/



/*******************************************************/
/*****Input CID[5]; OUTPUT 0-CardIsNotRegistered, 1~255 CardIDisRegister, value is the UserID****************/
/*******************************************************/

/*******************************************************/
/*****Input CID[5]; OUTPUT 0-CardIsNotRegistered, 1~255 CardIDisRegister, value is the UserID****************/
/*******************************************************/


/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowRegisterCardUser(void)
{
	status_t GetCardID;
	//uint8_t i;
	code uint8_t TitleStr[]={HZ_tian,HZ_jia,HZ_ka,HZ_pian,HZ_end};  	//���ӿ�Ƭ�û�
	code uint8_t TitleStrEn[]={"Add card user"};  	//���ӿ�Ƭ�û�
	
	if (SystemLanguage == Chinese){
		DisHZ16x14Str(0,36,TitleStr,NormalDisplay);
	}
	else{
		DisEN16x8Str(0,16,TitleStrEn,NormalDisplay);
	}

	if ( CardUserRegisterMgr.Status == StartCardUserRegister )
	{
		if ( CheckMemoryMgr.CardUserNum < DEF_MAX_CARDUSER )
		{
			CardUserRegisterMgr.Status = InputCardUserID;
			DataInputMgr.Status = InputIdle;
			//PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseInputID);
		}
		else
		{
			CardUserRegisterMgr.Status = Fail;
			CardUserRegisterMgr.ErrorType = MemoryIsFull;
			CardUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_UsersAreFull);
		}	
	}
	else if ( CardUserRegisterMgr.Status == InputCardUserID )
	{
		CardUserRegisterMgr.UserID = Get_Availabe_CardUserID();

//		if (SystemLanguage == Chinese){
//			DisHZ16x14Str(4,20,UserIDStr,NormalDisplay);
//		}
//		else{
//			DisEN16x8Str(4,20,UserIDStrEn,NormalDisplay);
//		}
//		
//		DisOneDigital16x8(4,84,CardUserRegisterMgr.UserID/100,NormalDisplay);
//		DisOneDigital16x8(4,92,CardUserRegisterMgr.UserID%100/10,NormalDisplay);
//		DisOneDigital16x8(4,100,CardUserRegisterMgr.UserID%10,NormalDisplay);

		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(3,20,UserIDStr,NormalDisplay);
			DisOneDigital16x8(3,84,CardUserRegisterMgr.UserID/100,NormalDisplay);
			DisOneDigital16x8(3,92,CardUserRegisterMgr.UserID%100/10,NormalDisplay);
			DisOneDigital16x8(3,100,CardUserRegisterMgr.UserID%10,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(2,20,UserIDStrEn,NormalDisplay);
			DisOneDigital16x8(2,84,CardUserRegisterMgr.UserID/100,NormalDisplay);
			DisOneDigital16x8(2,92,CardUserRegisterMgr.UserID%100/10,NormalDisplay);
			DisOneDigital16x8(2,100,CardUserRegisterMgr.UserID%10,NormalDisplay);
		}	
		
		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(6,0,PressAsteriskKeyToReturnStr,NormalDisplay);
			DisHZ16x14Str(6,76,PressPoundKeyToConfirmStr,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(4,0,PressPoundKeyToConfirmStrEn,NormalDisplay);
			DisEN16x8Str(6,0,PressAsteriskKeyToReturnStrEn,NormalDisplay);
		}
		
		VoiceReportUserIDWithUserConfirm(CardUserRegisterMgr.UserID);
		
		CardUserRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt15s;
		
		CardUserRegisterMgr.Status = ReportCardUserID;
		
	}
	else if ( CardUserRegisterMgr.Status == ReportCardUserID )
	{
		if ( CardUserRegisterMgr.TimeCnt-- < 1 )
		{
			GoIntoCardMenu_Init();
		}
	}
	else if ( CardUserRegisterMgr.Status == ReadingCardID)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(4,40,PleaseSwingCardStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(4,16,PleaseSwingCardStrEn,NormalDisplay);
		}
#if 0
		if ( CardUserRegisterMgr.TimeCnt%32 == 0 )	//0.5s
		{
			GetCardID = MFC_Auto_Reader(CardUserRegisterMgr.CID);
			if ( GetCardID == S_SUCCESS )
			{
				CardUserRegisterMgr.Status = SavedCardID;
				GUI_RefreshSleepTime();
			}
		}
#endif
		if ( CardIdentifyMgr.CardDetectIntervalTimeCnt ==0  )	//FPM Cmd is sent out
		{
			CardIdentifyMgr.CardDetectIntervalTimeCnt = Def_CardDetectIntervalTime;
			
			GetCardID = MFC_Auto_Reader(CardUserRegisterMgr.CID);
			
			if ( GetCardID == S_SUCCESS )
			{
				CardUserRegisterMgr.Status = SavedCardID;
				GUI_RefreshSleepTime();
			}
		}
		if ( --CardUserRegisterMgr.TimeCnt < 1 )
		{
			CardUserRegisterMgr.Status = Fail;
			CardUserRegisterMgr.ErrorType = TimeOut;
			CardUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay; 	
			GUI_Flag_RefreshLCD = bTRUE;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationFail);
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Red,DEF_FpmLedColor_Red,255);
		}
	}
	else if ( CardUserRegisterMgr.Status ==  SavedCardID )
	{
		if (CompareCardIDwithMemory(CardUserRegisterMgr.CID) == 0x00 )		//card CID is not be used
		{
			if ( SaveCardUserToMemory(CardUserRegisterMgr.CID,CardUserRegisterMgr.UserID) == S_SUCCESS )
			{
				CardUserRegisterMgr.Status = Success;
				CardUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay; 	
				GUI_Flag_RefreshLCD = bTRUE;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationSuccess);
				CheckMemoryMgr.CardUserNum+=1;

				ComPort_SetPost_Info(DEF_WifiInfo_AddUser,CARDUSER,CardUserRegisterMgr.UserID);
				#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
				Wifi_PostEvent(DEF_WifiEvent_AddUser,CARDUSER,CardUserRegisterMgr.UserID);
				#endif

			}
			else
			{
				CardUserRegisterMgr.Status = Fail;
				CardUserRegisterMgr.ErrorType = MemoryIsFull;
				CardUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay; 	
				GUI_Flag_RefreshLCD = bTRUE;
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_UsersAreFull);
			}
		}
		else
		{
			CardUserRegisterMgr.Status = Fail;
			CardUserRegisterMgr.ErrorType = CardCIDisBeUsed;
			CardUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;	
			GUI_Flag_RefreshLCD = bTRUE;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_RepeatedCard);
		}

		if ( CardUserRegisterMgr.Status ==  Success )
		{
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Green,DEF_FpmLedColor_Green,255);
		}
		else if (CardUserRegisterMgr.Status == Fail)
		{
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Red,DEF_FpmLedColor_Red,255);
		}
	}
	else if ( CardUserRegisterMgr.Status ==  Success )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
			}
			if ( --CardUserRegisterMgr.TimeCnt < 1 )
			{
				GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
				GUI_RefreshSleepTime();
				CardUserRegisterMgr.Status = StartCardUserRegister;
				GUI_Flag_RefreshLCD = bTRUE;
				GUI_CreatAndSaveLog(AddCardUser);
			}
		}
	else if ( CardUserRegisterMgr.Status == Fail )
		{
			if (CardUserRegisterMgr.ErrorType == UserIDisRegistered)
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(4,15,IDisRegisteredStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(4,15,IDisRegisteredStrEn,NormalDisplay);
				}
			}
			else if ( CardUserRegisterMgr.ErrorType == SystemNoMaster )
			{
				Clear_Screen();
				DisImage(2,50,27,24,Icon_Warning,NormalDisplay);
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(6,14,PleaseAddMasterStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(6,10,PleaseAddMasterStrEn,NormalDisplay);
				}
			}
			else if ( CardUserRegisterMgr.ErrorType == MemoryIsFull )
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(4,32,UserIsFullStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(4,4,UserIsFullStrEn,NormalDisplay);
				}
			}
			else if ( CardUserRegisterMgr.ErrorType == CardCIDisBeUsed )
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(4,36,CardCIDisBeUsedStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(4,12,CardCIDisBeUsedStrEn,NormalDisplay);
				}
			}
			else
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(4,36,OperationFailStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(4,48,OperationFailStrEn,NormalDisplay);
				}
			}
			if ( CardUserRegisterMgr.TimeCnt-- < 1 )
			{
				GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
				GoIntoCardMenu_Init();
			}
		}
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowDeleteCardUser(void)
{
	//uint8_t i;
	code uint8_t TitleStr[]={HZ_shan,HZ_chufa,HZ_ka,HZ_pian,HZ_end};  	//ɾ����Ƭ�û�
	code uint8_t TitleStrEn[]={"Delete CD user"}; 	//ɾ����Ƭ�û�

	if (SystemLanguage == Chinese){
		DisHZ16x14Str(0,36,TitleStr,NormalDisplay);
	}
	else{
		DisEN16x8Str(0,8,TitleStrEn,NormalDisplay);
	}

	if ( CardUserDeleteMgr.Status == StartCardUserDelete )
	{
		CardUserDeleteMgr.Status = InputCardUserID;
		DataInputMgr.Status = InputIdle;
		PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseInputID);
	}
	else if ( CardUserDeleteMgr.Status == InputCardUserID )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(3,28,InputUserIDStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(3,20,InputUserIDStrEn,NormalDisplay);
		}
		
		GUI_DataInputCreat(6,48,3,0x0000);

		if (DataInputMgr.Status == InputEnd)
		{
			CardUserDeleteMgr.UserID = DataInputMgr.Value;
			CardUserDeleteMgr.Status = ReportCardUserID;
			CardUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt4s;
			DataInputMgr.Status = InputIdle;	
			VoiceReportUserID(CardUserDeleteMgr.UserID);
		}
		else if  (DataInputMgr.Status == InputExit)
		{
			CardUserDeleteMgr.Status = Fail;
			CardUserDeleteMgr.ErrorType = QUIT;
			CardUserDeleteMgr.TimeCnt = 0;
		}
	}
	else if ( CardUserDeleteMgr.Status == ReportCardUserID )
	{
		if (--CardUserDeleteMgr.TimeCnt < 1 )
		{
			CardUserDeleteMgr.Status = CheckCardUserIDisRegistered;
		}
	}
	else if ( CardUserDeleteMgr.Status == CheckCardUserIDisRegistered)
	{
		if ( (IfCardUserIDisRegistered(CardUserDeleteMgr.UserID) == bTRUE) && (CardUserDeleteMgr.UserID <= DEF_MAX_CARDUSER) )
		{
			DeleteCardUserfromMemory(CardUserDeleteMgr.UserID);
			CardUserDeleteMgr.Status = Success;	
			CardUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay; 	
			GUI_Flag_RefreshLCD = bTRUE;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteSuccess);
			if ( CheckMemoryMgr.CardUserNum > 0 )
			{
				CheckMemoryMgr.CardUserNum-=1;
			}
		
			ComPort_SetPost_Info(DEF_WifiInfo_DeleteUser,CARDUSER,CardUserDeleteMgr.UserID);

			#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
			Wifi_PostEvent(DEF_WifiEvent_DeleteUser,CARDUSER,CardUserDeleteMgr.UserID);
			#endif
				
		}
		else
		{
			CardUserDeleteMgr.Status = Fail;
			CardUserDeleteMgr.ErrorType = UserIDisNotRegistered;
			CardUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay; 	
			GUI_Flag_RefreshLCD = bTRUE;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_UserIdIsNotExist);
		}
	}
	
	else if  ( CardUserDeleteMgr.Status == Success)
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
			}
			if (--CardUserDeleteMgr.TimeCnt < 1 )
				{
//					GoIntoCardMenu_Init();
					CardUserDeleteMgr.Status = StartCardUserDelete;
					GUI_Flag_RefreshLCD = bTRUE;
					UnlockModeAutoCalculate();
					GUI_CreatAndSaveLog(DeleteCardUser);
				}
		}
	else if ( CardUserDeleteMgr.Status == Fail)
		{
			if (CardUserDeleteMgr.ErrorType == UserIDisNotRegistered)
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(3,15,IDisNotRegisteredStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(3,12,IDisNotRegisteredStrEn,NormalDisplay);
				}
			}
			else
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(6,36,OperationFailStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(6,48,OperationFailStrEn,NormalDisplay);
				}

			}
			if ( CardUserDeleteMgr.TimeCnt-- < 1 )
			{
				GoIntoCardMenu_Init();
			}
		}
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowDeleteAllCardUser(void)
{
	
	if ( AllCardUserDeleteMgr.Status == StartAllCardUserDelete )
		{
			AllCardUserDeleteMgr.Status = WaitForUserConfirmDeleteAllCard;
			AllCardUserDeleteMgr.Selection = NO;
			if (SystemLanguage == Chinese)
			{
				DisHZ16x14Str(2,16,ConfirmDeleteStr,NormalDisplay);
				DisHZ16x14Str(4,16,AbortDeleteStr,NormalDisplay);
			}
			else
			{
				DisEN16x8Str(2,0,ConfirmDeleteStrEn,NormalDisplay);
				DisEN16x8Str(4,0,AbortDeleteStrEn,NormalDisplay);
			}	
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_ConfirmOrExitDelete);
		}
	else if ( AllCardUserDeleteMgr.Status == WaitForUserConfirmDeleteAllCard )
		{
			
		}
    else if ( AllCardUserDeleteMgr.Status == DeletingAllCardUser )
		{
			
			DeleteAllCardUserfromMemory();
			AllCardUserDeleteMgr.TimeCnt =Def_MessageBoxTimeDelay;
			AllCardUserDeleteMgr.Status = Success;
			GUI_Flag_RefreshLCD = bTRUE;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteSuccess);
			CheckMemoryMgr.CardUserNum =0;
		}
	else if ( AllCardUserDeleteMgr.Status == Success )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
			}
			if (AllCardUserDeleteMgr.TimeCnt-- < 1 )
			{
				GoIntoCardMenu_Init();
				UnlockModeAutoCalculate();
				GUI_CreatAndSaveLog(DeleteAllCardUser);
			}
		}
	else if ( AllCardUserDeleteMgr.Status == CardUserEXIT )
		{
			GoIntoCardMenu_Init();
		}
}











/*******************************************************/
/*******************************************************/
/*******************************************************/








/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowRegisterPasscodeUser(void)
{
	uint8_t i;
	
	code uint8_t TitleStr1[]={HZ_tian,HZ_jia,HZ_guan,HZ_li,HZ_yuan,HZ_mi,HZ_ma,HZ_end};  	//���ӹ�������
	code uint8_t TitleStr1En[]={"Add PW admin"};  	//���ӹ�������
	code uint8_t TitleStr2[]={HZ_tian,HZ_jia,HZ_yong,HZ_hu,HZ_mi,HZ_ma,HZ_end};	//�����û�����
	code uint8_t TitleStr2En[]={"Add PW user"};	//�����û�����
	code uint8_t PasscodeIsBeUsedStr[]={HZ_chong,HZ_fu,HZ_mi,HZ_ma,HZ_end};
	code uint8_t PasscodeIsBeUsedStrEn[]={"Repeated PW"};


	if (PasscodeUserRegisterMgr.UserPriority == Master)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(0,22,TitleStr1,NormalDisplay);
		}
		else{
			DisEN16x8Str(0,16,TitleStr1En,NormalDisplay);
		}
	}
	else
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(0,22,TitleStr2,NormalDisplay);
		}
		else{
			DisEN16x8Str(0,20,TitleStr2En,NormalDisplay);
		}
	}
	
	if (PasscodeUserRegisterMgr.Status == StartPasscodeUserRegister)
	{
		if ((CheckMemoryMgr.FpMasterNum == 0x00 )
			&&(PasscodeUserRegisterMgr.UserPriority == User)
			&&(CheckMemoryMgr.PasscodeMasterNum == 0x00)
			)
		{
			PasscodeUserRegisterMgr.Status = RegisterPasscodeUserFail;
			PasscodeUserRegisterMgr.ErrorType = SystemNoMaster;
			PasscodeUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseAddMasterFirst);
		}
		else if ( 	((PasscodeUserRegisterMgr.UserPriority == Master)&&(!(CheckMemoryMgr.PasscodeMasterNum < DEF_MAX_PASSCODEMASTER)))
					||((PasscodeUserRegisterMgr.UserPriority == User)&&(!(CheckMemoryMgr.PasscodeUserNum < DEF_MAX_PASSCODEUSER)))
				)
		{
			PasscodeUserRegisterMgr.Status = RegisterPasscodeUserFail;
			PasscodeUserRegisterMgr.ErrorType = MemoryIsFull;
			PasscodeUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_UsersAreFull);
		}
		else
		{
			PasscodeUserRegisterMgr.Status = InputPasscodeUserID;
			DataInputMgr.Status = InputIdle;
			for (i=0;i<12;i++)
			{
				PasscodeInputMgr.InputBuff[i] = 0xFF;		//Initial passcode buffer
			}
		}
	}
	else if  (PasscodeUserRegisterMgr.Status == InputPasscodeUserID)
	{
		if (PasscodeUserRegisterMgr.UserPriority == Master)
		{
			PasscodeUserRegisterMgr.UserID = Get_Availabe_PasscodeMasterID();
		}
		else
		{
			PasscodeUserRegisterMgr.UserID = Get_Availabe_PasscodeUserID();
		}
		
		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(3,20,UserIDStr,NormalDisplay);
			DisOneDigital16x8(3,84,PasscodeUserRegisterMgr.UserID/100,NormalDisplay);
			DisOneDigital16x8(3,92,PasscodeUserRegisterMgr.UserID%100/10,NormalDisplay);
			DisOneDigital16x8(3,100,PasscodeUserRegisterMgr.UserID%10,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(2,20,UserIDStrEn,NormalDisplay);
			DisOneDigital16x8(2,84,PasscodeUserRegisterMgr.UserID/100,NormalDisplay);
			DisOneDigital16x8(2,92,PasscodeUserRegisterMgr.UserID%100/10,NormalDisplay);
			DisOneDigital16x8(2,100,PasscodeUserRegisterMgr.UserID%10,NormalDisplay);
		}

		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(6,0,PressAsteriskKeyToReturnStr,NormalDisplay);
			DisHZ16x14Str(6,76,PressPoundKeyToConfirmStr,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(4,0,PressPoundKeyToConfirmStrEn,NormalDisplay);
			DisEN16x8Str(6,0,PressAsteriskKeyToReturnStrEn,NormalDisplay);
		}		
		
		PasscodeUserRegisterMgr.Status = ReportPasscodeUserID;

		VoiceReportUserIDWithUserConfirm(PasscodeUserRegisterMgr.UserID);
		
		PasscodeUserRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt15s;
		
	}

	else if ( PasscodeUserRegisterMgr.Status == ReportPasscodeUserID )
	{
		if ( PasscodeUserRegisterMgr.TimeCnt-- <1 )
		{
			GoIntoPasscodeMenu_Init();
		}
	
	}
	else if  ( PasscodeUserRegisterMgr.Status == InputFirstPasscode)
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(3,24,InputPasscodeStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(3,16,InputPasscodeStrEn,NormalDisplay);
		}

		GUI_PasscodeInputCreat(5,0);

		if (PasscodeInputMgr.Status == PasscodeInputEnd)
		{
			if ( PasscodeInputMgr.Point > 5 )
			{
				for (i=0;i<12;i++)
				{
					PasscodeBUFF1[i] = PasscodeInputMgr.InputBuff[i];
				}
				PasscodeUserRegisterMgr.Status = InputSecondPasscode;
				PasscodeUserRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt10s;
				PasscodeInputMgr.Point = 0x00;
				PasscodeInputMgr.PasscodeLen = 12;
				PasscodeInputMgr.Status = PasscodeInputStart;
				for (i=0;i<12;i++)
				{
					PasscodeInputMgr.InputBuff[i] = 0xFF;		//Initial passcode buffer
				}
				PasscodeUserRegisterMgr.TimeCnt = Def_WaitUserInputPasscodeTimeDelay;	
				GUI_Flag_RefreshLCD = bTRUE;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PleaseInputPasswordAgain);
			}
			else
			{
				PasscodeUserRegisterMgr.Status = InputFirstPasscode;
				PasscodeInputMgr.Point = 0x00;
				PasscodeInputMgr.PasscodeLen = 12;
				PasscodeInputMgr.Status = PasscodeInputStart;
				for (i=0;i<12;i++)
				{
					PasscodeInputMgr.InputBuff[i] = 0xFF;		//Initial passcode buffer
				}
				PasscodeUserRegisterMgr.TimeCnt = Def_WaitUserInputPasscodeTimeDelay;
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_InputError);
				GUI_Flag_RefreshLCD = bTRUE;
			}
		}
		else if ( PasscodeInputMgr.Status == PasscodeInputExit )
		{
			PasscodeUserRegisterMgr.Status = RegisterPasscodeUserFail;
			PasscodeUserRegisterMgr.ErrorType = QUIT;
			PasscodeUserRegisterMgr.TimeCnt = 1;
		}

		if ( PasscodeUserRegisterMgr.TimeCnt > 0 )
		{
			PasscodeUserRegisterMgr.TimeCnt--;
		}
		else
		{
			PasscodeUserRegisterMgr.Status = RegisterPasscodeUserFail;
			PasscodeUserRegisterMgr.ErrorType = TimeOut;
			GUI_Flag_RefreshLCD = bTRUE;
			PasscodeUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationFail);
		}
		
	}
	else if ( PasscodeUserRegisterMgr.Status == InputSecondPasscode )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(3,24,ConfirmPasscode,NormalDisplay);
		}
		else{
			DisEN16x8Str(3,24,ConfirmPasscodeEn,NormalDisplay);
		}
		
		GUI_PasscodeInputCreat(5,0);

		if (PasscodeInputMgr.Status == PasscodeInputEnd)
		{
			if ( PasscodeInputMgr.Point > 5 )
				{
					PasscodeUserRegisterMgr.Status = CompareTwoPasscode;	
					GUI_Flag_RefreshLCD = bTRUE;
				}
			else
				{
					PasscodeUserRegisterMgr.Status = InputSecondPasscode;
					PasscodeInputMgr.Point = 0x00;
					PasscodeInputMgr.PasscodeLen = 12;
					PasscodeInputMgr.Status = PasscodeInputStart;
					for (i=0;i<12;i++)
					{
						PasscodeInputMgr.InputBuff[i] = 0xFF;		//Initial passcode buffer
					}
					PasscodeUserRegisterMgr.TimeCnt = Def_WaitUserInputPasscodeTimeDelay;	
					GUI_Flag_RefreshLCD = bTRUE;
				}
		}
		else if ( PasscodeInputMgr.Status == PasscodeInputExit )
		{
			PasscodeUserRegisterMgr.Status = RegisterPasscodeUserFail;
			PasscodeUserRegisterMgr.ErrorType = QUIT;
			PasscodeUserRegisterMgr.TimeCnt = 1;
		}
		
		if ( PasscodeUserRegisterMgr.TimeCnt > 0 )
		{
			PasscodeUserRegisterMgr.TimeCnt--;
		}
		else
		{
			PasscodeUserRegisterMgr.Status = RegisterPasscodeUserFail;
			PasscodeUserRegisterMgr.ErrorType = QUIT;
			PasscodeUserRegisterMgr.TimeCnt = 1;
		}

	}
	
	else if ( PasscodeUserRegisterMgr.Status == CompareTwoPasscode )
		{
			if (GUI_CompareTwoPasscodes(PasscodeBUFF1,PasscodeInputMgr.InputBuff) == bTRUE)
				{
					if (PasscodeIdendify(PasscodeInputMgr.InputBuff) == 0x00 )	//passcode is not be used
					{
						if (SavePasscodeUserToMemory(PasscodeInputMgr.InputBuff,PasscodeUserRegisterMgr.UserID) == S_SUCCESS)
						{
							PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationSuccess);
							PasscodeUserRegisterMgr.Status = RegisterPasscodeUserSuccess;
							PasscodeUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;	
							GUI_Flag_RefreshLCD = bTRUE;
							if (PasscodeUserRegisterMgr.UserPriority == Master){
								CheckMemoryMgr.PasscodeMasterNum+=1;
							}
							else{
								CheckMemoryMgr.PasscodeUserNum+=1;
							}
							
							ComPort_SetPost_Info(DEF_WifiInfo_AddUser,PASSCODEUSER,PasscodeUserRegisterMgr.UserID);
							#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
							Wifi_PostEvent(DEF_WifiEvent_AddUser,PASSCODEUSER,PasscodeUserRegisterMgr.UserID);
							#endif
							
						}
						else
						{
							PasscodeUserRegisterMgr.Status = RegisterPasscodeUserFail;
							PasscodeUserRegisterMgr.ErrorType = MemoryIsFull;
							PasscodeUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;	
							GUI_Flag_RefreshLCD = bTRUE;
							PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_UsersAreFull);
						}
					}
					else
					{
						PasscodeUserRegisterMgr.Status = RegisterPasscodeUserFail;
						PasscodeUserRegisterMgr.ErrorType = PasscodeIsBeUsed;
						PasscodeUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;	
						GUI_Flag_RefreshLCD = bTRUE;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_RepeatedPassword);
					}
				}
			else{
					PasscodeUserRegisterMgr.Status = RegisterPasscodeUserFail;
					PasscodeUserRegisterMgr.ErrorType = TwoPasscodesDoNotMatch;
					PasscodeUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;	
					GUI_Flag_RefreshLCD = bTRUE;
					PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_InputError);
				}

			if ( PasscodeUserRegisterMgr.Status == RegisterPasscodeUserSuccess )
			{
				GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Green,DEF_FpmLedColor_Green,255);
			}
			else if (PasscodeUserRegisterMgr.Status == RegisterPasscodeUserFail)
			{
				GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Red,DEF_FpmLedColor_Red,255);
			}
		}

	else if ( PasscodeUserRegisterMgr.Status ==  RegisterPasscodeUserSuccess )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
		}
		if ( PasscodeUserRegisterMgr.TimeCnt-- < 1 )
		{
			if ((CheckMemoryMgr.FpMasterNum == 0x00 )
			&&(PasscodeUserRegisterMgr.UserPriority == Master)
			&&(CheckMemoryMgr.PasscodeMasterNum == 0x01)
			)
			{
				ManagerIdentifyMgr.MasterType = PASSCODEUSER;
				ManagerIdentifyMgr.PasscodeUserID = 0X01;	
				GoIntoMainMenu_Init();
			}
			else
			{
				PasscodeUserRegisterMgr.Status = StartPasscodeUserRegister;
			}
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
			GUI_Flag_RefreshLCD = bTRUE;
			GUI_CreatAndSaveLog(AddPasscodeUser);
		}
	}
	else if ( PasscodeUserRegisterMgr.Status == RegisterPasscodeUserFail )
	{
		if ( PasscodeUserRegisterMgr.ErrorType == SystemNoMaster )
		{
			Clear_Screen();
			DisImage(2,50,27,24,Icon_Warning,NormalDisplay);
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(6,14,PleaseAddMasterStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(6,10,PleaseAddMasterStrEn,NormalDisplay);
			}
		}
		else if ( PasscodeUserRegisterMgr.ErrorType == PasscodeIsBeUsed )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,36,PasscodeIsBeUsedStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(3,16,PasscodeIsBeUsedStrEn,NormalDisplay);
			}
		}
		else if ( PasscodeUserRegisterMgr.ErrorType == MemoryIsFull )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,32,UserIsFullStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,4,UserIsFullStrEn,NormalDisplay);
			}
		}
		else if  ( PasscodeUserRegisterMgr.ErrorType == TwoPasscodesDoNotMatch )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,34,InputErrorStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,20,InputErrorStrEn,NormalDisplay);
			}
		}
		else if ( PasscodeUserRegisterMgr.ErrorType == QUIT )
		{
		
		}
		else
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationFailStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,48,OperationFailStrEn,NormalDisplay);
			}
		}
	
		if ( PasscodeUserRegisterMgr.TimeCnt-- < 1 )
		{
			if 	( 	(PasscodeUserRegisterMgr.ErrorType == QUIT )
					&&(CheckMemoryMgr.FpMasterNum == 0x00 )
					&&(CheckMemoryMgr.PasscodeMasterNum == 0x00)
				)
			{
				GoIntoMainScreen_WithIdentifyInit();
			}
			else if ((CheckMemoryMgr.FpMasterNum == 0x00 )
			&&(PasscodeUserRegisterMgr.UserPriority == Master)
			&&(CheckMemoryMgr.PasscodeMasterNum == 0x00)
			)
			{
				GoIntoMainScreen_WithIdentifyInit();
			}
			else if ( (PasscodeUserRegisterMgr.ErrorType == MemoryIsFull )
				||(PasscodeUserRegisterMgr.ErrorType == QUIT )
				||( PasscodeUserRegisterMgr.ErrorType == SystemNoMaster )
				||( PasscodeUserRegisterMgr.ErrorType == TimeOut )
				)
			{
				GoIntoPasscodeMenu_Init();
			}
			else
			{
				PasscodeUserRegisterMgr.Status = StartPasscodeUserRegister;
				GUI_Flag_RefreshLCD = bTRUE;
			}
			GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
		}
	}
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowDeletePasscodeUser(void)
{
	//uint8_t i;
	code uint8_t TitleStr2[]={HZ_shan,HZ_chufa,HZ_mi,HZ_ma,HZ_end};  	//ɾ���û�����
	code uint8_t TitleStr2En[]={"Delete Password"};  	//ɾ���û�����


	if (SystemLanguage == Chinese){
		DisHZ16x14Str(0,36,TitleStr2,NormalDisplay);
	}
	else{
		DisEN16x8Str(0,4,TitleStr2En,NormalDisplay);
	}

	
	if ( PasscodeUserDeleteMgr.Status == StartPasscodeUserDelete )
	{
		PasscodeUserDeleteMgr.Status = InputPasscodeUserID;
		DataInputMgr.Status = InputIdle;
		PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseInputID);
	}
	else if ( PasscodeUserDeleteMgr.Status == InputPasscodeUserID )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(3,28,InputUserIDStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(3,20,InputUserIDStrEn,NormalDisplay);
		}
		
		GUI_DataInputCreat(6,52,2,0x0000);

		if (DataInputMgr.Status == InputEnd)
		{
			PasscodeUserDeleteMgr.UserID = DataInputMgr.Value;
			PasscodeUserDeleteMgr.Status = ReportFpUserID;
			PasscodeUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt4s;
			DataInputMgr.Status = InputIdle;	
			VoiceReportUserID(PasscodeUserDeleteMgr.UserID);
		}
		else if  (DataInputMgr.Status == InputExit)
		{
			PasscodeUserDeleteMgr.Status = DeletePasscodeUserFail;
			PasscodeUserDeleteMgr.ErrorType = QUIT;
			PasscodeUserDeleteMgr.TimeCnt = 0;
		}
	}
	else if ( PasscodeUserDeleteMgr.Status == ReportFpUserID )
	{
		if (--PasscodeUserDeleteMgr.TimeCnt < 1 )
		{
			PasscodeUserDeleteMgr.Status = CheckIfPasscodeUserIDisRegistered;
		}
	}
	else if ( PasscodeUserDeleteMgr.Status == CheckIfPasscodeUserIDisRegistered)
	{
		if ( IfPasscodeUserIDisRegistered(PasscodeUserDeleteMgr.UserID) == bTRUE )
		{
			if ( (ManagerIdentifyMgr.MasterType == PASSCODEUSER )
			&&(ManagerIdentifyMgr.PasscodeUserID == PasscodeUserDeleteMgr.UserID)
			)
			{
				PasscodeUserDeleteMgr.Status = DeletePasscodeUserFail;
				PasscodeUserDeleteMgr.ErrorType = ManagerHasLogin;
				PasscodeUserDeleteMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
				GUI_Flag_RefreshLCD = bTRUE;
				//PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteFail);
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_AdminIsLoginCannotbeDelete);
			}
			else
			{
				DeletePasscodeUserfromMemory(PasscodeUserDeleteMgr.UserID);
				PasscodeUserDeleteMgr.Status = DeletePasscodeUserSuccess;	
				PasscodeUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay; 	
				GUI_Flag_RefreshLCD = bTRUE;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteSuccess);

				if ( PasscodeUserDeleteMgr.UserID <= DEF_MAX_PASSCODEMASTER )
				{
					if ( CheckMemoryMgr.PasscodeMasterNum > 0 )
					{
						CheckMemoryMgr.PasscodeMasterNum-=1;
					}
				}
				else
				{
					if ( CheckMemoryMgr.PasscodeUserNum > 0 )
					{
						CheckMemoryMgr.PasscodeUserNum-=1;
					}
				}
				
				ComPort_SetPost_Info(DEF_WifiInfo_DeleteUser,PASSCODEUSER,PasscodeUserDeleteMgr.UserID);
				
				#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
				Wifi_PostEvent(DEF_WifiEvent_DeleteUser,PASSCODEUSER,PasscodeUserDeleteMgr.UserID);
				#endif
			}
				
		}
		else
			{
				PasscodeUserDeleteMgr.Status = DeletePasscodeUserFail;
				PasscodeUserDeleteMgr.ErrorType = UserIDisNotRegistered;
				PasscodeUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay; 	
				GUI_Flag_RefreshLCD = bTRUE;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_UserIdIsNotExist);
			}
	}
	else if  ( PasscodeUserDeleteMgr.Status == DeletePasscodeUserSuccess)
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
			}

			if (--PasscodeUserDeleteMgr.TimeCnt < 1 )
				{
					PasscodeUserDeleteMgr.Status = StartPasscodeUserDelete;
					GUI_Flag_RefreshLCD = bTRUE;
					UnlockModeAutoCalculate();
					GUI_CreatAndSaveLog(DeletePasscodeUser);
				}
		}
	else if ( PasscodeUserDeleteMgr.Status == DeletePasscodeUserFail)
		{
			if ( PasscodeUserDeleteMgr.ErrorType == UserIDisNotRegistered)
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(3,15,IDisNotRegisteredStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(3,12,IDisNotRegisteredStrEn,NormalDisplay);
				}
			}
			else if ( PasscodeUserDeleteMgr.ErrorType == ManagerHasLogin )
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(3,15,CanNotDeleteLastOneMasterStr1,NormalDisplay);
					DisHZ16x14Str(5,32,CanNotDeleteLastOneMasterStr2,NormalDisplay);
				}
				else
				{
					DisEN16x8Str(3,4,CanNotDeleteLastOneMasterStr1En,NormalDisplay);
					DisEN16x8Str(5,16,CanNotDeleteLastOneMasterStr2En,NormalDisplay);
				}
			}
			else
			{
				if (SystemLanguage == Chinese){
					DisHZ16x14Str(6,36,OperationFailStr,NormalDisplay);
				}
				else{
					DisEN16x8Str(6,48,OperationFailStrEn,NormalDisplay);
				}
			}
			
			if (PasscodeUserDeleteMgr.TimeCnt-- < 1 )
			{
				if ( PasscodeUserDeleteMgr.ErrorType == QUIT )
				{
					GoIntoPasscodeMenu_Init();
				}
				else
				{
					//PasscodeUserDeleteMgr.Status = StartPasscodeUserDelete;
					GoIntoPasscodeMenu_Init();
				}
			}
		}
	
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowDeleteAllPasscodeUser(void)
{
	//uint8_t i;
	
	if ( AllPasscodeUserDeleteMgr.Status == StartAllPasscodeUserDelete )
	{
		AllPasscodeUserDeleteMgr.Status = WaitForDeleteAllPasscodeUserConfirm;
		AllPasscodeUserDeleteMgr.Selection = NO;
		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(2,16,ConfirmDeleteStr,NormalDisplay);
			DisHZ16x14Str(4,16,AbortDeleteStr,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(2,0,ConfirmDeleteStrEn,NormalDisplay);
			DisEN16x8Str(4,0,AbortDeleteStrEn,NormalDisplay);
		}	
		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_ConfirmOrExitDelete);
	}
	else if ( AllPasscodeUserDeleteMgr.Status == WaitForDeleteAllPasscodeUserConfirm )
	{
		
	}
    else if ( AllPasscodeUserDeleteMgr.Status == DeletingAllPasscodeUser )
		{
			
			DeleteAllPasscodeUserfromMemory();
			AllPasscodeUserDeleteMgr.TimeCnt = Def_MessageBoxTimeDelay;
			AllPasscodeUserDeleteMgr.Status = DeleteAllPasscodeUserSuccess;
			GUI_Flag_RefreshLCD = bTRUE;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteSuccess);
			CheckMemoryMgr.PasscodeUserNum = 0;
		}
	else if ( AllPasscodeUserDeleteMgr.Status == DeleteAllPasscodeUserSuccess )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
			}
			if (AllPasscodeUserDeleteMgr.TimeCnt-- < 1 )
			{
				GoIntoPasscodeMenu_Init();
				UnlockModeAutoCalculate();
				GUI_CreatAndSaveLog(DeleteAllPasscodeUser);
			}
		}
	else if  ( AllPasscodeUserDeleteMgr.Status == PasscodeUserEXIT )
		{
			GoIntoPasscodeMenu_Init();
		}
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowTimeSetting(void)
{
	//uint8_t i;
	uint8_t  code TitleStr[]={HZ_shi,HZ_jian,HZ_she,HZ_ding,HZ_end};  						//ʱ���趨
	uint8_t  code TitleStrEn[]={"Time Setting"};  						//ʱ���趨	
	
 	uint8_t  code YearMonthDayStrEn[]={"2019-01-01"};
	
	uint8_t  code TimeStrEn[]={"23:01:01"};

	if (SystemLanguage == Chinese){
		DisHZ16x14Str(0,28,TitleStr,NormalDisplay);
	}
	else{
		DisEN16x8Str(0,12,TitleStrEn,NormalDisplay);
	}
	
	DisEN16x8Str(3,24,YearMonthDayStrEn,NormalDisplay);
	DisBcdDigital16x8(3,40,TempSystemTime.year,NormalDisplay);
	DisBcdDigital16x8(3,64,TempSystemTime.month,NormalDisplay);
	DisBcdDigital16x8(3,88,TempSystemTime.date,NormalDisplay);
	
	DisEN16x8Str(6,24,TimeStrEn,NormalDisplay);
	DisBcdDigital16x8(6,24,TempSystemTime.hour,NormalDisplay);
	DisBcdDigital16x8(6,48,TempSystemTime.minute,NormalDisplay);
	DisBcdDigital16x8(6,72,TempSystemTime.second,NormalDisplay);
	

	if ( (TimeSettingMgr.Status == SetYearMajor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(3,40,TempSystemTime.year>>4,InverseDisplay);				
	}
	else if ( (TimeSettingMgr.Status == SetYearMinor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(3,48,TempSystemTime.year&0x0F,InverseDisplay);	
	}
	else if ( (TimeSettingMgr.Status == SetMonthMajor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(3,64,TempSystemTime.month>>4,InverseDisplay);		
	}
	else if ( (TimeSettingMgr.Status == SetMonthMinor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(3,72,TempSystemTime.month&0x0F,InverseDisplay);	
	}
	else if ( (TimeSettingMgr.Status == SetDateMajor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(3,88,TempSystemTime.date>>4,InverseDisplay);		
	}
	else if ( (TimeSettingMgr.Status == SetDateMinor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(3,96,TempSystemTime.date&0x0F,InverseDisplay);	
	}
	
	else if ( (TimeSettingMgr.Status == SetHourMajor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(6,24,TempSystemTime.hour>>4,InverseDisplay);		
	}
	else if ( (TimeSettingMgr.Status == SetHourMinor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(6,32,TempSystemTime.hour&0x0F,InverseDisplay);	
	}
	else if ( (TimeSettingMgr.Status == SetMinuteMajor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(6,48,TempSystemTime.minute>>4,InverseDisplay);		
	}
	else if ( (TimeSettingMgr.Status == SetMinuteMinor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(6,56,TempSystemTime.minute&0x0F,InverseDisplay);		
	}
	else if ( (TimeSettingMgr.Status == SetSecondMajor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(6,72,TempSystemTime.second>>4,InverseDisplay);		
	}
	else if ( (TimeSettingMgr.Status == SetSecondMinor)&&(GUI_ToggleFlag_05s==0x01) )
	{
		DisOneDigital16x8(6,80,TempSystemTime.second&0x0F,InverseDisplay);	
	}

	
}

/*******************************************************/
/*******************************************************/
/*******************************************************/

void ShowLanguageSetting(void)
{
	code uint8_t LanguageStr[]={ZF_1,ZF_xiaoshudian,HZ_zhong,HZ_wenzi,HZ_end};
	code uint8_t LanguageStrEn[]={"2.English"};

	if ( SystemLanguage == Chinese )
	{
		DisHZ16x14Str(0,4,LanguageStr,InverseDisplay);	
		DisEN16x8Str(2,4,LanguageStrEn,NormalDisplay);
	}
	else{
		DisHZ16x14Str(0,4,LanguageStr,NormalDisplay);	
		DisEN16x8Str(2,4,LanguageStrEn,InverseDisplay);
	}

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < 2 )
		{
			PLAY_VOICE_MULTISEGMENTS_IGNORELANGUAGE(VoiceMgr.volume,LanguageSetVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
		else if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,LanguageSetVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void VoiceReportCurrentVolume(void)
{
	uint16_t VoiceStr[5];
	VoiceStr[0] = VOICE_Current;
	VoiceStr[1] = VOICE_Setting;
	if ( VoiceMgr.volume == 0 )
	{
		VoiceStr[2] = VOICE_Mute;
		VoiceStr[3] = VOICE_Mute20ms;
	}	
	else if ( VoiceMgr.volume == 1 )
	{
		VoiceStr[2] = VOICE_Small;
		VoiceStr[3] = VOICE_Volume;
	}
	else if ( VoiceMgr.volume == 2 )
	{
		VoiceStr[2] = VOICE_Middle;
		VoiceStr[3] = VOICE_Volume;
	}
	else
	{
		VoiceStr[2] = VOICE_Big;
		VoiceStr[3] = VOICE_Volume;
	}
	VoiceStr[4] = DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}



void ShowVolumeSetting(void)
{
	uint8_t i;
	
	for (i=0;i<4;i++)
	{
		if (SystemLanguage == Chinese)
		{
			if ( VoiceMgr.volume == (3-i))
			{
				DisHZ16x14Str(2*i,4,VolumeAdjustStr[i],InverseDisplay);
			}
			else
			{
				DisHZ16x14Str(2*i,4,VolumeAdjustStr[i],NormalDisplay);
			}
		}
		else
		{
			if ( VoiceMgr.volume == (3-i))
			{
				DisEN16x8Str(2*i,4,VolumeAdjustStrEn[i],InverseDisplay);
			}
			else
			{
				DisEN16x8Str(2*i,4,VolumeAdjustStrEn[i],NormalDisplay);
			}
		}
	}

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VolumeSetVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	if ( VoiceMgr.volume > 0 ){
		VoiceMgr.Enable = bTRUE;
	}
	else{
		VoiceMgr.Enable = bFALSE;
	}
	
}

/*******************************************************/
/*******************************************************/
/*******************************************************/

void ShowMemoryUsage(void)
{

	code uint8_t Str0[]={HZ_ren,HZ_lianbu,ZF_maohao,HZ_end};				//ָ�ƣ�/
	code uint8_t Str0En[]={"FACE:"}; 			//ָ�ƣ�

	code uint8_t Str1[]={HZ_zhi,HZ_wen,ZF_maohao,HZ_end};				//ָ�ƣ�/
	code uint8_t Str1En[]={"FP:"};				//ָ�ƣ�
	
	code uint8_t Str3[]={HZ_mi,HZ_ma,ZF_maohao,HZ_end};	//���룺
	code uint8_t Str3En[]={"PW:"};					//���룺


	code uint8_t Str5[]={HZ_ka,HZ_pian,ZF_maohao,HZ_end};	//��Ƭ��/
	code uint8_t Str5En[]={"CD:"};	//��Ƭ�û���

	uint8_t TempValue;

	GUI_Flag_RefreshLCD = bTRUE;

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,MemoryUsageVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		if (SystemLanguage == Chinese)
		{
			DisHZ16x14Str(0,0,Str0,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(0,0,Str0En,NormalDisplay);
		}
		DisOneDigital16x8(0,48,(CheckMemoryMgr.FaceMasterNum+CheckMemoryMgr.FaceUserNum)/100,NormalDisplay);
		DisOneDigital16x8(0,56,(CheckMemoryMgr.FaceMasterNum+CheckMemoryMgr.FaceUserNum)%100/10,NormalDisplay);
		DisOneDigital16x8(0,64,(CheckMemoryMgr.FaceMasterNum+CheckMemoryMgr.FaceUserNum)%10,NormalDisplay);
		DisEN16x8Str(0,72,"/",NormalDisplay);
		TempValue = DEF_MAX_FACEMASTER+DEF_MAX_FACEUSER;
		DisOneDigital16x8(0,80,TempValue/100,NormalDisplay);
		DisOneDigital16x8(0,88,TempValue%100/10,NormalDisplay);
		DisOneDigital16x8(0,96,TempValue%10,NormalDisplay);
	}
	
	if (SystemLanguage == Chinese)
	{
		DisHZ16x14Str(2,0,Str1,NormalDisplay);
	}
	else
	{
		DisEN16x8Str(2,0,Str1En,NormalDisplay);
	}
	DisOneDigital16x8(2,48,(CheckMemoryMgr.FpMasterNum+CheckMemoryMgr.FpUserNum+CheckMemoryMgr.StressFpUserNum)/100,NormalDisplay);
	DisOneDigital16x8(2,56,(CheckMemoryMgr.FpMasterNum+CheckMemoryMgr.FpUserNum+CheckMemoryMgr.StressFpUserNum)%100/10,NormalDisplay);
	DisOneDigital16x8(2,64,(CheckMemoryMgr.FpMasterNum+CheckMemoryMgr.FpUserNum+CheckMemoryMgr.StressFpUserNum)%10,NormalDisplay);
	DisEN16x8Str(2,72,"/",NormalDisplay);
	TempValue = DEF_MAX_FPMASTER+DEF_MAX_FPUSER+DEF_MAX_STRESSFPUSER;
	DisOneDigital16x8(2,80,TempValue/100,NormalDisplay);
	DisOneDigital16x8(2,88,TempValue%100/10,NormalDisplay);
	DisOneDigital16x8(2,96,TempValue%10,NormalDisplay);


	if (SystemLanguage == Chinese)
	{
		DisHZ16x14Str(4,0,Str3,NormalDisplay);
	}
	else
	{
		DisEN16x8Str(4,0,Str3En,NormalDisplay);
	}

	DisOneDigital16x8(4,48,(CheckMemoryMgr.PasscodeMasterNum+CheckMemoryMgr.PasscodeUserNum)/10,NormalDisplay);
	DisOneDigital16x8(4,56,(CheckMemoryMgr.PasscodeMasterNum+CheckMemoryMgr.PasscodeUserNum)%10,NormalDisplay);
	DisEN16x8Str(4,64,"/",NormalDisplay);
	TempValue = DEF_MAX_PASSCODEMASTER+DEF_MAX_PASSCODEUSER;
	DisOneDigital16x8(4,72,TempValue/10,NormalDisplay);
	DisOneDigital16x8(4,80,TempValue%10,NormalDisplay);
	

	GUI_Flag_RefreshLCD = bTRUE;		
	if (SystemLanguage == Chinese)
	{
		DisHZ16x14Str(6,0,Str5,NormalDisplay);
	}
	else
	{
		DisEN16x8Str(6,0,Str5En,NormalDisplay);
	}
	DisOneDigital16x8(6,48,CheckMemoryMgr.CardUserNum/100,NormalDisplay);
	DisOneDigital16x8(6,56,CheckMemoryMgr.CardUserNum%100/10,NormalDisplay);
	DisOneDigital16x8(6,64,CheckMemoryMgr.CardUserNum%10,NormalDisplay);
	DisEN16x8Str(6,72,"/",NormalDisplay);
	TempValue = DEF_MAX_CARDUSER;
	DisOneDigital16x8(6,80,TempValue/100,NormalDisplay);
	DisOneDigital16x8(6,88,TempValue%100/10,NormalDisplay);
	DisOneDigital16x8(6,96,TempValue%10,NormalDisplay);

}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void VoiceReportCurrentUnlockMode(void)
{
	uint16_t VoiceStr[5];
	VoiceStr[0] = VOICE_Current;
	VoiceStr[1] = VOICE_Setting;
	if( UserIdentifyResultMgr.UnlockingMode == SingalMode  )
	{
		VoiceStr[2] = VOICE_SingleUnlock;
	}
	else
	{
		VoiceStr[2] = VOICE_CombinationUnlock;
	}
	VoiceStr[3] = DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}





/*******************************************************/
/*******************************************************/
/*******************************************************/

void VoiceReportCurrentPickAlarmEnableSetting(void)
{
	if(PickAlarmEnableMgr.Enable == bTRUE)
	{
		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_AntiPryingOpened);
	}
	else
	{
		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_AntiPryingClosed);
	}
}




void ShowPickAlarmEnableSetting(void)
{
	if (SystemLanguage == Chinese)
	{
		if(PickAlarmEnableMgr.Enable == bTRUE)
			{
		DisHZ16x14Str(0,4,AntiPryingEnableStr,InverseDisplay);
		DisHZ16x14Str(2,4,AntiPryingDisableStr,NormalDisplay);
			}
		else{
			DisHZ16x14Str(0,4,AntiPryingEnableStr,NormalDisplay);
			DisHZ16x14Str(2,4,AntiPryingDisableStr,InverseDisplay);
			}
	}
	else{
		if(PickAlarmEnableMgr.Enable == bTRUE)
		{
			DisEN16x8Str(0,4,AntiPryingEnableStrEn,InverseDisplay);
			DisEN16x8Str(2,4,AntiPryingDisableStrEn,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(0,4,AntiPryingEnableStrEn,NormalDisplay);
			DisEN16x8Str(2,4,AntiPryingDisableStrEn,InverseDisplay);
		}

	}
	
	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,AntiPryingSettingVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}

}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void VoiceReportCurrentBodyInduction(void)
{
	uint16_t VoiceStr[4];
	VoiceStr[0] = VOICE_Current;
	VoiceStr[1] = VOICE_BodyInduction;
	if( BodyInductionMgr.SensingDistanceLevel == SensingDistanceL0 )
	{
		VoiceStr[2] = VOICE_Close;
	}
	else if( BodyInductionMgr.SensingDistanceLevel == SensingDistanceL1 )
	{
		VoiceStr[2] = VOICE_Small;
	}
	else if( BodyInductionMgr.SensingDistanceLevel == SensingDistanceL2 )
	{
		VoiceStr[2] = VOICE_Big;
	}

	VoiceStr[3] = DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}



/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowRestoreFactoryDefault(void)
{
	uint8_t i;

	//RestoreFactoryDefaultMgr.Status = RestoreFactoryDefaultEXIT;

	if ( RestoreFactoryDefaultMgr.Status == StartRestoreFactoryDefault )
	{
		RestoreFactoryDefaultMgr.Status = WaitForRestoreFactoryDefaultUserConfirm;
		GUI_Flag_RefreshLCD = bTRUE;
		RestoreFactoryDefaultMgr.Selection = NO;
		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_ConfirmOrExitRestorFactoryDefault);
	}
	else if ( RestoreFactoryDefaultMgr.Status == WaitForRestoreFactoryDefaultUserConfirm )
	{
		if (SystemLanguage == Chinese){
			
			DisHZ16x14Str(1,32,ConfirmRestoreFactoryDefaultStr1,NormalDisplay);	
			DisHZ16x14Str(4,32,ConfirmRestoreFactoryDefaultStr2,NormalDisplay);
		}
		else{
			DisEN16x8Str(0,4,ConfirmRestoreFactoryDefaultStr1En,NormalDisplay);	
			DisEN16x8Str(3,4,ConfirmRestoreFactoryDefaultStr2En,NormalDisplay);	
		}
	}
	else if ( RestoreFactoryDefaultMgr.Status == ConfirmedToRestoreFactoryDefault )
	{
		GUI_Flag_RefreshLCD = bTRUE;
		
		SET_ALLKEYLED_OFF();

		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_RestorFactoryDefaultPleaseWait);
		
		Soft_Delay1ms(100);

//			#ifdef Function_FPMserialNumberCheck
//			RestoreFactoryDefaultMgr.Status = SaveFPMserialNumber;
//			#else
//			RestoreFactoryDefaultMgr.Status = ResetFPMuser;
//			AllUserFpDeleteMgr.Status = StartAllUserFpDelete;
//			RestoreFactoryDefaultMgr.FailTimes = 0x00;
//			#endif

		RestoreFactoryDefaultMgr.Status = ResetFPMuser;
		AllUserFpDeleteMgr.Status = StartAllUserFpDelete;
		RestoreFactoryDefaultMgr.FailTimes = 0x00;

	}
//	else if ( RestoreFactoryDefaultMgr.Status == SaveFPMserialNumber )
//	{
//		if ( SaveFPMserialNumberToMemory() == S_SUCCESS )
//			{
//				RestoreFactoryDefaultMgr.Status = ResetFPMuser;
//				AllUserFpDeleteMgr.Status = StartAllUserFpDelete;
//				RestoreFactoryDefaultMgr.FailTimes = 0x00;
//			}
//		else{	
//			RestoreFactoryDefaultMgr.Status = RestoreFactoryFail;
//			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationFail);
//		}
//	}	
	else if ( RestoreFactoryDefaultMgr.Status == ResetFPMuser )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(2,24,RestoreFactoryDoingStr1,NormalDisplay);	
			DisHZ16x14Str(5,43,RestoreFactoryDoingStr2,NormalDisplay);	
		}
		else{
			DisEN16x8Str(3,16,RestoreFactoryDoingStr1En,NormalDisplay);
			DisEN16x8Str(5,20,RestoreFactoryDoingStr2En,NormalDisplay);
		}	
		DeleteAllFpFromFPM();
		if ( AllUserFpDeleteMgr.Status == DeleteAllFpUserSuccess )
		{
			if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
			{
				RestoreFactoryDefaultMgr.Status = ResetFaceUser;
				RestoreFactoryDefaultMgr.FailTimes = 0x00;
				DeleteAllFaceTemplateMgr.Status = StartAllFaceTemplateDelete;
			}
			else
			{
				RestoreFactoryDefaultMgr.Status = ResetCardUser;
				#ifdef Function_FaceRecoginition					
				DeleteAllFaceUserfromMemory();
				#endif		
			}
			RestoreFactoryDefaultMgr.TimeCnt = Def_MessageBoxTimeDelay;
			CheckMemoryMgr.FpUserNum = 0x00;
			CheckMemoryMgr.StressFpUserNum = 0x00;
			CheckMemoryMgr.FpMasterNum = 0x00;	
			for (i=0;i<(DEF_MAX_FPMASTER+DEF_MAX_FPUSER+DEF_MAX_STRESSFPUSER);i++)
			{
				FpUserMemoryMgr[i].UserID = 0xFFFF;
				FpUserMemoryMgr[i].RegisterStatus = UnRegistered;
				FpUserMemoryMgr[i].UserPriority = Undefined;
			}	
			ResetFPuserIdListInEEPROM();
		}
		else if ( AllUserFpDeleteMgr.Status == DeleteAllFpUserFail )
		{
			if ( RestoreFactoryDefaultMgr.FailTimes < 4 )
			{
				RestoreFactoryDefaultMgr.FailTimes++;
				AllUserFpDeleteMgr.Status = StartAllUserFpDelete;
				SET_FPMPOWER_OFF;	
				Hardware_DelayMs(5);//Wait for Power line lost power
				SET_FPMPOWER_ON;	
				Hardware_DelayMs(10);//Wait for Power line lost power
				GUI_RefreshSleepTime();
			}
			else
			{
				//RestoreFactoryDefaultMgr.Status = RestoreFactoryFail;
				//PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationFail);
				if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
				{
					RestoreFactoryDefaultMgr.Status = ResetFaceUser;
					RestoreFactoryDefaultMgr.FailTimes = 0x00;
					DeleteAllFaceTemplateMgr.Status = StartAllFaceTemplateDelete;
				}
				else
				{
					RestoreFactoryDefaultMgr.Status = ResetCardUser;
					#ifdef Function_FaceRecoginition
					DeleteAllFaceUserfromMemory();
					#endif	
				}
				RestoreFactoryDefaultMgr.TimeCnt = Def_MessageBoxTimeDelay;
				CheckMemoryMgr.FpUserNum = 0x00;
				CheckMemoryMgr.StressFpUserNum = 0x00;
				CheckMemoryMgr.FpMasterNum = 0x00;	
				for (i=0;i<(DEF_MAX_FPMASTER+DEF_MAX_FPUSER+DEF_MAX_STRESSFPUSER);i++)
				{
					FpUserMemoryMgr[i].UserID = 0xFFFF;
					FpUserMemoryMgr[i].RegisterStatus = UnRegistered;
					FpUserMemoryMgr[i].UserPriority = Undefined;
				}
				ResetFPuserIdListInEEPROM();
			}
		}	
	}
	#ifdef Function_FaceRecoginition			
	else if ( RestoreFactoryDefaultMgr.Status == ResetFaceUser)
	{
		DeleteAllFaceTemplate();
		if ( DeleteAllFaceTemplateMgr.Status == DeleteAllFaceTemplateSuccess )
		{
			RestoreFactoryDefaultMgr.Status = ResetCardUser;
			CheckMemoryMgr.FaceMasterNum = 0x00;
			CheckMemoryMgr.FaceUserNum = 0x00;
		}
		else if ( DeleteAllFaceTemplateMgr.Status == DeleteAllFaceTemplateFail )
		{
			if ( RestoreFactoryDefaultMgr.FailTimes < 2 )
			{
				RestoreFactoryDefaultMgr.FailTimes++;
				DeleteAllFaceTemplateMgr.Status = StartAllFaceTemplateDelete;
				GUI_RefreshSleepTime();
			}
			else
			{
				RestoreFactoryDefaultMgr.Status = ResetCardUser;
				DeleteAllFaceUserfromMemory();
				CheckMemoryMgr.FaceMasterNum = 0x00;
				CheckMemoryMgr.FaceUserNum = 0x00;				
			}
		}
	}
	#endif	
	else if ( RestoreFactoryDefaultMgr.Status == ResetCardUser )
		{			
			if (RestoreFactoryDefaultMgr.TimeCnt-- < 1 )
			{
				DeleteAllCardUserfromMemory();
				RestoreFactoryDefaultMgr.Status = ResetPasscodeUser;
				RestoreFactoryDefaultMgr.TimeCnt = Def_MessageBoxTimeDelay;
				CheckMemoryMgr.CardUserNum = 0x00;
			}	
		}
	else if ( RestoreFactoryDefaultMgr.Status == ResetPasscodeUser )
		{
			if (RestoreFactoryDefaultMgr.TimeCnt-- < 1 )
			{
				DeleteAllPasscodeMasterfromMemory();
				DeleteAllPasscodeUserfromMemory();
				SystemConfigReset();

				/** Erase Event Log **/

				if ( DeleteAllLog() != S_SUCCESS )
				{
					if ( DeleteAllLog() != S_SUCCESS )
					{
						DeleteAllLog();
					}
				}
				
				LogMgr.LastPoint = 0x0000;
				LogMgr.DisplayPoint = 0x0000;
				LogMgr.NewLog.LogOrType._Bit.LogIDmajor = 0x00;


				ComPort_SetPost_ClearWifiData();
				
				#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
				Wifi_PostClearData();
				#endif
				
				RestoreFactoryDefaultMgr.Status = RestoreFactorySuccess;
				RestoreFactoryDefaultMgr.TimeCnt = Def_MessageBoxTimeDelay;
				CheckMemoryMgr.PasscodeMasterNum = 0x00;
				CheckMemoryMgr.PasscodeUserNum = 0x00;
				GUI_Flag_RefreshLCD = bTRUE;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationSuccess);
			}
		}
	
	else if ( RestoreFactoryDefaultMgr.Status == RestoreFactorySuccess )
		{
			GUI_Flag_RefreshLCD = bTRUE;
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(4,36,OperationSuccessStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(4,36,OperationSuccessStrEn,NormalDisplay);
			}
			if (RestoreFactoryDefaultMgr.TimeCnt-- < 1 )
			{
				GoIntoMainScreen_WithIdentifyInit();
				ComportMgr.RestoreFactoryDefaultTrig = bFALSE;
			}
			
		}
	else if ( RestoreFactoryDefaultMgr.Status == RestoreFactoryFail )
		{
			GUI_Flag_RefreshLCD = bTRUE;
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,36,OperationFailStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(3,48,OperationFailStrEn,NormalDisplay);
			}
			if (RestoreFactoryDefaultMgr.TimeCnt-- < 1 )
			{
				GoIntoMainScreen_WithIdentifyInit();
				ComportMgr.RestoreFactoryDefaultTrig = bFALSE;
			}
		}
	else if ( RestoreFactoryDefaultMgr.Status == RestoreFactoryDefaultEXIT )
		{
			if ( ComportMgr.RestoreFactoryDefaultTrig == bTRUE )
			{
				GoIntoMainScreen_WithIdentifyInit();
				ComportMgr.RestoreFactoryDefaultTrig = bFALSE;
			}
			else{
				GoIntoInfoInquiryMenu_Init();	
			}
		}

}
/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowNetWorkConnecting(void)
{
	code uint8_t LinkingStr[]={HZ_lian,HZ_wang,HZ_zhong,ZF_douhao,HZ_qing,HZ_shao,HZ_houniao,HZ_end};		//�����У����Ժ�
	code uint8_t LinkingStrEn1[]={"Network"};
	code uint8_t LinkingStrEn2[]={"Connecting..."};
	code uint8_t LinkSuccessStr[]={HZ_lian,HZ_wang,HZ_cheng,HZ_gong,HZ_end};		//�����ɹ�
	code uint8_t LinkSuccessStrEn[]={"Connected!"};	
	code uint8_t LinkFailStr[]={HZ_lian,HZ_wang,HZ_shibai,HZ_bai,HZ_end};		//����ʧ��
	code uint8_t LinkFailStrEn[]={"Connect FAIL!"};	

	if ( WifiMgr.Link.Status == LinkStart )
	{
		ComPort_SetPost_WifiHotSpot();
		WifiMgr.Link.Status = LinkWait;
		WifiMgr.Link.TimeCnt = 185*64;	//185S
		SET_ALLKEYLED_OFF();
		PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_NetworkingConfiguration);
	}
	else if ( WifiMgr.Link.Status == LinkWait )
	{
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(3,16,LinkingStr,NormalDisplay);
		}
		else
		{
			DisEN16x8Str(2,36,LinkingStrEn1,NormalDisplay);
			DisEN16x8Str(4,12,LinkingStrEn2,NormalDisplay);
		}
		GUI_RefreshSleepTime();
		KEYLED_ASTERISK_Flash();
	}
	else if ( WifiMgr.Link.Status == LinkSuccess )
	{
		SET_ALLKEYLED_OFF();
		Clear_Screen();
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(3,36,LinkSuccessStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(3,8,LinkSuccessStrEn,NormalDisplay);
		}
		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationSuccess);
		WifiMgr.Link.Status = LinkIdle;
		WifiMgr.Link.TimeCnt = Def_GuiTimeDelayCnt3s;
	}
	else if ( WifiMgr.Link.Status == LinkFail )
	{
		Clear_Screen();
		if ( WifiMgr.Link.errorcode == 0x02 )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,36,NoNetworkDeviceStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(3,8,NoNetworkDeviceStrEn,NormalDisplay);
			}
		}
		else
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,36,LinkFailStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(3,8,LinkFailStrEn,NormalDisplay);
			}
		}	
		if ( WifiMgr.Link.errorcode == 0x02 )	//wifi module not be found
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume, VoiceStr_HardwareNotSupportOperationFail);
		}
		else
		{
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationFail);
		}
		WifiMgr.Link.Status = LinkIdle;
		WifiMgr.Link.TimeCnt = Def_GuiTimeDelayCnt3s;
	}
	
	if (WifiMgr.Link.TimeCnt > 0){
		WifiMgr.Link.TimeCnt--;
	}
	else
	{
		if ( WifiMgr.Link.Status == LinkWait )
		{
			WifiMgr.Link.Status = LinkFail;
			WifiMgr.Link.errorcode = 0x01;
		}
		else
		{
			ComPort_SetPost_ExitWifiHotSpot();
			GoIntoMainMenu_Init();
		}
	}
	
	
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void VoiceReportCurrentSettingTime_Integer(uint8_t Value)
{
	uint16_t VoiceStr[6];
	VoiceStr[0]=VOICE_Current;
	VoiceStr[1]=VOICE_Setting;
	VoiceStr[2]=TranslateNumberToVoice(Value%100/10);
	VoiceStr[3]=TranslateNumberToVoice(Value%10);
	VoiceStr[4]=VOICE_Second;
	VoiceStr[5]=DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void VoiceReportCurrentSettingTime_Decimal(uint8_t Value)
{
	uint16_t VoiceStr[7];
	VoiceStr[0]=VOICE_Current;
	VoiceStr[1]=VOICE_Setting;
	VoiceStr[2]=TranslateNumberToVoice(Value%100/10);
	VoiceStr[3]=VOICE_Dot;
	VoiceStr[4]=TranslateNumberToVoice(Value%10);
	VoiceStr[5]=VOICE_Second;
	VoiceStr[6]=DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}

void VoiceReportCurrentTravelSetting(uint8_t Value)
{
	uint16_t VoiceStr[4];
	VoiceStr[0]=VOICE_Current;
	VoiceStr[1]=VOICE_LockDistance;
	VoiceStr[2]=TranslateNumberToVoice(Value%10);
	VoiceStr[3]=DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}

void VoiceReportCurrentUnlockDirrect(void)
{
	uint16_t VoiceStr[4];
	VoiceStr[0]=VOICE_Current;
	VoiceStr[1]=VOICE_Setting;
	if ( AutoMotorMgr.LockDirection == LEFTOPEN )
	{
		VoiceStr[2]=VOICE_LeftOpen;
	}
	else
	{
		VoiceStr[2]=VOICE_RightOpen;
	}
	VoiceStr[3]=DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}

void VoiceReportCurrentTorque(void)
{
	uint16_t VoiceStr[5];
	VoiceStr[0]=VOICE_Current;
	VoiceStr[1]=VOICE_Setting;
	if ( AutoMotorMgr.TorqueLevel == LargeTorque )
	{
		VoiceStr[2]=VOICE_Big;
	}
	else if ( AutoMotorMgr.TorqueLevel == MiddleTorque )
	{
		VoiceStr[2]=VOICE_Middle;
	}
	else
	{
		VoiceStr[2]=VOICE_Small;
	}
	VoiceStr[3] = VOICE_Torque;
	VoiceStr[4] = DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}
/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowFrmConnectionCheck(void)
{
	#ifdef Function_FaceRecoginition	
		
	if (FrmConnectionCheckMgr.Status == FrmCheckInit )
	{
		FaceRecognition_HardwarePowerOff();
		FrmConnectionCheckMgr.TimeCnt = Def_GuiTimeDelayCnt025s;
		FrmConnectionCheckMgr.Status = FrmCheckPowerOff;
		FrmConnectionCheckMgr.FrmCheckFailTimes = 0x00;
	}
	else if (FrmConnectionCheckMgr.Status == FrmCheckPowerOff )
	{
		if ( --FrmConnectionCheckMgr.TimeCnt < 1 )
		{
			FaceRecognition_HardwarePowerOn();
			FrmConnectionCheckMgr.Status = FrmCheckPowerOn;
			FrmConnectionCheckMgr.TimeCnt = Def_GuiTimeDelayCnt1s5;
		}
	}
	else if (FrmConnectionCheckMgr.Status == FrmCheckPowerOn )
	{
		FaceRecognitionMgr_Task();
		if ( FrmMgr.PostFlag_Ready == bTRUE )
		{
			DEBUG_MARK;
			DEBUG_MARK;
			FaceRecognition_HardwarePowerOff();
			FrmConnectionCheckMgr.Status = FrmCheckStop;
			FrmMgr.FrmFunctionConfig = FRM_Enabled;
		}
		if (--FrmConnectionCheckMgr.TimeCnt < 1 )
		{
			FrmConnectionCheckMgr.Status = FrmCheckReset;
			FaceRecognition_Reset();
			//FaceRecognition_GetVerionNumber();
			FrmConnectionCheckMgr.TimeCnt = Def_GuiTimeDelayCnt1s;
		}		
	}
	else if (FrmConnectionCheckMgr.Status == FrmCheckReset )
	{
		FaceRecognitionMgr_Task();
		UART0_TX_Task();
		if ( FrmMgr.PostFlag_ResetResult == bTRUE )
		{
			DEBUG_MARK;
			DEBUG_MARK;
			FaceRecognition_HardwarePowerOff();
			FrmConnectionCheckMgr.Status = FrmCheckStop;
			FrmMgr.FrmFunctionConfig = FRM_Enabled;	
		}
		if (--FrmConnectionCheckMgr.TimeCnt < 1 )
		{
			if ( ++FrmConnectionCheckMgr.FrmCheckFailTimes < 2 )
			{
				FaceRecognition_HardwarePowerOff();
				FrmConnectionCheckMgr.TimeCnt = Def_GuiTimeDelayCnt025s;
				FrmConnectionCheckMgr.Status = FrmCheckPowerOff;
				DEBUG_MARK;				
			}
			else
			{
				FaceRecognition_HardwarePowerOff();
				FrmConnectionCheckMgr.Status = FrmCheckStop;
				FrmMgr.FrmFunctionConfig = FRM_Disabled;
			}
		}
	}
	#endif		
}


/*******************************************************/
/*******************************************************/
/*******************************************************/


/*******************************************************/
/*******************************************************/
/*******************************************************/



void VoiceReportOneEventLog(uint16_t EventLogID)
{
	code uint16_t VoiceStr_UnlockLog[]={VOICE_Log,VOICE_Type,VOICE_Unlock,DEF_VoiceSegmentEndFlag};
	code uint16_t VoiceStr_AddUser[]={VOICE_Log,VOICE_Type,VOICE_Add,VOICE_User,DEF_VoiceSegmentEndFlag};
	code uint16_t VoiceStr_DeleteUser[]={VOICE_Log,VOICE_Type,VOICE_Delete,VOICE_User,DEF_VoiceSegmentEndFlag};

	uint16_t VoiceStr_LogID[6];//={VOICE_Log,VOICE_ID,DEF_VoiceSegmentEndFlag};
	uint16_t VoiceStr_LogTime[10];
	uint16_t VoiceStr_FaceUserID[8];
	uint16_t VoiceStr_FpUserID[8];
	uint16_t VoiceStr_PasswordUserID[8];
	uint16_t VoiceStr_CardUserID[8];
	uint16_t VoiceStr_TempUserID[8];
	
	systemtime_t LogTime;

	if ( VoiceReportLogMgr.Status == ReportLogInit )
	{
		VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt05s;
		VoiceReportLogMgr.Status = ReportLogID;
	}
	else if ( VoiceReportLogMgr.Status == ReportLogID )
	{	
		VoiceStr_LogID[0] = VOICE_Log;
		VoiceStr_LogID[1] = VOICE_ID;
		VoiceStr_LogID[2] = TranslateNumberToVoice(EventLogID/100);
		VoiceStr_LogID[3] = TranslateNumberToVoice(EventLogID%100/10);
		VoiceStr_LogID[4] = TranslateNumberToVoice(EventLogID%10);
		VoiceStr_LogID[5] = DEF_VoiceSegmentEndFlag;
		PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_LogID);
		VoiceReportLogMgr.Status = ReportLogType;
		VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
	}	

	else if ( VoiceReportLogMgr.Status == ReportLogType )
	{
		if ( VoiceReportLogMgr.TimeCnt--< 1 )
		{
			if ( LogMgr.DisplayLog.LogOrType._Bit.EventType == OpenDoor )
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_UnlockLog);
				VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt2s5;
			}
			else if (( LogMgr.DisplayLog.LogOrType._Bit.EventType == AddFaceUser )
					||( LogMgr.DisplayLog.LogOrType._Bit.EventType == AddFpUser )
					||( LogMgr.DisplayLog.LogOrType._Bit.EventType == AddPasscodeUser )
					||( LogMgr.DisplayLog.LogOrType._Bit.EventType == AddCardUser )
					)
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_AddUser);
				VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
			}

			else if (( LogMgr.DisplayLog.LogOrType._Bit.EventType == DeleteFaceUser )
					||( LogMgr.DisplayLog.LogOrType._Bit.EventType == DeleteFpUser )
					||( LogMgr.DisplayLog.LogOrType._Bit.EventType == DeleteAllStressFpUser )
					||( LogMgr.DisplayLog.LogOrType._Bit.EventType == DeletePasscodeUser )
					||( LogMgr.DisplayLog.LogOrType._Bit.EventType == DeleteCardUser )
					||( LogMgr.DisplayLog.LogOrType._Bit.EventType == DeleteAllFpUser )
					||( LogMgr.DisplayLog.LogOrType._Bit.EventType == DeleteAllCardUser )
					||( LogMgr.DisplayLog.LogOrType._Bit.EventType == DeleteAllPasscodeUser ) 
					)
			{
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_DeleteUser);
				VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
			}
					
			VoiceReportLogMgr.Status = ReportLogYear;	
		}
	}

	else if ( VoiceReportLogMgr.Status == ReportLogYear )
	{
		if ( VoiceReportLogMgr.TimeCnt--< 1 )
		{
			LogTime = UTCToSystemtime(LogMgr.DisplayLog.UTC);
			VoiceStr_LogTime[0]=VOICE_Two;
			VoiceStr_LogTime[1]=VOICE_Zero;
			VoiceStr_LogTime[2]=TranslateNumberToVoice(LogTime.year/16);
			VoiceStr_LogTime[3]=TranslateNumberToVoice(LogTime.year%16);
			VoiceStr_LogTime[4]=VOICE_Year;
			VoiceStr_LogTime[5]=DEF_VoiceSegmentEndFlag;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_LogTime);
			VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt2s5;
			VoiceReportLogMgr.Status = ReportLogMonth;
		}
	}
	else if ( VoiceReportLogMgr.Status == ReportLogMonth )
	{	
		if ( VoiceReportLogMgr.TimeCnt--< 1 )
		{
			VoiceStr_LogTime[0]=TranslateNumberToVoice(LogTime.month/16);
			VoiceStr_LogTime[1]=TranslateNumberToVoice(LogTime.month%16);
			VoiceStr_LogTime[2]=VOICE_Month;
			VoiceStr_LogTime[3]=DEF_VoiceSegmentEndFlag;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_LogTime);
			VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt1s5;
			VoiceReportLogMgr.Status = ReportLogDate;
		}
	}
	else if ( VoiceReportLogMgr.Status == ReportLogDate )
	{	
		if ( VoiceReportLogMgr.TimeCnt--< 1 )
		{
			VoiceStr_LogTime[0]=TranslateNumberToVoice(LogTime.date/16);
			VoiceStr_LogTime[1]=TranslateNumberToVoice(LogTime.date%16);
			VoiceStr_LogTime[2]=VOICE_Date;
			VoiceStr_LogTime[3]=DEF_VoiceSegmentEndFlag;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_LogTime);
			VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt1s5;
			VoiceReportLogMgr.Status = ReportLogHour;
		}
	}	
	else if ( VoiceReportLogMgr.Status == ReportLogHour )
	{	
		if ( VoiceReportLogMgr.TimeCnt--< 1 )
		{
			VoiceStr_LogTime[0]=TranslateNumberToVoice(LogTime.hour/16);
			VoiceStr_LogTime[1]=TranslateNumberToVoice(LogTime.hour%16);
			VoiceStr_LogTime[2]=VOICE_Hour;
			VoiceStr_LogTime[3]=DEF_VoiceSegmentEndFlag;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_LogTime);
			VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt1s5;
			VoiceReportLogMgr.Status = ReportLogMinute;
		}
	}
	else if ( VoiceReportLogMgr.Status == ReportLogMinute )
	{	
		if ( VoiceReportLogMgr.TimeCnt--< 1 )
		{
			VoiceStr_LogTime[0]=TranslateNumberToVoice(LogTime.minute/16);
			VoiceStr_LogTime[1]=TranslateNumberToVoice(LogTime.minute%16);
			VoiceStr_LogTime[2]=VOICE_Minute;
			VoiceStr_LogTime[3]=DEF_VoiceSegmentEndFlag;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_LogTime);
			VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt1s5;
			VoiceReportLogMgr.Status = ReportLogSecond;
		}
	}
	else if ( VoiceReportLogMgr.Status == ReportLogSecond )
	{	
		if ( VoiceReportLogMgr.TimeCnt--< 1 )
		{
			VoiceStr_LogTime[0]=TranslateNumberToVoice(LogTime.second/16);
			VoiceStr_LogTime[1]=TranslateNumberToVoice(LogTime.second%16);
			VoiceStr_LogTime[2]=VOICE_Second;
			VoiceStr_LogTime[3]=DEF_VoiceSegmentEndFlag;
			PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_LogTime);
			VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt1s5;
			VoiceReportLogMgr.Status = ReportLogUserID;
		}
	}

	else if ( VoiceReportLogMgr.Status == ReportLogUserID )
	{
		if ( VoiceReportLogMgr.TimeCnt--< 1 )
		{
			if ( LogMgr.DisplayLog.LogOrType._Bit.UserType == FACEUSER )
			{

				VoiceStr_FaceUserID[0] = VOICE_Face;
				VoiceStr_FaceUserID[1] = VOICE_User;
				VoiceStr_FaceUserID[2] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID/100);
				VoiceStr_FaceUserID[3] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID%100/10);
				VoiceStr_FaceUserID[4] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID%10);
				VoiceStr_FaceUserID[5] = DEF_VoiceSegmentEndFlag;

				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_FaceUserID);
			}
			else if ( LogMgr.DisplayLog.LogOrType._Bit.UserType == CARDUSER )
			{
				if ( LogMgr.DisplayLog.LogOrType._Bit.EventType != DeleteAllCardUser )
				{
					VoiceStr_CardUserID[0] = VOICE_Card;
					VoiceStr_CardUserID[1] = VOICE_User;
					VoiceStr_CardUserID[2] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID/100);
					VoiceStr_CardUserID[3] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID%100/10);
					VoiceStr_CardUserID[4] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID%10);
					VoiceStr_CardUserID[5] = DEF_VoiceSegmentEndFlag;
				}
				else
				{
					VoiceStr_CardUserID[0] = VOICE_All;
					VoiceStr_CardUserID[1] = VOICE_Card;
					VoiceStr_CardUserID[2] = DEF_VoiceSegmentEndFlag;
				}
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_CardUserID);
			}
			else if ( LogMgr.DisplayLog.LogOrType._Bit.UserType ==  FPUSER )
			{

				if ( (LogMgr.DisplayLog.LogOrType._Bit.EventType != DeleteAllFpUser) && (LogMgr.DisplayLog.LogOrType._Bit.EventType != DeleteAllStressFpUser) )
				{
					VoiceStr_FpUserID[0] = VOICE_Fingerprint;
					VoiceStr_FpUserID[1] = VOICE_User;
					VoiceStr_FpUserID[2] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID/100);
					VoiceStr_FpUserID[3] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID%100/10);
					VoiceStr_FpUserID[4] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID%10);
					VoiceStr_FpUserID[5] = DEF_VoiceSegmentEndFlag;
				}
				else
				{
					VoiceStr_FpUserID[0] = VOICE_All;
					VoiceStr_FpUserID[1] = VOICE_Fingerprint;
					VoiceStr_FpUserID[2] = DEF_VoiceSegmentEndFlag;
				}
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_FpUserID);

			}
			else if (LogMgr.DisplayLog.LogOrType._Bit.UserType ==  PASSCODEUSER )
			{
				if ( LogMgr.DisplayLog.LogOrType._Bit.EventType != DeleteAllPasscodeUser )
				{
					VoiceStr_PasswordUserID[0] = VOICE_Password;
					VoiceStr_PasswordUserID[1] = VOICE_User;
					VoiceStr_PasswordUserID[2] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID/100);
					VoiceStr_PasswordUserID[3] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID%100/10);
					VoiceStr_PasswordUserID[4] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID%10);
					VoiceStr_PasswordUserID[5] = DEF_VoiceSegmentEndFlag;
				}
				else
				{
					VoiceStr_PasswordUserID[0] = VOICE_All;
					VoiceStr_PasswordUserID[1] = VOICE_Password;
					VoiceStr_PasswordUserID[2] = DEF_VoiceSegmentEndFlag;
				}
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PasswordUserID);
			}
			else if (LogMgr.DisplayLog.LogOrType._Bit.UserType == ONLINEPASSCODEUSER )
			{
				VoiceStr_TempUserID[0] = VOICE_Temporary;
				VoiceStr_TempUserID[1] = VOICE_Password;
				VoiceStr_TempUserID[2] = VOICE_User;
				VoiceStr_TempUserID[3] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID/100);
				VoiceStr_TempUserID[4] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID%100/10);
				VoiceStr_TempUserID[5] = TranslateNumberToVoice(LogMgr.DisplayLog.UserID%10);
				VoiceStr_TempUserID[6] = DEF_VoiceSegmentEndFlag;
				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_TempUserID);
			}
			else
			{

			}
			VoiceReportLogMgr.TimeCnt = Def_GuiTimeDelayCnt3s;
			VoiceReportLogMgr.Status = ReportLogEnd;
		}
	}
}
/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowEventLogByDate(void)
{
	code uint8_t InputDateStr[]={HZ_shu,HZ_ru,HZ_ri,HZ_qi,HZ_end};
	code uint8_t InputDateStrEn[]={"Input Date"};
	
	if (  (CheckEventLogByDateMgr.Status == SetYear)
		||(CheckEventLogByDateMgr.Status == SetMonth)
		||(CheckEventLogByDateMgr.Status == SetDate)
	   )
	{
		#ifdef Function_TouchKeyIsTwoLine
		SET_UDandTHREEandConfirmLED_ON();
		#else
		SET_UDandLRandConfirmLED_ON();
		#endif
		
		if (SystemLanguage == Chinese){
			DisHZ16x14Str(0,32,InputDateStr,NormalDisplay);
		}
		else{
			DisEN16x8Str(0,24,InputDateStrEn,NormalDisplay);
		}
		
		DisZF16x8(3,20,ZF_2,NormalDisplay);
		DisZF16x8(3,28,ZF_0,NormalDisplay);
		DisBcdDigital16x8(3,36,CheckEventLogByDateMgr.year,NormalDisplay);
		DisZF16x8(3,52,ZF_hengan,NormalDisplay);
		DisBcdDigital16x8(3,60,CheckEventLogByDateMgr.month,NormalDisplay);
		DisZF16x8(3,76,ZF_hengan,NormalDisplay);
		DisBcdDigital16x8(3,84,CheckEventLogByDateMgr.date,NormalDisplay);
		if (CheckEventLogByDateMgr.Status == SetYear)
		{
			DisBcdDigital16x8(3,36,CheckEventLogByDateMgr.year,InverseDisplay);
		}
		else if (CheckEventLogByDateMgr.Status == SetMonth)
		{
			DisBcdDigital16x8(3,60,CheckEventLogByDateMgr.month,InverseDisplay);
		}
		else if (CheckEventLogByDateMgr.Status == SetDate)
		{
			DisBcdDigital16x8(3,84,CheckEventLogByDateMgr.date,InverseDisplay);	
		}
	}
	else if (CheckEventLogByDateMgr.Status == SearchEventLogWithDate)
	{
		//Clear_Screen();
		SET_ALLKEYLED_OFF();
		//SearchEventLogByDate();
		CheckEventLogByDateMgr.Status = ShowEventLogWithDate;
		Clear_Screen();

		if ( CheckEventLogByDateMgr.MatchedEventLogNum > 0x0000 )
		{
			LogMgr.DisplayPoint = CheckEventLogByDateMgr.StartEventLogPoint;
			LogMgr.SavedDisplayPoint = LogMgr.DisplayPoint+1;	//for reload Display Log
			CheckEventLogByDateMgr.OffsetEventLogNum = 0x0000;
		}
	}
	else if (CheckEventLogByDateMgr.Status == ShowEventLogWithDate)
	{	
		if ( CheckEventLogByDateMgr.MatchedEventLogNum == 0x0000 )
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,40,NoEventLogStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(3,40,NoEventLogStrEn,NormalDisplay);
			}
		}
		else
		{
			SET_UDandAPled_ON();

			if ( LogMgr.SavedDisplayPoint != LogMgr.DisplayPoint )
			{
				LogMgr_ReadLog(LogMgr.DisplayPoint,&LogMgr.DisplayLog.FlagHighByte);
				LogMgr.SavedDisplayPoint = LogMgr.DisplayPoint;
				Clear_Screen();
			}
			DisplayOneEventLog(CheckEventLogByDateMgr.OffsetEventLogNum+1);
			VoiceReportOneEventLog(CheckEventLogBySequenceMgr.OffsetEventLogNum+1);
		}
		
	}

}

/*******************************************************/
/*******************************************************/
/*******************************************************/


/*******************************************************/
/*******************************************************/
/*******************************************************/


/*******************************************************/
/*******************************************************/


void VoiceReportYearAndInputMonth(uint8_t value)
{
	uint16_t VoiceStr[7];
	VoiceStr[0] = TranslateNumberToVoice(value/16);
	VoiceStr[1] = TranslateNumberToVoice(value%16);
	VoiceStr[2] = VOICE_Year;
	VoiceStr[3] = VOICE_PleaseEnter;
	VoiceStr[4] = VOICE_Month;
	VoiceStr[5] = DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}
void VoiceReportMonthAndInputDate(uint8_t value)
{
	uint16_t VoiceStr[7];
	VoiceStr[0] = TranslateNumberToVoice(value/16);
	VoiceStr[1] = TranslateNumberToVoice(value%16);
	VoiceStr[2] = VOICE_Month;
	VoiceStr[3] = VOICE_PleaseEnter;
	VoiceStr[4] = VOICE_Date;
	VoiceStr[5] = DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}
void VoiceReportDateAndInputHour(uint8_t value)
{
	uint16_t VoiceStr[7];
	VoiceStr[0] = TranslateNumberToVoice(value/16);
	VoiceStr[1] = TranslateNumberToVoice(value%16);
	VoiceStr[2] = VOICE_Date;
	VoiceStr[3] = VOICE_PleaseEnter;
	VoiceStr[4] = VOICE_Hour;
	VoiceStr[5] = DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}
void VoiceReportHourAndInputMinute(uint8_t value)
{
	uint16_t VoiceStr[7];
	VoiceStr[0] = TranslateNumberToVoice(value/16);
	VoiceStr[1] = TranslateNumberToVoice(value%16);
	VoiceStr[2] = VOICE_Hour;
	VoiceStr[3] = VOICE_PleaseEnter;
	VoiceStr[4] = VOICE_Minute;
	VoiceStr[5] = DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}
void VoiceReportMinuteAndInputSecond(uint8_t value)
{
	uint16_t VoiceStr[7];
	VoiceStr[0] = TranslateNumberToVoice(value/16);
	VoiceStr[1] = TranslateNumberToVoice(value%16);
	VoiceStr[2] = VOICE_Minute;
	VoiceStr[3] = VOICE_PleaseEnter;
	VoiceStr[4] = VOICE_Second;
	VoiceStr[5] = DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}
void VoiceReportSecond(uint8_t value)
{
	uint16_t VoiceStr[4];
	VoiceStr[0] = TranslateNumberToVoice(value/16);
	VoiceStr[1] = TranslateNumberToVoice(value%16);
	VoiceStr[2] = VOICE_Second;
	VoiceStr[3] = DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}


/*******************************************************/
/*******************************************************/
void GUI_Button_Monitor(void)
{
	uint8_t i;
	
	DEBUG_MARK;

	#ifdef Function_TouchUsed_CSK14S
		if (CardIdentifyMgr.CardDetectIntervalTimeCnt > ( Def_CardDetectIntervalTime-8))
		{
			return;
		}
	#endif
		

	gui_keycode = Key_Scan();

	DEBUG_MARK;

	if ( gui_keycode != KEY_NONE )
	{
//		if ( TouchPowerMgr.Status != HighSensitivity )
//		{
//			//SET_TOUCH_AWAKE_SENSITIVITY();
//		}
		GUI_RefreshSleepTime();
		
		FaceIdentifyMgr.ReportFaceStatusTimeCnt = Def_GuiTimeDelayCnt2s;		//report face status delay time

		if ( AwakeDisplayMgr.DisplayType == DisplayHide )
		{
			PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_POWERON);
			AwakeDisplayMgr.DisplayType = DisplayCaseIgnore;
		}
	}
	
	switch ( CurrentScreen)
	{
		case SCREEN_Main:
			
			if ( ComportMgr.RestoreFactoryDefaultTrig == bTRUE )
			{
				CurrentScreen = SCREEN_RestoreFactoryDefault;
				RestoreFactoryDefaultMgr.Status = StartRestoreFactoryDefault;
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_Beep);
				GUI_RefreshSleepTime();
			}
			
			if ( ((gui_keycode == KEY_DOORCLOSE )||(AwakeSystemKeyMgr.IsDoorColseKeyAwake == bTRUE))
					&&( AutoMotorMgr.AutoEject == 0x00 )	//�Ե�����ر� 
					)
			{
					AwakeSystemKeyMgr.IsDoorColseKeyAwake = bFALSE;
					DEF_ButtonPress_Voice;
					CurrentScreen = SCREEN_IdentifySuccess;
					DisplayDoorStatusMgr.Status = DoorCloseInit;
					UserIdentifyResultMgr.IdentifyType = OutsideCloseDoor;
			}
			else if  ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyIdle )
			{
				if ( gui_keycode < 10 )		//from KEY0~KEY9
				{
					if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyIdle )
					{
						PasscodeInputMgr.Point = 0x01;
						PasscodeInputMgr.PasscodeLen = 16;
						PasscodeInputMgr.Status = PasscodeInputStart;
						PasscodeInputMgr.InputBuff[0] = gui_keycode;
						for (i=1;i<PasscodeInputMgr.PasscodeLen;i++)
						{
							PasscodeInputMgr.InputBuff[i]=0xff;
						}
						
						PasscodeUserIdentifyMgr.Status = PasscodeIdentifyStart;
						DEF_ButtonPress_Voice;
					}
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					#if (defined Function_IndependentDoorBellKey) || (defined Function_IndependentLockKey)
					if ( g_ASTERISK_PressedOnMainScreen == bFALSE ){
						DEF_ButtonPress_Voice;
						g_ASTERISK_PressedOnMainScreen = bTRUE;
					}
					else 
					{
						SystemPowerMgr.SleepDelayTimerCnt = 0x0000;
						SystemPowerMgr.SleepSource = UserForced;
					}
					#else
					if ( g_ASTERISK_PressedOnMainScreen == bFALSE ){
						DEF_ButtonPress_Voice;
						g_ASTERISK_PressedOnMainScreen = bTRUE;
//						CurrentScreen = SCREEN_IdentifySuccess;
//						DisplayDoorStatusMgr.Status = DoorCloseInit;
//						UserIdentifyResultMgr.IdentifyType = OutsideCloseDoor;
					}
					else 
					{
						SystemPowerMgr.SleepDelayTimerCnt = 0x0000;
						#ifdef Function_BodyInductionByRadar
						BodyInductionMgr.BodyInductionDelayTimeCnt = 6; //4.5s
						#endif
						SystemPowerMgr.SleepSource = UserForced;
					}
					#endif
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					#if (defined Function_IndependentDoorBellKey) || (defined Function_IndependentLockKey)
					if ( g_ASTERISK_PressedOnMainScreen == bTRUE )
					{
						 DEF_ButtonPress_Voice;
						 CurrentScreen = SCREEN_ManagerIdentify;
						 ManagerIdentifyMgr.Status = StartManagerIdentify;
						 g_ASTERISK_PressedOnMainScreen = bFALSE;
					}
					else
					{
						#ifndef Function_IndependentDoorBellKey
						PLAY_VOICE_DOORBELL();	//DOORBELL			
						CurrentScreen = SCREEN_RemoteUnlockRequest;
						WifiMgr.RemoteUnlockMgr.Status = RemoteUnlockRequestInit;
						#else
							#ifndef Function_IndependentLockKey
							if( AutoMotorMgr.AutoEject == 0x00 )		//�Ե�����ر�
							{
								DEF_ButtonPress_Voice;
								CurrentScreen = SCREEN_IdentifySuccess;
								DisplayDoorStatusMgr.Status = DoorCloseInit;
								UserIdentifyResultMgr.IdentifyType = OutsideCloseDoor;
							}
							#endif
							DEF_ButtonPress_Voice;
						#endif
					}
					#else
					PLAY_VOICE_DOORBELL();	//DOORBELL
					CurrentScreen = SCREEN_RemoteUnlockRequest;
					WifiMgr.RemoteUnlockMgr.Status = RemoteUnlockRequestInit;
					#endif
				}
			}
			else if ( gui_keycode != KEY_NONE )		//from KEY0~KEY9
			{
				g_ASTERISK_PressedOnMainScreen = bFALSE;
				if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyPasscodeInput )
				{
					DEF_ButtonPress_Voice;
					PasscodeUserIdentifyMgr.TimeCnt = 240;	//
					GUI_PasscodeInputButtonMonitor(gui_keycode);
				}
			}
			
			if ( gui_keycode == KEY_DOORBELL )  
			{
				PLAY_VOICE_DOORBELL();	//DOORBELL
				CurrentScreen = SCREEN_RemoteUnlockRequest;
				WifiMgr.RemoteUnlockMgr.Status = RemoteUnlockRequestInit;
			}
			
			break;
			
		case SCREEN_MainMenu:

			if ( gui_keycode == KEY_ONE )
			{
				DEF_ButtonPress_Voice;
				GoIntoUserManagementMenu_Init();
			}
			else if (gui_keycode == KEY_TWO)
			{
				DEF_ButtonPress_Voice;
				GoIntoSystemConfigMenu_Init();	
			}
			else if (gui_keycode == KEY_THREE)
			{
				DEF_ButtonPress_Voice;
				GoIntoInfoInquiryMenu_Init();
			}
			else if (gui_keycode == KEY_FOUR)
			{
				DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_NetWorkLink;
				WifiMgr.Link.Status = LinkStart;
			}

			else if ( gui_keycode == KEY_ASTERISK )
			{
				//DEF_ButtonPress_Voice;
				PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_ExitMenu);	
				GoIntoMainScreen_WithIdentifyInit();
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoMainMenu_Init();
			}
			
			break;

		case SCREEN_UserManagementMenu:

			if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
			{
				if ( gui_keycode == KEY_TWO )
				{
					DEF_ButtonPress_Voice;
					GoIntoFpMenu_Init();
				}
				else if ( gui_keycode == KEY_THREE )
				{
					DEF_ButtonPress_Voice;
					GoIntoPasscodeMenu_Init();
				}
				else if ( gui_keycode == KEY_FOUR)
				{
					DEF_ButtonPress_Voice;
					GoIntoCardMenu_Init();
				}
				#ifdef Function_FaceRecoginition
				else if ( gui_keycode == KEY_ONE )
				{
					DEF_ButtonPress_Voice;
					GoIntoFaceMenu_Init();
				}
				#endif
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					GoIntoMainMenu_Init();
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					DEF_ButtonPress_Voice;
					GoIntoUserManagementMenu_Init();
				}
			}
			else
			{
				if ( gui_keycode == KEY_ONE )
				{
					DEF_ButtonPress_Voice;
					GoIntoFpMenu_Init();
				}
				else if ( gui_keycode == KEY_TWO)
				{
					DEF_ButtonPress_Voice;
					GoIntoPasscodeMenu_Init();
				}
				else if (gui_keycode == KEY_THREE)
				{
					DEF_ButtonPress_Voice;
					GoIntoCardMenu_Init();
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					GoIntoMainMenu_Init();
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					DEF_ButtonPress_Voice;
					GoIntoUserManagementMenu_Init();
				}
			}
			break;

		case SCREEN_FaceMenu:
			
			if ( gui_keycode == KEY_ONE )
			{	
				//DEF_ButtonPress_Voice;
				FaceUserRegisterMgr.Status = StartFaceUserRegister;
				FaceUserRegisterMgr.FaceUserType = FaceMaster;
				CurrentScreen = SCREEN_RegisterMasterFace;
			}
			else if (gui_keycode == KEY_TWO)
			{	
				//DEF_ButtonPress_Voice;			
				FaceUserRegisterMgr.Status = StartFaceUserRegister;
				FaceUserRegisterMgr.FaceUserType = FaceUser;
				CurrentScreen = SCREEN_RegisterUserFace;
			}
			else if (gui_keycode == KEY_THREE)
			{	
				//DEF_ButtonPress_Voice;
				FaceUserDeleteMgr.Status = StartFaceUserDelete;
				CurrentScreen = SCREEN_DeleteUserFace;
			}			
			else if ( gui_keycode == KEY_ASTERISK )
			{
				DEF_ButtonPress_Voice;
				GoIntoUserManagementMenu_Init();
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoFaceMenu_Init();
			}
			break;	
			
		case SCREEN_FpMenu:
			
			if ( gui_keycode == KEY_ONE )
			{	
				//DEF_ButtonPress_Voice;
				FpUserRegisterMgr.Status = StartFpUserRegister;
				FpUserRegisterMgr.FpUserType = FpMaster;
				CurrentScreen = SCREEN_RegisterMasterFp;
			}
			else if (gui_keycode == KEY_TWO)
			{	
				//DEF_ButtonPress_Voice;			
				FpUserRegisterMgr.Status = StartFpUserRegister;
				FpUserRegisterMgr.FpUserType = FpUser;
				CurrentScreen = SCREEN_RegisterUserFp;
			}
			else if (gui_keycode == KEY_THREE)
			{	
				//DEF_ButtonPress_Voice;
				FpUserRegisterMgr.Status = StartFpUserRegister;
				FpUserRegisterMgr.FpUserType = StressFpUser;
				CurrentScreen = SCREEN_RegisterStressUserFp;
			}	
			else if (gui_keycode == KEY_FOUR)
			{	
				//DEF_ButtonPress_Voice;
				GoIntoFpDeleteMenu_Init();
			}		
			else if ( gui_keycode == KEY_ASTERISK )
			{
				DEF_ButtonPress_Voice;
				GoIntoUserManagementMenu_Init();
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoFpMenu_Init();
			}
			break;
			
		case SCREEN_FpDeleteMenu:
			
			if (gui_keycode == KEY_ONE)
			{	
				//DEF_ButtonPress_Voice;
				FpUserDeleteMgr.Status = StartFpUserDelete;
				FpUserDeleteMgr.FpUserType = FpUser;
				CurrentScreen = SCREEN_DeleteUserFp;
			}	
			else if (gui_keycode == KEY_TWO)
			{	
				//DEF_ButtonPress_Voice;
				AllUserFpDeleteMgr.Status = StartAllUserFpDelete;
				AllUserFpDeleteMgr.FpUserType = FpUser;
				CurrentScreen = SCREEN_DeleteAllUserFp;
			}
			else if (gui_keycode == KEY_THREE)
			{	
				//DEF_ButtonPress_Voice;
				AllUserFpDeleteMgr.Status = StartAllUserFpDelete;
				AllUserFpDeleteMgr.FpUserType = StressFpUser;
				CurrentScreen = SCREEN_DeleteAllStressUserFp;
			}		
			else if ( gui_keycode == KEY_ASTERISK )
			{
				DEF_ButtonPress_Voice;
				GoIntoFpMenu_Init();
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoFpDeleteMenu_Init();
			}
			break;
			
		case SCREEN_PasscodeMenu:
			
			if ( gui_keycode == KEY_ONE )
			{	
				//DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_RegisterPasscodeUser;
				PasscodeUserRegisterMgr.Status = StartPasscodeUserRegister;
				PasscodeUserRegisterMgr.UserPriority = Master;
			}
			else if ( gui_keycode == KEY_TWO )
			{	
				//DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_RegisterPasscodeUser;
				PasscodeUserRegisterMgr.Status = StartPasscodeUserRegister;
				PasscodeUserRegisterMgr.UserPriority = User;
			}
			else if ( gui_keycode == KEY_THREE )
			{	
				//DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_DeletePasscodeUser;
				PasscodeUserDeleteMgr.Status = StartPasscodeUserDelete;
				PasscodeUserDeleteMgr.UserPriority = Master;
			}
			else if ( gui_keycode == KEY_FOUR )
			{	
				//DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_DeleteAllPasscodeUser;
				AllPasscodeUserDeleteMgr.Status = StartAllPasscodeUserDelete;
			}
			else if ( gui_keycode == KEY_ASTERISK )
			{
				DEF_ButtonPress_Voice;
				GoIntoUserManagementMenu_Init();
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoPasscodeMenu_Init();
			}

			break;

		case SCREEN_CardUserMenu:
			
			if ( gui_keycode == KEY_ONE )
			{	
				//DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_RegisterCardUser;
				CardUserRegisterMgr.Status = StartCardUserRegister;
			}
			else if ( gui_keycode == KEY_TWO )
			{	
				//DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_DeleteCardUser;
				CardUserDeleteMgr.Status = StartCardUserDelete;
			}
			else if ( gui_keycode == KEY_THREE )
			{	
				//DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_DeleteAllCardUser;
				AllCardUserDeleteMgr.Status = StartAllCardUserDelete;
			}
			else if ( gui_keycode == KEY_ASTERISK )
			{	
				DEF_ButtonPress_Voice;
				GoIntoUserManagementMenu_Init();	
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoCardMenu_Init();
			}

			break;	


		case SCREEN_InfoInquiryMenu:
			
			if ( gui_keycode == KEY_ONE )
			{	
				DEF_ButtonPress_Voice;
				GoIntoLogMenu_Init();
			}
			else if ( gui_keycode == KEY_TWO )
			{	
				DEF_ButtonPress_Voice;
				GoIntoMemoryUsageScreen();
			}
			else if ( gui_keycode == KEY_THREE )
			{	
				DEF_ButtonPress_Voice;
				GoIntoShowSystemVersion();
			}
			else if ( gui_keycode == KEY_FOUR )
			{	
				DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_RestoreFactoryDefault;
				RestoreFactoryDefaultMgr.Status = StartRestoreFactoryDefault;		
			}			
			else if ( gui_keycode == KEY_ASTERISK )
			{	
				DEF_ButtonPress_Voice;
				GoIntoMainMenu_Init();	
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoInfoInquiryMenu_Init();
			}

			break;	
			
		case SCREEN_EventLogMenu:

			if ( gui_keycode == KEY_ONE )
			{	
				DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_CheckEventLogBySequence;
				CheckEventLogBySequenceMgr.Status = SearchEventLogWithSequence;
			}
			/*
			else if ( gui_keycode == KEY_TWO )
			{
				CurrentScreen = SCREEN_CheckEventLogByDate;
				CheckEventLogByDateMgr.year = SystemTime.year;
				CheckEventLogByDateMgr.month = SystemTime.month;
				CheckEventLogByDateMgr.date = SystemTime.date;
				CheckEventLogByDateMgr.Status = SetYear;
			}
			else if ( gui_keycode == KEY_THREE )
			{
				CurrentScreen = SCREEN_DeleteEventLog;
				LogDeleteMgr.Status = LogDeleteStart;
			}
			*/
			else if ( gui_keycode == KEY_TWO )
			{	
				DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_DeleteEventLog;
				LogDeleteMgr.Status = LogDeleteStart;
			}
			else if ( gui_keycode == KEY_ASTERISK )
			{
				DEF_ButtonPress_Voice;
				GoIntoInfoInquiryMenu_Init();
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoLogMenu_Init();
			}
			
			break;

			
		case SCREEN_SystemConfigMenu:
			
			if ( gui_keycode == KEY_ONE )
			{	
				DEF_ButtonPress_Voice;
				CurrentScreen = SCREEN_TimeSetting;
				
				TimeSettingMgr.Status = SetYearMajor;
				TempSystemTime.year	=SystemTime.year;
				TempSystemTime.month	=SystemTime.month ;
				TempSystemTime.date	=SystemTime.date ;
				TempSystemTime.day	=SystemTime.day;
				TempSystemTime.hour	=SystemTime.hour;
				TempSystemTime.minute	=SystemTime.minute;
				TempSystemTime.second	=SystemTime.second;

				PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PleaseInputYear);
			}
			else if ( gui_keycode == KEY_TWO )
			{	
				DEF_ButtonPress_Voice;
				GoIntoVoiceSettingMenu_Init();
			}				
			else if ( gui_keycode == KEY_THREE )
			{	
				DEF_ButtonPress_Voice;
				GoIntoDoorLockSettingMenu_Init();
			}
			else if ( gui_keycode == KEY_FOUR )
			{	
				DEF_ButtonPress_Voice;
				GoIntoMotorSettingMenu_Init();		
			}
			else if ( gui_keycode == KEY_ASTERISK )
			{
				DEF_ButtonPress_Voice;
				GoIntoMainMenu_Init();	
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoSystemConfigMenu_Init();
			}

			break;

		case SCREEN_VoiceSettingMenu:

			if ( gui_keycode == KEY_ONE )
			{	
				DEF_ButtonPress_Voice;
				GoIntoLanguageSetting_Init();
			}
			else if ( gui_keycode == KEY_TWO )
			{	
				DEF_ButtonPress_Voice;
				GoIntoVolumeSetting_Init();
			}
			else if ( gui_keycode == KEY_ASTERISK )
			{
				DEF_ButtonPress_Voice;
				GoIntoSystemConfigMenu_Init();	
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoVoiceSettingMenu_Init();
			}
			break;

		case SCREEN_EngineeringModeMneu:
 
			if ( gui_keycode == KEY_ONE )
			{
				DEF_ButtonPress_Voice;
				GotoMotorLockDirrectionSetting_Init();		
			}
			else if ( gui_keycode == KEY_TWO )
			{
				DEF_ButtonPress_Voice;
				GotoMotorTorqueSetting_Init();	
			}
			else if ( gui_keycode == KEY_THREE )
			{
				DEF_ButtonPress_Voice;
				GotoBoltLockTimeSetting_Init();
			}
			else if ( gui_keycode == KEY_FOUR )
			{
				DEF_ButtonPress_Voice;
				GotoLockingTravelSetting_Init();	
			}
			else if ( gui_keycode == KEY_FIVE )
			{
				DEF_ButtonPress_Voice;
				GotoAutoEjectSetting_Init();
			}	
			else if ( gui_keycode == KEY_SIX )
			{
				DEF_ButtonPress_Voice;
				GotoMotorSelfTest_Init();
				AutoMotorMgr.SelfTest.Status = SelfTestStart;
				ComPort_SetPost_MotorSelftest();
			}

			else if ( (gui_keycode == KEY_SEVEN)&&(FrmMgr.FrmFunctionConfig == FRM_Enabled) )
			{
				DEF_ButtonPress_Voice;
				GoIntoBodyInductionSetting_Init();
			}

			else if ( gui_keycode == KEY_ASTERISK )
			{

				DEF_ButtonPress_Voice;
				GoIntoMainScreen_WithIdentifyInit();
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoEngineeringModeMenu_Init();
			}

			break;
			
		case SCREEN_AutoMotorSettingMenu:

			 if ( gui_keycode == KEY_ONE )
			{
				DEF_ButtonPress_Voice;
				GotoMotorUnlockTimeSetting_Init();
			}
			else if ( gui_keycode == KEY_TWO )
			{
				DEF_ButtonPress_Voice;
				GotoMotorAutoLockTimeSetting_Init();
			}
			else if ( gui_keycode == KEY_THREE )
			{
				DEF_ButtonPress_Voice;
				GotoMotorSelfTest_Init();
				AutoMotorMgr.SelfTest.Status = SelfTestStart;
				ComPort_SetPost_MotorSelftest();
			}
			else if ( gui_keycode == KEY_FOUR )
			{
				DEF_ButtonPress_Voice;
				GotoMotorTorqueSetting_Init();	
			}
			else if ( gui_keycode == KEY_ASTERISK )
			{
				DEF_ButtonPress_Voice;
				GoIntoSystemConfigMenu_Init();		
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				DEF_ButtonPress_Voice;
				GoIntoMotorSettingMenu_Init();	
			}

			break;		

		case SCREEN_RegisterMasterFace:
					
			if ( gui_keycode == KEY_ASTERISK )
			{
				if (( FaceUserRegisterMgr.Status != RegisterFaceUserSuccess )
					&&( FaceUserRegisterMgr.Status != RegisterFaceUserFail )
					)
				{
					DEF_ButtonPress_Voice;
					#ifdef Function_FaceRecoginition			
					//FaceRecognition_FaceReset();
					FaceRecognition_HardwarePowerOff();
					#endif			
					GoIntoFaceMenu_Init();
				}
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				if ( FaceUserRegisterMgr.Status == ReportFaceUserID )
				{
					FaceUserRegisterMgr.Status = AddUserToFRM;	
					GUI_FaceTemplateRegisterMgr.Status = StartFaceRegister;
					GUI_Flag_RefreshLCD = bTRUE;
				}
			}
				
			break;

		
		case SCREEN_RegisterUserFace:
			
			if ( gui_keycode == KEY_ASTERISK )
			{
				if (( FaceUserRegisterMgr.Status != RegisterFaceUserSuccess )
					&&( FaceUserRegisterMgr.Status != RegisterFaceUserFail )
					)
				{
					DEF_ButtonPress_Voice;
					#ifdef Function_FaceRecoginition			
					//FaceRecognition_FaceReset();
					FaceRecognition_HardwarePowerOff();
					#endif			
					GoIntoFaceMenu_Init();
				}
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				if ( FaceUserRegisterMgr.Status == ReportFaceUserID )
				{
					FaceUserRegisterMgr.Status = AddUserToFRM;	
					GUI_FaceTemplateRegisterMgr.Status = StartFaceRegister;
					GUI_Flag_RefreshLCD = bTRUE;
				}
			}
				
			break;

		
		case SCREEN_DeleteUserFace:
			
			if ( FaceUserDeleteMgr.Status == InputUserID )
			{
				GUI_UserIDinputButtonMonitor(gui_keycode);
			}
			
			break;

		case SCREEN_RegisterMasterFp: 
				
			if ( gui_keycode == KEY_ASTERISK )
			{
				if (( FpUserRegisterMgr.Status != RegisterUserSuccess )
					&&( FpUserRegisterMgr.Status != RegisterUserFail )
					)
				{
					DEF_ButtonPress_Voice;
					GoIntoFpMenu_Init();
				}
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				if ( FpUserRegisterMgr.Status == ReportFpUserID )
				{
					FpUserRegisterMgr.Status = AddUserToFPM;	
					FpRegisterMgr.Status = FPMcmdStart;		
					GUI_Flag_RefreshLCD = bTRUE;
				}
			}
				
			break;

		case SCREEN_RegisterUserFp:

			if ( gui_keycode == KEY_ASTERISK )
			{
				if (( FpUserRegisterMgr.Status != RegisterUserSuccess )
					&&( FpUserRegisterMgr.Status != RegisterUserFail )
					)
				{
					DEF_ButtonPress_Voice;
					GoIntoFpMenu_Init();
				}
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				if ( FpUserRegisterMgr.Status == ReportFpUserID )
				{
					FpUserRegisterMgr.Status = AddUserToFPM;	
					FpRegisterMgr.Status = FPMcmdStart;		
					GUI_Flag_RefreshLCD = bTRUE;
				}
			}
				
			break;
			
		case SCREEN_DeleteUserFp:
			
			if ( FpUserDeleteMgr.Status == InputUserID )
			{
				GUI_UserIDinputButtonMonitor(gui_keycode);
			}

			break;

		case SCREEN_DeleteAllUserFp:
			
			if ( AllUserFpDeleteMgr.Status == WaitForUserConfirmDeleteAllFP )
			{
				if ( gui_keycode == KEY_POUNDSIGN )
				{
					AllUserFpDeleteMgr.Status = SendDeleteAllUserFpCmdToFPM;
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					AllUserFpDeleteMgr.Status = EXIT;
				}
			}

			break;

		case SCREEN_RegisterStressUserFp:
				
			
			if ( gui_keycode == KEY_ASTERISK )
			{
				if (( FpUserRegisterMgr.Status != RegisterUserSuccess )
					&&( FpUserRegisterMgr.Status != RegisterUserFail )
					)
				{
					DEF_ButtonPress_Voice;
					GoIntoFpMenu_Init();
				}
			}
			else if ( gui_keycode == KEY_POUNDSIGN )
			{
				if ( FpUserRegisterMgr.Status == ReportFpUserID )
				{
					FpUserRegisterMgr.Status = AddUserToFPM;	
					FpRegisterMgr.Status = FPMcmdStart;		
					GUI_Flag_RefreshLCD = bTRUE;
				}
			}
				
			break;
			
		case SCREEN_DeleteStressUserFp:
			
			if ( FpUserDeleteMgr.Status == InputUserID )
			{
				GUI_UserIDinputButtonMonitor(gui_keycode);
			}

			break;

		case SCREEN_DeleteAllStressUserFp:
			
			if ( AllUserFpDeleteMgr.Status == WaitForUserConfirmDeleteAllFP )
			{
				if ( gui_keycode == KEY_POUNDSIGN )
				{
					AllUserFpDeleteMgr.Status = SendDeleteAllUserFpCmdToFPM;
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					AllUserFpDeleteMgr.Status = EXIT;
				}
			}

			break;

		case SCREEN_RegisterCardUser:
			

				if ( gui_keycode == KEY_ASTERISK )
				{
					if (( CardUserRegisterMgr.Status != Success )
						&&( CardUserRegisterMgr.Status != Fail )
						)
					{
						DEF_ButtonPress_Voice;
						GoIntoCardMenu_Init();
					}
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					if ( CardUserRegisterMgr.Status == ReportCardUserID )
					{
						PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_PleaseSwingCard);
						CardUserRegisterMgr.Status = ReadingCardID;
						CardUserRegisterMgr.TimeCnt = Def_UserSwingCardTimeDelay;	//set to 5s
						GUI_RefreshSleepTime();
						GUI_Flag_RefreshLCD = bTRUE;
					}
				}
			break;
			
		case SCREEN_DeleteCardUser:

				if ( CardUserDeleteMgr.Status == InputCardUserID )
				{
					GUI_UserIDinputButtonMonitor(gui_keycode);
				}
			break;

		case SCREEN_DeleteAllCardUser:
				
				if ( AllCardUserDeleteMgr.Status == WaitForUserConfirmDeleteAllCard )
				{
					if ( gui_keycode == KEY_POUNDSIGN )
					{
						AllCardUserDeleteMgr.Status = DeletingAllCardUser;
					}
					else if ( gui_keycode == KEY_ASTERISK )
					{
						DEF_ButtonPress_Voice;
						AllCardUserDeleteMgr.Status = CardUserEXIT;
					}	
				}

			break;	


		case SCREEN_RegisterPasscodeUser:

				if ( PasscodeUserRegisterMgr.Status == InputFirstPasscode )
				{
					if ( gui_keycode != KEY_NONE )
					{
						GUI_PasscodeInputButtonMonitor(gui_keycode);
						PasscodeUserRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt10s;
					}
				}
				else if ( PasscodeUserRegisterMgr.Status == InputSecondPasscode )
				{
					if ( gui_keycode != KEY_NONE )
					{
						GUI_PasscodeInputButtonMonitor(gui_keycode);
						PasscodeUserRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt10s;
					}
				}
				else if ( PasscodeUserRegisterMgr.Status == ReportPasscodeUserID )
				{
					if ( gui_keycode == KEY_POUNDSIGN )
					{
						PasscodeUserRegisterMgr.Status = InputFirstPasscode;	
						PasscodeUserRegisterMgr.TimeCnt = Def_GuiTimeDelayCnt10s;
						PasscodeInputMgr.Point = 0x00;
						PasscodeInputMgr.PasscodeLen = 12;
						PasscodeInputMgr.Status = PasscodeInputStart;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PleaseInputPassword);
						GUI_Flag_RefreshLCD = bTRUE;

					}
					else if ( gui_keycode == KEY_ASTERISK )
					{
						GoIntoPasscodeMenu_Init();
						DEF_ButtonPress_Voice;
					}
				}
		
			break;
			
		case SCREEN_DeletePasscodeUser:

			if ( PasscodeUserDeleteMgr.Status == InputPasscodeUserID )
				{
					GUI_UserIDinputButtonMonitor(gui_keycode);
				}

			break;

		case SCREEN_DeleteAllPasscodeUser:
			
			if ( AllPasscodeUserDeleteMgr.Status == WaitForDeleteAllPasscodeUserConfirm )
			{
				if ( gui_keycode == KEY_POUNDSIGN )
				{
					AllPasscodeUserDeleteMgr.Status = DeletingAllPasscodeUser;
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					AllPasscodeUserDeleteMgr.Status = PasscodeUserEXIT;
				}
			}


			break;
			

		case SCREEN_TimeSetting:

				if ( TimeSettingMgr.Status == SetYearMajor)
				{
					if ( (gui_keycode < KEY_NINE )||(gui_keycode == KEY_NINE) )
					{
						DEF_ButtonPress_Voice;
						TempSystemTime.year = (TempSystemTime.year&0x0F)+(gui_keycode<<4);
						TimeSettingMgr.Status = SetYearMinor;
					}
				}
				else if ( TimeSettingMgr.Status == SetYearMinor)
				{
					if ( gui_keycode == KEY_ASTERISK )
					{
						DEF_ButtonPress_Voice;
						//TimeSettingMgr.Status = SetMonthMajor;
						TimeSettingMgr.Status = SetYearMajor;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PleaseInputYear);
					}
					else if ( (gui_keycode < KEY_NINE )||(gui_keycode == KEY_NINE) )
					{
						DEF_ButtonPress_Voice;
						TempSystemTime.year =(TempSystemTime.year&0xF0)+gui_keycode;
						TimeSettingMgr.Status = SetMonthMajor;
						VoiceReportYearAndInputMonth(TempSystemTime.year);
					}
				}
				
				else if ( TimeSettingMgr.Status == SetMonthMajor)
				{
					if ( (gui_keycode < KEY_TWO) )
					{
						DEF_ButtonPress_Voice;
						TempSystemTime.month= (TempSystemTime.month&0x0F)+(gui_keycode<<4);
						TimeSettingMgr.Status = SetMonthMinor;
					}
				}
				else if ( TimeSettingMgr.Status == SetMonthMinor)
				{
					if ( gui_keycode == KEY_ASTERISK )
					{
						DEF_ButtonPress_Voice;
						TimeSettingMgr.Status = SetMonthMajor;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PleaseInputMonth);
					}
					else if ( (gui_keycode < KEY_NINE )||(gui_keycode == KEY_NINE) )
					{
						DEF_ButtonPress_Voice;
						TempSystemTime.month=(TempSystemTime.month&0xF0)+gui_keycode;
						if ( TempSystemTime.month > 0x12 ){
							TempSystemTime.month = 0x12;
						}
						TimeSettingMgr.Status = SetDateMajor;
						VoiceReportMonthAndInputDate(TempSystemTime.month);
					}
				}
				
				else if ( TimeSettingMgr.Status == SetDateMajor)
				{
					if ( gui_keycode == KEY_ASTERISK ){
						DEF_ButtonPress_Voice;
						TimeSettingMgr.Status = SetDateMinor;
					}
					else if ( (gui_keycode < KEY_FOUR) )
					{
						DEF_ButtonPress_Voice;
						TempSystemTime.date= (TempSystemTime.date&0x0F)+(gui_keycode<<4);
						TimeSettingMgr.Status = SetDateMinor;
					}
				}
				else if ( TimeSettingMgr.Status == SetDateMinor)
				{
					if ( gui_keycode == KEY_ASTERISK ){
						DEF_ButtonPress_Voice;
						TimeSettingMgr.Status = SetDateMajor;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PleaseInputDate);
					}
					else if ( (gui_keycode < KEY_NINE )||(gui_keycode == KEY_NINE) )
					{
						DEF_ButtonPress_Voice;
						TempSystemTime.date=(TempSystemTime.date&0xF0)+gui_keycode;
						if ( TempSystemTime.date > 0x31 ){
							TempSystemTime.date = 0x31;
						}
						TimeSettingMgr.Status = SetHourMajor;
						VoiceReportDateAndInputHour(TempSystemTime.date);
					}
				}

				else if ( TimeSettingMgr.Status == SetHourMajor)
				{
					if ( gui_keycode == KEY_ASTERISK ){
						DEF_ButtonPress_Voice;
						TimeSettingMgr.Status = SetHourMinor;
					}
					else if ( (gui_keycode < KEY_THREE )){
						DEF_ButtonPress_Voice;
						TempSystemTime.hour= (TempSystemTime.hour&0x0F)+(gui_keycode<<4);
						TimeSettingMgr.Status = SetHourMinor;
					}
				}
				else if ( TimeSettingMgr.Status == SetHourMinor)
				{
					if ( gui_keycode == KEY_ASTERISK ){
						DEF_ButtonPress_Voice;
						TimeSettingMgr.Status = SetHourMajor;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PleaseInputHour);
					}
					else if( (gui_keycode < KEY_NINE )||(gui_keycode == KEY_NINE) )
					{
						DEF_ButtonPress_Voice;
						TempSystemTime.hour=(TempSystemTime.hour&0xF0)+gui_keycode;
						if (TempSystemTime.hour > 0x23){
							TempSystemTime.hour = 0x23;
						}
						TimeSettingMgr.Status = SetMinuteMajor;
						VoiceReportHourAndInputMinute(TempSystemTime.hour);
					}
				}


				else if ( TimeSettingMgr.Status == SetMinuteMajor)
				{
					if ( gui_keycode == KEY_ASTERISK ){
						DEF_ButtonPress_Voice;
						TimeSettingMgr.Status = SetMinuteMinor;
					}
					else if ( gui_keycode < KEY_SIX)
					{
						DEF_ButtonPress_Voice;
						TempSystemTime.minute= (TempSystemTime.minute&0x0F)+(gui_keycode<<4);
						TimeSettingMgr.Status = SetMinuteMinor;
					}
				}
				else if ( TimeSettingMgr.Status == SetMinuteMinor)
				{
					if ( gui_keycode == KEY_ASTERISK ){
						DEF_ButtonPress_Voice;
						TimeSettingMgr.Status = SetMinuteMajor;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PleaseInputMinute);
					}
					else if ( (gui_keycode < KEY_NINE )||(gui_keycode == KEY_NINE) ){
						DEF_ButtonPress_Voice;
						TempSystemTime.minute=(TempSystemTime.minute&0xF0)+gui_keycode;
						TimeSettingMgr.Status = SetSecondMajor;
						VoiceReportMinuteAndInputSecond(TempSystemTime.minute);
					}
				}

				else if ( TimeSettingMgr.Status == SetSecondMajor)
				{
					if ( gui_keycode == KEY_ASTERISK ){
						DEF_ButtonPress_Voice;
						TimeSettingMgr.Status = SetSecondMinor;
					}
					else if ( gui_keycode < KEY_SIX){
						DEF_ButtonPress_Voice;
						TempSystemTime.second= (TempSystemTime.second&0x8F)+(gui_keycode<<4);
						TimeSettingMgr.Status = SetSecondMinor;
					}
				}
				else if ( TimeSettingMgr.Status == SetSecondMinor)
				{
					if ( gui_keycode == KEY_ASTERISK ){
						DEF_ButtonPress_Voice;
						TimeSettingMgr.Status = SetSecondMajor;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_PleaseInputSecond);
					}
					else if ( (gui_keycode < KEY_NINE )||(gui_keycode == KEY_NINE) ){
						DEF_ButtonPress_Voice;
						TempSystemTime.second=(TempSystemTime.second&0xF0)+gui_keycode;
						//TimeSettingMgr.Status = SetYearMajor;
						VoiceReportSecond(TempSystemTime.second);
					}
				}

				if ( gui_keycode == KEY_POUNDSIGN )
				{
					if (is_valid_date(TempSystemTime.year, TempSystemTime.month, TempSystemTime.date)==bTRUE)
					{
						//DEF_ButtonPress_Voice;
						PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationSuccess);
						SystemTime.year    	=	TempSystemTime.year;
						SystemTime.month 	= 	TempSystemTime.month;
						SystemTime.date    	= 	TempSystemTime.date;
						SystemTime.day		= 	TempSystemTime.day;
						SystemTime.hour    	= 	TempSystemTime.hour;
						SystemTime.minute 	= 	TempSystemTime.minute;
						SystemTime.second 	= 	TempSystemTime.second;
						
						#ifdef Function_USE_Internal_RTC
						G_SystemUTCTime = SystemTimeToUTC(SystemTime);
						#else
						PCF8563_WriteTime();
						#endif
					}
					else{
						PLAY_VOICE_ONESEGMENT(VoiceMgr.volume,VOICE_InputError);
					}
					
					GoIntoSystemConfigMenu_Init();		
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					GoIntoSystemConfigMenu_Init();	
				}

			break;

		  case SCREEN_RestoreFactoryDefault:

				if ( RestoreFactoryDefaultMgr.Status == WaitForRestoreFactoryDefaultUserConfirm )
				{
					if ( gui_keycode == KEY_ASTERISK )
					{
						DEF_ButtonPress_Voice;
						RestoreFactoryDefaultMgr.Status = RestoreFactoryDefaultEXIT;
					}
					else if ( gui_keycode == KEY_POUNDSIGN )
					{
						DEF_ButtonPress_Voice;
						RestoreFactoryDefaultMgr.Status = ConfirmedToRestoreFactoryDefault;
					}
				}

				break;

		  case SCREEN_LanguageSetting:
	
				if( gui_keycode == KEY_ONE )
				{
					SystemLanguage = Chinese;
					VoiceReportCurrentLanguage();
				}
				else if ( gui_keycode == KEY_TWO )
				{
					SystemLanguage = English;
					VoiceReportCurrentLanguage();
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					SystemConfigSave();
					GoIntoVoiceSettingMenu_Init();	
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					GoIntoLanguageSetting_Init();	
				}
				break;

		  case SCREEN_VolumeSetting:

				if ( gui_keycode == KEY_ONE )
				{
					VoiceMgr.volume = 3;
					//SET_VOLUME(VoiceMgr.volume*5);	
					VoiceReportCurrentVolume();
				}
				else if ( gui_keycode == KEY_TWO )
				{
					VoiceMgr.volume = 2;
					//SET_VOLUME(VoiceMgr.volume*5);
					VoiceReportCurrentVolume();
				}

				else if ( gui_keycode == KEY_THREE )
				{
					VoiceMgr.volume = 1;			
					//SET_VOLUME(VoiceMgr.volume*5);
					VoiceReportCurrentVolume();
				}
				else if ( gui_keycode == KEY_FOUR )
				{	
					VoiceMgr.volume = 0;		
					//SET_VOLUME(VoiceMgr.volume*5);	
					VoiceReportCurrentVolume();
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					SystemConfigSave();
					GoIntoVoiceSettingMenu_Init();	
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					DEF_ButtonPress_Voice;
					GoIntoVolumeSetting_Init();	
				}
				break;	

       case SCREEN_AutoMotorLockDirection:
			
				if ( gui_keycode == KEY_ONE )
				{
					DEF_ButtonPress_Voice;
					AutoMotorMgr.LockDirection= LEFTOPEN;
					VoiceReportCurrentUnlockDirrect();
				}
				else if ( gui_keycode == KEY_TWO )
				{
					DEF_ButtonPress_Voice;
					AutoMotorMgr.LockDirection= RIGHTOPEN;
					VoiceReportCurrentUnlockDirrect();
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					EEPROM_WriteSequential(AutoMotorMgrLockDirectionAddr,&AutoMotorMgr.LockDirection,1);
					GoIntoEngineeringModeMenu_Init();	
					ComPort_SetPost_Parameter();
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					GotoMotorLockDirrectionSetting_Init();		
				}
					
				break;

         case SCREEN_AutoMotorTorque:
				
				if ( gui_keycode == KEY_ONE )
				{
					DEF_ButtonPress_Voice;
					AutoMotorMgr.TorqueLevel = LowTorque;
					VoiceReportCurrentTorque();
				}
				else if ( gui_keycode == KEY_TWO )
				{
					DEF_ButtonPress_Voice;
					AutoMotorMgr.TorqueLevel = MiddleTorque;
					VoiceReportCurrentTorque();
				}
				else if ( gui_keycode == KEY_THREE )
				{
					DEF_ButtonPress_Voice;
					AutoMotorMgr.TorqueLevel = LargeTorque;
					VoiceReportCurrentTorque();
				}
				else if ((gui_keycode == KEY_ASTERISK))
				{
					DEF_ButtonPress_Voice;
					EEPROM_WriteSequential(AutoMotorMgrTorqueAddr,&AutoMotorMgr.TorqueLevel,1);
					if ( IfSystemIsInFactoryDefaultStatus() == bTRUE )
					{
						GoIntoEngineeringModeMenu_Init();
					}
					else
					{
						GoIntoMotorSettingMenu_Init();
					}
					ComPort_SetPost_Parameter();		
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					GotoMotorTorqueSetting_Init();	
				}


				break;
				
			case SCREEN_AutoMotorUnlockTime:
			
				   if ( gui_keycode == KEY_TWO )
				   {
						DEF_ButtonPress_Voice;
						if ( AutoMotorMgr.UnlockTime < 10 )
						{
						   AutoMotorMgr.UnlockTime++;
						}
				   		VoiceReportCurrentSettingTime_Integer(AutoMotorMgr.UnlockTime);
				   }
				   else if ( gui_keycode == KEY_EIGHT )
				   {
					   DEF_ButtonPress_Voice;
					   if ( AutoMotorMgr.UnlockTime > 2 )
					   {
						   AutoMotorMgr.UnlockTime--;
					   }
					   VoiceReportCurrentSettingTime_Integer(AutoMotorMgr.UnlockTime);
				   }
				   else if ( gui_keycode == KEY_ASTERISK )
				   {
					   DEF_ButtonPress_Voice;
					   EEPROM_WriteSequential(AutoMotorMgrUnlockTimeAddr,&AutoMotorMgr.UnlockTime,1);
					   GoIntoMotorSettingMenu_Init();  
					   ComPort_SetPost_Parameter();
				   }
				   else if ( gui_keycode == KEY_POUNDSIGN )
				   {
						GotoMotorUnlockTimeSetting_Init();	
				   }
				   break;  
				   
			 case SCREEN_AutoMotorAutoLockTime:
	
				   if ( gui_keycode == KEY_TWO )
				   {
						DEF_ButtonPress_Voice;
						 
						#ifdef ProjectIs_BarLock_S101Z01
							if ( AutoMotorMgr.AutoLockTime < 0 )
					   {
						   AutoMotorMgr.AutoLockTime=0;
					   }
					   else if ( AutoMotorMgr.AutoLockTime < 60 )
					   {
						   AutoMotorMgr.AutoLockTime = AutoMotorMgr.AutoLockTime+5;
					   }
						#else
							if ( AutoMotorMgr.AutoLockTime < 5 )
					   {
						   AutoMotorMgr.AutoLockTime=5;
					   }
					   else if ( AutoMotorMgr.AutoLockTime < 20 )
					   {
						   AutoMotorMgr.AutoLockTime++;
					   }
						#endif
						 

					   VoiceReportCurrentSettingTime_Integer(AutoMotorMgr.AutoLockTime);
				   }
				   else if ( gui_keycode == KEY_EIGHT )
				   {
					   DEF_ButtonPress_Voice;
					   if ( AutoMotorMgr.AutoLockTime >5 )
					   {
							#ifdef ProjectIs_BarLock_S101Z01
							AutoMotorMgr.AutoLockTime = AutoMotorMgr.AutoLockTime-5;
							#else
							AutoMotorMgr.AutoLockTime--;
							#endif
						  
						   VoiceReportCurrentSettingTime_Integer(AutoMotorMgr.AutoLockTime);
					   }
					   else
					   {
						   AutoMotorMgr.AutoLockTime=0;
						   PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,AutoLockOffVoiceStr);
					   }
					   
				   }
				   else if ( gui_keycode == KEY_ASTERISK )
				   {
					   DEF_ButtonPress_Voice;
					   EEPROM_WriteSequential(AutoMotorMgrAutoLockTimeAddr,&AutoMotorMgr.AutoLockTime,1);
					   GoIntoMotorSettingMenu_Init();  
					   ComPort_SetPost_Parameter();
				   }	
				   else if ( gui_keycode == KEY_POUNDSIGN )
				   {
						GotoMotorAutoLockTimeSetting_Init();	
				   }
				   break;  

				
		case SCREEN_AutoMotorBoltLockTime:

				if ( gui_keycode == KEY_TWO )
				{
					DEF_ButtonPress_Voice;
					if ( AutoMotorMgr.BoltLockTime< 23){
						AutoMotorMgr.BoltLockTime+=2;
					}
					VoiceReportCurrentSettingTime_Decimal(AutoMotorMgr.BoltLockTime/2);
				}
				else if ( gui_keycode == KEY_EIGHT )
				{
					DEF_ButtonPress_Voice;
					if ( AutoMotorMgr.BoltLockTime> 3 )
					{
						AutoMotorMgr.BoltLockTime-=2;
					}
					VoiceReportCurrentSettingTime_Decimal(AutoMotorMgr.BoltLockTime/2);
				}
				else if ((gui_keycode == KEY_ASTERISK) )
				{
					DEF_ButtonPress_Voice;
					EEPROM_WriteSequential(AutoMotorMgrBoltLockTimeAddr,&AutoMotorMgr.BoltLockTime,1);
					GoIntoEngineeringModeMenu_Init();	
					ComPort_SetPost_Parameter();
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
			   {
					GotoBoltLockTimeSetting_Init();	
			   }
				break;	
				
		case SCREEN_LockingTravel:

				if ( gui_keycode == KEY_TWO )
				{
					DEF_ButtonPress_Voice;
					if ( AutoMotorMgr.LockingTravel< 8){
						AutoMotorMgr.LockingTravel++;
					}
					VoiceReportCurrentTravelSetting(AutoMotorMgr.LockingTravel);
				}
				else if ( gui_keycode == KEY_EIGHT )
				{
					DEF_ButtonPress_Voice;
					if ( AutoMotorMgr.LockingTravel> 1 )
					{
						AutoMotorMgr.LockingTravel--;
					}
					VoiceReportCurrentTravelSetting(AutoMotorMgr.LockingTravel);
				}
				else if ( (gui_keycode == KEY_POUNDSIGN)||(gui_keycode == KEY_ASTERISK) )
				{
					DEF_ButtonPress_Voice;
					EEPROM_WriteSequential(AutoMotorMgrLockingTravelAddr,&AutoMotorMgr.LockingTravel,1);
					GoIntoEngineeringModeMenu_Init();	
					ComPort_SetPost_Parameter();
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
			   {
					GotoLockingTravelSetting_Init();	
			   }
				
				break;		
				
		case SCREEN_AutoEject:
		
				if ( gui_keycode == KEY_ONE )
				{
					DEF_ButtonPress_Voice;
					AutoMotorMgr.AutoEject = 0x01;
					PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,AutoEjectOnVoiceStr);
				}
				else if ( gui_keycode == KEY_TWO )
				{
					DEF_ButtonPress_Voice;
					AutoMotorMgr.AutoEject = 0x00;
					PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,AutoEjectOffVoiceStr);
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					EEPROM_WriteSequential(AutoMotorMgrAutoEjectAddr,&AutoMotorMgr.AutoEject,1);
					GoIntoEngineeringModeMenu_Init();	
					ComPort_SetPost_Parameter();
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
			   {
					GotoAutoEjectSetting_Init();	
			   }

				break;
							
			case SCREEN_MemoryUsage:
				
				if ( gui_keycode == KEY_TWO )
				{
					DEF_ButtonPress_Voice;
					if ( DisplayMemoryUsageMgr.Status == DisplayCardUserMemoryUsage )
					{
						DisplayMemoryUsageMgr.Status = DisplayPasscodeUserMemoryUsage;
					}
					else if ( DisplayMemoryUsageMgr.Status == DisplayPasscodeUserMemoryUsage )
					{
						DisplayMemoryUsageMgr.Status = DisplayFpUserMemoryUsage;
					}
				}
				else if ( gui_keycode == KEY_EIGHT )
				{
					DEF_ButtonPress_Voice;
					if ( DisplayMemoryUsageMgr.Status == DisplayFpUserMemoryUsage )
					{
						DisplayMemoryUsageMgr.Status = DisplayPasscodeUserMemoryUsage;
					}
					else if ( DisplayMemoryUsageMgr.Status == DisplayPasscodeUserMemoryUsage )
					{
						DisplayMemoryUsageMgr.Status = DisplayCardUserMemoryUsage;
					}
				}
				if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					GoIntoInfoInquiryMenu_Init();
				}
				else if (gui_keycode == KEY_POUNDSIGN)
				{
					DEF_ButtonPress_Voice;
					GoIntoMemoryUsageScreen();
				}
				
				break;
				
			case SCREEN_ManagerIdentify:

					if ( ManagerIdentifyMgr.Status == IdentifyingManager )
						{
							GUI_PasscodeInputButtonMonitor(gui_keycode);
						}
				break;

			case SCREEN_DoorLockSettingMenu:

				if ( gui_keycode == KEY_ONE )
				{
					DEF_ButtonPress_Voice;
					GoIntoUnlockingModeSetting_Init();
				}
				else if ( gui_keycode == KEY_TWO )
				{
					DEF_ButtonPress_Voice;
					GoIntoPickAlarmEnableSetting_Init();
				}
				else if ( gui_keycode == KEY_THREE )
				{
					if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
					{
						GoIntoBodyInductionSetting_Init();
					}
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					GoIntoSystemConfigMenu_Init();
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					DEF_ButtonPress_Voice;
					GoIntoDoorLockSettingMenu_Init();
				}

				break;
	
			case SCREEN_UnlockingModeSetting:
					
					if ( gui_keycode == KEY_ONE )
					{
						DEF_ButtonPress_Voice;
						UserIdentifyResultMgr.UnlockingMode = SingalMode;
						VoiceReportCurrentUnlockMode();
					}
					else if ( gui_keycode == KEY_TWO )
					{
						DEF_ButtonPress_Voice;
						if	( IfSystemWithoutSecondIdentity() == bTRUE )
						{
							UserIdentifyResultMgr.UnlockingMode = SingalMode;
							SystemConfigSave();
							PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr_OperationFail);
							GoIntoUnlockingModeSetting_Init();
						}
						else
						{
							UserIdentifyResultMgr.UnlockingMode = DoubleMode;
							VoiceReportCurrentUnlockMode();
						}
					}
					else if (gui_keycode == KEY_ASTERISK)
					{
						DEF_ButtonPress_Voice;
						UnlockModeAutoCalculate();
						SystemConfigSave();
						GoIntoDoorLockSettingMenu_Init();
					}
					else if ( gui_keycode == KEY_POUNDSIGN )
					{
						DEF_ButtonPress_Voice;
						GoIntoUnlockingModeSetting_Init();
					}

				break;

						
			case SCREEN_PickAlarmEnableSetting:
			
					if ( gui_keycode == KEY_ONE )
					{
						DEF_ButtonPress_Voice;
						PickAlarmEnableMgr.Enable = bTRUE;
						AntiPryingMgr.AntiPryingTrigger = bFALSE;		//Refresh Anti-Prying Trigger
						VoiceReportCurrentPickAlarmEnableSetting();
					}
					else if ( gui_keycode == KEY_TWO )
					{
						DEF_ButtonPress_Voice;
						PickAlarmEnableMgr.Enable = bFALSE;
						AntiPryingMgr.AntiPryingTrigger = bFALSE;		//Refresh Anti-Prying Trigger
						VoiceReportCurrentPickAlarmEnableSetting();
					}
					else if (gui_keycode == KEY_ASTERISK)
					{
						DEF_ButtonPress_Voice;
						SystemConfigSave();
						Config_AntiPrying_Interrupt();
						GoIntoDoorLockSettingMenu_Init();	
					}
					else if ( gui_keycode == KEY_POUNDSIGN )
					{
						DEF_ButtonPress_Voice;
						GoIntoPickAlarmEnableSetting_Init();
					}
						
					break;
					
			case SCREEN_BodyInductionSetting:

				if ( gui_keycode == KEY_ONE )
				{
					DEF_ButtonPress_Voice;
					BodyInductionMgr.SensingDistanceLevel = SensingDistanceL0;
					VoiceReportCurrentBodyInduction();
				}
				else if ( gui_keycode == KEY_TWO )
				{
					DEF_ButtonPress_Voice;
					BodyInductionMgr.SensingDistanceLevel = SensingDistanceL1;
					VoiceReportCurrentBodyInduction();
				}

				else if ( gui_keycode == KEY_THREE )
				{
					DEF_ButtonPress_Voice;
					BodyInductionMgr.SensingDistanceLevel = SensingDistanceL2;
					VoiceReportCurrentBodyInduction();
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					SystemConfigSave();	
					#ifdef Function_BodyInductionByRadar
					Radar_Init();
					#endif
					if ( IfSystemIsInFactoryDefaultStatus() == bTRUE )
					{
						GoIntoEngineeringModeMenu_Init();
					}
					else
					{
						GoIntoDoorLockSettingMenu_Init();
					}
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					DEF_ButtonPress_Voice;
					GoIntoBodyInductionSetting_Init();
				}
				break;

			case SCREEN_SystemVersion:

					if (gui_keycode == KEY_POUNDSIGN )
					{
						DEF_ButtonPress_Voice;
						GoIntoShowSystemVersion();
					}
					else if ( gui_keycode == KEY_ASTERISK )
					{
						DEF_ButtonPress_Voice;
						if (IfSystemIsInFactoryDefaultStatus()==bTRUE)
						{
							GoIntoMainScreen_WithIdentifyInit();
						}
						else
						{
							GoIntoInfoInquiryMenu_Init();
						}
					}
					break;

/*
			case SCREEN_SelfTest:

					if ( SelfTestMgr.Status == KEYandLED_TEST )
					{
						if (gui_keycode!=KEY_NONE){
							SelfTestMgr.ButtonStatus |= 1<<gui_keycode;
							SET_KEYLED_OFF(gui_keycode);
							DEF_ButtonPress_Voice;
						}
						
					}
					else if ( SelfTestMgr.Status == FPM_TEST )
					{
						if ( gui_keycode == KEY_POUNDSIGN )
						{
							SelfTestMgr.Status = MOTOR_TEST;
							SelfTestMgr.TestResult = Unknow;
						}
					}
					else if ( SelfTestMgr.Status == MOTOR_TEST )
					{
						if ( gui_keycode == KEY_POUNDSIGN )
						{
							SelfTestMgr.Status = EMAGNET_TEST;
							SelfTestMgr.TestResult = Unknow;
						}
					}
					else if ( SelfTestMgr.Status == EMAGNET_TEST )
					{
						if ( gui_keycode == KEY_POUNDSIGN )
						{
							SelfTestMgr.Status = EEPROM_TEST;
							SelfTestMgr.TestResult = Unknow;
						}
					}
					else if ( SelfTestMgr.Status == EEPROM_TEST )
					{
						if ( gui_keycode == KEY_POUNDSIGN )
						{
							SelfTestMgr.Status = FLASH_TEST;
							SelfTestMgr.TestResult = Unknow;
						}
					}
					
					else if ( SelfTestMgr.Status == FLASH_TEST )
					{
						if ( gui_keycode == KEY_POUNDSIGN )
						{
							SelfTestMgr.Status = RFID_TEST;
							SelfTestMgr.TestResult = Unknow;
						}
					}
					else if ( SelfTestMgr.Status == RFID_TEST )
					{
						if (( gui_keycode == KEY_POUNDSIGN )&&(SelfTestMgr.TestResult == Passed))
						{
							SelfTestMgr.Status = VOLTAGE_TEST;
							SelfTestMgr.TestResult = Unknow;
						}
					}
					else if ( SelfTestMgr.Status == VOLTAGE_TEST )
					{
						if ( gui_keycode == KEY_POUNDSIGN )
						{
							SelfTestMgr.Status = LOWPOWER_TEST;
							SelfTestMgr.TestResult = Unknow;
						}
					}					
				break;
*/
			case SCREEN_CheckEventLogBySequence:

				if (CheckEventLogBySequenceMgr.Status == ShowEventLogWithSequence)
				{
					if ((gui_keycode == KEY_TWO )||(gui_keycode == KEY_TWO_HOLD))
					{
						if ( gui_keycode == KEY_TWO ){
							DEF_ButtonPress_Voice;
						}
						if  ( CheckEventLogBySequenceMgr.OffsetEventLogNum > 0 )
						{
							CheckEventLogBySequenceMgr.OffsetEventLogNum--;

							if ( LogMgr.DisplayPoint < (DEF_MaxRecordedLogID-1)){
								LogMgr.DisplayPoint++;
							}
							else{
								LogMgr.DisplayPoint = 0;
							}
						}
					}
					else if (( gui_keycode == KEY_EIGHT )||(gui_keycode == KEY_EIGHT_HOLD))
					{
						if ( gui_keycode == KEY_EIGHT ){
							DEF_ButtonPress_Voice;
						}
						if ( (CheckEventLogBySequenceMgr.OffsetEventLogNum+1) < CheckEventLogBySequenceMgr.MatchedEventLogNum )
						{
							if ( LogMgr.DisplayPoint > 0 )
							{
								LogMgr.DisplayPoint--;
							}
							else if( LogMgr.DisplayPoint == 0 )
							{
								if ( JudgeLogSaved(DEF_MaxRecordedLogID-1) == S_SUCCESS )
								{
									LogMgr.DisplayPoint = DEF_MaxRecordedLogID-1;
								}
							}
							CheckEventLogBySequenceMgr.OffsetEventLogNum++;
						}
					}
					else if (gui_keycode == KEY_ASTERISK)
					{
						DEF_ButtonPress_Voice;	
						GoIntoLogMenu_Init();
					}
					else if ( gui_keycode == KEY_POUNDSIGN )
					{
						DEF_ButtonPress_Voice;	
						VoiceReportLogMgr.Status = ReportLogInit;
					}
				}

				break;

			case SCREEN_CheckEventLogByDate:

				if (CheckEventLogByDateMgr.Status == SetYear)
				{
					if ( gui_keycode == KEY_TWO )
					{
						DEF_ButtonPress_Voice;
						if ( CheckEventLogByDateMgr.year < 0x99 )
						{
							CheckEventLogByDateMgr.year = BcdCode_Plus(CheckEventLogByDateMgr.year);
						}
					}
					else if ( gui_keycode == KEY_EIGHT )
					{
						DEF_ButtonPress_Voice;
						if ( CheckEventLogByDateMgr.year > 0x00  )
						{
							CheckEventLogByDateMgr.year = BcdCode_Minus(CheckEventLogByDateMgr.year);
						}
					}
					#ifdef Function_TouchKeyIsTwoLine
					else if ( gui_keycode == KEY_THREE )
					{
						DEF_ButtonPress_Voice;
						if ( CheckEventLogByDateMgr.Status == SetYear ){
							CheckEventLogByDateMgr.Status = SetMonth;
						}
						else if ( CheckEventLogByDateMgr.Status == SetMonth ){
							CheckEventLogByDateMgr.Status = SetDate;
						}
						else if ( CheckEventLogByDateMgr.Status == SetDate ){
							CheckEventLogByDateMgr.Status = SetYear;
						}
					}
					#else
					else if ( gui_keycode == KEY_SIX )
					{
						DEF_ButtonPress_Voice;
						CheckEventLogByDateMgr.Status = SetMonth;
					}
					#endif
					else if (gui_keycode == KEY_POUNDSIGN )
					{
						DEF_ButtonPress_Voice;
						CheckEventLogByDateMgr.Status = SearchEventLogWithDate;
					}
					else if (gui_keycode == KEY_ASTERISK)
					{
						DEF_ButtonPress_Voice;	
						GoIntoLogMenu_Init();
					}
					
				}
				else if (CheckEventLogByDateMgr.Status == SetMonth)
				{
					if ( gui_keycode == KEY_TWO )
					{
						DEF_ButtonPress_Voice;
						if ( CheckEventLogByDateMgr.month < 0x12 )
						{
							CheckEventLogByDateMgr.month=BcdCode_Plus(CheckEventLogByDateMgr.month);
						}
					}
					else if ( gui_keycode == KEY_EIGHT )
					{
						DEF_ButtonPress_Voice;
						if ( CheckEventLogByDateMgr.month > 0x01  )
						{
							CheckEventLogByDateMgr.month=BcdCode_Minus(CheckEventLogByDateMgr.month);
						}
					}
					#ifdef Function_TouchKeyIsTwoLine
					else if ( gui_keycode == KEY_THREE )
					{
						DEF_ButtonPress_Voice;
						if ( CheckEventLogByDateMgr.Status == SetYear ){
							CheckEventLogByDateMgr.Status = SetMonth;
						}
						else if ( CheckEventLogByDateMgr.Status == SetMonth ){
							CheckEventLogByDateMgr.Status = SetDate;
						}
						else if ( CheckEventLogByDateMgr.Status == SetDate ){
							CheckEventLogByDateMgr.Status = SetYear;
						}
					}
					#else
					else if ( gui_keycode == KEY_FOUR )
					{
						DEF_ButtonPress_Voice;
						CheckEventLogByDateMgr.Status = SetYear;
					}
					else if ( gui_keycode == KEY_SIX )
					{
						DEF_ButtonPress_Voice;
						CheckEventLogByDateMgr.Status = SetDate;
					}
					#endif
					
					else if (gui_keycode == KEY_POUNDSIGN )
					{
						DEF_ButtonPress_Voice;
						CheckEventLogByDateMgr.Status = SearchEventLogWithDate;
					}
					else if (gui_keycode == KEY_ASTERISK)
					{
						DEF_ButtonPress_Voice;	
						GoIntoLogMenu_Init();
					}
				}
				else if (CheckEventLogByDateMgr.Status == SetDate)
				{
					if ( gui_keycode == KEY_TWO )
					{
						DEF_ButtonPress_Voice;
						if ( CheckEventLogByDateMgr.date < BcdMaxDays_in_Month(CheckEventLogByDateMgr.year,CheckEventLogByDateMgr.month) )
						{
							CheckEventLogByDateMgr.date = BcdCode_Plus(CheckEventLogByDateMgr.date);
						}
					}
					else if ( gui_keycode == KEY_EIGHT )
					{
						DEF_ButtonPress_Voice;
						if ( CheckEventLogByDateMgr.date > 0x01  )
						{
							CheckEventLogByDateMgr.date = BcdCode_Minus(CheckEventLogByDateMgr.date);
						}
					}
					#ifdef Function_TouchKeyIsTwoLine
					else if ( gui_keycode == KEY_THREE )
					{
						DEF_ButtonPress_Voice;
						if ( CheckEventLogByDateMgr.Status == SetYear ){
							CheckEventLogByDateMgr.Status = SetMonth;
						}
						else if ( CheckEventLogByDateMgr.Status == SetMonth ){
							CheckEventLogByDateMgr.Status = SetDate;
						}
						else if ( CheckEventLogByDateMgr.Status == SetDate ){
							CheckEventLogByDateMgr.Status = SetYear;
						}
					}
					#else
					else if ( gui_keycode == KEY_FOUR )
					{
						DEF_ButtonPress_Voice;
						CheckEventLogByDateMgr.Status = SetMonth;
					}
					#endif
					else if (gui_keycode == KEY_POUNDSIGN )
					{
						DEF_ButtonPress_Voice;
						CheckEventLogByDateMgr.Status = SearchEventLogWithDate;
					}
					else if (gui_keycode == KEY_ASTERISK)
					{
						DEF_ButtonPress_Voice;	
						GoIntoLogMenu_Init();
					}
				}
				else if (CheckEventLogByDateMgr.Status == ShowEventLogWithDate)
				{
					if (( gui_keycode == KEY_TWO )||( gui_keycode == KEY_TWO_HOLD ))
					{
						if (gui_keycode == KEY_TWO){
							DEF_ButtonPress_Voice;
						}
						if  ( CheckEventLogByDateMgr.OffsetEventLogNum > 0 )
						{
							CheckEventLogByDateMgr.OffsetEventLogNum--;
							if ( LogMgr.DisplayPoint < (DEF_MaxRecordedLogID-1)){
								LogMgr.DisplayPoint++;
							}
							else{
								LogMgr.DisplayPoint = 0;
							}
						}
					}
					else if (( gui_keycode == KEY_EIGHT )||(gui_keycode == KEY_EIGHT_HOLD))
					{
						if ( gui_keycode == KEY_EIGHT ){
							DEF_ButtonPress_Voice;
						}
						if ( (CheckEventLogByDateMgr.OffsetEventLogNum+1) < CheckEventLogByDateMgr.MatchedEventLogNum )
						{
							if ( LogMgr.DisplayPoint > 0 )
							{
								LogMgr.DisplayPoint--;
							}
							else if( LogMgr.DisplayPoint == 0 )
							{
								if ( JudgeLogSaved(DEF_MaxRecordedLogID-1) == S_SUCCESS )
								{
									LogMgr.DisplayPoint = DEF_MaxRecordedLogID-1;
								}
							}
							CheckEventLogByDateMgr.OffsetEventLogNum++;
						}
					}
					else if (( gui_keycode == KEY_POUNDSIGN )||(gui_keycode == KEY_ASTERISK))
					{
						DEF_ButtonPress_Voice;	
						GoIntoLogMenu_Init();
					}
				}
			break;

			case SCREEN_DeleteEventLog:
			
			if ( LogDeleteMgr.Status == WaitforLogDeleteCofirm )
				{
					if ( gui_keycode == KEY_POUNDSIGN )
					{
						DEF_ButtonPress_Voice;
						LogDeleteMgr.Status = LogDeleting;
					}
					else if ( gui_keycode == KEY_ASTERISK )
					{
						DEF_ButtonPress_Voice;
						//LogDeleteMgr.Status = LogDeleteIdle;
						GoIntoLogMenu_Init();
					}
				}

			break;

		case SCREEN_PickLockAlarm:
	
			if  ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyIdle )
			{
				if ( gui_keycode < 10 )		//from KEY0~KEY9
				{
					if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyIdle )
					{
						
						PasscodeInputMgr.Point = 0x01;
						PasscodeInputMgr.PasscodeLen = 16;
						PasscodeInputMgr.Status = PasscodeInputStart;
						PasscodeInputMgr.InputBuff[0] = gui_keycode;
						for (i=1;i<PasscodeInputMgr.PasscodeLen;i++)
						{
							PasscodeInputMgr.InputBuff[i]=0xff;
						}
						
						PasscodeUserIdentifyMgr.Status = PasscodeIdentifyStart;
						//DEF_ButtonPress_Voice;
					}
				 }
				else if ( gui_keycode == KEY_ASTERISK )
				{
				}
			}
			else if ( gui_keycode != KEY_NONE )		//from KEY0~KEY9
			{
				if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyPasscodeInput )
				{
					//DEF_ButtonPress_Voice;
					PasscodeUserIdentifyMgr.TimeCnt = 240;	//
					GUI_PasscodeInputButtonMonitor(gui_keycode);
				}
			}
			
			break;

		case SCREEN_NetWorkLink:

			if (gui_keycode == KEY_ASTERISK)
			{
				DEF_ButtonPress_Voice;
				if ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyNetWorkLinkSuccess )
				{
					GoIntoMainScreen_WithIdentifyInit();
				}else{
					ComPort_SetPost_ExitWifiHotSpot();
					GoIntoMainMenu_Init();
				}
			}

			break;

		case SCREEN_RemoteUnlockRequest:
			
			if ( WifiMgr.RemoteUnlockMgr.Status == RemoteUnlockRequestWait )
			{
				if (gui_keycode == KEY_ASTERISK)
				{
					DEF_ButtonPress_Voice;
					WifiMgr.RemoteUnlockMgr.Status = RemoteUnlockExit;
					#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi) 
						Wifi_PositiveExitRemoteUnlock();
					#endif
				}
				else if ( gui_keycode == KEY_DOORBELL )
				{
					if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
					{
						PLAY_VOICE_DOORBELL();	//DOORBELL	
						#ifndef Function_MainBoardWithoutVoicePlayer
						ComPort_SetPost_Info(DEF_WifiInfo_DoorBell,0x00,0x00);
						#endif
					}
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					#ifndef Function_IndependentDoorBellKey
					if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
					{
						PLAY_VOICE_DOORBELL();	//DOORBELL
						#ifndef Function_MainBoardWithoutVoicePlayer
						ComPort_SetPost_Info(DEF_WifiInfo_DoorBell,0x00,0x00);
						#endif
					}
					#endif	
				}
			}
			break;
			
		#if defined ProjectIs_BarLock_S101Z01	
		case SCREEN_AgingTest:
			if (gui_keycode == KEY_ASTERISK)
			{
				AgingTestMgr.MotorRunTimes = 100000;
				DEF_ButtonPress_Voice;
				GoIntoMainScreen_WithIdentifyInit();
			}
			break;
		#endif	
		
		case SCREEN_SelfTest:

			if ( SelfTestMgr.Status == VoiceAndTouchAndLEDs_TEST )
			{
				if ( gui_keycode == KEY_ZERO )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_ZERO_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_ONE )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_ONE_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_TWO )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_TWO_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_THREE )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_THREE_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_FOUR )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_FOUR_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_FIVE )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_FIVE_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_SIX )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_SIX_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_SEVEN )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_SEVEN_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_EIGHT )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_EIGHT_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_NINE )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_NINE_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_ASTERISK_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_POUNDSIGN )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_POUNDSIGN_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_DOORCLOSE )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_DOORCLOSE_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
				else if ( gui_keycode == KEY_DOORBELL )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.TouchKeySelfTestStatus.KEY_DOORBELL_OK = bTRUE;
					SET_KEYLED_OFF(gui_keycode);
				}
			}
			/*
			else if ( SelfTestMgr.Status == Display_TEST )
			{
				if ( gui_keycode == KEY_POUNDSIGN )
				{
					DEF_ButtonPress_Voice;
					Clear_Screen();
				}
				else if ( gui_keycode == KEY_ASTERISK )
				{
					PLAY_VOICE_ONESEGMENT(3,VOICE_PleasePutFinger);
					SelfTestMgr.Status = FPM_TEST;
				}
			}
			*/
			else if ( SelfTestMgr.Status == VOLTAGE_TEST )
			{
				if ( gui_keycode == KEY_POUNDSIGN )
				{
					DEF_ButtonPress_Voice;
					SelfTestMgr.Status = LOWPOWER_TEST;
				}
			}

			break;
				
		default:

			break;		
	}

}

/*******************************************************/
/*******************************************************/
void GUI_Update_Screen(void)
{
	if (( CurrentScreen !=LastScreen )||(GUI_Flag_RefreshLCD == bTRUE))
	{
		Clear_Screen();
		LastScreen =  CurrentScreen;
		GUI_Flag_RefreshLCD = bFALSE;
	}

	switch ( CurrentScreen)
	{
		case SCREEN_Initialization:

			SET_ALLKEYLED_OFF();
			#ifdef Function_FaceRecoginitionSwitchedAutoDetection
			ShowFrmConnectionCheck();
			#endif
			ShowInitialization();
	
		break;
		
		case SCREEN_LowBattery:

			SET_ALLKEYLED_OFF();
			ShowLowBattery();
			
		break;

		case SCREEN_PickLockAlarm:

			SET_ALLKEYLED_ON();
			ShowPickLockAlarm();
			
		break;

		case SCREEN_Main:
				
			GUI_UpadteMain();
//			DisplayMainPage();

		break;

		case SCREEN_IdentifySuccess:

			if ( BatteryMgr.BatteryType == LiBattery )
			{
				KEYLED_WATERLIGHT_Task();
			}
			else
			{
				SET_ALLKEYLED_OFF();
			}
			ShowIdentifySuccessPage();
		
			break;
			
		case SCREEN_IdentifyFail:
				
			SET_ALLKEYLED_OFF();
			
			ShowIdentifyFailPage();
		
			break;

		case SCREEN_MainMenu:

			SET_1234andAPled_ON();
			
			ShowMainMenu();

			break;

		case SCREEN_UserManagementMenu:

			if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
				{
					SET_1234andAPled_ON();
				}
			else{
					SET_123andAPled_ON();
				}
			
			ShowUserManagementMenu();

			break;

		case SCREEN_FaceMenu:
			
			SET_123andAPled_ON();
			ShowFaceMenu();
			break;
			
		case SCREEN_FpMenu:
			
			SET_1234andAPled_ON();
			ShowFpMenu();
			break;

		case SCREEN_FpDeleteMenu:
			
			SET_123andAPled_ON();
			ShowFpDeleteMenu();
			break;

		case SCREEN_CardUserMenu:

			SET_123andAPled_ON();
			ShowCardMenu();
			break;

		case SCREEN_PasscodeMenu:
			
			SET_1234andAPled_ON();
			ShowPasscodeMenu();
			break;
			
		case SCREEN_SystemConfigMenu:

			SET_1234andAPled_ON();
			ShowSystemConfigMenu();
			break;

		case SCREEN_VoiceSettingMenu:

			SET_12andAPled_ON();
			ShowVoiceSettingMenu();
			break;

		case SCREEN_InfoInquiryMenu:

			SET_1234andAPled_ON();
			ShowInfoInquiryMenu();
			break;

		case SCREEN_NetWorkLink:
			ShowNetWorkConnecting();
			break;

		case SCREEN_RegisterMasterFace:
			if ( FaceUserRegisterMgr.Status == ReportFaceUserID )
			{
				SET_APled_ON();
			}
			else
			{
				SET_AsteriskLED_ON();
			}
			ShowRegisterUserFace();
			break;

		//case SCREEN_DeleteMasterFace:
		//	SET_ALLKEYLED_ON();
		//	ShowDeleteUserFace();
		//	break;
			
		case SCREEN_RegisterUserFace:
			if ( FaceUserRegisterMgr.Status == ReportFaceUserID )
			{
				SET_APled_ON();
			}
			else
			{
				SET_AsteriskLED_ON();
			}
			ShowRegisterUserFace();

			break;

		case SCREEN_DeleteUserFace:
			SET_ALLKEYLED_ON();
			ShowDeleteUserFace();

			break;

	//	case SCREEN_DeleteAllUserFace:
	//		SET_UDandConfirmLED_ON();
	//		ShowDeleteAllUserFace();
	//		break;

		case SCREEN_RegisterUserFp:
			if ( FpUserRegisterMgr.Status == ReportFpUserID )
			{
				SET_APled_ON();
			}
			else
			{
				SET_AsteriskLED_ON();
			}
			ShowRegisterUserFp();

			break;
			
		case SCREEN_DeleteUserFp:
			SET_ALLKEYLED_ON();
			ShowDeleteUserFp();

			break;

		case SCREEN_DeleteAllUserFp:
			SET_APled_ON();
			ShowDeleteAllUserFp();

			break;

		case SCREEN_RegisterStressUserFp:
			if ( FpUserRegisterMgr.Status == ReportFpUserID )
			{
				SET_APled_ON();
			}
			else
			{
				SET_AsteriskLED_ON();
			}
			ShowRegisterUserFp();

			break;
			
		case SCREEN_DeleteStressUserFp:
			SET_ALLKEYLED_ON();
			ShowDeleteUserFp();

			break;

		case SCREEN_DeleteAllStressUserFp:
			SET_APled_ON();
			ShowDeleteAllUserFp();

			break;
		
		case SCREEN_RegisterMasterFp:
			if ( FpUserRegisterMgr.Status == ReportFpUserID )
			{
				SET_APled_ON();
			}
			else
			{
				SET_AsteriskLED_ON();
			}
			ShowRegisterUserFp();
			break;

		case SCREEN_RegisterCardUser:

			if ( CardUserRegisterMgr.Status == ReportCardUserID )
			{
				SET_APled_ON();
			}
			else
			{
				SET_AsteriskLED_ON();
			}
			ShowRegisterCardUser();

			break;
			
		case SCREEN_DeleteCardUser:
			SET_ALLKEYLED_ON();
			ShowDeleteCardUser();

			break;

		case SCREEN_DeleteAllCardUser:
			SET_APled_ON();
			ShowDeleteAllCardUser();

			break;

		case SCREEN_RegisterPasscodeUser:
			if ( PasscodeUserRegisterMgr.Status == ReportPasscodeUserID )
			{
				SET_APled_ON();
			}
			else if (( PasscodeUserRegisterMgr.Status == InputFirstPasscode )
				||(PasscodeUserRegisterMgr.Status == InputSecondPasscode))
			{
				SET_ALLKEYLED_ON();
			}
			else
			{
				SET_ALLKEYLED_OFF();
			}
			ShowRegisterPasscodeUser();

			break;
			
		case SCREEN_DeletePasscodeUser:
			SET_ALLKEYLED_ON();
			ShowDeletePasscodeUser();

			break;

		case SCREEN_DeleteAllPasscodeUser:
			SET_APled_ON();
			ShowDeleteAllPasscodeUser();

			break;


		case SCREEN_TimeSetting:
			SET_ALLKEYLED_ON();
			ShowTimeSetting();

			break;		
		case SCREEN_RestoreFactoryDefault:
			if ( RestoreFactoryDefaultMgr.Status == WaitForRestoreFactoryDefaultUserConfirm )
			{
				SET_APled_ON();
			}
			else
			{
				SET_ALLKEYLED_OFF();
			}
			
			ShowRestoreFactoryDefault();

			break;

		case SCREEN_LanguageSetting:
			SET_12andAPled_ON();
			ShowLanguageSetting();
		
			break;
			
		case SCREEN_VolumeSetting:
			SET_1234andAPled_ON();
			ShowVolumeSetting();

			break;

		case SCREEN_MemoryUsage:
			SET_APled_ON();
			ShowMemoryUsage();
		
			break;
			
		case SCREEN_ManagerIdentify:

			SET_ALLKEYLED_ON();
			ShowManagerIdentify();
			break;

		case SCREEN_DoorLockSettingMenu:
			if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
				{
			SET_123andAPled_ON();
				}
			else{
			SET_12andAPled_ON();
				}
			ShowDoorLockSettingMenu();
			break;

		case SCREEN_UnlockingModeSetting:
			SET_12andAPled_ON();
			ShowUnlockingModeSetting();
		
			break;			
		case SCREEN_PickAlarmEnableSetting:	
			SET_12andAPled_ON();
			ShowPickAlarmEnableSetting();
			break;
			
		case SCREEN_BodyInductionSetting:	
			SET_123andAPled_ON();
			ShowBodyInductionSetting();
			break;
			
		case SCREEN_SystemVersion:	
			SET_APled_ON();
			ShowSystemVersion();
			break;

		case SCREEN_SelfTest:	
			ShowSelfTest();		
			break;
	
		case SCREEN_AgingTest:

			KEYLED_WATERLIGHT_Task();
			ShowAgingTest();
			break;

		case SCREEN_SystemLocked:

			SET_ALLKEYLED_OFF();
			ShowSystemLocked();
			break;

		case SCREEN_EventLogMenu:
			
			SET_12andAPled_ON();
			ShowEventLogMenu();
			break;
			
		case SCREEN_CheckEventLogBySequence:

			SET_UDandAPled_ON();
			ShowEventLogBySequence();
			break;
			
		case SCREEN_CheckEventLogByDate:	
			SET_UDandAPled_ON();
			//ShowEventLogByDate();
			break;

		case SCREEN_DeleteEventLog:
			SET_APled_ON();
			ShowClearEventLog();
			
			break;	
			
		case SCREEN_RemoteUnlockRequest:
			if ( WifiMgr.RemoteUnlockMgr.Status == RemoteUnlockRequestWait ){
				KEYLED_ASTERISK_Flash();
			}
			else{
				SET_ALLKEYLED_OFF();
			}
			ShowRemoteUnlockRequest();
			
			break;	
		case SCREEN_AutoMotorSettingMenu:
			SET_1234andAPled_ON();
			ShowAutoMotorSettingMenu();
			break;
			
		case SCREEN_EngineeringModeMneu:
			if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
			{
				SET_1234567andAPled_ON();
			}
			else{
				SET_123456andAPled_ON();
			}
			ShowEngineeringModeMenu();
			break;
	
		case  SCREEN_AutoMotorUnlockTime:
			SET_UDandAPled_ON();
			 ShowAutoMotorUnlockTimeSetting();
			break;
		case  SCREEN_AutoMotorAutoLockTime:
			SET_UDandAPled_ON();
			ShowAutoMotorAutoLockTimeSetting();
			break;
		case  SCREEN_AutoMotorLockDirection:
			SET_12andAPled_ON();
			ShowAutoMotorLockDirectionSetting();
			break;
		case  SCREEN_AutoMotorTorque:
			SET_123andAPled_ON();
			ShowAutoMotorTorqueSetting();
			break;
		case  SCREEN_AutoMotorBoltLockTime:
			SET_UDandAPled_ON();
			ShowBoltLockTimeSetting();
			break;
			
		case  SCREEN_LockingTravel:
			SET_UDandAPled_ON();
			ShowLockingTravelSetting();
			break;
			
		case  SCREEN_AutoEject:
			SET_12andAPled_ON();
			ShowAutoEjectSetting();
			break;
			
		case  SCREEN_AutoMotorSelfTest:
			KEYLED_ASTERISK_Flash();
			ShowAutoMotorSelfTest();
			break;	
		case  SCREEN_WifiMFT:
			KEYLED_ASTERISK_Flash();
			ShowWifiManufactureTest();
			break;
		case  SCREEN_ErrorMessage:
			ShowErrorMessage();
			break;
	
		default:
			break;
	}
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
/*******************************************************/
/*******************************************************/
/*******************************************************/
void Wifi_PowerOnForOnlinePasswordVerifyMgr(void)
{
	if (   (CurrentScreen == SCREEN_Main )
		&& ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyPasscodeInput )		//passcode user identify
		 &&( PasscodeInputMgr.Point > 3 )
		 &&( PasscodeInputMgr.InputBuff[0] == 1)
		 &&( IfSystemIsInFactoryDefaultStatus()!=bTRUE )
		)
	{
		if ( WifiMgr.WifiOnlinePasswordVerifyMgr.WifiPowerIsOnForOnlinePassword != bTRUE )
		{
			ComPort_SetPost_PositivePowerOnWifi();
		}
	}
}

#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
void LocalWifi_PowerOnForOnlinePasswordVerifyMgr(void)
{
	if (   (CurrentScreen == SCREEN_Main )
		&& ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyPasscodeInput )		//passcode user identify
		 //&&( PasscodeInputMgr.Status == PasscodeInputStart )
		 &&( PasscodeInputMgr.Point > 3 )
		 &&( PasscodeInputMgr.Point < 8 )		//online password lenth is	7
		 &&( PasscodeInputMgr.InputBuff[0] == 1)
		 &&( IfSystemIsInFactoryDefaultStatus()!=bTRUE )
		)
	{
		if ( WifiMgr.Power.PowerOnForOnlinePassword != bTRUE )
		{
			WifiMgr.Power.PowerOnForOnlinePassword = bTRUE;
		}
	}
	else
	{
		if (  ( PasscodeUserIdentifyMgr.Status == PasscodeIdentifyPasscodeInput )		//passcode user identify
			//&&( PasscodeInputMgr.Status == PasscodeInputEnd )
		  	&&( PasscodeInputMgr.Point == 7 ) 
		   	&&( PasscodeInputMgr.InputBuff[0] == 1)
		   )
		{
			//Do nothing
		}
	   else
		{
		
			#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
			Wifi_PowerOffIfPowerOnForOnlinePasswordVerify();
			#endif
		}
	}
}
#endif

/*******************************************************/
/*******************************************************/
/*******************************************************/
void GUI_Init(void)
{
	
	Clear_Screen();

	GUI_ToggleFlag_05s=0x00;
	GUI_ToggleFlag_1s=0x01;

	GUI_Flag_RefreshLCD = bFALSE;

	FpIdentifyMgr.Status = FPMcmdStart;
	CardIdentifyMgr.Status = ReadingCardID;
	
	BatteryMgr.PostLowBattery = bTRUE;

	//VoiceMgr.Enable = bTRUE;		//default Enable Voice
	
	Key_Init();

	ReadCardUserMemoryFromEEPROM();

	ReadPasscodeUserMemoryFromEEPROM();
	
	#ifdef Function_FaceRecoginition				
	//if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		ReadFaceUserMemoryFromEEPROM();
	}
	#endif		
	
  	ReadAutoMotorMgrConfig();

//	ReadManagerPasscodeFromMemory();

//	SafetyMonitorMgr.IdentifyFailedTimes = 0x00;
//	SafetyMonitorMgr.SystemLocked = bFALSE;
	UserIdentifyResultMgr.CardIdentifyStatus = S_FAIL;
	UserIdentifyResultMgr.FPIdentifyStatus = S_FAIL;
	UserIdentifyResultMgr.PasscodeIdentifyStatus = S_FAIL;
	
	FaceIdentifyMgr.IndentifyDelayTimeCnt = 0;

	g_ASTERISK_PressedOnMainScreen = bFALSE;

	DriverBoardVersion.HWversion = 0x00;
	DriverBoardVersion.FWversion = 0x00;

	FpmLEDsMgr.OperationMode = DEF_FpmLedMode_Off;
	FpmLEDsMgr.StartColor = DEF_FpmLedColor_All;
	FpmLEDsMgr.StopColor = DEF_FpmLedColor_All;
	FpmLEDsMgr.Cycles = 0;
       
  DEBUG_MARK;
		
	#ifdef Function_USE_Internal_RTC
	SystemTime = UTCToSystemtime(G_SystemUTCTime);
	#else
	PCF8563_ReadTime();
	#endif
	
	#ifdef Function_DisplayUsed_OLED128X64
	OLED_Init();
	#elif defined Function_DisplayUsed_HFG12864
	Display_Init();
	#endif
	LockBrand.BrandChangeTimeDelay = 0;
	
}

/*******************************************************/
/*******************************************************/
/*******************************************************/


/*******************************************************/
/*******************************************************/
/*******************************************************/
void GUI_Task(void)
{
	//uint8_t *Point;
        uint8_t i;
	if (++GUI_TimeCnt > 63)
	{
		GUI_ToggleFlag_1s^=0x01;
		GUI_TimeCnt =0;
	}
	
	if ( GUI_TimeCnt %32 == 0x00 ){	
		GUI_ToggleFlag_05s^= 0x01;
	}
	
	if ( CardIdentifyMgr.CardDetectIntervalTimeCnt >  0 )
	{
		CardIdentifyMgr.CardDetectIntervalTimeCnt --;
	}
	
	if ( FrmMgr.FrmFunctionSwitchTimeDelay >  0 )
	{
		FrmMgr.FrmFunctionSwitchTimeDelay --;
	}
	if ( LockBrand.BrandChangeTimeDelay > 0 )
	{
		 LockBrand.BrandChangeTimeDelay--;
	}

	if (  (AntiPryingMgr.AntiPryingTrigger == bTRUE)
		&&(CurrentScreen != SCREEN_PickLockAlarm)
		&&( CurrentScreen != SCREEN_Initialization )
		&&( CurrentScreen != SCREEN_PickAlarmEnableSetting )
		&&( CurrentScreen != SCREEN_RestoreFactoryDefault )		//add on 2022.08.24
		&&( PickAlarmEnableMgr.Enable == bTRUE)
	   )
	{
		AntiPryingMgr.AntiPryingTrigger = bFALSE;
		AntiPryingMgr.FilterTimes = 0x00;
		for (i=0;i<50;i++)
		{
			if ( 
			#if (defined ProjectIs_BarLock_S15Z08)
			( PINMACRO_PICKLOCK_STATUS == 1 )
			#else
			( PINMACRO_PICKLOCK_STATUS == 0 )
			#endif
			)
			{
				AntiPryingMgr.FilterTimes++;
			}
			Hardware_DelayMs(1);
		}
		if ( AntiPryingMgr.FilterTimes > 45 )
		{
//			if ( TouchPowerMgr.Status != HighSensitivity )
//			{
//				//SET_TOUCH_AWAKE_SENSITIVITY();
//			}/** in case of AntiPrying trigger when MotorSlider is moving down, turn on CSK14**/

			if ( CurrentScreen == SCREEN_NetWorkLink )
			{
				ComPort_SetPost_ExitWifiHotSpot();
			}
			else if ( CurrentScreen == SCREEN_RemoteUnlockRequest )
			{
				ComPort_SetPost_ExitRemoteUnlcok();
			}

			UserIdentifyResultMgr.CardIdentifyStatus = S_FAIL;
			UserIdentifyResultMgr.FPIdentifyStatus = S_FAIL;
			UserIdentifyResultMgr.PasscodeIdentifyStatus = S_FAIL;
			UserIdentifyResultMgr.FaceIdentifyStatus = S_FAIL;
	
			CurrentScreen = SCREEN_PickLockAlarm;
			AntiPryingMgr.TimeCnt = DEF_AntiPryingTime;
			PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
			FpIdentifyMgr.Status = FPMcmdStart;
			CardIdentifyMgr.Status = ReadingCardID;		
			
			ComPort_SetPost_Alarm(DEF_WifiAlarm_PickLock,UNDEFINEDUSER,0x00);
			
			#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
			Wifi_PostEvent(DEF_WifiEvent_AntiPryingAlarm,0x00,0x00);
			#endif
			
			GUI_SetFPM_LED(DEF_FpmLedMode_Off,DEF_FpmLedColor_All,DEF_FpmLedColor_All,255);

			SET_LED_RGB_OFF();
			SET_LED_RB_OFF();
		}
	}

	//if ( GUI_TimeCnt%4==0 )
	//{
		GUI_Button_Monitor();
	//}

	GUI_Update_Screen();
	
	#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
	LocalWifi_PowerOnForOnlinePasswordVerifyMgr();
	#else
	Wifi_PowerOnForOnlinePasswordVerifyMgr();	
	#endif
}
