#include "gpio.h"
//Protocol layer
#include "HostUart.h"
#include "MFC_MF17622.h"
#include "PIR.h"
#include "EEPROM.h"
#include "BeepMgr.h"
#include "FingerPrint.h"
#include "FaceRecoginitionMgr.h"
#include "YouzhiyunjiaWifi.h"
//Logic layer
#include "AppUnlock.h"
#include "FP.h"
#include "LCD.h"
#include "MFC.h"
#include "FaceGUI.h"
//Application layer
#include "GUI_Function.h"
#include "global_variable.h"
#include "Font.h"
#include "Voice_Menu.h"
#include "Font_Menu.h"

extern screen_t CurrentScreen;
extern uint8_t LEDsCtrlSwitch;
extern uint8_t GUI_ToggleFlag_05s;
extern keycode_t gui_keycode;
extern bool_t GUI_Flag_RefreshLCD;


void GoToMainMenu(void)//�������˵�
{
	VoiceMenuMgr.MenuPoint=0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_MainMenu;
}

void GoToFpMenu(void)//����ָ�Ʋ˵�
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_FpMenu;
}
void GoToPasswordMenu(void)//��������˵�
{
	VoiceMenuMgr.MenuPoint=0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_PasscodeMenu;
}
void GoToCardMenu(void)//���뿨Ƭ�˵�
{
	VoiceMenuMgr.MenuPoint=0;
	VoiceMenuMgr.TotalMenuNum = 5;
	CurrentScreen = SCREEN_CardUserMenu;
}
void GoIntoFaceMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 5;
	CurrentScreen = SCREEN_FaceMenu;
	//DEF_MenuSwitchDelayTime;
	FaceRecognition_HardwarePowerOn();
}

void GoIntoVoiceSettingMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 4;
	CurrentScreen = SCREEN_VoiceSettingMenu;
	//DEF_MenuSwitchDelayTime;
}
void GoIntoDoorLockSettingMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	CurrentScreen = SCREEN_DoorLockSettingMenu;

	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		VoiceMenuMgr.TotalMenuNum = 5;
	}
	else
	{
		VoiceMenuMgr.TotalMenuNum = 4;
	}
	//DEF_MenuSwitchDelayTime;
	
}

void GoIntoLanguageSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 4;
	CurrentScreen = SCREEN_LanguageSetting;
}

void GoIntoVolumeSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_VolumeSetting;
}

void GotoAutoEjectSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 4;
	CurrentScreen = SCREEN_AutoEject;
}





void GoToSystemConfigMenu(void)//����ϵͳ���ò˵�
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_SystemConfigMenu;
}

void GotoLogMenu(void)//������־�˵�
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 4;
	CurrentScreen = SCREEN_EventLogMenu;
}

//void GoIntoDoorLockSettingMenu_Init(void)
//{
//	VoiceMenuMgr.MenuPoint = 0;
//	CurrentScreen = SCREEN_DoorLockSettingMenu;

//	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
//	{
//		VoiceMenuMgr.TotalMenuNum = 5;
//	}
//	else
//	{
//		VoiceMenuMgr.TotalMenuNum = 4;
//	}
//}

void GoIntoUnlockingModeSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 4;
	CurrentScreen = SCREEN_UnlockingModeSetting;
}

void GoIntoPickAlarmEnableSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 4;
	CurrentScreen = SCREEN_PickAlarmEnableSetting;
}




void GoIntoBodyInductionSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 5;
	CurrentScreen = SCREEN_BodyInductionSetting;
}



void GoIntoMainMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_MainMenu;
	//DEF_MenuSwitchDelayTime;
}

void GoIntoUserManagementMenu_Init(void)
{
	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		VoiceMenuMgr.TotalMenuNum = 6;
	}
	else
	{
		VoiceMenuMgr.TotalMenuNum = 5;
	}
	VoiceMenuMgr.MenuPoint = 0;
	CurrentScreen = SCREEN_UserManagementMenu;
	//DEF_MenuSwitchDelayTime;
	FaceRecognition_HardwarePowerOff();
}

void GoIntoMemoryUsageScreen()
{
	uint8_t TempValue;
	CurrentScreen = SCREEN_MemoryUsage;

	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
		{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 6;	
		}
	else{
	VoiceMenuMgr.MenuPoint = 1;
	VoiceMenuMgr.TotalMenuNum = 6;	
		}
	
	MemoryUsageVoiceBuff[0][2]=TranslateNumberToVoice((CheckMemoryMgr.FaceMasterNum+CheckMemoryMgr.FaceUserNum)/100);
	MemoryUsageVoiceBuff[0][3]=TranslateNumberToVoice((CheckMemoryMgr.FaceMasterNum+CheckMemoryMgr.FaceUserNum)%100/10);
	MemoryUsageVoiceBuff[0][4]=TranslateNumberToVoice((CheckMemoryMgr.FaceMasterNum+CheckMemoryMgr.FaceUserNum)%10);
	TempValue = DEF_MAX_FACEMASTER+DEF_MAX_FACEUSER;
	MemoryUsageVoiceBuff[0][6]=TranslateNumberToVoice((TempValue)/100);
	MemoryUsageVoiceBuff[0][7]=TranslateNumberToVoice((TempValue)%100/10);
	MemoryUsageVoiceBuff[0][8]=TranslateNumberToVoice((TempValue)%10);

	MemoryUsageVoiceBuff[1][2]=TranslateNumberToVoice((CheckMemoryMgr.FpMasterNum+CheckMemoryMgr.FpUserNum+CheckMemoryMgr.StressFpUserNum)/100);
	MemoryUsageVoiceBuff[1][3]=TranslateNumberToVoice((CheckMemoryMgr.FpMasterNum+CheckMemoryMgr.FpUserNum+CheckMemoryMgr.StressFpUserNum)%100/10);
	MemoryUsageVoiceBuff[1][4]=TranslateNumberToVoice((CheckMemoryMgr.FpMasterNum+CheckMemoryMgr.FpUserNum+CheckMemoryMgr.StressFpUserNum)%10);
	TempValue = DEF_MAX_FPMASTER+DEF_MAX_FPUSER+DEF_MAX_STRESSFPUSER;
	MemoryUsageVoiceBuff[1][6]=TranslateNumberToVoice((TempValue)/100);
	MemoryUsageVoiceBuff[1][7]=TranslateNumberToVoice((TempValue)%100/10);
	MemoryUsageVoiceBuff[1][8]=TranslateNumberToVoice((TempValue)%10);


	MemoryUsageVoiceBuff[2][2]=TranslateNumberToVoice((CheckMemoryMgr.PasscodeMasterNum+CheckMemoryMgr.PasscodeUserNum)/10);
	MemoryUsageVoiceBuff[2][3]=TranslateNumberToVoice((CheckMemoryMgr.PasscodeMasterNum+CheckMemoryMgr.PasscodeUserNum)%10);
	TempValue = DEF_MAX_PASSCODEMASTER+DEF_MAX_PASSCODEUSER;
	MemoryUsageVoiceBuff[2][5]=TranslateNumberToVoice((TempValue)/10);
	MemoryUsageVoiceBuff[2][6]=TranslateNumberToVoice((TempValue)%10);


	
	MemoryUsageVoiceBuff[3][2]=TranslateNumberToVoice(CheckMemoryMgr.CardUserNum/100);
	MemoryUsageVoiceBuff[3][3]=TranslateNumberToVoice(CheckMemoryMgr.CardUserNum%100/10);
	MemoryUsageVoiceBuff[3][4]=TranslateNumberToVoice(CheckMemoryMgr.CardUserNum%10);
	TempValue = DEF_MAX_CARDUSER;
	MemoryUsageVoiceBuff[3][6]=TranslateNumberToVoice(TempValue/100);
	MemoryUsageVoiceBuff[3][7]=TranslateNumberToVoice(TempValue%100/10);
	MemoryUsageVoiceBuff[3][8]=TranslateNumberToVoice(TempValue%10);
	
	
}

/*******************************************************/
/*******************************************************/
/*******************************************************/

void GotoMotorUnlockTimeSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 3;
	CurrentScreen = SCREEN_AutoMotorUnlockTime;	
}

void GotoMotorAutoLockTimeSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 3;
	CurrentScreen = SCREEN_AutoMotorAutoLockTime;	
}

void GotoMotorSelfTest_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 1;
	CurrentScreen = SCREEN_AutoMotorSelfTest;
}

void GotoMotorTorqueSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 5;
	CurrentScreen = SCREEN_AutoMotorTorque;	
}


void GoIntoMotorSettingMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_AutoMotorSettingMenu;
	//DEF_MenuSwitchDelayTime;
}

void GoIntoFpDeleteMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 5;
	CurrentScreen = SCREEN_FpDeleteMenu;
	//DEF_MenuSwitchDelayTime;
}

void GotoBoltLockTimeSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 3;
	CurrentScreen = SCREEN_AutoMotorBoltLockTime;
}

void GotoLockingTravelSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 3;
	CurrentScreen = SCREEN_LockingTravel;
}




bool_t IfSystemIsInFactoryDefaultStatus(void)
{
	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{
		if ( ( CheckMemoryMgr.FpUserNum == 0x00 )
				&&(CheckMemoryMgr.FpMasterNum == 0x00 )
				&&(CheckMemoryMgr.CardUserNum == 0x00 )
				&&(CheckMemoryMgr.PasscodeMasterNum == 0x00 )
				&&(CheckMemoryMgr.PasscodeUserNum == 0x00 )
				&&(CheckMemoryMgr.FaceMasterNum == 0x00 )
				&&(CheckMemoryMgr.FaceUserNum == 0x00 )
				)
		{
			return bTRUE;
		}
		else
		{
			return bFALSE;
		}
	}
	else
	{
		if ( ( CheckMemoryMgr.FpUserNum == 0x00 )
			&&(CheckMemoryMgr.FpMasterNum == 0x00 )
			&&(CheckMemoryMgr.CardUserNum == 0x00 )
			&&(CheckMemoryMgr.PasscodeMasterNum == 0x00 )
			&&(CheckMemoryMgr.PasscodeUserNum == 0x00 )
			)
		{
			return bTRUE;
		}
		else
		{
			return bFALSE;
		}
	}
}

bool_t IfSystemWithoutSecondIdentity(void)
{
	if  ( (((CheckMemoryMgr.FpUserNum+CheckMemoryMgr.FpMasterNum+CheckMemoryMgr.StressFpUserNum) == 0x00 )&&((CheckMemoryMgr.PasscodeMasterNum + CheckMemoryMgr.PasscodeUserNum)== 0x00))
		||(((CheckMemoryMgr.FpUserNum+CheckMemoryMgr.FpMasterNum+CheckMemoryMgr.StressFpUserNum) == 0x00 )&&(CheckMemoryMgr.CardUserNum == 0x00 ))
		||(((CheckMemoryMgr.PasscodeMasterNum + CheckMemoryMgr.PasscodeUserNum)== 0x00)&&(CheckMemoryMgr.CardUserNum == 0x00 ))
		)
	{
		return bTRUE;
	}
	else
	{
		return bFALSE;
	}
}

bool_t IfSystemIsNoCardUser(void)
{
	if ( CheckHowManyRegisteredCardUser() == 0 )
	{
		return bTRUE;
	}
	else
	{
		return bFALSE;
	}
}

bool_t CompareTwoArrayIsSame(uint8_t Point1[],uint8_t Point2[],uint8_t Lenth)
{
	uint8_t i;
	for (i=0;i<Lenth;i++)
	{
		if (Point1[i]!=Point2[i]){
			return bFALSE;
		}
	}
	return bTRUE;
}

void UnlockModeJudgment(void)//����ģʽ��Ч���ж�
{
	if	( IfSystemWithoutSecondIdentity() == bTRUE )
	{
		UserIdentifyResultMgr.UnlockingMode = SingalMode;
		EEPROM_WriteSequential(UnlockModeStartAddr,&UserIdentifyResultMgr.UnlockingMode,1);
	}
}

bool_t is_valid_date(uint8_t year, uint8_t month, uint8_t date)
{
       	uint8_t monttbuffer[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
		uint16_t y;
		uint8_t m,d;
		y=((year/16)*10)+(year%16)+2000;
		m = ((month/16)*10)+(month%16);
		d = ((date/16)*10) + (date%16);
        if (((y % 4 == 0) && (y % 100 != 0)) 
			|| (y % 400 == 0)
			)
        {
                monttbuffer[1] = 29; 
		}
        if ( (m > 0) 
			&& (m < 13)
			&& (d > 0) 
			&& (d <= monttbuffer[m - 1])
			)
        {
			return bTRUE;
		}
		else{
			return bFALSE;
		}
}

void Config_AntiPrying_Interrupt(void)//���÷���
{
	if (PickAlarmEnableMgr.Enable == bTRUE)
	{
		EnableAntiPrying_Interrupt();
	}
	else{
		DisableAntiPrying_Interrupt();
	}
}

void FrmFunctionConfigSave(void)
{
	EEPROM_WriteSequential(FrmFunctionConfigAddr,&FrmMgr.FrmFunctionConfig,1);
}


void GUI_RefreshSleepTime(void)
{
	if (( CurrentScreen == SCREEN_Main )||( CurrentScreen == SCREEN_LowBattery ))
	{
		SystemPowerMgr.SleepDelayTimerCnt = Def_GuiTimeDelayCnt10s;
	}
	else if(CurrentScreen == SCREEN_CheckEventLogBySequence)
	{
		SystemPowerMgr.SleepDelayTimerCnt = Def_GuiTimeDelayCnt50s;
	}
	else
	{
		SystemPowerMgr.SleepDelayTimerCnt = Def_GuiTimeDelayCnt35s;
	}
}


void SystemConfigSave(void)//ϵͳ���ñ���
{
	uint8_t SavedVolume;
	SavedVolume = VoiceMgr.volume + 1;
	EEPROM_WriteSequential(BodyInductionStartAddr,&BodyInductionMgr.SensingDistanceLevel,1);
	EEPROM_WriteSequential(SystemLanguageStartAddr,&SystemLanguage,1);
	EEPROM_WriteSequential(UnlockModeStartAddr,&UserIdentifyResultMgr.UnlockingMode,1);
	EEPROM_WriteSequential(VolumeValueStartAddr,&SavedVolume,1);
	EEPROM_WriteSequential(PickAlarmSwitchStartAddr,&PickAlarmEnableMgr.Enable,1);
	
}

void FrmFunctionConfigLoad(void)
{
	uint8_t temp;
	
	EEPROM_ReadSequential(FrmFunctionConfigAddr,&temp,1);

	#ifdef Function_FaceRecoginition
		#ifdef Function_FaceRecoginitionSwitchedByNFC
		if (temp == FRM_Disabled )
		{
			FrmMgr.FrmFunctionConfig = FRM_Disabled;
		}
		else
		{
		  	FrmMgr.FrmFunctionConfig = FRM_Enabled;
		}
		#endif
	#else
	
		FrmMgr.FrmFunctionConfig = FRM_Disabled;
	
	#endif
}

void BodyInductionConfigLoad(void)
{
	uint8_t temp;
	EEPROM_ReadSequential(BodyInductionStartAddr,&temp,1);
	if (temp < 3 )
	{
		BodyInductionMgr.SensingDistanceLevel = temp;
	}
	else
	{
	  	BodyInductionMgr.SensingDistanceLevel = SensingDistanceL1;
	}
}


void SystemConfigLoad(void)
{
	uint8_t temp;

	FrmFunctionConfigLoad();
  BodyInductionConfigLoad();
	
	EEPROM_ReadSequential(SystemLanguageStartAddr,&temp,1);
	if (temp == English)
	{
        SystemLanguage = English;
	}
    else
    {
      SystemLanguage = Chinese;
    }
	
	EEPROM_ReadSequential(UnlockModeStartAddr,&temp,1);
	if (temp == DoubleMode)
	{
            UserIdentifyResultMgr.UnlockingMode = DoubleMode;
	}
    else
    {
      UserIdentifyResultMgr.UnlockingMode = SingalMode;
    }
	
	EEPROM_ReadSequential(VolumeValueStartAddr,&temp,1);
	if (( temp > 0 )&&( temp < 5 ))		//from 1~4
	{
    	VoiceMgr.volume = temp - 1;
	}
	else
	{
	#ifdef ProjectIs_AutoBarLock_S70Z01
			VoiceMgr.volume = 1;
	#else
			VoiceMgr.volume = 3;
	#endif
	}

	if ( VoiceMgr.volume > 0 ){
		VoiceMgr.Enable = bTRUE;
	}
	else{
		VoiceMgr.Enable = bFALSE;
	}
		
	EEPROM_ReadSequential(PickAlarmSwitchStartAddr,&temp,1);
	
	#ifdef Function_AntiPryingDefaultDisabled
	if (temp == bTRUE)
	{
    	PickAlarmEnableMgr.Enable = bTRUE;
	}
    else
    {
      	PickAlarmEnableMgr.Enable = bFALSE;
    }
	#else
	if (temp == bFALSE)
	{
    	PickAlarmEnableMgr.Enable = bFALSE;
	}
    else
    {
      	PickAlarmEnableMgr.Enable = bTRUE;
    }
	#endif

	Config_AntiPrying_Interrupt();
	
}

/****************************************************************/
/****************************************************************/
void ReadLockBrand(void)
{
	EEPROM_ReadSequential(LockBrandStartAddr,&LockBrand.BrandType,1);
	
	if ( LockBrand.BrandType == SmallBrand )
	{
		EEPROM_ReadSequential(LockBrandStartAddr+1,&LockBrand.LockBrandDisDataBuff[0],224);
		//LockBrand.BrandType = SmallBrand;
	}
	else if ( LockBrand.BrandType == BigBrand )
	{
		EEPROM_ReadSequential(LockBrandStartAddr+1,&LockBrand.LockBrandDisDataBuff[0],512);
		//LockBrand.BrandType = BigBrand;
	}
	else if ( LockBrand.BrandType == DefaultBigBrand )
	{
		//LockBrand.BrandType = DefaultBigBrand;
	}
	else
	{
		//LockBrand.BrandType = DefaultSmallBrand;
	}	
	
}

/****************************************************************/
/****************************************************************/
/****************************************************************/
/****************************************************************/
void WriteLockBrand(void)
{	
	LockBrand.GotBrandData = bFALSE;
	if ( MFC_ReadLockBrandData(&LockBrand.LockBrandDisDataBuff[0]) == S_SUCCESS )
	{
		EEPROM_WriteSequential(LockBrandStartAddr,&LockBrand.BrandType,1);
		
		if ( LockBrand.BrandType == SmallBrand )
		{
			EEPROM_WriteSequential(LockBrandStartAddr+1,&LockBrand.LockBrandDisDataBuff[0],224);
		}
		else if ( LockBrand.BrandType == BigBrand )
		{
			EEPROM_WriteSequential(LockBrandStartAddr+1,&LockBrand.LockBrandDisDataBuff[0],512);
		}
		LockBrand.GotBrandData = bTRUE;
	}
}

void SystemConfigReset(void)
{
	UserIdentifyResultMgr.UnlockingMode = SingalMode;
	
	VoiceMgr.Enable = bTRUE;
	
	AntiPryingMgr.AntiPryingTrigger = bFALSE;		//Refresh Anti-Prying Trigger

	#ifdef Function_AntiPryingDefaultDisabled
		PickAlarmEnableMgr.Enable = bFALSE;
	#else
		PickAlarmEnableMgr.Enable = bTRUE;
	#endif

	BodyInductionMgr.SensingDistanceLevel = SensingDistanceL1;

	#ifdef ProjectIs_AutoBarLock_S70Z01
	VoiceMgr.volume = 1;
	#else
  	VoiceMgr.volume = 3;
	#endif
	
	Config_AntiPrying_Interrupt();

	SystemConfigSave();
	
	//AutoMotorMgrInitConfigReset();

}

void VoiceReportCurrentLanguage(void)
{
	uint16_t VoiceStr[5];
	if ( SystemLanguage == Chinese )
	{
		VoiceStr[0] = VOICE_Current;
		VoiceStr[1] = VOICE_Setting;
		VoiceStr[2] = VOICE_Chinese;
	}
	else
	{
		VoiceStr[0] = VOICE_Current+1;
		VoiceStr[1] = VOICE_Setting+1;
		VoiceStr[2] = VOICE_English;
	}
	VoiceStr[3] = DEF_VoiceSegmentEndFlag;
	PLAY_VOICE_MULTISEGMENTS_IGNORELANGUAGE(VoiceMgr.volume,VoiceStr);
}

//ID����Ч����ʾ����
void GUI_DataInputCreat(uint8_t StartPage,uint8_t StartColumn,uint8_t InputNum,uint16_t DefaultValue)
{
	uint8_t i,temp;
	uint16_t value;


	if( DataInputMgr.Status == InputIdle )
	{
		DataInputMgr.Status = InputStart;
		DataInputMgr.Value = DefaultValue;
		DataInputMgr.InputNum = InputNum;

		if ( DefaultValue == 0x0000 ){
			DataInputMgr.InputPoint = 0;
		}
		else{
			DataInputMgr.InputPoint = InputNum;
		}
	}
		
	else if ( DataInputMgr.Status == InputStart )
	{
		if (DataInputMgr.InputPoint > DataInputMgr.InputNum ){
			return;
		}

		value = DataInputMgr.Value;
		for (i=0;i<DataInputMgr.InputPoint;i++)
		{	
			temp = value%10;
			DisOneDigital16x8(StartPage,StartColumn+(8*(DataInputMgr.InputPoint-i-1)),temp,NormalDisplay);
			value/=10;
		}

		for (i=DataInputMgr.InputPoint;i<(DataInputMgr.InputNum+1);i++)		//"+1" for clear underline
		{
			DisZF16x8(StartPage,StartColumn+(8*i),ZF_kongge,NormalDisplay);
		}
		
		if ( GUI_ToggleFlag_05s == 1 )
		{
			DisZF16x8(StartPage,StartColumn+(8*DataInputMgr.InputPoint),ZF_kongge,NormalDisplay);
		}
		else{
			DisZF16x8(StartPage,StartColumn+(8*DataInputMgr.InputPoint),ZF_underline,NormalDisplay);
		}
	}

}


void GUI_UserIDinputButtonMonitor(keycode_t keycode)
{
	if ( (keycode < KEY_NINE)||(keycode == KEY_NINE) )
	{
		DEF_ButtonPress_Voice;
		if ( DataInputMgr.InputPoint < DataInputMgr.InputNum )
		{
			DataInputMgr.Value = DataInputMgr.Value*10+gui_keycode;
			DataInputMgr.InputPoint++;
		}
	}
	else if ( keycode == KEY_ASTERISK )
	{
		DEF_ButtonPress_Voice;
		if ( DataInputMgr.InputPoint > 0 )
		{
			//DataInputMgr.InputPoint--;
			//DataInputMgr.Value/=10;
			DataInputMgr.InputPoint=0;
			DataInputMgr.Value=0;
		}
		else
		{
			DataInputMgr.Status = InputExit;
		}
	}
	else if ( keycode == KEY_POUNDSIGN )
	{
		DEF_ButtonPress_Voice;
		if ( DataInputMgr.InputPoint == 0 )
		{
			DataInputMgr.Status = InputExit;
		}
		else
		{
			DataInputMgr.Status = InputEnd;
		}
	}
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void GUI_PasscodeInputCreat(uint8_t StartPage,uint8_t StartColumn)
{
	uint8_t i;

	if (PasscodeInputMgr.Point > 16){
		StartColumn = 0;//������ ����warning
		return;
	}
	
	Clear_Screen_Page(StartPage);
	Clear_Screen_Page(StartPage+1);
	for (i=0;i<PasscodeInputMgr.Point;i++)
	{
		DisZF16x8(StartPage,(8*i)+(64-(PasscodeInputMgr.Point*4)),ZF_xinghao,NormalDisplay);
	}

}

void GUI_PasscodeInputButtonMonitor(keycode_t keycode)
{
	uint i;
	if ( (keycode < KEY_NINE)||(keycode == KEY_NINE) )
	{
		if ( CurrentScreen != SCREEN_PickLockAlarm ){
			DEF_ButtonPress_Voice;
		}
		if ( PasscodeInputMgr.Point <  PasscodeInputMgr.PasscodeLen )
		{
			PasscodeInputMgr.InputBuff[PasscodeInputMgr.Point] = gui_keycode;
			PasscodeInputMgr.Point++;
		}
	}
	else if ( keycode == KEY_ASTERISK )
	{
		if ( CurrentScreen != SCREEN_PickLockAlarm ){
			DEF_ButtonPress_Voice;
		}		
		if ( PasscodeInputMgr.Point > 0 )
		{
			for (i=0;i<16;i++)
			{
				PasscodeInputMgr.InputBuff[i]=0xff;
			}
			PasscodeInputMgr.Point = 0;
		}
		else
		{
			PasscodeInputMgr.Status = PasscodeInputExit;
		}
	}
	else if ( keycode == KEY_POUNDSIGN )
	{
		if ( CurrentScreen != SCREEN_PickLockAlarm ){
			DEF_ButtonPress_Voice;
		}
//		if ( PasscodeInputMgr.Point == 0 )
//		{
//			PasscodeInputMgr.Status = PasscodeInputExit;
//		}
//		else
//		{
			PasscodeInputMgr.Status = PasscodeInputEnd;
//		}
	}
}

void PasscodeUserIdentify(void)
{
	//uint8_t PasscodeBUFF[16];
	//uint8_t i;

	if ( PasscodeUserIdentifyMgr.Status != PasscodeIdentifyIdle )
	{
		if (PasscodeUserIdentifyMgr.Status == PasscodeIdentifyStart )
		{
			/*
			PasscodeInputMgr.Point = 0x00;
			PasscodeInputMgr.PasscodeLen = 16;
			PasscodeInputMgr.Status = PasscodeInputStart;
			for (i=0;i<PasscodeInputMgr.PasscodeLen;i++)
			{
				PasscodeInputMgr.InputBuff[i]=0xff;
			}
			*/
			GUI_Flag_RefreshLCD = bTRUE;	
			PasscodeUserIdentifyMgr.TimeCnt = 240;	//
			PasscodeUserIdentifyMgr.Status = PasscodeIdentifyPasscodeInput;
		}
		else if (PasscodeUserIdentifyMgr.Status == PasscodeIdentifyPasscodeInput)
		{
			if (SystemLanguage == Chinese){
				DisHZ16x14Str(3,28,InputPasscodeStr,NormalDisplay);
			}
			else{
				DisEN16x8Str(3,16,InputPasscodeStrEn,NormalDisplay);
			}
			GUI_PasscodeInputCreat(6,0);
			if (PasscodeInputMgr.Status == PasscodeInputEnd)
			{
				#if (defined Function_IndependentDoorBellKey) || (defined Function_IndependentLockKey)
				if (0)
				{
					
				}
				#else
				if ((PasscodeInputMgr.InputBuff[0]==0x01)&&(PasscodeInputMgr.Point == 1))
				{
					PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIntoMainMenuSuccess;
				}
				#endif
				else
				{
					if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
					{
						if( ( (PasscodeInputMgr.InputBuff[0]==0x01)
							&&(PasscodeInputMgr.InputBuff[1]==0x01)
							&&(PasscodeInputMgr.InputBuff[2]==0x01)
							&&(PasscodeInputMgr.InputBuff[3]==0x01)
							&&(PasscodeInputMgr.InputBuff[4]==0x01)
							&&(PasscodeInputMgr.InputBuff[5]==0x01)
							&&(PasscodeInputMgr.InputBuff[6]==0x01)
							&&(PasscodeInputMgr.InputBuff[8]==0x01)
							&&(PasscodeInputMgr.InputBuff[9]==0x01)
						  )
						  ||((PasscodeInputMgr.InputBuff[0]==0x03)&&(PasscodeInputMgr.Point == 1))
						  )
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifyAgingTestSuccess;
						}
						else if ((PasscodeInputMgr.InputBuff[0]==0x08)
								&&(PasscodeInputMgr.InputBuff[1]==0x08)
								&&(PasscodeInputMgr.InputBuff[2]==0x08)
								&&(PasscodeInputMgr.Point == 3)
								)
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifyEngineeringModeSuccess;
						}
						#ifdef ProjectIs_BarLock_S101Z01
						else if ((PasscodeInputMgr.InputBuff[0]==0x00)
						&&(PasscodeInputMgr.InputBuff[1]==0x01)
						&&(PasscodeInputMgr.Point == 2)
						)
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifyWifiMFTSuccess;
						}
						#else
						else if ((PasscodeInputMgr.InputBuff[0]==0x07)
								&&(PasscodeInputMgr.InputBuff[1]==0x06)
								&&(PasscodeInputMgr.InputBuff[2]==0x04)
								&&(PasscodeInputMgr.InputBuff[3]==0x03)
								&&(PasscodeInputMgr.Point == 4)
								)
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifyWifiMFTSuccess;
						}
						#endif
						else if ((PasscodeInputMgr.InputBuff[0]==0x01)
								&&(PasscodeInputMgr.InputBuff[1]==0x04)
								&&(PasscodeInputMgr.InputBuff[2]==0x05)
								&&(PasscodeInputMgr.InputBuff[3]==0x08)
								&&(PasscodeInputMgr.Point == 4)
								)
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifySelfTestSuccess;
						}
						else if ((PasscodeInputMgr.InputBuff[0]==0x01)
						&&(PasscodeInputMgr.InputBuff[1]==0x03)
						&&(PasscodeInputMgr.InputBuff[2]==0x05)
						&&(PasscodeInputMgr.InputBuff[3]==0x07)
						&&(PasscodeInputMgr.Point == 4)
						)
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifyFastVersionCheckSuccess;
						}
						else if ((PasscodeInputMgr.InputBuff[0]==0x02)
						&&(PasscodeInputMgr.InputBuff[1]==0x05)
						&&(PasscodeInputMgr.InputBuff[2]==0x06)
						&&(PasscodeInputMgr.InputBuff[3]==0x08)
						&&(PasscodeInputMgr.Point == 4)
						)
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifyLanguageSetToEnglishSuccess;
						}
						else if ((PasscodeInputMgr.InputBuff[0]==0x02)
						&&(PasscodeInputMgr.InputBuff[1]==0x05)
						&&(PasscodeInputMgr.InputBuff[2]==0x06)
						&&(PasscodeInputMgr.InputBuff[3]==0x09)
						&&(PasscodeInputMgr.Point == 4)
						)
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifyLanguageSetToChineseSuccess;
						}
						#if (defined ProjectIs_BarLock_S15Z07) || (defined ProjectIs_BarLock_S15Z08) \
					|| (defined ProjectIs_BarLock_S15Z09)
						else if ((PasscodeInputMgr.InputBuff[0]==0x07)
						&&(PasscodeInputMgr.Point == 1)
						)
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifySwitchPryingEnable;
						}
						#endif
						else
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifyFail;
						}
					}
					else
					{
						PasscodeUserIdentifyMgr.UserID = PasscodeIdendify( PasscodeInputMgr.InputBuff);
						if ( PasscodeUserIdentifyMgr.UserID != 0x00 )//Identify success
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifySuccess; 
							PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifySuccessScreenTimeDelay;
							UserIdentifyResultMgr.PasscodeType = LocalPasscode;
							GUI_Flag_RefreshLCD = bTRUE;
							#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi) 
								Wifi_PowerOffIfPowerOnForOnlinePasswordVerify();
							#endif
						}
						else
						{
							if ( PasscodeInputMgr.Point == 12 )
							{
								PasscodeUserIdentifyMgr.UserID = AppPasscodeIdentify(PasscodeInputMgr.InputBuff);
								if ( PasscodeUserIdentifyMgr.UserID != 0x00 )//App unlock success
								{
									PasscodeUserIdentifyMgr.Status = PasscodeIdentifySuccess;
									PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifySuccessScreenTimeDelay;
									UserIdentifyResultMgr.PasscodeType = AppPasscode;
									GUI_Flag_RefreshLCD = bTRUE;
								}
								else
								{
									PasscodeUserIdentifyMgr.Status = PasscodeIdentifyFail;
									PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifyFailScreenTimeDelay;
									GUI_Flag_RefreshLCD = bTRUE;
								}
								#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi) 
								Wifi_PowerOffIfPowerOnForOnlinePasswordVerify();
								#endif
							}
							else if  (( PasscodeInputMgr.Point == 7 )&&(PasscodeInputMgr.InputBuff[0] == 1 ))
							{
								if ( WifiMgr.WifiOnlinePasswordVerifyMgr.Status == OnlinePasswordVerifyInit )
								{
									WifiMgr.WifiOnlinePasswordVerifyMgr.Status = OnlinePasswordVerifyStart;
									#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi) 
									Wifi_PostOnlinePasswordVerify(&PasscodeInputMgr.InputBuff[1]);
									#else
									ComPort_SetPost_OnlinePasswordVerify(&PasscodeInputMgr.InputBuff[1]);
									#endif
								}
								else if ( WifiMgr.WifiOnlinePasswordVerifyMgr.Status == OnlinePasswordVerifySuccess )
								{
									PasscodeUserIdentifyMgr.Status = PasscodeIdentifySuccess;
									PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifySuccessScreenTimeDelay;
									UserIdentifyResultMgr.PasscodeType = OnlinePasscode;
									PasscodeUserIdentifyMgr.UserID = 0x00;	//(WifiMgr.WifiOnlinePasswordVerifyMgr.UserID-1023)%256;	//online passcode user ID from 1024 to 2048
									WifiMgr.WifiOnlinePasswordVerifyMgr.Status = OnlinePasswordVerifyInit;
									GUI_Flag_RefreshLCD = bTRUE;
									#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi) 
									Wifi_PowerOffIfPowerOnForOnlinePasswordVerify();
									#endif

								}
								else if ( WifiMgr.WifiOnlinePasswordVerifyMgr.Status == OnlinePasswordVerifyFail )
								{
									PasscodeUserIdentifyMgr.Status = PasscodeIdentifyFail;
									PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifyFailScreenTimeDelay;
									WifiMgr.WifiOnlinePasswordVerifyMgr.Status = OnlinePasswordVerifyInit;
									GUI_Flag_RefreshLCD = bTRUE; 
									#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi) 
									Wifi_PowerOffIfPowerOnForOnlinePasswordVerify();
									#endif
								}
							}
							else
							{

							#if defined ProjectIs_BarLock_S101Z01
							if( ((PasscodeInputMgr.InputBuff[0]==0x03)&&(PasscodeInputMgr.Point == 1))){
									PasscodeUserIdentifyMgr.Status = PasscodeIdentifyAgingTestSuccess;
							}
							else{
								PasscodeUserIdentifyMgr.Status = PasscodeIdentifyFail;
								PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifyFailScreenTimeDelay;
								GUI_Flag_RefreshLCD = bTRUE;
								#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi) 
								Wifi_PowerOffIfPowerOnForOnlinePasswordVerify();
								#endif
							}
							#else
								PasscodeUserIdentifyMgr.Status = PasscodeIdentifyFail;
								PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifyFailScreenTimeDelay;
								GUI_Flag_RefreshLCD = bTRUE;
								#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi) 
								Wifi_PowerOffIfPowerOnForOnlinePasswordVerify();
								#endif
							#endif								
							}
						}
					}
				}
			}
			else if (PasscodeInputMgr.Status == PasscodeInputExit)
			{
				PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
				PasscodeUserRegisterMgr.TimeCnt = 0;	
				GUI_Flag_RefreshLCD = bTRUE;
			}
		}
	}
}

/*******************************************************/
/*****Input BUFF[10]; OUTPUT 0-PasscodeIsNotRegistered, 1~255 Passcode is Registered, return value is the UserID****************/
/*******************************************************/
uint8_t PasscodeIdendify(uint8_t *BUFF1)
{
	uint8_t i,j,k;
	uint8_t PasscodeLen;
	for (i=0;i<(DEF_MAX_PASSCODEMASTER+DEF_MAX_PASSCODEUSER);i++)
	{
		if ( PasscodeMemoryMgr[i].Status != PasscodeIsValid ){
			continue;
		}

		PasscodeLen = 0;
		for (j=11;j>=0;j--)
		{
			if(j%2==1)
			{
				if ( (PasscodeMemoryMgr[i].PasscodeBuff[j/2]&0xf) != 0xF )
				{
					PasscodeLen = j+1;
					break;
				}
			}
			else
			{
				if ( ((PasscodeMemoryMgr[i].PasscodeBuff[j/2]>>4)&0xf) != 0xF )
				{
					PasscodeLen = j+1;
					break;
				}
			}
		}
		
		for (j=0;j<(16-PasscodeLen+1);j++)
		{
			for (k=0;k<PasscodeLen;k++)
			{
				if(k%2==1)
				{
					if (((PasscodeMemoryMgr[i].PasscodeBuff[k/2]&0xf) != *(BUFF1+k+j)))
					{
						break;
					}
				}
			    else
				{
					if ((((PasscodeMemoryMgr[i].PasscodeBuff[k/2]>>4)&0xf) != *(BUFF1+k+j)))
					{
						break;
					}
				}
			}
			if (k == PasscodeLen){
				return PasscodeMemoryMgr[i].UserID;
			}
		}
	}
	return 0;
}



/*******************************************************/
/*******************************************************/
/*******************************************************/
uint8_t AppPasscodeIdentify(uint8_t BUFF[])
{
	uint8_t i,j;
	uint8_t UserPasscodeLen;
	uint8_t temp[12];
	for (i=0;i<DEF_MAX_PASSCODEMASTER;i++){
		UserPasscodeLen = 0;
		for(j=0;j<6;j++)
		{
			temp[2*j]=PasscodeMemoryMgr[i].PasscodeBuff[j]>>4;
			temp[2*j+1]=PasscodeMemoryMgr[i].PasscodeBuff[j]&0x0f;
		}
		for (j=0;j<12;j++){
	     if ( temp[j] < 10){
	          UserPasscodeLen++;
	     }
	     else{
	         break;
	     }
		}
		if(UserPasscodeLen<6){
				continue;
		}
		if ( pwd_decrypt_checkmode(temp,UserPasscodeLen,BUFF,12) > 0 ){
       return i+1;
		}
	}
	return 0;
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
void ShowLockBrand(void)
{
	#if (defined ProjectIs_BarLock_S15Z07) || (defined ProjectIs_BarLock_S15Z08) \
					|| (defined ProjectIs_BarLock_S15Z09)
	uint8_t Welcome_Str[5]={HZ_huan,HZ_yingjie,HZ_huijia,HZ_jiating,HZ_end};
	#else
	uint8_t Welcome_Str[8]={HZ_huan,HZ_yingjie,HZ_shiyong,HZ_yong,HZ_zhineng,HZ_neng,HZ_suomen,HZ_end};
	#endif
	code uint8_t Welcome_StrEn[]={"WELCOME"};

	if ( LockBrand.BrandType == SmallBrand )
	{
		DisImage_RAM(6,8,112,16,&LockBrand.LockBrandDisDataBuff[0],NormalDisplay);
	}
	else if ( LockBrand.BrandType == BigBrand )
	{
		DisImage_RAM(2,0,128,32,&LockBrand.LockBrandDisDataBuff[0],NormalDisplay);
	}
	else if ( LockBrand.BrandType == DefaultBigBrand )
	{
		if ( SystemLanguage == Chinese ) 
		{
			DisImage(2,10,108,32,&Icon_Welcome[0],NormalDisplay);
		}
		else
		{
			DisImage(2,15,98,32,&Icon_WelcomeEn[0],NormalDisplay);
		}
	}	
	else //if ( LockBrand.BrandType == DefaultSmallBrand )
	{
		if ( SystemLanguage == Chinese ) 
		{
			#if (defined ProjectIs_BarLock_S15Z07) || (defined ProjectIs_BarLock_S15Z08) \
					|| (defined ProjectIs_BarLock_S15Z09)
			DisHZ16x14Str(6,40,Welcome_Str,NormalDisplay);
			#else
			DisHZ16x14Str(6,16,Welcome_Str,NormalDisplay);
			#endif
		}
		else
		{
			DisEN16x8Str(6,36,Welcome_StrEn,NormalDisplay);
		}
	}
}
/*******************************************************/
/*******************************************************/
/*******************************************************/
void GoIntoMainScreen_WithIdentifyInit(void)
{
	PasscodeInputMgr.Point = 0x00;
	PasscodeInputMgr.PasscodeLen = 16;
	PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
	
	FpIdentifyMgr.Status = FPMcmdStart;
	
	CardIdentifyMgr.Status = ReadingCardID;
	CardIdentifyMgr.CardDetectIntervalTimeCnt = Def_GuiTimeDelayCnt05s;

	FaceIdentifyMgr.Status = FrmIdentifyStart;
	CurrentScreen = SCREEN_Main;
}
/*******************************************************/
/*******************************************************/
/*******************************************************/
void GoIntoShowSystemVersion(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 5;
	CurrentScreen = SCREEN_SystemVersion;
	
	SystemVersionVoiceBuff[0][1] = TranslateNumberToVoice(DEF_CustomerNumber/100);
	SystemVersionVoiceBuff[0][2] = TranslateNumberToVoice(DEF_CustomerNumber%100/10);
	SystemVersionVoiceBuff[0][3] = TranslateNumberToVoice(DEF_CustomerNumber%10);
	SystemVersionVoiceBuff[0][5] = TranslateNumberToVoice(DEF_ModelNumber/100);
	SystemVersionVoiceBuff[0][6] = TranslateNumberToVoice(DEF_ModelNumber%100/10);
	SystemVersionVoiceBuff[0][7] = TranslateNumberToVoice(DEF_ModelNumber%10);	

	//Main Board Hardware Version
	SystemVersionVoiceBuff[1][0] = TranslateNumberToVoice(DEF_HardwareVerion/100);
	SystemVersionVoiceBuff[1][1] = TranslateNumberToVoice(DEF_HardwareVerion%100/10);
	SystemVersionVoiceBuff[1][2] = TranslateNumberToVoice(DEF_HardwareVerion%10);
	//Main Board Firmware Version
	SystemVersionVoiceBuff[1][4] = TranslateNumberToVoice(DEF_FirmwareVerion/100);
	SystemVersionVoiceBuff[1][5] = TranslateNumberToVoice(DEF_FirmwareVerion%100/10);
	SystemVersionVoiceBuff[1][6] = TranslateNumberToVoice(DEF_FirmwareVerion%10);

	//Driver Board Hardware Version
	SystemVersionVoiceBuff[2][0]= TranslateNumberToVoice(DriverBoardVersion.HWversion/100);
	SystemVersionVoiceBuff[2][1]= TranslateNumberToVoice(DriverBoardVersion.HWversion%100/10);
	SystemVersionVoiceBuff[2][2]= TranslateNumberToVoice(DriverBoardVersion.HWversion%10);
	//Driver Board Firmware Version
	SystemVersionVoiceBuff[2][4]= TranslateNumberToVoice(DriverBoardVersion.FWversion/100);
	SystemVersionVoiceBuff[2][5]= TranslateNumberToVoice(DriverBoardVersion.FWversion%100/10);
	SystemVersionVoiceBuff[2][6]= TranslateNumberToVoice(DriverBoardVersion.FWversion%10);	
}

void ReadPasscodeUserMemoryFromEEPROM(void)//��EEPROM�ڴ��ȡ�����û�
{
	EEPROM_ReadSequential(PasscodeUserMemoryStartAddr,&PasscodeMemoryMgr[0].UserID,(8*(DEF_MAX_PASSCODEUSER+DEF_MAX_PASSCODEMASTER)));
}

void WritePasscodeUserMemoryToEEPROM(void)//��EEPROM�ڴ�д�������û�
{
	EEPROM_WriteSequential(PasscodeUserMemoryStartAddr,&PasscodeMemoryMgr[0].UserID,(8*(DEF_MAX_PASSCODEUSER+DEF_MAX_PASSCODEMASTER)));
}

/*******************************************************/
/*******************************************************/
/*******************************************************/
bool_t GUI_CompareTwoPasscodes(uint8_t *BUFF1,uint8_t *BUFF2)
{
	if (  ( *BUFF1 == *BUFF2)
		&&(*(BUFF1+1) == *(BUFF2+1))
		&&(*(BUFF1+2) == *(BUFF2+2))
		&&(*(BUFF1+3) == *(BUFF2+3))
		&&(*(BUFF1+4) == *(BUFF2+4))
		&&(*(BUFF1+5) == *(BUFF2+5))
		&&(*(BUFF1+6) == *(BUFF2+6))
		&&(*(BUFF1+7) == *(BUFF2+7))
		&&(*(BUFF1+8) == *(BUFF2+8))
		&&(*(BUFF1+9) == *(BUFF2+9))
		&&(*(BUFF1+10) == *(BUFF2+10))
		&&(*(BUFF1+11) == *(BUFF2+11))
	   )
	{
		return bTRUE;
	}
	else
	{
		return bFALSE;
	}
}

bool_t IfPasscodeUserIDisRegistered(uint8_t UserID)
{
	uint8_t i;
	for (i=0;i<(DEF_MAX_PASSCODEUSER+DEF_MAX_PASSCODEMASTER);i++)
	{
		if (PasscodeMemoryMgr[i].UserID == UserID )
		{
			return bTRUE;
		}
	}
	return bFALSE;
}


uint8_t CheckHowManyRegisteredPasscodeMaster( void )
{
	uint8_t i,MasterNum;
	MasterNum =0;
	for (i=0;i<(DEF_MAX_PASSCODEMASTER);i++)
	{
		if ( IfPasscodeUserIDisRegistered(i+1) == bTRUE )
		{
			MasterNum++;
		}
	}
	return MasterNum;
}

uint8_t CheckHowManyRegisteredPasscodeUser( void )
{
	uint8_t i,UserNum;
	UserNum =0;
	for (i=DEF_MAX_PASSCODEMASTER;i<(DEF_MAX_PASSCODEUSER+DEF_MAX_PASSCODEMASTER);i++)
	{
		if ( IfPasscodeUserIDisRegistered(i+1) == bTRUE )
		{
			UserNum++;
		}
	}
	return UserNum;
}


/*******************************************************/
/*******************************************************/
/*******************************************************/

/*******************************************************/
/*******************************************************/
/*******************************************************/
void DeletePasscodeUserfromMemory(uint8_t UserID)
{
	uint8_t i,j;

	for (i=0;i<(DEF_MAX_PASSCODEUSER+DEF_MAX_PASSCODEMASTER);i++)
	{
		if (PasscodeMemoryMgr[i].UserID == UserID )
		{
			PasscodeMemoryMgr[i].Status = PasscodeIsInvalid;
			PasscodeMemoryMgr[i].UserID = 0xFF;
			for (j=0;j<6;j++)
			{
				PasscodeMemoryMgr[i].PasscodeBuff[j] = 0xFF;
			}
			break;
		}
	}	

	WritePasscodeUserMemoryToEEPROM();
}


void DeleteAllPasscodeMasterfromMemory(void)
{
	uint8_t i,j;

	for (i=0;i<DEF_MAX_PASSCODEMASTER;i++)
	{

		PasscodeMemoryMgr[i].Status = PasscodeIsInvalid;
		PasscodeMemoryMgr[i].UserID = 0xFF;
		for (j=0;j<6;j++)
		{
			PasscodeMemoryMgr[i].PasscodeBuff[j] = 0xFF;
		}

	}	
	WritePasscodeUserMemoryToEEPROM();
}

void DeleteAllPasscodeUserfromMemory(void)
{
	uint8_t i,j;

	for (i=DEF_MAX_PASSCODEMASTER;i<(DEF_MAX_PASSCODEMASTER+DEF_MAX_PASSCODEUSER);i++)
	{

		PasscodeMemoryMgr[i].Status = PasscodeIsInvalid;
		PasscodeMemoryMgr[i].UserID = 0xFF;
		for (j=0;j<6;j++)
		{
			PasscodeMemoryMgr[i].PasscodeBuff[j] = 0xFF;
		}

	}	
	WritePasscodeUserMemoryToEEPROM();
}

/*******************************************************/
/*****		Input BUFF[6]; 					   *********/
/*****      OUTPUT S_FAIL- MemoryIsFull, SUCCESS-be saved ****************/
/*******************************************************/
status_t SavePasscodeUserToMemory(uint8_t *Point,uint8_t UserID)
{
	uint8_t j;
/*
	for (i=0;i<DEF_MAX_PASSCODEUSER;i++)
	{
		if ( PasscodeMemoryMgr[i].Status == PasscodeIsValid)		//refer to flash default data
		{
			continue;
		}
		else
		{
			break;
		}
	}

	if ( i < DEF_MAX_PASSCODEUSER )
	{
		for (j=0;j<6;j++)
		{
			PasscodeMemoryMgr[i].PasscodeBuff[j] = *(Point+j);
		}
		PasscodeMemoryMgr[i].UserID = UserID;
		PasscodeMemoryMgr[i].Status = PasscodeIsValid;
		WritePasscodeUserMemoryToEEPROM();
		return S_SUCCESS;
	}
	else
	{
		return S_FAIL;
	}
*/
	for (j=0;j<6;j++)
	{
		PasscodeMemoryMgr[UserID-1].PasscodeBuff[j] = (*(Point+2*j))<<4|((*(Point+2*j+1)&0X0f));
	}
	PasscodeMemoryMgr[UserID-1].UserID = UserID;
	PasscodeMemoryMgr[UserID-1].Status = PasscodeIsValid;
	WritePasscodeUserMemoryToEEPROM();
	return S_SUCCESS;

}

/*******************************************************/
/*******************************************************/
/*******************************************************/
uint8_t Get_Availabe_PasscodeMasterID(void)//��ȡ��ע���������ԱID
{
	uint8_t i;
	for (i=0;i<DEF_MAX_PASSCODEMASTER;i++)
	{
		if ( PasscodeMemoryMgr[i].Status != PasscodeIsValid ){
			return (i+1);
		}
	}
	return 0;
}
/*******************************************************/
/*******************************************************/
/*******************************************************/
uint8_t Get_Availabe_PasscodeUserID(void)//��ȡ��ע�������û�ID
{
	uint8_t i;
	for (i=DEF_MAX_PASSCODEMASTER;i<(DEF_MAX_PASSCODEMASTER+DEF_MAX_PASSCODEUSER);i++)
	{
		if ( PasscodeMemoryMgr[i].Status != PasscodeIsValid ){
			return (i+1);
		}
	}
	return 0;
}




void ReadRegisteredFPuserFromLocalList(void)
{
	uint8_t i,j,USERID,Checksum,UserIdByte;
	
	
	ReadFPuserIdListFromEEPROM();

	Checksum = 0x00;

	for ( i=0;i<32;i++)
	{
		Checksum+=CheckHomManyRegisteredFPuser.UserIdList[i];
	}

	if (Checksum!=CheckHomManyRegisteredFPuser.UserIdListChecksum)
	{
		ResetFPuserIdListInEEPROM();
		CheckHomManyRegisteredFPuser.UserNum = 0x00;
		CheckHomManyRegisteredFPuser.StressUserNum = 0x00;
		CheckHomManyRegisteredFPuser.MasterNum = 0x00;
	}
	else
	{		
		USERID = 0x00;
		CheckHomManyRegisteredFPuser.UserNum = 0x00;
		CheckHomManyRegisteredFPuser.StressUserNum = 0x00;
		CheckHomManyRegisteredFPuser.MasterNum = 0x00;
		for ( i=0;i<32;i++)
		{
			UserIdByte = CheckHomManyRegisteredFPuser.UserIdList[i];
			for (j=0;j<8;j++)
			{	
				if ( (UserIdByte&0x01) !=0 )
				{
					if ( USERID < DEF_MAX_FPMASTER )
					{
						CheckHomManyRegisteredFPuser.MasterNum++;
						FpUserMemoryMgr[USERID].UserID = USERID;
						FpUserMemoryMgr[USERID].RegisterStatus = Registered;
						FpUserMemoryMgr[USERID].UserPriority = Master;
					}
					else if ( USERID < (DEF_MAX_FPMASTER+DEF_MAX_FPUSER))
					{
						CheckHomManyRegisteredFPuser.UserNum++;
						FpUserMemoryMgr[USERID].UserID = USERID;
						FpUserMemoryMgr[USERID].RegisterStatus = Registered;
						FpUserMemoryMgr[USERID].UserPriority = User;
					}
					else if ( USERID < (DEF_MAX_FPMASTER+DEF_MAX_FPUSER+DEF_MAX_STRESSFPUSER))
					{
						CheckHomManyRegisteredFPuser.StressUserNum++;
						FpUserMemoryMgr[USERID].UserID = USERID;
						FpUserMemoryMgr[USERID].RegisterStatus = Registered;
						FpUserMemoryMgr[USERID].UserPriority = User;
					}
					
				}
				else
				{
					if ( USERID < DEF_MAX_FPMASTER )
					{
						FpUserMemoryMgr[USERID].UserID = USERID;
						FpUserMemoryMgr[USERID].RegisterStatus = UnRegistered;
						FpUserMemoryMgr[USERID].UserPriority = Master;
					}
					else if ( USERID < (DEF_MAX_FPMASTER+DEF_MAX_FPUSER))
					{
						FpUserMemoryMgr[USERID].UserID = USERID;
						FpUserMemoryMgr[USERID].RegisterStatus = UnRegistered;
						FpUserMemoryMgr[USERID].UserPriority = User;
					}
					else if ( USERID < (DEF_MAX_FPMASTER+DEF_MAX_FPUSER+DEF_MAX_STRESSFPUSER))
					{
						FpUserMemoryMgr[USERID].UserID = USERID;
						FpUserMemoryMgr[USERID].RegisterStatus = UnRegistered;
						FpUserMemoryMgr[USERID].UserPriority = User;
					}

				}
				UserIdByte>>=1;
				USERID++;
			}
		}
	}
}

/*******************************************************/
/*******************************************************/
/*******************************************************/

void CheckHowManyRegisteredFPuserFromFPM(void)
{
	//uint8_t FPindexTable[32];
	uint8_t i,j,USERID;
	
	if ( CheckHomManyRegisteredFPuser.Status == StartCheckHowManyRegisteredFPuser )
		{
			FPM_SendReadIndexTableCmd();
			CheckHomManyRegisteredFPuser.TimeCnt = Def_GuiTimeDelayCnt05s;//Def_FPMcmdTimeOutDelay;
			CheckHomManyRegisteredFPuser.Status = WaitForCheckHowManyRegisteredFPuserCmdAck;
			FpmAckMgr.Status = WaitACK;
			FpmAckMgr.TimeOutCnt = DEF_FpmAckTimeoutTime;
		}
	else if ( CheckHomManyRegisteredFPuser.Status == WaitForCheckHowManyRegisteredFPuserCmdAck)
		{
			if (FpmAckMgr.Status == GotACK)
			{
				if ( FpmAckMgr.ErrorCode == Error_NONE)
				{
					USERID = 0x00;
					CheckHomManyRegisteredFPuser.UserNum = 0x00;
					CheckHomManyRegisteredFPuser.StressUserNum = 0x00;
					CheckHomManyRegisteredFPuser.MasterNum = 0x00;
					for ( i=0;i<32;i++)
						{
							for (j=0;j<8;j++)
							{	
								if ( (FpmAckMgr.Buff[10+i]&0x01) !=0 )
								{
									if ( USERID < DEF_MAX_FPMASTER )
									{
										CheckHomManyRegisteredFPuser.MasterNum++;
										FpUserMemoryMgr[USERID].UserID = USERID;
										FpUserMemoryMgr[USERID].RegisterStatus = Registered;
										FpUserMemoryMgr[USERID].UserPriority = Master;
									}
									else if ( USERID < (DEF_MAX_FPMASTER+DEF_MAX_FPUSER))
									{
										CheckHomManyRegisteredFPuser.UserNum++;
										FpUserMemoryMgr[USERID].UserID = USERID;
										FpUserMemoryMgr[USERID].RegisterStatus = Registered;
										FpUserMemoryMgr[USERID].UserPriority = User;
									}
									else if ( USERID < (DEF_MAX_FPMASTER+DEF_MAX_FPUSER+DEF_MAX_STRESSFPUSER))
									{
										CheckHomManyRegisteredFPuser.StressUserNum++;
										FpUserMemoryMgr[USERID].UserID = USERID;
										FpUserMemoryMgr[USERID].RegisterStatus = Registered;
										FpUserMemoryMgr[USERID].UserPriority = User;
									}
								}
								else
								{
									if ( USERID < DEF_MAX_FPMASTER )
									{
										FpUserMemoryMgr[USERID].UserID = USERID;
										FpUserMemoryMgr[USERID].RegisterStatus = UnRegistered;
										FpUserMemoryMgr[USERID].UserPriority = Master;
									}
									else if ( USERID < (DEF_MAX_FPMASTER+DEF_MAX_FPUSER))
									{
										FpUserMemoryMgr[USERID].UserID = USERID;
										FpUserMemoryMgr[USERID].RegisterStatus = UnRegistered;
										FpUserMemoryMgr[USERID].UserPriority = User;
									}
									else if ( USERID < (DEF_MAX_FPMASTER+DEF_MAX_FPUSER+DEF_MAX_STRESSFPUSER))
									{
										FpUserMemoryMgr[USERID].UserID = USERID;
										FpUserMemoryMgr[USERID].RegisterStatus = UnRegistered;
										FpUserMemoryMgr[USERID].UserPriority = User;
									}

								}
								
								FpmAckMgr.Buff[10+i]>>=1;
								USERID++;
							}
						}
					CheckHomManyRegisteredFPuser.Status = CheckHomManyRegisteredFPuserSuccess;
				}
				else{
					DEBUG_MARK;
					CheckHomManyRegisteredFPuser.Status = CheckHomManyRegisteredFPuserFail;
				}
			}
			if ( CheckHomManyRegisteredFPuser.TimeCnt-- < 1 )
			{
				CheckHomManyRegisteredFPuser.Status = CheckHomManyRegisteredFPuserFail;
			}
		}
	
}


/*******************************************************/
/*******************************************************/
/*******************************************************/

void GUI_GetUserNumList(void)
{

	if ( CheckMemoryMgr.Status == StartCheckMemory)
	{
		CheckHomManyRegisteredFPuser.Status = StartCheckHowManyRegisteredFPuser;
		CheckHomManyRegisteredFPuser.FailTimes = 0x00;
		CheckMemoryMgr.Status = WaitForReadFPuserNum;
	}
	else if ( CheckMemoryMgr.Status == WaitForReadFPuserNum )
	{
		CheckHowManyRegisteredFPuserFromFPM();
		if ( CheckHomManyRegisteredFPuser.Status == CheckHomManyRegisteredFPuserSuccess )
		{
			CheckMemoryMgr.FpUserNum = CheckHomManyRegisteredFPuser.UserNum;
			CheckMemoryMgr.StressFpUserNum = CheckHomManyRegisteredFPuser.StressUserNum;
			CheckMemoryMgr.FpMasterNum = CheckHomManyRegisteredFPuser.MasterNum;
			CheckMemoryMgr.CardUserNum = CheckHowManyRegisteredCardUser();
			CheckMemoryMgr.PasscodeMasterNum = CheckHowManyRegisteredPasscodeMaster();
			CheckMemoryMgr.PasscodeUserNum = CheckHowManyRegisteredPasscodeUser();
			#ifdef Function_FaceRecoginition					
			CheckMemoryMgr.FaceMasterNum = CheckHowManyRegisteredFaceMaster();
			CheckMemoryMgr.FaceUserNum = CheckHowManyRegisteredFaceUser();
			#endif		
			CheckMemoryMgr.Status = CheckMemorySuccess;
		}
		else if ( CheckHomManyRegisteredFPuser.Status == CheckHomManyRegisteredFPuserFail )
		{
			if ( CheckHomManyRegisteredFPuser.FailTimes++ < 3 )
			{
				CheckHomManyRegisteredFPuser.Status = StartCheckHowManyRegisteredFPuser;//retry
			}
			else
			{
				ReadRegisteredFPuserFromLocalList();
				CheckMemoryMgr.FpUserNum = CheckHomManyRegisteredFPuser.UserNum;
				CheckMemoryMgr.StressFpUserNum = CheckHomManyRegisteredFPuser.StressUserNum;
				CheckMemoryMgr.FpMasterNum = CheckHomManyRegisteredFPuser.MasterNum;
				CheckMemoryMgr.CardUserNum = CheckHowManyRegisteredCardUser();
				CheckMemoryMgr.PasscodeMasterNum = CheckHowManyRegisteredPasscodeMaster();
				CheckMemoryMgr.PasscodeUserNum = CheckHowManyRegisteredPasscodeUser();
				#ifdef Function_FaceRecoginition			
				CheckMemoryMgr.FaceMasterNum = CheckHowManyRegisteredFaceMaster();
				CheckMemoryMgr.FaceUserNum = CheckHowManyRegisteredFaceUser();
				#endif		
				CheckMemoryMgr.Status = CheckMemoryFail;
			}
		}
	} 
	
}

void VoiceReportUserIDWithUserConfirm(uint16_t Value)
{
	uint16_t VoiceStr[11];
	VoiceStr[0]=VOICE_Current;
	VoiceStr[1]=VOICE_User;
	VoiceStr[2]=VOICE_ID;
	VoiceStr[3]=TranslateNumberToVoice(Value%1000/100);
	VoiceStr[4]=TranslateNumberToVoice(Value%100/10);
	VoiceStr[5]=TranslateNumberToVoice(Value%10);
	VoiceStr[6]=VOICE_PressPoundKey;
	VoiceStr[7]=VOICE_Confirm;
	VoiceStr[8]=VOICE_PressAsteriskKey;
	VoiceStr[9]=VOICE_ReturnPreviousMenu;
	VoiceStr[10]=DEF_VoiceSegmentEndFlag;

	PLAY_VOICE_MULTISEGMENTS(VoiceMgr.volume,VoiceStr);
}

/*******************************************************/
/*******************************************************/
/*******************************************************/

uint8_t TranslateNumberToVoice(uint8_t value)
{
	return 12+(2*value);
}

void SaveSystemTime( void )
{
	SystemTime.year   =		TempSystemTime.year;
	SystemTime.month 	= 	TempSystemTime.month;
	SystemTime.date   = 	TempSystemTime.date;
	SystemTime.day		= 	TempSystemTime.day;
	SystemTime.hour   = 	TempSystemTime.hour;
	SystemTime.minute = 	TempSystemTime.minute;
	SystemTime.second = 	TempSystemTime.second;
}

void GotSystemTime( void )
{
	TempSystemTime.year		=	SystemTime.year;
	TempSystemTime.month	= SystemTime.month;
	TempSystemTime.date 	= SystemTime.date;
	TempSystemTime.day		= SystemTime.day;
	TempSystemTime.hour		= SystemTime.hour;
	TempSystemTime.minute	= SystemTime.minute;
	TempSystemTime.second	= SystemTime.second;
}

void GoIntoEngineeringModeMenu_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
		{
	VoiceMenuMgr.TotalMenuNum = 9;
		}
	else{
	VoiceMenuMgr.TotalMenuNum = 8;
		}
	CurrentScreen = SCREEN_EngineeringModeMneu;
	//DEF_MenuSwitchDelayTime;
}

void GotoMotorLockDirrectionSetting_Init(void)
{
	VoiceMenuMgr.MenuPoint = 0;
	VoiceMenuMgr.TotalMenuNum = 4;
	CurrentScreen = SCREEN_AutoMotorLockDirection;	
}




