#ifndef GUI2_H
#define GUI2_H

#include "global_variable.h"
#include "StdTypes.h"


extern void ShowManagerIdentify(void);

extern void ShowInitialization(void);
extern void ShowLowBattery(void);
extern void ShowIdentifySuccessPage(void);
extern void ShowIdentifyFailPage(void);
extern void ShowSelfTest(void);
extern void ShowAgingTest(void);
extern void ShowSystemLocked(void);
extern void ShowUnlockingModeSetting(void);
extern void ShowInfoInquiryMenu(void);
extern void ShowEventLogBySequence(void);
extern void ShowClearEventLog(void);
extern void ShowPickLockAlarm(void);
extern void ShowDoorLockSettingMenu(void);
extern void ShowBodyInductionSetting(void);
extern void ShowSystemVersion(void);
extern void ShowRemoteUnlockRequest(void);
extern void ShowEngineeringModeMenu(void);
extern void ShowAutoMotorUnlockTimeSetting(void);
extern void ShowAutoMotorAutoLockTimeSetting(void);
extern void ShowAutoMotorLockDirectionSetting(void);
extern void ShowAutoMotorTorqueSetting(void);
extern void ShowBoltLockTimeSetting(void);
extern void ShowLockingTravelSetting(void);
extern void ShowAutoEjectSetting(void);
extern void ShowAutoMotorSelfTest(void);
extern void ShowWifiManufactureTest(void);
extern void ShowErrorMessage(void);




#endif
