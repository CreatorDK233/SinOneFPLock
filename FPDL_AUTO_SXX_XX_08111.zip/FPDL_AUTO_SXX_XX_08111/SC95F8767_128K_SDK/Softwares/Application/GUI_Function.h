#ifndef _GUI_Function_H_
#define _GUI_Function_H_

#include "StdTypes.h"

#define DEF_SystemSleepDelayTime_MainScreen		640		//10s

#define DEF_SystemSleepDelayTime_MenuScreen		1920	//30s

#define DEF_MenuSwitchDelayTime //Hardware_DelayMs(100);

void GoToMainMenu(void);
void GoToFpMenu(void);
void GoToPasswordMenu(void);
void GoToCardMenu(void);
void ShowFaceMenu(void);
void GoIntoFaceMenu_Init(void);
void GoToSystemConfigMenu(void);
void GotoLogMenu(void);
void GoIntoEngineeringModeMenu_Init(void);
void GotoBoltLockTimeSetting_Init(void);
void GotoLockingTravelSetting_Init(void);
void GotoAutoEjectSetting_Init(void);



extern void GotoMotorUnlockTimeSetting_Init(void);
extern void GotoMotorAutoLockTimeSetting_Init(void);
extern void GotoMotorSelfTest_Init(void);
extern void GotoMotorTorqueSetting_Init(void);
extern void GoIntoMotorSettingMenu_Init(void);

extern void GoIntoMainMenu_Init(void);
extern void GoIntoUserManagementMenu_Init(void);
extern void GoIntoMemoryUsageScreen(void);
extern void GoIntoFpDeleteMenu_Init(void);
extern void GoIntoVoiceSettingMenu_Init(void);
extern void GoIntoLanguageSetting_Init(void);
extern void GoIntoVolumeSetting_Init(void);
extern void GoToSystemConfigMenu(void);
extern void GoIntoDoorLockSettingMenu_Init(void);
extern void GoIntoBodyInductionSetting_Init(void);
extern void GotoMotorLockDirrectionSetting_Init(void);
extern void GoIntoUnlockingModeSetting_Init(void);
extern void GoIntoPickAlarmEnableSetting_Init(void);


void FrmFunctionConfigSave(void);
bool_t IfSystemIsInFactoryDefaultStatus(void);
bool_t IfSystemWithoutSecondIdentity(void);
bool_t IfSystemIsNoCardUser(void);
bool_t CompareTwoArrayIsSame(uint8_t Point1[],uint8_t Point2[],uint8_t Lenth);
void UnlockModeJudgment(void);
bool_t is_valid_date(uint8_t year, uint8_t month, uint8_t date);
void Config_AntiPrying_Interrupt(void);

void GUI_RefreshSleepTime(void);
void SystemConfigSave(void);
void SystemConfigLoad(void);
void BodyInductionConfigLoad(void);
void ReadLockBrand(void);
void WriteLockBrand(void);
void SystemConfigReset(void);
void VoiceReportCurrentLanguage(void);
void GUI_DataInputCreat(uint8_t StartPage,uint8_t StartColumn,uint8_t InputNum,uint16_t DefaultValue);
void GUI_UserIDinputButtonMonitor(keycode_t keycode);
void GUI_PasscodeInputCreat(uint8_t StartPage,uint8_t StartColumn);
void GUI_PasscodeInputButtonMonitor(keycode_t keycode);
void PasscodeUserIdentify(void);
uint8_t PasscodeIdendify(uint8_t *BUFF1);
uint8_t AppPasscodeIdentify(uint8_t BUFF[]);
void ShowLockBrand(void);
void GoIntoShowSystemVersion(void);

void ReadPasscodeUserMemoryFromEEPROM(void);
void WritePasscodeUserMemoryToEEPROM(void);	
bool_t GUI_CompareTwoPasscodes(uint8_t *BUFF1,uint8_t *BUFF2);
bool_t IfPasscodeUserIDisRegistered(uint8_t UserID);
uint8_t CheckHowManyRegisteredPasscodeMaster( void );
uint8_t CheckHowManyRegisteredPasscodeUser( void );
void DeletePasscodeUserfromMemory(uint8_t UserID);
void DeleteAllPasscodeMasterfromMemory(void);
void DeleteAllPasscodeUserfromMemory(void);
status_t SavePasscodeUserToMemory(uint8_t *Point,uint8_t UserID);
uint8_t Get_Availabe_PasscodeMasterID(void);
uint8_t Get_Availabe_PasscodeUserID(void);
void GUI_GetUserNumList(void);
void VoiceReportUserIDWithUserConfirm(uint16_t Value);
extern uint8_t TranslateNumberToVoice(uint8_t value);	
void SaveSystemTime(void);
void GotSystemTime(void);
extern void GoIntoMainScreen_WithIdentifyInit(void);



#endif