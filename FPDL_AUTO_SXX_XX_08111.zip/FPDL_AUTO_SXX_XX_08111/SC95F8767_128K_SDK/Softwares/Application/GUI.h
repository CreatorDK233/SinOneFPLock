#ifndef GUI_H
#define GUI_H

#include "global_variable.h"
#include "StdTypes.h"

extern VoiceMenuMgr_t VoiceMenuMgr;
extern DataInputMgr_t DataInputMgr;
extern PasscodeInputMgr_t PasscodeInputMgr;
extern DisplayDoorStatusMgr_t DisplayDoorStatusMgr;
extern ErrorMessageMgr_t ErrorMessageMgr;
extern AwakeSystemKeyMgr_t AwakeSystemKeyMgr;
extern AwakeDisplayMgr_t AwakeDisplayMgr;
extern void VoiceReportOneEventLog(uint16_t EventLogID);
extern void GoIntoLogMenu_Init(void);


#define Def_CardDetectIntervalTime	Def_GuiTimeDelayCnt05s
#define Def_WaitUserInputPasscodeTimeDelay	Def_GuiTimeDelayCnt10s

#define DEF_FpIdentifyFailedTimesLimited	4
#define DEF_CardIdentifyFailedTimesLimited	4
#define DEF_PasscodeIdentifyFailedTimesLimited  4
#define DEF_ManagerPasscodeIdentifyFailedTimesLimited 5
#define DEF_ManagerFpIdentifyFailedTimesLimited   5


#define DEF_SystemLockedTime	11160	//180s
#define DEF_AntiPryingTime		11160	//180s

#define DEF_StrongUnlockingIntervalLimited		15			//in second

#define Def_IdentifySuccessScreenTimeLimited 2560		//40s
#define Def_BodyInductionDelayTime_AntiTurningBack  20 //15s
#define Def_UserSwingCardTimeDelay	512	//8s

extern void GUI_Task(void);
extern void GUI_Init(void);

extern void ShowManagerIdentify(void);
extern void ShowInitialization(void);
extern void ShowLowBattery(void);
extern void ShowIdentifySuccessPage(void);
extern void ShowIdentifyFailPage(void);
extern void ShowSelfTest(void);
extern void ShowAgingTest(void);
extern void ShowSystemLocked(void);
extern void ShowUnlockingModeSetting(void);
extern void ShowInfoInquiryMenu(void);
extern void ShowEventLogBySequence(void);
extern void ShowClearEventLog(void);
extern void ShowPickLockAlarm(void);
extern void ShowDoorLockSettingMenu(void);
extern void ShowBodyInductionSetting(void);
extern void ShowSystemVersion(void);
extern void ShowEngineeringModeMenu(void);
extern void ShowAutoMotorUnlockTimeSetting(void);
extern void ShowAutoMotorAutoLockTimeSetting(void);
extern void ShowAutoMotorLockDirectionSetting(void);
extern void ShowAutoMotorTorqueSetting(void);
extern void ShowBoltLockTimeSetting(void);
extern void ShowLockingTravelSetting(void);
extern void ShowAutoEjectSetting(void);
extern void ShowAutoMotorSelfTest(void);
extern void ShowWifiManufactureTest(void);
extern void ShowErrorMessage(void);
extern void VoiceReportCurrentPickAlarmEnableSetting(void);
















#endif
