#ifndef __Project__
#define __Project__

#include "SC95F876x_C.H"

//#define DEBUG_MODE

//��64Z24�����⣬��Ϊ����rtc
//JUN
//#define ProjectIs_BarLock_S64Z24		//ƽͷ�� ����
//#define	ProjectIs_BarLock_S06Z09		//����
//#define ProjectIs_BarLock_S64Z31    //����� ����
//#define ProjectIs_BarLock_S64Z48		//�º�� ����
//#define ProjectIs_BarLock_S64Z61		//		����
//#define	ProjectIs_BarLock_S06Z10		//����
//LONG
//#define ProjectIs_BarLock_S15Z07		//����(B96)����Radar
//#define ProjectIs_BarLock_S15Z08		//����(B66)ֱ������
//#define ProjectIs_BarLock_S15Z09		//����(B92)����Radar
#define	ProjectIs_BarLock_S101Z01		//�᱾
//#define	ProjectIs_BarLock_S111Z01		//

//#define Function_FaceRecoginitionSwitchedByNFC

#ifdef ProjectIs_BarLock_S64Z24
#define DEF_CustomerNumber	64			//should be less than 256
#define DEF_ModelNumber			24			//should be less than 256
#define DEF_HardwareVerion	105			//should be less than 256
#define DEF_FirmwareVerion	116			//should be less than 256
#define Function_AppUnlock
#define Function_ScreenDisplay
//#define Function_DisplayUsed_OLED128X64
#define Function_DisplayUsed_HFG12864
#define Function_TouchUsed_SinOne
#define Function_FPMserialNumberCheck
#define Function_DisableFpmDuplicateCheck
#define Function_FPMBreathingLed
//#define Function_FM17622_LPCD
#define Function_MainBoardWithoutVoicePlayer
#define Function_AntiPryingDefaultDisabled
#define Function_IndependentDoorBellKey
#define Function_IndependentLockKey
#define Function_FaceRecoginition
#define Function_FaceRecoginitionSwitchedAutoDetection
//#define Function_FaceRegisterMultiTimes		//һ�㲻��
#define Function_FaceRegisterSingleTimes
#define Function_BodyInductionByIR
//#define Function_BodyInductionByRadar
#define Function_EventLog
#define Function_VoiceReportFaceStatusWhileIdendify
#define Function_USE_Internal_RTC
//#define Function_YouzhiyunjiaWifi
//#define Function_TuyaWifi
//#define Function_DynamicSensitivity

#elif defined ProjectIs_BarLock_S64Z31
#define DEF_CustomerNumber	64			//should be less than 256
#define DEF_ModelNumber			31			//should be less than 256
#define DEF_HardwareVerion	105			//should be less than 256
#define DEF_FirmwareVerion	102			//should be less than 256
#define Function_AppUnlock
#define Function_ScreenDisplay
//#define Function_DisplayUsed_OLED128X64
#define Function_DisplayUsed_HFG12864
#define Function_TouchUsed_SinOne
#define Function_FPMserialNumberCheck
#define Function_DisableFpmDuplicateCheck
#define Function_FPMBreathingLed
//#define Function_FM17622_LPCD
#define Function_MainBoardWithoutVoicePlayer
#define Function_AntiPryingDefaultDisabled
#define Function_IndependentDoorBellKey
#define Function_IndependentLockKey
#define Function_FaceRecoginition
#define Function_FaceRecoginitionSwitchedAutoDetection
//#define Function_FaceRegisterMultiTimes		//һ�㲻��
#define Function_FaceRegisterSingleTimes
#define Function_BodyInductionByIR
//#define Function_BodyInductionByRadar
#define Function_EventLog
#define Function_VoiceReportFaceStatusWhileIdendify
#define Function_USE_Internal_RTC
//#define Function_YouzhiyunjiaWifi
//#define Function_TuyaWifi
#define Function_DynamicSensitivity

#elif defined ProjectIs_BarLock_S64Z48
#define DEF_CustomerNumber	64			//should be less than 256
#define DEF_ModelNumber		48			//should be less than 256
#define DEF_HardwareVerion	105			//should be less than 256
#define DEF_FirmwareVerion	109		//should be less than 256
#define Function_AppUnlock
#define Function_ScreenDisplay
//#define Function_DisplayUsed_OLED128X64
#define Function_DisplayUsed_HFG12864
#define Function_TouchUsed_SinOne
#define Function_FPMserialNumberCheck
#define Function_DisableFpmDuplicateCheck
#define Function_FPMBreathingLed
//#define Function_FM17622_LPCD
#define Function_MainBoardWithoutVoicePlayer
#define Function_AntiPryingDefaultDisabled
#define Function_IndependentDoorBellKey
#define Function_IndependentLockKey
#define Function_FaceRecoginition
#define Function_FaceRecoginitionSwitchedAutoDetection
//#define Function_FaceRegisterMultiTimes		//һ�㲻��
#define Function_FaceRegisterSingleTimes
#define Function_BodyInductionByIR
//#define Function_BodyInductionByRadar
#define Function_EventLog
#define Function_VoiceReportFaceStatusWhileIdendify
#define Function_USE_Internal_RTC
//#define Function_YouzhiyunjiaWifi
//#define Function_TuyaWifi
#define Function_DynamicSensitivity

#elif defined ProjectIs_BarLock_S64Z61
#define DEF_CustomerNumber	64			//should be less than 256
#define DEF_ModelNumber			61			//should be less than 256
#define DEF_HardwareVerion	107			//should be less than 256
#define DEF_FirmwareVerion	100			//should be less than 256
#define Function_AppUnlock
#define Function_ScreenDisplay
//#define Function_DisplayUsed_OLED128X64
#define Function_DisplayUsed_HFG12864
#define Function_TouchUsed_SinOne
#define Function_FPMserialNumberCheck
#define Function_DisableFpmDuplicateCheck
#define Function_FPMBreathingLed
//#define Function_FM17622_LPCD
#define Function_MainBoardWithoutVoicePlayer
#define Function_AntiPryingDefaultDisabled
#define Function_IndependentDoorBellKey
#define Function_IndependentLockKey
#define Function_FaceRecoginition
#define Function_FaceRecoginitionSwitchedAutoDetection
//#define Function_FaceRegisterMultiTimes		//һ�㲻��
#define Function_FaceRegisterSingleTimes
#define Function_BodyInductionByIR
//#define Function_BodyInductionByRadar
#define Function_EventLog
#define Function_VoiceReportFaceStatusWhileIdendify
#define Function_USE_Internal_RTC
//#define Function_YouzhiyunjiaWifi
//#define Function_TuyaWifi
#define Function_DynamicSensitivity

#elif defined ProjectIs_BarLock_S15Z07
#define DEF_CustomerNumber	15		//should be less than 256
#define DEF_ModelNumber			7			//should be less than 256
#define DEF_HardwareVerion	100		//should be less than 256
#define DEF_FirmwareVerion	118		//should be less than 256
#define Function_AppUnlock
#define Function_ScreenDisplay
//#define Function_DisplayUsed_OLED128X64
#define Function_DisplayUsed_HFG12864
#define Function_TouchUsed_SinOne
#define Function_FPMserialNumberCheck
#define Function_DisableFpmDuplicateCheck
#define Function_FPMBreathingLed
//#define Function_FM17622_LPCD
//#define Function_MainBoardWithoutVoicePlayer
#define Function_AntiPryingDefaultDisabled
//#define Function_IndependentDoorBellKey
//#define Function_IndependentLockKey
#define Function_FaceRecoginition
#define Function_FaceRecoginitionSwitchedAutoDetection
//#define Function_FaceRegisterMultiTimes		//һ�㲻��
#define Function_FaceRegisterSingleTimes
//#define Function_BodyInductionByIR
#define Function_BodyInductionByRadar
#define Function_EventLog
#define Function_VoiceReportFaceStatusWhileIdendify
#define Function_USE_Internal_RTC
//#define Function_YouzhiyunjiaWifi
//#define Function_TuyaWifi
#define Function_DynamicSensitivity

#elif defined ProjectIs_BarLock_S15Z08
#define DEF_CustomerNumber	15		//should be less than 256
#define DEF_ModelNumber			8			//should be less than 256
#define DEF_HardwareVerion	100		//should be less than 256
#define DEF_FirmwareVerion	118		//should be less than 256
#define Function_AppUnlock
#define Function_ScreenDisplay
//#define Function_DisplayUsed_OLED128X64
#define Function_DisplayUsed_HFG12864
#define Function_TouchUsed_SinOne
#define Function_FPMserialNumberCheck
#define Function_DisableFpmDuplicateCheck
#define Function_FPMBreathingLed
//#define Function_FM17622_LPCD
//#define Function_MainBoardWithoutVoicePlayer
#define Function_AntiPryingDefaultDisabled
//#define Function_IndependentDoorBellKey
//#define Function_IndependentLockKey
#define Function_FaceRecoginition
#define Function_FaceRecoginitionSwitchedAutoDetection
//#define Function_FaceRegisterMultiTimes		//һ�㲻��
#define Function_FaceRegisterSingleTimes
#define Function_BodyInductionByIR
//#define Function_BodyInductionByRadar
#define Function_EventLog
#define Function_VoiceReportFaceStatusWhileIdendify
#define Function_USE_Internal_RTC
//#define Function_YouzhiyunjiaWifi
//#define Function_TuyaWifi
#define Function_DynamicSensitivity

#elif defined ProjectIs_BarLock_S15Z09
#define DEF_CustomerNumber	15		//should be less than 256
#define DEF_ModelNumber			9			//should be less than 256
#define DEF_HardwareVerion	100		//should be less than 256
#define DEF_FirmwareVerion	118		//should be less than 256
#define Function_AppUnlock
#define Function_ScreenDisplay
//#define Function_DisplayUsed_OLED128X64
#define Function_DisplayUsed_HFG12864
#define Function_TouchUsed_SinOne
#define Function_FPMserialNumberCheck
#define Function_DisableFpmDuplicateCheck
#define Function_FPMBreathingLed
//#define Function_FM17622_LPCD
//#define Function_MainBoardWithoutVoicePlayer
#define Function_AntiPryingDefaultDisabled
//#define Function_IndependentDoorBellKey
//#define Function_IndependentLockKey
#define Function_FaceRecoginition
#define Function_FaceRecoginitionSwitchedAutoDetection
//#define Function_FaceRegisterMultiTimes		//һ�㲻��
#define Function_FaceRegisterSingleTimes
//#define Function_BodyInductionByIR
#define Function_BodyInductionByRadar
#define Function_EventLog
#define Function_VoiceReportFaceStatusWhileIdendify
#define Function_USE_Internal_RTC
//#define Function_YouzhiyunjiaWifi
//#define Function_TuyaWifi
#define Function_DynamicSensitivity

#elif defined ProjectIs_BarLock_S06Z09
#define DEF_CustomerNumber	6			//should be less than 256
#define DEF_ModelNumber			9			//should be less than 256
#define DEF_HardwareVerion	100			//should be less than 256
#define DEF_FirmwareVerion	108			//should be less than 256
#define Function_AppUnlock
#define Function_ScreenDisplay
//#define Function_DisplayUsed_OLED128X64
#define Function_DisplayUsed_HFG12864
#define Function_TouchUsed_SinOne
#define Function_FPMserialNumberCheck
#define Function_DisableFpmDuplicateCheck
#define Function_FPMBreathingLed
#define Function_FM17622_LPCD
#define Function_MainBoardWithoutVoicePlayer
#define Function_AntiPryingDefaultDisabled
//#define Function_IndependentDoorBellKey
//#define Function_IndependentLockKey
#define Function_FaceRecoginition
#define Function_FaceRecoginitionSwitchedAutoDetection
//#define Function_FaceRegisterMultiTimes		//һ�㲻��
#define Function_FaceRegisterSingleTimes
//#define Function_BodyInductionByIR
#define Function_BodyInductionByRadar
#define Function_EventLog
#define Function_VoiceReportFaceStatusWhileIdendify
#define Function_USE_Internal_RTC
//#define Function_YouzhiyunjiaWifi
//#define Function_TuyaWifi

#elif defined ProjectIs_BarLock_S06Z10
#define DEF_CustomerNumber	6			//should be less than 256
#define DEF_ModelNumber			10			//should be less than 256
#define DEF_HardwareVerion	100			//should be less than 256
#define DEF_FirmwareVerion	100			//should be less than 256
#define Function_AppUnlock
#define Function_ScreenDisplay
//#define Function_DisplayUsed_OLED128X64
#define Function_DisplayUsed_HFG12864
#define Function_TouchUsed_SinOne
#define Function_FPMserialNumberCheck
#define Function_DisableFpmDuplicateCheck
#define Function_FPMBreathingLed
#define Function_FM17622_LPCD
#define Function_MainBoardWithoutVoicePlayer
#define Function_AntiPryingDefaultDisabled
//#define Function_IndependentDoorBellKey
#define Function_IndependentLockKey
#define Function_FaceRecoginition
#define Function_FaceRecoginitionSwitchedAutoDetection
//#define Function_FaceRegisterMultiTimes		//һ�㲻��
#define Function_FaceRegisterSingleTimes
#define Function_BodyInductionByIR
//#define Function_BodyInductionByRadar
#define Function_EventLog
#define Function_VoiceReportFaceStatusWhileIdendify
#define Function_USE_Internal_RTC
//#define Function_YouzhiyunjiaWifi
//#define Function_TuyaWifi
#define Function_DynamicSensitivity

#elif defined ProjectIs_BarLock_S101Z01
#define DEF_CustomerNumber	101			//should be less than 256
#define DEF_ModelNumber			1			//should be less than 256
#define DEF_HardwareVerion	100			//should be less than 256
#define DEF_FirmwareVerion	110			//should be less than 256
#define Function_AppUnlock
#define Function_ScreenDisplay
//#define Function_DisplayUsed_OLED128X64
#define Function_DisplayUsed_HFG12864
#define Function_TouchUsed_SinOne
#define Function_FPMserialNumberCheck
#define Function_DisableFpmDuplicateCheck
#define Function_FPMBreathingLed
#define Function_FM17622_LPCD
//#define Function_MainBoardWithoutVoicePlayer
#define Function_AntiPryingDefaultDisabled
#define Function_IndependentDoorBellKey
#define Function_IndependentLockKey
#define Function_FaceRecoginition
#define Function_FaceRecoginitionSwitchedAutoDetection
//#define Function_FaceRegisterMultiTimes		//һ�㲻��
#define Function_FaceRegisterSingleTimes
#define Function_BodyInductionByIR
//#define Function_BodyInductionByRadar
#define Function_EventLog
#define Function_VoiceReportFaceStatusWhileIdendify
#define Function_USE_Internal_RTC
//#define Function_YouzhiyunjiaWifi
//#define Function_TuyaWifi
#define Function_DynamicSensitivity

#elif defined ProjectIs_BarLock_S111Z01
#define DEF_CustomerNumber	101			//should be less than 256
#define DEF_ModelNumber			1			//should be less than 256
#define DEF_HardwareVerion	100			//should be less than 256
#define DEF_FirmwareVerion	100			//should be less than 256
#define Function_AppUnlock
#define Function_ScreenDisplay
//#define Function_DisplayUsed_OLED128X64
#define Function_DisplayUsed_HFG12864
#define Function_TouchUsed_SinOne
#define Function_FPMserialNumberCheck
#define Function_DisableFpmDuplicateCheck
#define Function_FPMBreathingLed
#define Function_FM17622_LPCD
//#define Function_MainBoardWithoutVoicePlayer
#define Function_AntiPryingDefaultDisabled
//#define Function_IndependentDoorBellKey
#define Function_IndependentLockKey
#define Function_FaceRecoginition
#define Function_FaceRecoginitionSwitchedAutoDetection
//#define Function_FaceRegisterMultiTimes		//һ�㲻��
#define Function_FaceRegisterSingleTimes
//#define Function_BodyInductionByIR
#define Function_BodyInductionByRadar
#define Function_EventLog
#define Function_VoiceReportFaceStatusWhileIdendify
#define Function_USE_Internal_RTC
//#define Function_YouzhiyunjiaWifi
//#define Function_TuyaWifi
//#define Function_DynamicSensitivity



#endif

#define DEF_SystemSleepDelayTime_MainScreen		640		//10s

#define DEF_SystemSleepDelayTime_MenuScreen		1920	//30s

#define Def_GuiTimeDelayCnt45s			2880		//45s



#ifdef DEBUG_MODE 
#define DEBUG_MARK {Soft_Delay(1);}
#define EnableWDT()	//
					//Enable watch dog  //Disable Protection  //1/256		//862ms			//Refresh WDG Timer and Enable Protection
#define CLRWDT()	//
#else
#define DEBUG_MARK //_nop_(); 
#define EnableWDT()	 WDTCON &= 0x00;   //Utilites����DEBUG Setting customer����WDTʹ�� bit4��CLRWDT Biy[2:0] WDTCKS 500ms
					
#define CLRWDT()   WDTCON |= 0x10;
#endif




#endif
