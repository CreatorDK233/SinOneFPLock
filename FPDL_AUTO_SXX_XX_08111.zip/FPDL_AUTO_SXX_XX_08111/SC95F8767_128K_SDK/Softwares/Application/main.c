#include "i2c.h"
#include "usart.h"
#include "spi.h"
#include "tim.h"
#include "pwm.h"
#include "IO.h"
#include "LCD_HFG12864.h"
#include <string.h>
#include "RTC_PCF8563.h"
#include "RTC.h"
#include "adc.h"
#include "BeepMgr.h"
#include "Key_SinOne.h"
#include "MFC_MF17622.h"
#include "GUI_Function.h"
#include "Basic_Function.h"
#include "Flash.h"
#include "FingerPrint.h"
#include "LEDsMgr.h"
#include "Motor.h"
#include "Battery.h"
#include "HallSlide.h"
#include "Log.h"
#include "LowPower.h"
#include "FP.h"
#include "GUI.h"
#include "GUI2.h"
#include "HostUart.h"

#include "FaceRecoginitionMgr.h"
#include "PIR.h"
#include "Radar.h"
#include "YouzhiyunjiaWifi.h"

/**************************************************************
˵����
***************************************************************/
uint8_t ReadRTC = 0;
extern void BTM_Init(void);
extern uint16_t a2d_data[1];
uint8_t bufftext[2]={0};

//uint8_t system_IC_busy_Flag = 0;
void Main_System_Init(void)
{
	EnableWDT();
	MX_GPIO_Init();
	MX_ADC1_Init();	
	MX_TIM_Init();
	BTM_Init();
	MX_SPI0_Init();
	MX_I2C_Init();
	#ifdef Function_FaceRecoginition	
	Uart0_Init(32,115200);
	#endif
	MX_USART1_UART_Init();
	MX_USART2_UART_Init();
	
	SYSPOWER_ON;
	SET_LEDPOWER_ON;
	
	FPcmd_Init();
	FPMpowerMgr.Status = FPMpowerOn;
	ComPort_Init();
	SystemConfigLoad();
	#ifdef Function_BodyInductionByRadar
		BodyInductionConfigLoad();
		Radar_Init();
	#endif
	#ifdef Function_FaceRecoginition	
	if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
	{	
			FaceRecognitionMgr_Init();
	}
	#endif	
	#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
	Wifi_Init();
	#endif
	VOICE_Init();
	
	MFC_Init();
	Hardware_DelayMs(10);
	Touch_Init();
	AwakeSystemKeyMgr.IsDoorBellKeyAwake = bFALSE;
	AwakeSystemKeyMgr.IsDoorColseKeyAwake = bFALSE;
	AwakeSystemKeyMgr.IsPoundsignKeyAwake = bFALSE;
	Hardware_DelayMs(10);
	GUI_Init();
	PIR_Init();
	MX_RTC_Init();
	
	SafetyMonitorMgr.FpIdentifyFailedTimes = 0x00;
    SafetyMonitorMgr.CardIdentifyFailedTimes = 0x00;
    SafetyMonitorMgr.PasscodeIdentifyFailedTimes = 0x00;
	SafetyMonitorMgr.ManagerPasscodeIdentifyFailedTimes = 0x00;
	SafetyMonitorMgr.ManagerFpIdentifyFailedTimes = 0x00;
	SafetyMonitorMgr.SystemLocked = bFALSE;
	BodyInductionMgr.BodyInductionDelayTimeCnt = 0;
		
	LogMgr_Init();
	LEDsMgr_Init();
	
	CurrentScreen = SCREEN_Initialization;
	InitializationMgr.Status = StartInitialization;
	FrmConnectionCheckMgr.Status = FrmCheckInit;
	BatteryMgr.ProtectVoltageTriggerTimes = 0;
	BatteryMgr.LowBatteryProtectionEnabled = bFALSE;
	BatteryMgr.BatteryVoltage = 0;
	StrongUnlockMgr.LastUTCtime = 0x00000000;
	StrongUnlockMgr.TrigStrongUnlocking = bFALSE;
	
	GUI_RefreshSleepTime();
	
	ComportMgr.PostOnlinePasswordVerify = 0;
	ComportMgr.PostMotorSelftest = 0;
	ComportMgr.PostGetNetworkTime = 0;
	ComportMgr.PostGetVoicePlayerStatus=0;
	ComportMgr.PostCloseDoor=0;
	ComportMgr.PostOpenDoor=0;
	ComportMgr.PostWifiHostSpot=0;
	ComportMgr.PostExitWifiHostSpot=0;
	ComportMgr.PostClearWifiData=0;
	ComportMgr.PostRemoteUnlock=0;
	ComportMgr.PostExitRemoteUnlock=0;
	ComportMgr.TimeSyncWithNetwork = bFALSE;
	SaveTime.SavedDateWhileNetWorkTimeUpdated = 0;
	SaveTime.SavedMonthWhileNetWorkTimeUpdated = 0;
	AgingTestMgr.TimeCnt = 0x0000;//Ensure FPM starts in red

//	uint8_t PostParameter;
//	uint8_t PostStatus;
//	uint8_t PostOpenDoor;
//	uint8_t PostInfo;
//	uint8_t PostAlarm;
//	uint8_t PostWifiMFT;
//	uint8_t PostPositivePowerOnWifi;
//	uint8_t PostPlayVoice_1;
//	uint8_t PostPlayVoice_2;
}

void main(void)
{
	uint8_t i;
	
    FLASH_OB_Config();			//�����պ���
	Main_System_Init();
	
	for (i=0;i<50;i++)						//��ȡ�Ƚ�׼�ĵ�ѹֵ
	{
     Hardware_Task_Analog_Battery();
     HardwareBatteryMgr_Task();
	}
	HardwareBatteryTypeAutoSwitch();		//�Զ�ʶ����﮵�ػ��Ǹɵ��
	for (i=0;i<100;i++)						//���¼����ص����ȼ�
	{
     Hardware_Task_Analog_Battery();
     HardwareBatteryMgr_Task();
	}
	#if (defined ProjectIs_BarLock_S15Z07) || (defined ProjectIs_BarLock_S15Z08) \
					|| (defined ProjectIs_BarLock_S15Z09)
	if( BatteryMgr.BatteryLevel == LEVEL_0 )
	{
		BatteryMgr.PowerSavingMode = bTRUE;
	}
	else{
		BatteryMgr.PowerSavingMode = bFALSE;
	}
	#endif
	
	#ifdef Function_FPMBreathingLed
		GUI_SetFPM_LED(DEF_FpmLedMode_Breath,DEF_FpmLedColor_Blue,DEF_FpmLedColor_Blue,255);
	#endif
	
	while (1)
  {
		if ( G_tflagbits.T1024Hz == 1 )
		{
			G_tflagbits.T1024Hz =0;	
		}
		if ( G_tflagbits.T256Hz == 1 )
		{
			G_tflagbits.T256Hz =0;		
		}
		
		if ( G_tflagbits.T128Hz == 1 )
		{
			G_tflagbits.T128Hz = 0;
			LastIOStatus.AntiPryingInt = PINMACRO_PICKLOCK_STATUS;
		 	ComPort_Mgr_Task();
		}	
		
		if ( G_tflagbits.T64Hz == 1 )
		{
			G_tflagbits.T64Hz = 0;
	
			#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
				Wifi_Mgr_Task();
			#endif
			
			#ifdef Function_FaceRecoginition
			if ( FrmMgr.FrmFunctionConfig == FRM_Enabled )
			{
				FaceRecognitionMgr_Task();
			}
			#endif
			
			FPM_Mgr_Task();

//			#ifdef Function_DisplayUsed_OLED128X64
//				OLED_Display_Task();
//			#endif

			LEDsMgr_Task();
			
			GUI_Task();
			
			if ( SystemPowerMgr.SleepDelayTimerCnt > 0 )
			{
                SystemPowerMgr.SleepDelayTimerCnt--;
			}
			
			if (SystemPowerMgr.AwakeTimerCnt < 60)
			{
				SystemPowerMgr.AwakeTimerCnt++;
			}

			if ( ( SystemPowerMgr.SleepDelayTimerCnt == 0x0000 ) 
				//&&( PINMACRO_KB_IRQ_STATUS!=0x00 )
				&&( CurrentScreen != SCREEN_Initialization )
				&&( CurrentScreen != SCREEN_PickLockAlarm )
				&&( CurrentScreen != SCREEN_SystemLocked )
				&&( CurrentScreen != SCREEN_AgingTest )
				&&(CurrentScreen != SCREEN_SelfTest)
				&&( CurrentScreen != SCREEN_IdentifySuccess )
				#if defined (Function_YouzhiyunjiaWifi) || defined (Function_TuyaWifi)
				&&(WifiMgr.Power.Status == PowerOff)	
				#endif
				&&( ( ( ComportMgr.Status == AckIdle ) && ( ComportMgr.DoorStatus == Standby) )
					|| ( ComportMgr.TimeOutTimes > 5) ) )
				{
					System_PowerDown();
					System_Awake();
					CLRWDT();
					GUI_RefreshSleepTime();
					SystemPowerMgr.AwakeTimerCnt = 0x0000;	
				}
			}
		if ( G_tflagbits.T16Hz == 1 )
		{
			G_tflagbits.T16Hz = 0;
			#ifdef Function_DisplayUsed_HFG12864
			for( i=0; i<8; i++ )
			{
				Display_Task();	
			}
			#endif				
		}	
		if ( G_tflagbits.T8Hz == 1 )
		{
			G_tflagbits.T8Hz = 0;
			CLRWDT();
			if ( CurrentScreen == SCREEN_AgingTest )
			{
				Hardware_Task_Analog_Battery();
				HardwareBatteryMgr_Task();
			}
//			#ifdef Function_DisplayUsed_HFG12864
//			for( i=0; i<8; i++ )
//			{
//				Display_Task();	
//			}
//			#endif				
		}

		if ( G_tflagbits.T2Hz == 1 )
		{
			G_tflagbits.T2Hz =0;
		}
		
		if ( G_tflagbits.T1Hz == 1 )
		{
			G_tflagbits.T1Hz =0;
			
			//Uart_Test1();
	
			SystemTimeUpdate();		

			//EEPROM_TESTING();

			//MFC_Test();
			//Flash_Test();
			//AppUnlockTest();
			
			DEBUG_MARK;

		}
  }
}
