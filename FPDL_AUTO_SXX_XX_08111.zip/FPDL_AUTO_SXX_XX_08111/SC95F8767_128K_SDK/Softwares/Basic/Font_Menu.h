#ifndef _Font_Menu_H_
#define _Font_Menu_H_

#include "StdTypes.h"

code uint8_t InputUserIDStr[];
code uint8_t InputUserIDStrEn[];
code uint8_t IDisNotRegisteredStr[];
code uint8_t IDisNotRegisteredStrEn[];
code uint8_t IDisRegisteredStr[];
code uint8_t IDisRegisteredStrEn[];

code uint8_t PleaseAddMasterStr[];
code uint8_t PleaseAddMasterStrEn[];


code uint8_t InputPasscodeStr[];
code uint8_t InputPasscodeStrEn[];
code uint8_t ConfirmPasscode[];
code uint8_t ConfirmPasscodeEn[];


code uint8_t AutoEjectEnableStr[];
code uint8_t AutoEjectEnableStrEn[];

code uint8_t AutoEjectDisableStr[];
code uint8_t AutoEjectDisableStrEn[];

code uint8_t FpUserStr[];
code uint8_t FpUserStrEn[];

code uint8_t CardUserStr[];
code uint8_t CardUserStrEn[];

code uint8_t PasscodeUserStr[];
code uint8_t PasscodeUserStrEn[];

code uint8_t TemporaryPasswordStr[];
code uint8_t TemporaryPasswordStrEn[];

code uint8_t FaceUserStr[];
code uint8_t FaceUserStrEn[];

code uint8_t IDStr[];
code uint8_t IDStrEn[];

code uint8_t UserIDStr[];
code uint8_t UserIDStrEn[];

code uint8_t NoEventLogStr[];
code uint8_t NoEventLogStrEn[];

code uint8_t UserIsFullStr[];
code uint8_t UserIsFullStrEn[];

code uint8_t OperationSuccessStr[];
code uint8_t OperationSuccessStrEn[];

code uint8_t OperationFailStr[];
code uint8_t OperationFailStrEn[];

code uint8_t Yes[];
code uint8_t YesEn[];

code uint8_t No[];
code uint8_t NoEn[];

code uint8_t FaceRepeated[];
code uint8_t FaceRepeatedEn[];

code uint8_t FingerprintRepeated[];
code uint8_t FingerprintRepeatedEn[];

code uint8_t CanNotDeleteLastOneMasterStr1[];
code uint8_t CanNotDeleteLastOneMasterStr1En[];

code uint8_t CanNotDeleteLastOneMasterStr2[];
code uint8_t CanNotDeleteLastOneMasterStr2En[];

code uint8_t ConfirmDeleteStr[];
code uint8_t ConfirmDeleteStrEn[];
code uint8_t AbortDeleteStr[];
code uint8_t AbortDeleteStrEn[];


code uint8_t ConfirmRestoreFactoryDefaultStr1[];
code uint8_t ConfirmRestoreFactoryDefaultStr2[];
code uint8_t ConfirmRestoreFactoryDefaultStr1En[];
code uint8_t ConfirmRestoreFactoryDefaultStr2En[];


code uint8_t RestoreFactoryDoingStr1[];
code uint8_t RestoreFactoryDoingStr2[];
code uint8_t RestoreFactoryDoingStr1En[];
code uint8_t RestoreFactoryDoingStr2En[];


code uint8_t UnlockLogStr[];
code uint8_t UnlockLogStrEn[];

code uint8_t SingalModeStr[];
code uint8_t SingalModeStrEn[];
code uint8_t DoubleModeStr[];
code uint8_t DoubleModeStrEn[];

code uint8_t AntiPryingEnableStr[];
code uint8_t AntiPryingEnableStrEn[];
code uint8_t AntiPryingDisableStr[];
code uint8_t AntiPryingDisableStrEn[];


code uint8_t SystemNoSecondIdentityStr[];
code uint8_t SystemNoSecondIdentityStrEn[];

code uint8_t FpMasterIDRangeStrEn[];
code uint8_t FpUserIDRangeStrEn[];
code uint8_t CardUserIDRangeStrEn[];
code uint8_t PasscodeIDRangeStrEn[];

code uint8_t SystemLockedStr[];
code uint8_t SystemLockedStrEn[];

code uint8_t PleaseSwingCardStr[];
code uint8_t PleaseSwingCardStrEn[];
code uint8_t CardCIDisBeUsedStr[];
code uint8_t CardCIDisBeUsedStrEn[];

code uint8_t AntiPryingAlarmStr[];
code uint8_t AntiPryingAlarmStrEn[];
code uint8_t RemovalAlarmStr1[];
code uint8_t RemovalAlarmStr1En[];
code uint8_t RemovalAlarmStr2[];
code uint8_t RemovalAlarmStr2En[];

code uint8_t ReplaceBatteryStr1En[];
code uint8_t ReplaceBatteryStr2En[];

code uint8_t PleaseWaitStr[];
code uint8_t PleaseWaitStrEn[];

code uint8_t IdentifyFailStr[];
code uint8_t IdentifyFailStrEn[];

code uint8_t PressPoundKeyToConfirmStr[];
code uint8_t PressAsteriskKeyToReturnStr[];
code uint8_t PressPoundKeyToConfirmStrEn[];
code uint8_t PressAsteriskKeyToReturnStrEn[];

code uint8_t InputErrorStr[];
code uint8_t InputErrorStrEn[];

code uint8_t NoNetworkDeviceStr[];
code uint8_t NoNetworkDeviceStrEn[];

extern code uint8_t MainMenuStr[][10];
extern code uint8_t MainMenuStrEn[][16];
extern code uint8_t FpMenuStr[][11];
extern code uint8_t FpMenuStrEn[][18];
extern code uint8_t CardUserMenuStr[][11];
extern code uint8_t CardUserMenuStrEn[][18];
extern code uint8_t PassCodeMenuStr[][11];
extern code uint8_t PassCodeMenuStrEn[][18];
extern code uint8_t FaceMenuStr[][11];
extern code uint8_t FaceMenuStrEn[][18];
extern code uint8_t EventLogMenuStr[][10];
extern code uint8_t EventLogMenuStrEn[][16];
extern code uint8_t SytemConfigMenuStr[][9];
extern code uint8_t SytemConfigMenuStrEn[][18];

extern code uint8_t UserManagementMenuStr_WithFRM[][10];
extern code uint8_t UserManagementMenuStrEn_WithFRM[][16];
extern code uint8_t UserManagementMenuStr[][10];
extern code uint8_t UserManagementMenuStrEn[][16];
extern code uint8_t InfoInquiryMenuStr[][9];
extern code uint8_t InfoInquiryMenuStrEn[][16];
extern code uint8_t AutoMotorSetingMenuStr[][10];
extern code uint8_t AutoMotorSetingMenuStrEN[][18];
extern code uint8_t FpDeleteMenuStr[][11];
extern code uint8_t FpDeleteMenuStrEn[][18];
extern code uint8_t VoiceSettingMenuStr[][9];
extern code uint8_t VoiceSettingMenuStrEn[][18];
extern code uint8_t BodyInductionAdjustStr[][7];
extern code uint8_t BodyInductionAdjustStrEn[][9];
extern code uint8_t EngineeringModeMenuStr_WithFRM[][10];
extern code uint8_t EngineeringModeMenuStrEN_WithFRM[][18];
extern code uint8_t EngineeringModeMenuStr[][10];
extern code uint8_t EngineeringModeMenuStrEN[][18];
extern code uint8_t VolumeAdjustStr[][7];
extern code uint8_t VolumeAdjustStrEn[][9];
extern code uint8_t DoorLockSettingMenuStr[][10];
extern code uint8_t DoorLockSettingMenuStrEn[][18];

#endif