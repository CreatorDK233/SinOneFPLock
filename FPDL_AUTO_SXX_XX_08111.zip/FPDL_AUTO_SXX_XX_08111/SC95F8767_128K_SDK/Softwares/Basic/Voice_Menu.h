#ifndef _Voice_Menu_H_
#define _Voice_Menu_H_

#include "StdTypes.h"

extern code uint16_t MainMenuVoiceBuff[][6];
extern code uint16_t UserManagementMenuVoiceBuff_WithFRM[][6];
extern code uint16_t UserManagementMenuVoiceBuff[][6];
extern code uint16_t FaceMenuVoiceBuff[][7];
extern code uint16_t FpMenuVoiceBuff[][8];
extern code uint16_t FpDeleteMenuVoiceBuff[][8];
extern code uint16_t PasscodeMenuVoiceBuff[][7];
extern code uint16_t CardMenuVoiceBuff[][7];
extern code uint16_t InfoInquiryMenuVoiceBuff[][7];
extern uint16_t MemoryUsageVoiceBuff[][10];
extern code uint16_t SystemConfigMenuVoiceBuff[][6];
extern code uint16_t VoiceSettingMenuVoiceBuff[][6];
extern code uint16_t LanguageSetVoiceBuff[][4];
extern code uint16_t VolumeSetVoiceBuff[][5];
extern code uint16_t LogMenuVoiceBuff[][5];
extern code uint16_t VoiceStr_VoiceOpened[];
extern code uint16_t VoiceStr_VoiceClosed[];
extern code uint16_t VoiceStr_NormallyOpenModeOpened[];
extern code uint16_t VoiceStr_NormallyOpenModeClosed[];
extern code uint16_t DoorLockSettingVoiceBuff_WithFRM[][7];
extern code uint16_t DoorLockSettingVoiceBuff[][7];
extern code uint16_t UnlockModeSetVoiceBuff[][4];
extern code uint16_t BodyInductionVoiceBuff[][5];
extern code uint16_t VoiceStr_SingleUnlockModeOpened[];
extern code uint16_t VoiceStr_CombinationUnlockModeOpened[];
extern code uint16_t AntiPryingSettingVoiceBuff[][5];
extern code uint16_t VoiceStr_AntiPryingOpened[];
extern code uint16_t VoiceStr_AntiPryingClosed[];
extern code uint16_t PickAlarmSetVoiceBuff[][5];
extern code uint16_t RestoreFactoryDefaultVoiceBuff[][4];
extern code uint16_t EngineeringModeMenuVoiceBuff_WithFRM[][8];
extern code uint16_t EngineeringModeMenuVoiceBuff[][8];
extern code uint16_t MotorSettingMenuVoiceBuff[][8];
extern code uint16_t UnlockDirrectionSettingVoiceBuff[][4];
extern code uint16_t MotorTorqueSettingVoiceBuff[][5];
extern code uint16_t UnlockTimeSettingVoiceBuff[][7];
extern code uint16_t AutoLockDelayTimeSettingVoiceBuff[][7];
extern code uint16_t BoltLockTimeSettingVoiceBuff[][5];
extern code uint16_t LockingTravelSettingVoiceBuff[][5];
extern code uint16_t AutoEjectSettingVoiceBuff[][5];
extern code uint16_t MotorSelfTestVoiceBuff[][4];
extern uint16_t SystemVersionVoiceBuff[][10];


extern code uint16_t VoiceStr_ConfirmOrExitDelete[];
extern code uint16_t VoiceStr_ConfirmOrExitRestorFactoryDefault[];
extern code uint16_t VoiceStr_RestorFactoryDefaultPleaseWait[];
extern code uint16_t VoiceStr_OperationSuccess[];
extern code uint16_t VoiceStr_OperationFail[];
extern code uint16_t VoiceStr_HardwareNotSupportOperationFail[];
extern code uint16_t VoiceStr_RepeatedFingerprint[];
extern code uint16_t VoiceStr_RepeatedCard[];
extern code uint16_t VoiceStr_RepeatedPassword[];
extern code uint16_t VoiceStr_DeleteFail[];
extern code uint16_t VoiceStr_DeleteSuccess[];
extern code uint16_t VoiceStr_PleaseInputPassword[];
extern code uint16_t VoiceStr_PleaseInputPasswordAgain[];
extern code uint16_t VoiceStr_TimeSetting[];
extern code uint16_t VoiceStr_PleaseInputYear[];
extern code uint16_t VoiceStr_PleaseInputMonth[];
extern code uint16_t VoiceStr_PleaseInputDate[];
extern code uint16_t VoiceStr_PleaseInputHour[];
extern code uint16_t VoiceStr_PleaseInputMinute[];
extern code uint16_t VoiceStr_PleaseInputSecond[];
extern code uint16_t VoiceStr_PleaseInputSecondIdentity[];
extern code uint16_t VoiceStr_FrmFunctionEnabled[];
extern code uint16_t VoiceStr_FrmFunctionDisbled[];
extern code uint16_t VoiceStr_UserIdIsNotExist[];


extern code uint16_t AutoLockOffVoiceStr[];
extern code uint16_t AutoEjectOnVoiceStr[];
extern code uint16_t AutoEjectOffVoiceStr[];
extern code uint16_t NoLogVoiceStr[];

extern code uint16_t VoiceStr_RequestingRemoteUnlock[];

extern code uint16_t VoiceStr_VerifySuccess[];

extern code uint16_t VoiceStr_AddNewMasterPleaseInputPasscode[];



#endif