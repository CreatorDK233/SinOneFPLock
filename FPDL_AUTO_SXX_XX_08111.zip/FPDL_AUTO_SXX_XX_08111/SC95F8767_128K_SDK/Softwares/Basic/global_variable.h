#ifndef _global_variable_H_
#define _global_variable_H_

#include "StdTypes.h"

#define DEF_MAX_CARDUSER		100
#define DEF_MAX_PASSCODEMASTER  2
#define DEF_MAX_PASSCODEUSER	8
#define DEF_MAX_FPMASTER	10
#define DEF_MAX_FPUSER		30
#define DEF_MAX_STRESSFPUSER	10
#define DEF_MAX_FACEMASTER		10
#define DEF_MAX_FACEUSER		90

#define Def_GuiTimeDelayCnt01s	7
#define Def_GuiTimeDelayCnt025s	16
#define Def_GuiTimeDelayCnt05s	32
#define Def_GuiTimeDelayCnt1s	64
#define Def_GuiTimeDelayCnt1s5	96
#define Def_GuiTimeDelayCnt2s	128
#define Def_GuiTimeDelayCnt2s5	160
#define Def_GuiTimeDelayCnt3s	192
#define Def_GuiTimeDelayCnt4s	256
#define Def_GuiTimeDelayCnt5s	320
#define Def_GuiTimeDelayCnt10s	640
#define Def_GuiTimeDelayCnt15s	960
#define Def_GuiTimeDelayCnt20s	1280
#define Def_GuiTimeDelayCnt25s	1600
#define Def_GuiTimeDelayCnt30s	1920
#define Def_GuiTimeDelayCnt35s	2240
#define Def_GuiTimeDelayCnt50s	3200

#define DEF_WifiFlowChartTimeOutDelay	Def_GuiTimeDelayCnt2s			//2s
#define DEF_WifiPowerDelayTime			Def_GuiTimeDelayCnt1s5		//1.5s
#define DEF_WifiFastPowerDelayTime		Def_GuiTimeDelayCnt1s		//1s

#define FPMbreathingLed_Bule		1
#define FPMbreathingLed_Red			2
#define FPMbreathingLed_Green		3
#define FPMbreathingLed_Off  		4

#define Def_IdendtifyFailScreenTimeDelay	Def_GuiTimeDelayCnt3s
#define Def_IdendtifySuccessScreenTimeDelay	 Def_GuiTimeDelayCnt5s
#define Def_MessageBoxTimeDelay	 Def_GuiTimeDelayCnt2s

GLOBAL DriverBoardVersion_t DriverBoardVersion;

GLOBAL Timebase_t G_tflagbits;

GLOBAL systemtime_t SystemTime;
GLOBAL systemtime_t TempSystemTime;
GLOBAL savetime_t SaveTime;
GLOBAL uint32_t G_SystemUTCTime;

GLOBAL  UartMgr_t UART0_Mgr;

GLOBAL  UartMgr_t UART1_Mgr;

GLOBAL  UartMgr_t UART2_Mgr;
GLOBAL  UartEXD_t UART0_EXD;

GLOBAL TimeSettingMgr_t TimeSettingMgr;

GLOBAL VoiceMenuMgr_t VoiceMenuMgr;

//GLOBAL MenuMgr_t MenuMgr;

GLOBAL DataInputMgr_t DataInputMgr;

GLOBAL PasscodeInputMgr_t PasscodeInputMgr;

GLOBAL uint8_t G_DisRAM[1024];

GLOBAL screen_t CurrentScreen;

GLOBAL GUI_FaceTemplateRegisterMgr_t GUI_FaceTemplateRegisterMgr;
GLOBAL FaceUserRegisterMgr_t FaceUserRegisterMgr;
GLOBAL FaceUserDeleteMgr_t FaceUserDeleteMgr;
//GLOBAL AllUserFaceDeleteMgr_t AllUserFaceDeleteMgr;
//GLOBAL CheckHomManyRegisteredFACEuser_t CheckHomManyRegisteredFACEuser;

GLOBAL  FpmAckMgr_t FpmAckMgr;
GLOBAL  FpUserRegisterMgr_t FpUserRegisterMgr;
GLOBAL  AllUserFpDeleteMgr_t	AllUserFpDeleteMgr;
GLOBAL  FpUserDeleteMgr_t	FpUserDeleteMgr;
GLOBAL  FpIdentifyMgr_t FpIdentifyMgr;

GLOBAL  CardMemoryMgr_t CardMemoryMgr[DEF_MAX_CARDUSER];
GLOBAL  CardRegisterMgr_t CardUserRegisterMgr;
GLOBAL  CardIdentifyMgr_t CardIdentifyMgr;
GLOBAL  CardUserDeleteMgr_t CardUserDeleteMgr;
GLOBAL  AllCardUserDeleteMgr_t AllCardUserDeleteMgr;

GLOBAL  FpRegisterMgr_t FpRegisterMgr;

GLOBAL  PasscodeMemoryMgr_t PasscodeMemoryMgr[DEF_MAX_PASSCODEMASTER+DEF_MAX_PASSCODEUSER];
GLOBAL  PasscodeUserRegisterMgr_t PasscodeUserRegisterMgr;
GLOBAL  PasscodeUserDeleteMgr_t PasscodeUserDeleteMgr;
GLOBAL  AllPasscodeUserDeleteMgr_t AllPasscodeUserDeleteMgr;
GLOBAL  PasscodeUserIdentifyMgr_t PasscodeUserIdentifyMgr;
GLOBAL  BatteryMgr_t BatteryMgr;

//GLOBAL  EMAGNETMgr_t EMAGNETMgr;

GLOBAL  SystemPowerMgr_t SystemPowerMgr;

//GLOBAL  BeepMgr_t BeepMgr;

GLOBAL  FpUserMemoryMgr_t FpUserMemoryMgr[DEF_MAX_FPMASTER+DEF_MAX_FPUSER+DEF_MAX_STRESSFPUSER];

GLOBAL  RestoreFactoryDefaultMgr_t RestoreFactoryDefaultMgr;

GLOBAL  VoiceMgr_t VoiceMgr;
GLOBAL  PickAlarmEnableMgr_t PickAlarmEnableMgr;

GLOBAL  CheckHomManyRegisteredFPuser_t CheckHomManyRegisteredFPuser;
GLOBAL  CheckIfFpUserIDisRegistered_t CheckIfFpUserIDisRegistered;
GLOBAL  CheckMemoryMgr_t CheckMemoryMgr;
GLOBAL  ManagerIdentifyMgr_t ManagerIdentifyMgr;
GLOBAL  DisplayMemoryUsageMgr_t DisplayMemoryUsageMgr;
GLOBAL  InitializationMgr_t InitializationMgr;
GLOBAL  FrmConnectionCheckMgr_t FrmConnectionCheckMgr;
//GLOBAL  ManagerPasscodeModifyMgr_t	ManagerPasscodeModifyMgr;
GLOBAL  UserIdentifyResultMgr_t	UserIdentifyResultMgr;
GLOBAL  SelfTestMgr_t SelfTestMgr;

GLOBAL  SafetyMonitorMgr_t SafetyMonitorMgr;
//GLOBAL  UnlockingModeMgr_t UnlockingModeMgr;

GLOBAL VoiceDataTransferMgr_t VoiceDataTransferMgr; 
GLOBAL VoiceDataBufferMgr_t VoiceDataBufferMgr;


GLOBAL  FPMpowerMgr_t FPMpowerMgr;

GLOBAL  bool_t g_ASTERISK_PressedOnMainScreen; 
GLOBAL  AgingTestMgr_t AgingTestMgr;

GLOBAL  LogMgr_t LogMgr;

GLOBAL LockBrand_t LockBrand;

GLOBAL CheckEventLogByDateMgr_t CheckEventLogByDateMgr;

GLOBAL CheckEventLogBySequenceMgr_t CheckEventLogBySequenceMgr;

GLOBAL VoiceReportLogMgr_t VoiceReportLogMgr;

//GLOBAL TouchPowerMgr_t TouchPowerMgr;

GLOBAL SystemLanguage_t SystemLanguage;

GLOBAL AntiPryingMgr_t AntiPryingMgr;

GLOBAL LogDeleteMgr_t LogDeleteMgr;

GLOBAL FPMserialNumberManager_t FPMserialNumberManager;

GLOBAL LEDsMgr_t LEDsMgr;

GLOBAL WifiMgr_t WifiMgr;

GLOBAL ComportMgr_t ComportMgr;

GLOBAL AutoMotorMgr_t  AutoMotorMgr;

GLOBAL DisplayDoorStatusMgr_t DisplayDoorStatusMgr;

GLOBAL ErrorMessageMgr_t ErrorMessageMgr;
GLOBAL DoorBellMgr_t DoorBellMgr;

//GLOBAL FrmAckMgr_t FrmAckMgr;
GLOBAL FaceUserMemoryMgr_t FaceUserMemoryMgr[DEF_MAX_FACEMASTER+DEF_MAX_FACEUSER];
GLOBAL FrmMgr_t FrmMgr;
GLOBAL FaceIdentifyMgr_t FaceIdentifyMgr;
GLOBAL DeleteAllFaceTemplateMgr_t DeleteAllFaceTemplateMgr;
GLOBAL PIRmgr_t PIRmgr;

GLOBAL FpmLEDsMgr_t FpmLEDsMgr;

GLOBAL AwakeDisplayMgr_t AwakeDisplayMgr;

GLOBAL keycode_t Debug_Keycode;

GLOBAL StrongUnlockMgr_t StrongUnlockMgr;

GLOBAL BodyInductionMgr_t BodyInductionMgr;

GLOBAL AwakeSystemKeyMgr_t AwakeSystemKeyMgr;

#endif