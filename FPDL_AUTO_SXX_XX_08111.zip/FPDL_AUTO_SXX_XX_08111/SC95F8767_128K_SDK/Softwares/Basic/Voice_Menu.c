#include "Voice_Menu.h"
#include "BeepMgr.h"
#include "Project.h"


code uint16_t MainMenuVoiceBuff[][6]=
{	
	{VOICE_Press,VOICE_One,VOICE_User,VOICE_Management,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_SystemSetting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_InfomationInquiry,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Four,VOICE_NetworkConfig,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ExitMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};
	
code uint16_t UserManagementMenuVoiceBuff_WithFRM[][6]=
{
	{VOICE_Press,VOICE_One,VOICE_Face,VOICE_User,VOICE_Management,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Fingerprint,VOICE_User,VOICE_Management,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_Password,VOICE_User,VOICE_Management,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Four,VOICE_Card,VOICE_User,VOICE_Management,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ExitMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};		

code uint16_t UserManagementMenuVoiceBuff[][6]=
{	
	{VOICE_Press,VOICE_One,VOICE_Fingerprint,VOICE_User,VOICE_Management,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Password,VOICE_User,VOICE_Management,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_Card,VOICE_User,VOICE_Management,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ExitMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};


code uint16_t FaceMenuVoiceBuff[][7]=
{	
	{VOICE_Press,VOICE_One,VOICE_Add,VOICE_Administrator,VOICE_Face,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Add,VOICE_User,VOICE_Face,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_Delete,VOICE_Singal,VOICE_Face,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t FpMenuVoiceBuff[][8]=
{		
	{VOICE_Press,VOICE_One,VOICE_Add,VOICE_Administrator,VOICE_Fingerprint,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Add,VOICE_User,VOICE_Fingerprint,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_Add,VOICE_Stress,VOICE_Fingerprint,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Four,VOICE_Delete,VOICE_Fingerprint,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}	
};
	
code uint16_t FpDeleteMenuVoiceBuff[][8]=
{		
	{VOICE_Press,VOICE_One,VOICE_Delete,VOICE_Singal,VOICE_User,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Delete,VOICE_All,VOICE_User,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_Delete,VOICE_All,VOICE_Stress,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}	
};	

code uint16_t PasscodeMenuVoiceBuff[][7]=
{	
	{VOICE_Press,VOICE_One,VOICE_Add,VOICE_Administrator,VOICE_Password,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Add,VOICE_User,VOICE_Password,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_Delete,VOICE_Singal,VOICE_Password,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Four,VOICE_Delete,VOICE_All,VOICE_User,VOICE_Password,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t CardMenuVoiceBuff[][7]=
{	
	{VOICE_Press,VOICE_One,VOICE_Add,VOICE_Card,VOICE_User,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Delete,VOICE_Singal,VOICE_Card,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_Delete,VOICE_All,VOICE_Card,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag},
};


code uint16_t InfoInquiryMenuVoiceBuff[][7]=
{	
	{VOICE_Press,VOICE_One,VOICE_Log,VOICE_Query,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_MemoryUsage,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_SystemVersion,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Four,VOICE_RestoreFactoryDefault,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag},
};

uint16_t MemoryUsageVoiceBuff[][10]=
{	
	{VOICE_Face,VOICE_Used,VOICE_One,VOICE_Two,VOICE_Three,VOICE_All,VOICE_One,VOICE_One,VOICE_One,DEF_VoiceSegmentEndFlag},
	{VOICE_Fingerprint,VOICE_Used,VOICE_One,VOICE_Two,VOICE_Three,VOICE_All,VOICE_One,VOICE_One,VOICE_One,DEF_VoiceSegmentEndFlag},
	{VOICE_Password,VOICE_Used,VOICE_One,VOICE_Two,VOICE_All,VOICE_One,VOICE_One,DEF_VoiceSegmentEndFlag},
	{VOICE_Card,VOICE_Used,VOICE_One,VOICE_Two,VOICE_Three,VOICE_All,VOICE_One,VOICE_One,VOICE_One,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag},
};

code uint16_t SystemConfigMenuVoiceBuff[][6]=
{	
	{VOICE_Press,VOICE_One,VOICE_Time,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Voice,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_DoorLock,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Four,VOICE_Motor,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t VoiceSettingMenuVoiceBuff[][6]=
{	
	{VOICE_Press,VOICE_One,VOICE_Language,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Volume,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t LanguageSetVoiceBuff[][4]=
{	
	{VOICE_Press,VOICE_One,VOICE_Chinese,DEF_VoiceSegmentEndFlag},
	{VOICE_Press+1,VOICE_Two+1,VOICE_English,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t VolumeSetVoiceBuff[][5]=
{	
	{VOICE_Press,VOICE_One,VOICE_Big,VOICE_Volume,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Middle,VOICE_Volume,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_Small,VOICE_Volume,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Four,VOICE_Mute,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};
	
code uint16_t LogMenuVoiceBuff[][5]=
{	
	{VOICE_Press,VOICE_One,VOICE_Query,VOICE_Log,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Delete,VOICE_Log,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

	
code uint16_t VoiceStr_VoiceOpened[] = {VOICE_Voice,VOICE_Opened,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_VoiceClosed[] = {VOICE_Voice,VOICE_Closed,DEF_VoiceSegmentEndFlag};

code uint16_t VoiceStr_NormallyOpenModeOpened[] = {VOICE_NormallyOpen,VOICE_Opened,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_NormallyOpenModeClosed[] = {VOICE_NormallyOpen,VOICE_Closed,DEF_VoiceSegmentEndFlag};

/*
code uint16_t DoorLockSettingVoiceBuff[][7]=
{	
	{VOICE_Press,VOICE_One,VOICE_UnlockingMode,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_AntiSkidAlarm,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_BodyInduction,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};
*/

code uint16_t DoorLockSettingVoiceBuff_WithFRM[][7]=
{	
	{VOICE_Press,VOICE_One,VOICE_UnlockingMode,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_AntiSkidAlarm,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_BodyInduction,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t DoorLockSettingVoiceBuff[][7]=
{	
	{VOICE_Press,VOICE_One,VOICE_UnlockingMode,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_AntiSkidAlarm,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};


code uint16_t UnlockModeSetVoiceBuff[][4]=
{	
	{VOICE_Press,VOICE_One,VOICE_SingleUnlock,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_CombinationUnlock,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t BodyInductionVoiceBuff[][5]=
{	
	{VOICE_Press,VOICE_One,VOICE_BodyInduction,VOICE_Close,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_BodyInduction,VOICE_Small,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_BodyInduction,VOICE_Big,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

	
code uint16_t VoiceStr_SingleUnlockModeOpened[] = {VOICE_SingleUnlock,VOICE_Opened,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_CombinationUnlockModeOpened[] = {VOICE_CombinationUnlock,VOICE_Opened,DEF_VoiceSegmentEndFlag};

code uint16_t AntiPryingSettingVoiceBuff[][5]=
{	
	{VOICE_Press,VOICE_One,VOICE_AntiSkidAlarm,VOICE_Open,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_AntiSkidAlarm,VOICE_Close,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t VoiceStr_AntiPryingOpened[] = {VOICE_AntiSkidAlarm,VOICE_Opened,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_AntiPryingClosed[] = {VOICE_AntiSkidAlarm,VOICE_Closed,DEF_VoiceSegmentEndFlag};


code uint16_t PickAlarmSetVoiceBuff[][5]=
{	
	{VOICE_Press,VOICE_One,VOICE_AntiSkidAlarm,VOICE_Open,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_AntiSkidAlarm,VOICE_Close,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

	
code uint16_t RestoreFactoryDefaultVoiceBuff[][4]=
{	
	{VOICE_PressPoundKey,VOICE_Confirm,VOICE_RestoreFactoryDefault,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag}
};

code uint16_t EngineeringModeMenuVoiceBuff_WithFRM[][8]=
{	
	{VOICE_Press,VOICE_One,VOICE_UnlockingDirect,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Motor,VOICE_Torque,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_LockTongueReturn,VOICE_Time,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Four,VOICE_LockDistance,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Five,VOICE_SelfBounce,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Six,VOICE_Motor,VOICE_SelfTest,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Seven,VOICE_BodyInduction,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t EngineeringModeMenuVoiceBuff[][8]=
{	
	{VOICE_Press,VOICE_One,VOICE_UnlockingDirect,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Motor,VOICE_Torque,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_LockTongueReturn,VOICE_Time,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Four,VOICE_LockDistance,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Five,VOICE_SelfBounce,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Six,VOICE_Motor,VOICE_SelfTest,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};


code uint16_t MotorSettingMenuVoiceBuff[][8]=
{	
	{VOICE_Press,VOICE_One,VOICE_Lock,VOICE_Time,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_AutoLock,VOICE_Time,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_Motor,VOICE_SelfTest,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Four,VOICE_Motor,VOICE_Torque,VOICE_Setting,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};


code uint16_t UnlockDirrectionSettingVoiceBuff[][4]=
{
	{VOICE_Press,VOICE_One,VOICE_LeftOpen,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_RightOpen,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t MotorTorqueSettingVoiceBuff[][5]=
{
	{VOICE_Press,VOICE_One,VOICE_Small,VOICE_Torque,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Middle,VOICE_Torque,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Three,VOICE_Big,VOICE_Torque,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t UnlockTimeSettingVoiceBuff[][7]=
{
	{VOICE_Press,VOICE_Two,VOICE_Eight,VOICE_Adjust,VOICE_Lock,VOICE_Time,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};
	
code uint16_t AutoLockDelayTimeSettingVoiceBuff[][7]=
{
	{VOICE_Press,VOICE_Two,VOICE_Eight,VOICE_Adjust,VOICE_AutoLock,VOICE_Time,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};
	
code uint16_t BoltLockTimeSettingVoiceBuff[][5]=
{
	{VOICE_Press,VOICE_Two,VOICE_Eight,VOICE_Adjust,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t LockingTravelSettingVoiceBuff[][5]=
{
	{VOICE_Press,VOICE_Two,VOICE_Eight,VOICE_Adjust,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t AutoEjectSettingVoiceBuff[][5]=
{
	{VOICE_Press,VOICE_One,VOICE_Open,VOICE_SelfBounce,DEF_VoiceSegmentEndFlag},
	{VOICE_Press,VOICE_Two,VOICE_Close,VOICE_SelfBounce,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t MotorSelfTestVoiceBuff[][4]=
{
	{VOICE_Motor,VOICE_SelfTest,VOICE_PleaseWait,DEF_VoiceSegmentEndFlag}
};

uint16_t SystemVersionVoiceBuff[][10]=
{
	{VOICE_CharS,VOICE_Zero,VOICE_Zero,VOICE_Zero,VOICE_CharZ,VOICE_Zero,VOICE_Zero,VOICE_Zero,DEF_VoiceSegmentEndFlag},
	{VOICE_Zero,VOICE_Zero,VOICE_Zero,VOICE_Dot,VOICE_Zero,VOICE_Zero,VOICE_Zero,VOICE_Dot,DEF_VoiceSegmentEndFlag},
	{VOICE_Zero,VOICE_Zero,VOICE_Zero,VOICE_Dot,VOICE_Zero,VOICE_Zero,VOICE_Zero,DEF_VoiceSegmentEndFlag},
	{VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag},
	{VOICE_PressPoundKey,VOICE_ToRepeatListening,DEF_VoiceSegmentEndFlag}
};

code uint16_t VoiceStr_ConfirmOrExitDelete[]={VOICE_PressPoundKey,VOICE_ConfirmToDelete,VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_ConfirmOrExitRestorFactoryDefault[]={VOICE_PressPoundKey,VOICE_RestoreFactoryDefault,VOICE_PressAsteriskKey,VOICE_ReturnPreviousMenu,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_RestorFactoryDefaultPleaseWait[]={VOICE_RestoreFactoryDefault,VOICE_PleaseWait,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_OperationSuccess[]={VOICE_Operation,VOICE_Success,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_OperationFail[]={VOICE_Operation,VOICE_Fail,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_HardwareNotSupportOperationFail[]={VOICE_HardwareNotSupported,VOICE_Operation,VOICE_Fail,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_RepeatedFingerprint[]={VOICE_Duplicate,VOICE_Fingerprint,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_RepeatedCard[]={VOICE_Duplicate,VOICE_Card,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_RepeatedPassword[]={VOICE_Duplicate,VOICE_Password,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_DeleteFail[]={VOICE_Delete,VOICE_Fail,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_DeleteSuccess[]={VOICE_Delete,VOICE_Success,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_PleaseInputPassword[]={VOICE_PleaseEnter,VOICE_Password,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_PleaseInputPasswordAgain[]={VOICE_Again,VOICE_Password,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_TimeSetting[]={VOICE_Time,VOICE_Setting,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_PleaseInputYear[]={VOICE_PleaseEnter,VOICE_Year,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_PleaseInputMonth[]={VOICE_PleaseEnter,VOICE_Month,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_PleaseInputDate[]={VOICE_PleaseEnter,VOICE_Date,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_PleaseInputHour[]={VOICE_PleaseEnter,VOICE_Hour,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_PleaseInputMinute[]={VOICE_PleaseEnter,VOICE_Minute,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_PleaseInputSecond[]={VOICE_PleaseEnter,VOICE_Second,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_PleaseInputSecondIdentity[]={VOICE_Beep,VOICE_PleaseInputSecondIdentity,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_FrmFunctionEnabled[]={VOICE_Face,VOICE_Opened,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_FrmFunctionDisbled[]={VOICE_Face,VOICE_Closed,DEF_VoiceSegmentEndFlag};
code uint16_t VoiceStr_UserIdIsNotExist[]={VOICE_User,VOICE_ID,VOICE_NotExist,DEF_VoiceSegmentEndFlag};


code uint16_t AutoLockOffVoiceStr[]={VOICE_AutoLock,VOICE_Close,DEF_VoiceSegmentEndFlag};
code uint16_t AutoEjectOnVoiceStr[]={VOICE_SelfBounce,VOICE_Opened,DEF_VoiceSegmentEndFlag};
code uint16_t AutoEjectOffVoiceStr[]={VOICE_SelfBounce,VOICE_Closed,DEF_VoiceSegmentEndFlag};
code uint16_t NoLogVoiceStr[]={VOICE_Not,VOICE_Log,DEF_VoiceSegmentEndFlag};

code uint16_t VoiceStr_RequestingRemoteUnlock[]={VOICE_RequestingRemoteUnlock,VOICE_PleaseWait,DEF_VoiceSegmentEndFlag};

code uint16_t VoiceStr_VerifySuccess[]={VOICE_Validation,VOICE_Success,DEF_VoiceSegmentEndFlag};

code uint16_t VoiceStr_AddNewMasterPleaseInputPasscode[]={VOICE_Add,VOICE_Administrator,VOICE_Password,VOICE_PleaseEnter,VOICE_Password,DEF_VoiceSegmentEndFlag};


