#ifndef IO_H
#define IO_H

/* ************************ FILE HEADER *************************************/
/* ***************************************************************************
*  INCLUDE FILES
*/
#include "gpio.h"
#include "Project.h"
/* MASS MICROELECTRONICS TARGET BOARD I/O SETTINGS */
#if 1

#define SET_LCD_DS			P03
#define SET_LCD_CS			P01
#define SET_LCD_RST			P02

#define SET_LCD_DS_H 		SET_LCD_DS=1 
#define SET_LCD_DS_L 		SET_LCD_DS=0 

#define SET_LCD_CS_H 		SET_LCD_CS=1 
#define SET_LCD_CS_L 		SET_LCD_CS=0 

#define SET_LCD_RST_H 		SET_LCD_RST=1 
#define SET_LCD_RST_L 		SET_LCD_RST=0 

#if defined ProjectIs_BarLock_S5514 || defined ProjectIs_BarLock_S9201
	#define SET_MFC_RST_H			GPIO_Config(PORT0,PIN0,GPIO_Mode_OUT_PP);P00=1 
	#define SET_MFC_RST_L			P00=0 
	#define PINMACRO_NFC_IRQ_STATUS 		P20
	#define PINMACRO_NFC_IRQ PORT2,PIN0
	#define SET_FPMPOWER				P36
	#define PINMACRO_HALLSENSOR_STATUS 	P40
#else
	#define SET_MFC_RST_H			GPIO_Config(PORT2,PIN0,GPIO_Mode_OUT_PP);P20=1 
	#define SET_MFC_RST_L			P20=0 
	#ifdef ProjectIs_BarLock_S8709
	#define PINMACRO_NFC_IRQ_STATUS 		P21
	#define PINMACRO_NFC_IRQ PORT2,PIN1

	#else
	#define PINMACRO_NFC_IRQ_STATUS 		P00
	#define PINMACRO_NFC_IRQ PORT0,PIN0
	#endif
	#define SET_FPMPOWER			P40
#endif

#define SET_FPMPOWER_ON				SET_FPMPOWER=1 
#define SET_FPMPOWER_OFF			SET_FPMPOWER=0 

#define SYSPOWER_ON				SET_FPMPOWER=1 
#define SYSPOWER_OFF			SET_FPMPOWER=0 

#define SET_MFC_CS_L	
#define SET_MFC_CS_H	

#define SET_FLASH_CS_H	
#define SET_FLASH_CS_L	

#define SET_OLEDPOWER
#define SET_OLEDPOWER_ON  	SET_OLEDPOWER
#define SET_OLEDPOWER_OFF	  SET_OLEDPOWER	


#define PINMACRO_KB_IRQ_STATUS		

#define PINMACRO_ONBOARD_BUTTON_STATUS 	P42
#define PINMACRO_CASINGOPEN_STATUS		

#define PINMACRO_FPM_TOUCH_STATUS 	P43

#define SET_VOICEDATA_H 				P54=1 
#define SET_VOICEDATA_L 				P54=0 
#define STATUS_PINMACRO_VOICEDATA 		P54
#define STATUS_PINMACRO_VOICEBUSY 		P53

#define SET_VOICEDATA_SLEEP 				GPIO_Config(PORT5,PIN4,GPIO_Mode_INPUT_PU);
#define SET_VOICEBUSY_SLEEP 				GPIO_Config(PORT5,PIN3,GPIO_Mode_INPUT_PU);

#define SET_VOICEDATA2_H 							
#define SET_VOICEDATA2_L 							
#define STATUS_PINMACRO_VOICEDATA2 	

#define SET_LOGLED_ON					//
#define SET_LOGLED_OFF				//
#define SET_LEDKEYs_ON	

#if defined ProjectIs_BarLock_S4914
#define SET_LEDRGB_R				P22
#define SET_LEDRGB_G				P21
#define SET_LEDRGB_B				P23

#elif defined ProjectIs_BarLock_S8709
#define SET_LEDRGB_R				P00
#define SET_LEDRGB_G				P22
#define SET_LEDRGB_B				P23

#else
#define SET_LEDRGB_R				P21
#define SET_LEDRGB_G				P22
#define SET_LEDRGB_B				P23
#endif

#define SET_LEDKEYs_OFF				SET_LEDRGB_R=1;SET_LEDRGB_G=1;SET_LEDRGB_B=1
#define SET_LEDRGB_R_ON				SET_LEDRGB_R=0 
#define SET_LEDRGB_R_OFF			SET_LEDRGB_R=1 
#define SET_LEDRGB_G_ON				SET_LEDRGB_G=0 
#define SET_LEDRGB_G_OFF			SET_LEDRGB_G=1 
#define SET_LEDRGB_B_ON				SET_LEDRGB_B=0 
#define SET_LEDRGB_B_OFF			SET_LEDRGB_B=1 

#define PINMACRO_PICKLOCK_STATUS 		P41

#ifdef Function_TuyaWifi
#define MotorIOChange
#define SET_WIFIPOWER_ON			P55=1
#define SET_WIFIPOWER_OFF			P55=0
#endif

#ifdef MotorIOChange

#ifdef ProjectIs_BarLock_S0607
#define SET_MOTOR_INA_H				P46=1 
#define SET_MOTOR_INA_L				P46=0 
#define SET_MOTOR_INB_H				P47=1 
#define SET_MOTOR_INB_L				P47=0
#else
#define SET_MOTOR_INA_H				P47=1 
#define SET_MOTOR_INA_L				P47=0 
#define SET_MOTOR_INB_H				P46=1 
#define SET_MOTOR_INB_L				P46=0
#endif

#else

#define SET_MOTOR_INA_H				P51=1 
#define SET_MOTOR_INA_L				P51=0 
#define SET_MOTOR_INB_H				P50=1 
#define SET_MOTOR_INB_L				P50=0

#endif

#endif

#endif /* #ifndef IO_H */
/* ****************************** END OF FILE ****************************** */
