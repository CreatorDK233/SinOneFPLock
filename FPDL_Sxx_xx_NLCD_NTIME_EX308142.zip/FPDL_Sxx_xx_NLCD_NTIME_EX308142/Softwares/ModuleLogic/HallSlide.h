#ifndef _HallSlide_H_
#define _HallSlide_H_

#ifdef Function_HallSlide
extern void HallSlideCover_Init(void);
extern void HallSleep_Task(void);
extern void HallAwakeupDispose(void);
#endif

#endif