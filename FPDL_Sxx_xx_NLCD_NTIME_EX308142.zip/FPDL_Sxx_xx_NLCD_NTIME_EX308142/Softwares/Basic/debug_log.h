#ifndef __DEBUG_LOG_H__
#define __DEBUG_LOG_H__
#include <stdio.h>
#include <stdarg.h>
#ifdef FUNC_LOG
#define PRINT printf
#else
#define PRINT /##/
#endif
void PrintfBuf(const unsigned char* buf, int len);
#endif