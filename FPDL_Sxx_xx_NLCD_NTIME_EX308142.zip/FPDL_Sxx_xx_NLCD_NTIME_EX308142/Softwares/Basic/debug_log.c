#include "debug_log.h"
void Uart2SendByte(unsigned char dat);
char putchar(char c)
{
	Uart2SendByte((unsigned char)c);
	return c;
}
void PrintfBuf(const unsigned char* buf, int len)
{
	int i = 0;    
    while (i++ < len) {
        PRINT("%02x ",(int) *buf);
		buf++;
    }
    PRINT("\n");
}
