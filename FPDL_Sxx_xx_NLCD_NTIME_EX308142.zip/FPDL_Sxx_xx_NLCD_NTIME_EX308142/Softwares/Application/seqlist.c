#include <stdio.h>
#include "seqlist.h"

void InitList(SqList* L) {
    uint8_t i;
    for (i = 0; i < MAXSIZE; i++)
        L->dataArray[i] = 0;
    L->length = 0; 
}

bool_t ListInsert(SqList* L, uint8_t i, uint8_t e) {
	uint8_t j;
    if (i < 1 || i > L->length + 1)
        return bFALSE;
    if (L->length >= MAXSIZE)
        return bFALSE;
    for (j = L->length; j >= i; j--)
        L->dataArray[j] = L->dataArray[j - 1];
    L->dataArray[i - 1] = e;
    L->length++; 
    return bTRUE;
}

bool_t ListDelete(SqList* L, uint8_t i, uint8_t* e) {
	uint8_t j;
    if (i < 1 || i > L->length)
        return bFALSE;
    *e = L->dataArray[i - 1];
    for (j = i; j < L->length; j++)
        L->dataArray[j - 1] = L->dataArray[j];
    L->length--;

    return bTRUE;
}

uint8_t GetElem(SqList* L,uint8_t i){
    return L->dataArray[i-1];
}

void DeleteList(SqList* L){
    L->length = 0;
}
