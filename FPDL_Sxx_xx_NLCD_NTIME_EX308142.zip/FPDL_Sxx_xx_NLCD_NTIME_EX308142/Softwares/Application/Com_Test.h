#ifndef __COM_TEST_H__
#define __COM_TEST_H__
#include "global_variable.h"

#define DATA_BUF_LEN_MAX 30
#define BUF_LEN_MAX 35
typedef struct
{
    enum
    {
        EXIT_TEST_MODE,  // �˳�����ģʽ
        ENTER_TEST_MODE, // �������ģʽ
    } Lock_status;
} LockBoardState_t;

// typedef struct{
//     bool_t playWaterDrop;
//     bool_t motorLaunch;
// } TimeConsumeOperate_t;

void TestModeInit(void);
void TestMode_Task(void);
void RxDataAckHandle();
void RxDataAckHandle_Task();
void ExitFpEnterTestMode(void);
void ExitTestModeReportError(void);
void TimeConsumeOperation(void);
void TouchVar(void);

extern LockBoardState_t LockBoardState;
// extern TimeConsumeOperate_t timeConsumeOperate;

#endif
