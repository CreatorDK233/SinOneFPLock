#ifndef __QUEUE_H__
#define __QUEUE_H__
    #include <stdio.h>
    #include "global_variable.h"
    #define MaxSize 15
    #define BUFFLEN 30
    typedef struct {
        uint8_t cmd;
        uint8_t len;
        uint8_t dataBuf[BUFFLEN];
    }DataFrame;
    
    typedef struct
    {
        DataFrame array[MaxSize]; // ����Ԫ��
        uint8_t front, rear;   // ��ͷ�Ͷ�βָ��
    } SqQueue;

    typedef struct{
        SqQueue DataQueue;
        DataFrame testDadaQueueArray;
    }ComMachine;

    void InitQueue(SqQueue *Q);
    bool_t QueueEmpty(SqQueue *Q);
    bool_t IsFullQueue(SqQueue *Q);
    bool_t EnQueue(SqQueue *Q, DataFrame e);
    bool_t DeQueue(SqQueue *Q, DataFrame *x);
    bool_t GetHead(SqQueue *Q, DataFrame *x);
    void GetHeadAndDequeue(SqQueue *Q, DataFrame *x);
#endif
