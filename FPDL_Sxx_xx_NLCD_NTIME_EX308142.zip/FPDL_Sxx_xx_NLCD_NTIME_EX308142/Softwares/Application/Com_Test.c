#include "Project.h"
#include "IO.h"
// Protocol layer
#include "Fingerprint.h"
#include "BeepMgr.h"
#include "LCD_HFG12864.h"
#include "TuyaWIFI.h"
#include "EEPROM.h"
// Logic layer
#include "KeyScan.h"
#include "Motor.h"
#include "LCD.h"
// Application layer
#include "Basic_Function.h"
#include "usart.h"
#include "Com_Test.h"
#include "queue.h"
#include <string.h>
#include "seqlist.h"
#include "MFC_MF17622.h"
#include "debug_log.h"
#include "LowPower.h"
#include "GUI_Function.h"
#include "Battery.h"
#include "SensorMethod.h"

extern unsigned int GetCurrFingerValue(unsigned char i);

void RxDataHandle();
void SendAckData(uint16_t len, uint8_t *sendBuff, uint8_t ack);
void Test_ResetRX(void);
extern void ShowRestoreFactoryDefault(void);
#ifdef Function_AutoTest
#define SOCAPI_SET_TOUCHKEY_TOTAL 12
#define MAX_SOCAPI_SET_TOUCHKEY_TOTAL 14
uint8_t touchVarArr[SOCAPI_SET_TOUCHKEY_TOTAL*2];
// Э���ʽ
#define PACKAGE_L 0xEF               // ��ͷ
#define PACKAGE_H 0x01               // ��ͷ
#define MACHINE_ADDRESS 0xCCCCCCCC   // �豸��ַ
#define TESTMACHINE_PACKAGE_TAG 0xAA // ���Ի�����ʶ
#define LOCKBOARD_PACKAGE_TAG 0xAB   // �������ʶ

#define STATUS_1 0x00
#define STATUS_2 0x01
#define STATUS_3 0x02
#define STATUS_RESERVE 0xFF

#define ENTER_LOCK_BOARD_TEST_MODE 0x01
#define EXIT_LOCK_BOARD_TEST_MODE 0x02

// �����ѹ���
enum
{
    LCD_POWER = 0,
    FP_POWER,
    RGB_POWER,
    RGB1_POWER,
    FACE_POWER,
    PIR_RADR_POWER,
};

// ����IO��״̬
enum
{
    FACE_TXD_SINGAL = 0, // �����ź�TXD�źſ���
    PIR_PWM_SDA_SINGAL,  // PIR PWM/�״�SDA�źſ���
    PIR_PWM_SCL_SINGAL,  // PIR POWER EN/�״� SCL�źſ���
    HOST_TXD_SINGAL,     // ����ͨѶTXD�źſ���
    WIFI_TXD_SINGAL,     // WIF TXD�źſ���
    WIFI_EN_SINGAL,      // WIFI EN�źſ���
    OLED_CS_SINGAL,      // OLED CS�źſ���
    OLED_DC_SINGAL,      // OLED DC�źſ���
    OLED_RESET_SINGAL,   // OLED RESET�źſ���
    OLED_MOSI_SINGAL,    // OLED MOSI�źſ���
    OLED_SCK_SINGAL,     // OLED SCK�źſ���
    RGB_RED_SINGAL,      // RGB RED�źſ���
    RGB_GREEN_SINGAL,    // RGB GREEN	�źſ���
    RGB_BLUE_SINGAL,     // RGB BLUE�źſ���
    RGB1_RED_SINGAL,     // RGB1 RED�źſ���
    RGB1_GREEN_SINGAL,   // RGB1 GREEN�źſ���
    RGB1_BLUE_SINGAL,    // RGB1 BLUE�źſ���
    VOICE_POWER_SINGAL,  // ���ȿ���/�رտ���
    MOTOR_POWER_SINGAL,  // ���￪��/�رտ���
};

// ��ʾ����
enum
{
    LCD_OLED = 0, // LCD/OLED����
    KEY_LED,      // �����ƹ���
};

/**
 * @brief ���Ի������Լ�ָ��
 *
 */
enum
{
    TEST_MODE = 0xA0,     // ����ģʽ
    INPUT_VOLTAGE = 0xA1, // ��ѯ�����ѹ����
    OUTPUT_VOLTAGE,       // �����ѹ���
    IO_INPUT_STATE,       // ��ѯIO������״̬
    IO_OUTPUT_STATE,      // �������IO�ڵ�״̬
    TOUCH_SIGNAL,         // �����źŲ�ѯ
    MODEL_STATE,          // ����ģ�����в�ѯ
    DISPLAY_CONTROL,      // ��ʾ����
    RESTORYFACTORY,       // �ָ�����
    CMD_SLEEP,                // ����
};

enum
{
    Exec_Success = 0x00, // 0x00 ָ��ִ�гɹ�
    Exec_Fail = 0x01,    // 0x01 ָ��ִ�д���
    Non_Support          // 0x02 ָ�֧��
};



typedef struct
{
    uint8_t ack;
    uint16_t len;
    uint8_t dataBuf[DATA_BUF_LEN_MAX];
} ACKDataFrame;

typedef struct
{
    enum
    {
        ERROR_Default = 0x00,
        ERROR_NONE = 0x01, // ������ȷ
        ERROR_LENGTH,      // �������ݳ�������
        ERROR_CKS,         // У��ʹ���
        ERROR_PACKET       // ����ʶ����
    } ErrorCode;
    uint8_t sendBuff[BUF_LEN_MAX];
} ComTestMachine;

ComTestMachine comTestMachine;

ComMachine ComQueue;
SqList rXSeqList;
SqList tXSeqList;

LockBoardState_t LockBoardState;
//TimeConsumeOperate_t timeConsumeOperate;

uint16_t Cal_CKS(uint8_t *buff, uint8_t len)
{
    uint8_t i;
    uint16_t CKS = 0;

    for (i = 0; i < len; i++)
    {
        CKS += buff[i];
    }

    return CKS;
}

uint16_t SendDataLength(){    
    uint16_t fixLen = 0x0003;
    return ((uint16_t)tXSeqList.length)+fixLen;
}

void AckToTestMachine(void){
    if(ComQueue.testDadaQueueArray.cmd == CMD_SLEEP){
        return;
    }
    if(tXSeqList.length == 0){
        SendAckData(0x0003, NULL, Exec_Success);
    }else{
        SendAckData(SendDataLength(), tXSeqList.dataArray, Exec_Success);
    }
}

void ReserveBytes(){
    uint8_t i;
    uint8_t ReserveBytesLen = ComQueue.testDadaQueueArray.len - tXSeqList.length;
    if(ComQueue.testDadaQueueArray.len == 0 || ReserveBytesLen == 0 || ComQueue.testDadaQueueArray.cmd == TEST_MODE)
        return;
    for(i = tXSeqList.length; i < ComQueue.testDadaQueueArray.len; i++){
        ListInsert(&tXSeqList, i + 1,STATUS_RESERVE);
    }
}

void TestModeInit(void)
{
    UART2_Mgr.TxPoint = 0;
    UART2_Mgr.TxLength = 0;
    Test_ResetRX();
    InitQueue(&(ComQueue.DataQueue));
    // InitList(&rXSeqList);
    InitList(&tXSeqList);
}

void Test_ResetRX(void)
{
    UART2_Mgr.RX_DataPoint = 0x00;
    UART2_Mgr.Status = Idle;
}

void TestMode_Task(void)
{
    if(LockBoardState.Lock_status == ENTER_TEST_MODE)
        RxDataHandle();
}

void RxDataAckHandle_Task()
{
    if(LockBoardState.Lock_status == ENTER_TEST_MODE)
        RxDataAckHandle();
}


void SendAckData(uint16_t len, uint8_t *sendBuff, uint8_t ack)
{
    uint16_t CKS;
    comTestMachine.sendBuff[0] = PACKAGE_L;
    comTestMachine.sendBuff[1] = PACKAGE_H;
    comTestMachine.sendBuff[2] = MACHINE_ADDRESS >> 24;
    comTestMachine.sendBuff[3] = MACHINE_ADDRESS >> 16;
    comTestMachine.sendBuff[4] = MACHINE_ADDRESS >> 8;
    comTestMachine.sendBuff[5] = MACHINE_ADDRESS;
    comTestMachine.sendBuff[6] = ComQueue.testDadaQueueArray.cmd;
    comTestMachine.sendBuff[7] = (len) >> 8;
    comTestMachine.sendBuff[8] = len;
    comTestMachine.sendBuff[9] = ack;
    memcpy(&comTestMachine.sendBuff[10], sendBuff, len - 3);
    CKS = Cal_CKS(&(comTestMachine.sendBuff[6]), len + 1);
    comTestMachine.sendBuff[len - 3 + 10] = (CKS >> 8);
    comTestMachine.sendBuff[len - 3 + 11] = CKS;
    Uart2SendStr(comTestMachine.sendBuff, len + 9);
    Test_ResetRX();
    DeleteList(&tXSeqList);
}

void RxDataHandle()
{
    uint8_t i, j;
    uint16_t CmdLength, CKS, TempCKS;
    DataFrame RxDataFream;

    if (UART2_Mgr.Status != GotNewCmd)
    {
        return;
    }

    CmdLength = UART2_Mgr.RX_Buffer[8] + 9;

    if (CmdLength - 9 < 3 || CmdLength >= 50)
    {
        UART2_Mgr.RX_DataPoint = 0x00;
        UART2_Mgr.Status = Idle; // ����ģʽ
        comTestMachine.ErrorCode = ERROR_LENGTH;
        return;
    }

    CKS = 0x0000;
    for (i = 6; i < (CmdLength - 2); i++)
    {
        CKS = CKS + UART2_Mgr.RX_Buffer[i];
    }

    TempCKS = (UART2_Mgr.RX_Buffer[CmdLength - 2] * 256) + UART2_Mgr.RX_Buffer[CmdLength - 1];

    DEBUG_MARK;

    if (CKS != TempCKS)
    {
        DEBUG_MARK;
        UART2_Mgr.RX_DataPoint = 0x00;
        UART2_Mgr.Status = Idle; // ����ģʽ
        comTestMachine.ErrorCode = ERROR_CKS;
        return; // if check sum is failed, ignore this data strin
    }

    if (UART2_Mgr.RX_Buffer[6] == TESTMACHINE_PACKAGE_TAG)
    {
        UART2_Mgr.RX_DataPoint = 0x00;
        UART2_Mgr.Status = Idle; // ����ģʽ
        comTestMachine.ErrorCode = ERROR_NONE;

        RxDataFream.cmd = UART2_Mgr.RX_Buffer[9];
        RxDataFream.len = CmdLength - 9 - 3;
        if (CmdLength - 9 - 3 != 0)
        {
            for (j = 0; j < CmdLength - 9 - 3; j++)
            {
                RxDataFream.dataBuf[j] = UART2_Mgr.RX_Buffer[10 + j];
            }
        }
        //		Uart2SendStr(UART2_Mgr.RX_Buffer, CmdLength);
        //		Test_ResetRX();

        if(IsFullQueue(&(ComQueue.DataQueue)) == bFALSE){
            EnQueue(&(ComQueue.DataQueue), RxDataFream);
        }
    }
    else
    {
        UART2_Mgr.RX_DataPoint = 0x00;
        UART2_Mgr.Status = Idle; // ����ģʽ
        comTestMachine.ErrorCode = ERROR_PACKET;
        return;
    }
}

void EnterTestMode(void)
{
    CurrentScreen = SCREEN_TestMode;
    // SendAckData(0x0003, NULL, Exec_Success);
}

void LockExitTestMode(void)
{
        CurrentScreen = SCREEN_Main;
        LockBoardState.Lock_status = EXIT_TEST_MODE;
        // SendAckData(0x0003, NULL, Exec_Success);
}

void VoltageAck(void)
{
    uint8_t i;
    for (i=0;i<100;i++)
	{
		if( i%10 == 0 )CLRWDT();
		Hardware_Task_Analog();
		HardwareBatteryMgr_Task();
	}
    ListInsert(&tXSeqList, 1, BatteryMgr.BatteryVoltage);
}

void LcdPowerAck(void)
{
    #ifdef Function_ScreenDisplay
    if(ComQueue.testDadaQueueArray.dataBuf[LCD_POWER] == STATUS_1){
        SET_OLEDPOWER_OFF;
        ListInsert(&tXSeqList,LCD_POWER+1,STATUS_1);
    }else if(ComQueue.testDadaQueueArray.dataBuf[LCD_POWER] == STATUS_2){
        SET_OLEDPOWER_ON;
        ListInsert(&tXSeqList,LCD_POWER+1,0x21);
    }
    #else
    ListInsert(&tXSeqList,LCD_POWER+1,STATUS_RESERVE);
    #endif
}

void FpPowerAck(void)
{
    if(ComQueue.testDadaQueueArray.dataBuf[FP_POWER] == STATUS_1){
        SET_FPMPOWER_OFF;
        ListInsert(&tXSeqList,FP_POWER+1,STATUS_1);
    }else if(ComQueue.testDadaQueueArray.dataBuf[FP_POWER] == STATUS_2){
        SET_FPMPOWER_ON;
        ListInsert(&tXSeqList,FP_POWER+1,0x21);
    }
}

void RGBPowerAck(void)
{
    #ifdef RGB
    if(ComQueue.testDadaQueueArray.dataBuf[RGB_POWER] == STATUS_1){
        SET_LEDRGB_R_OFF;
        SET_LEDRGB_G_OFF;
        SET_LEDRGB_B_OFF;
        ListInsert(&tXSeqList,RGB_POWER+1,STATUS_1);
    }else if(ComQueue.testDadaQueueArray.dataBuf[RGB_POWER] == STATUS_2){
        SET_LEDRGB_R_ON;
        SET_LEDRGB_G_ON;
        SET_LEDRGB_B_ON;
        ListInsert(&tXSeqList,RGB_POWER+1,0x21);
    }
    #else
    ListInsert(&tXSeqList,RGB_POWER+1,STATUS_RESERVE);
    #endif
}

void RGB1PowerAck(void)
{
    #ifdef RGB_1
    if(ComQueue.testDadaQueueArray.dataBuf[RGB1_POWER] == STATUS_1){
        SET_LEDRGB_R_OFF;
        SET_LEDRGB_G_OFF;
        SET_LEDRGB_B_OFF;
        ListInsert(&tXSeqList,RGB1_POWER+1,STATUS_1);
    }else if(ComQueue.testDadaQueueArray.dataBuf[RGB1_POWER] == STATUS_2){
        SET_LEDRGB_R_ON;
        SET_LEDRGB_G_ON;
        SET_LEDRGB_B_ON;
        ListInsert(&tXSeqList,RGB1_POWER+1,0x21);
    }
    #else
    ListInsert(&tXSeqList,RGB1_POWER+1,STATUS_RESERVE);
    #endif
}

void FacePowerAck(void)
{
    #ifdef Function_FaceRecoginition
    if(ComQueue.testDadaQueueArray.dataBuf[FACE_POWER] == STATUS_1){
        SET_FACEPOWER_OFF;
        ListInsert(&tXSeqList,FACE_POWER+1,STATUS_1);
    }else if(ComQueue.testDadaQueueArray.dataBuf[FACE_POWER] == STATUS_2){
        SET_FACEPOWER_ON;
        ListInsert(&tXSeqList,FACE_POWER+1,0x21);
    }
    #else
    ListInsert(&tXSeqList,FACE_POWER+1,STATUS_RESERVE);
    #endif
}

void PirRadarPowerAck(void)
{
    #if defined Function_BodyInductionByIR || defined Function_BodyInductionByRadar
    if(ComQueue.testDadaQueueArray.dataBuf[PIR_RADR_POWER] == STATUS_1){
        SET_PIRPOWER_OFF;
        ListInsert(&tXSeqList,PIR_RADR_POWER+1,STATUS_1);
    }else if(ComQueue.testDadaQueueArray.dataBuf[PIR_RADR_POWER] == STATUS_2){
        SET_PIRPOWER_ON;
        ListInsert(&tXSeqList,PIR_RADR_POWER+1,0x21);
    }
    #else
    ListInsert(&tXSeqList,PIR_RADR_POWER+1,STATUS_RESERVE);
    #endif
}

void OutVoltageAck(void){
    LcdPowerAck();
    FpPowerAck();
    RGBPowerAck();
    CLRWDT();
    RGB1PowerAck();
    FacePowerAck();
    PirRadarPowerAck();
    CLRWDT();
}

void InputIOState(void)
{
    uint8_t type = 0;
    if (PINMACRO_FPM_TOUCH_STATUS == 0)
    {
        ListInsert(&tXSeqList, type + 1, STATUS_1);
    }
    else
    {
        ListInsert(&tXSeqList, type + 1, STATUS_2);
    }

    if (PINMACRO_PICKLOCK_STATUS == 0)
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_1);
    }
    else
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_2);
    }
#ifdef Function_FaceRecoginition
    if (IO_FACE_RXD == 0)
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_1);
    }
    else
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
#endif

#if defined Function_BodyInductionByIR || defined Function_BodyInductionByRadar
    if (IO_IR_INT == 0)
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_1);
    }
    else
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
#endif

#if defined HOSTUART
    if (HOSTUART_RXD == 0)
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_1);
    }
    else
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
#endif

#if defined HOSTUART
    if (IO_HOST_AWEAK_INT == 0)
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_1);
    }
    else
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
#endif

#if defined Function_TuyaWifi || defined Function_YouzhiyunjiaWifi
    if (HOSTUART_RXD == 0)
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_1);
    }
    else
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
#endif
    if (PINMACRO_ONBOARD_BUTTON_STATUS == 0)
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_1);
    }
    else
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_2);
    }

    // Ԥ��
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
}

void FaceTxdSingal(void)
{
#ifdef Function_FaceRecoginition
    if (ComQueue.testDadaQueueArray.dataBuf[FACE_TXD_SINGAL] == STATUS_1)
    {
        FRM_TXD = 1;
        ListInsert(&tXSeqList, FACE_TXD_SINGAL + 1, STATUS_1);
    }
    else
    {
        FRM_TXD = 0;
        ListInsert(&tXSeqList, FACE_TXD_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, FACE_TXD_SINGAL + 1, STATUS_RESERVE);
#endif
}

void PirPwmSDASingal(void)
{
#if defined Function_BodyInductionByIR || defined Function_BodyInductionByRadar
    if (ComQueue.testDadaQueueArray.dataBuf[PIR_PWM_SDA_SINGAL] == STATUS_1)
    {
        SDA = 1;
        ListInsert(&tXSeqList, PIR_PWM_SDA_SINGAL + 1, STATUS_1);
    }
    else
    {
        SDA = 0;
        ListInsert(&tXSeqList, PIR_PWM_SDA_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, PIR_PWM_SDA_SINGAL + 1, STATUS_RESERVE);
#endif
}

void PirPwmSCLSingal(void)
{
    #if defined Function_BodyInductionByIR || defined Function_BodyInductionByRadar
    if (ComQueue.testDadaQueueArray.dataBuf[PIR_PWM_SCL_SINGAL] == STATUS_1)
    {
        SCL = 1;
        ListInsert(&tXSeqList, PIR_PWM_SCL_SINGAL + 1, STATUS_1);
    }
    else
    {
        SCL = 0;
        ListInsert(&tXSeqList, PIR_PWM_SCL_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, PIR_PWM_SCL_SINGAL + 1, STATUS_RESERVE);
#endif
}

void HostTxdSingal(void)
{
#ifdef HOSTUART
    if (ComQueue.testDadaQueueArray.dataBuf[HOST_TXD_SINGAL] == STATUS_1)
    {
        HOST_TXD = 1;
        ListInsert(&tXSeqList, HOST_TXD_SINGAL + 1, STATUS_1);
    }
    else
    {
        HOST_TXD = 0;
        ListInsert(&tXSeqList, HOST_TXD_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, HOST_TXD_SINGAL + 1, STATUS_RESERVE);
#endif
}

void WifiTxdSingal(void)
{
#if defined Function_TuyaWifi || defined Function_YouzhiyunjiaWifi
    if (ComQueue.testDadaQueueArray.dataBuf[WIFI_TXD_SINGAL] == STATUS_1)
    {
        HOST_TXD = 1;
        ListInsert(&tXSeqList, WIFI_TXD_SINGAL + 1, STATUS_1);
    }
    else
    {
        HOST_TXD = 0;
        ListInsert(&tXSeqList, WIFI_TXD_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, WIFI_TXD_SINGAL + 1, STATUS_RESERVE);
#endif
}

void WifiEndSingal(void)
{
#if defined Function_TuyaWifi || defined Function_YouzhiyunjiaWifi
    if (ComQueue.testDadaQueueArray.dataBuf[WIFI_EN_SINGAL] == STATUS_1)
    {
        SET_WIFIPOWER_OFF;
        ListInsert(&tXSeqList, WIFI_EN_SINGAL + 1, STATUS_1);
    }
    else
    {
        SET_WIFIPOWER_ON;
        ListInsert(&tXSeqList, WIFI_EN_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, WIFI_EN_SINGAL + 1, STATUS_RESERVE);
#endif
}

void OledCSSingal(void)
{
#ifdef Function_ScreenDisplay
    if (ComQueue.testDadaQueueArray.dataBuf[OLED_CS_SINGAL] == STATUS_1)
    {
        SET_LCD_CS_H;
        ListInsert(&tXSeqList, OLED_CS_SINGAL + 1, STATUS_1);
    }
    else
    {
        SET_LCD_CS_L;
        ListInsert(&tXSeqList, OLED_CS_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, OLED_CS_SINGAL + 1, STATUS_RESERVE);
#endif
}

void OledDCSingal(void)
{
#ifdef Function_ScreenDisplay
    if (ComQueue.testDadaQueueArray.dataBuf[OLED_DC_SINGAL] == STATUS_1)
    {
        SET_LCD_DS_H;
        ListInsert(&tXSeqList, OLED_DC_SINGAL + 1, STATUS_1);
    }
    else
    {
        SET_LCD_DS_L;
        ListInsert(&tXSeqList, OLED_DC_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, OLED_DC_SINGAL + 1, STATUS_RESERVE);
#endif
}

void OledResetSingal(void)
{
#ifdef Function_ScreenDisplay
    if (ComQueue.testDadaQueueArray.dataBuf[OLED_RESET_SINGAL] == STATUS_1)
    {
        SET_LCD_RST_H;
        ListInsert(&tXSeqList, OLED_RESET_SINGAL + 1, STATUS_1);
    }
    else
    {
        SET_LCD_RST_L;
        ListInsert(&tXSeqList, OLED_RESET_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, OLED_RESET_SINGAL + 1, STATUS_RESERVE);
#endif
}

void OledMOSISingal(void)
{
    #ifdef Function_ScreenDisplay
    if (ComQueue.testDadaQueueArray.dataBuf[OLED_MOSI_SINGAL] == STATUS_1)
    {
        OLED_MOSI_H;
        ListInsert(&tXSeqList, OLED_MOSI_SINGAL + 1, STATUS_1);
    }
    else
    {
        OLED_MOSI_L;
        ListInsert(&tXSeqList, OLED_MOSI_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, OLED_MOSI_SINGAL + 1, STATUS_RESERVE);
#endif
}

void OledSCKSingal(void)
{
#ifdef Function_ScreenDisplay
    if (ComQueue.testDadaQueueArray.dataBuf[OLED_SCK_SINGAL] == STATUS_1)
    {
        OLED_SCK_H;
        ListInsert(&tXSeqList, OLED_SCK_SINGAL + 1, STATUS_1);
    }
    else
    {
        OLED_SCK_L;
        ListInsert(&tXSeqList, OLED_SCK_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, OLED_SCK_SINGAL + 1, STATUS_RESERVE);
#endif
}

void RGBRedSingal(void)
{
#ifdef RGB
    if (ComQueue.testDadaQueueArray.dataBuf[RGB_RED_SINGAL] == STATUS_1)
    {
        SET_LEDRGB_R_OFF;
        ListInsert(&tXSeqList, RGB_RED_SINGAL + 1, STATUS_1);
    }
    else
    {
        SET_LEDRGB_R_ON;
        ListInsert(&tXSeqList, RGB_RED_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, RGB_RED_SINGAL + 1, STATUS_RESERVE);
#endif

}

void RGBGreenSingal(void)
{
#ifdef RGB
     if (ComQueue.testDadaQueueArray.dataBuf[RGB_GREEN_SINGAL] == STATUS_1)
    {
        SET_LEDRGB_G_OFF;
        ListInsert(&tXSeqList, RGB_GREEN_SINGAL + 1, STATUS_1);
    }
    else
    {
        SET_LEDRGB_G_ON;
        ListInsert(&tXSeqList, RGB_GREEN_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, RGB_RED_SINGAL + 1, STATUS_RESERVE);
#endif
}

void RGBBlueSingal(void)
{
    #ifdef RGB
    if (ComQueue.testDadaQueueArray.dataBuf[RGB_BLUE_SINGAL] == STATUS_1)
    {
        SET_LEDRGB_B_OFF;
        ListInsert(&tXSeqList, RGB_BLUE_SINGAL + 1, STATUS_1);
    }
    else
    {
        SET_LEDRGB_B_ON;
        ListInsert(&tXSeqList, RGB_BLUE_SINGAL + 1, STATUS_2);
    }
    #else
    ListInsert(&tXSeqList, RGB_BLUE_SINGAL + 1, STATUS_RESERVE);
    #endif
}

void RGB1RedSingal(void)
{
#ifdef RGB_1
    if (ComQueue.testDadaQueueArray.dataBuf[RGB1_RED_SINGAL] == STATUS_1)
    {
        SET_LED_RB_R_OFF;
        ListInsert(&tXSeqList, RGB1_RED_SINGAL + 1, STATUS_1);
    }
    else
    {
        SET_LED_RB_R_ON;
        ListInsert(&tXSeqList, RGB1_RED_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, RGB1_RED_SINGAL + 1, STATUS_RESERVE);
#endif
}

void RGB1GreenSingal(void)
{
#ifdef RGB_1
    if (ComQueue.testDadaQueueArray.dataBuf[RGB1_GREEN_SINGAL] == STATUS_1)
    {
        SET_LED_RB_G_OFF;
        ListInsert(&tXSeqList, RGB1_GREEN_SINGAL + 1, STATUS_1);
    }
    else
    {
        SET_LED_RB_G_ON;
        ListInsert(&tXSeqList, RGB1_GREEN_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, RGB1_GREEN_SINGAL + 1, STATUS_RESERVE);
#endif
}

void RGB1BlueSingal(void)
{
#ifdef RGB_1
    if (ComQueue.testDadaQueueArray.dataBuf[RGB1_BLUE_SINGAL] == STATUS_1)
    {
        SET_LED_RB_B_OFF;
        ListInsert(&tXSeqList, RGB1_BLUE_SINGAL + 1, STATUS_1);
    }
    else
    {
        SET_LED_RB_B_ON;
        ListInsert(&tXSeqList, RGB1_BLUE_SINGAL + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, RGB1_BLUE_SINGAL + 1, STATUS_RESERVE);
#endif
}

void VoicePowerSingal(void)
{
    if (ComQueue.testDadaQueueArray.dataBuf[VOICE_POWER_SINGAL] == STATUS_1)
    {
        STOP_VOICEPLAY();
        // timeConsumeOperate.playWaterDrop = bFALSE;
        ListInsert(&tXSeqList, VOICE_POWER_SINGAL + 1, STATUS_1);
    }
    else
    {
        // timeConsumeOperate.playWaterDrop = bTRUE;
        // CLRWDT();
        // PLAY_VOICE_TWOSEGMENT(VOICE_WaterDrop,0xF2);
        PLAY_VOICE_THREESEGMENT(VOICE_Alarm,VOICE_Alarm,VOICE_Alarm);
        ListInsert(&tXSeqList, VOICE_POWER_SINGAL + 1, STATUS_2);
    }
}

void MotorPowerSingal(void)
{
    if (ComQueue.testDadaQueueArray.dataBuf[MOTOR_POWER_SINGAL] == STATUS_1)
    {
        // SET_MOTOR_INA_L;
        // SET_MOTOR_INB_L;
        MotorMgr.MotorStatus = CCWWAIT;
        // timeConsumeOperate.motorLaunch = bFALSE;
        ListInsert(&tXSeqList, MOTOR_POWER_SINGAL + 1, STATUS_1);
    }
    else
    {
        // SET_MOTOR_INA_H;
        // SET_MOTOR_INB_L;
        // Hardware_DelayMs(125);
        // CLRWDT();
        MotorMgr.MotorStatus = CW;
        MotorMgr.CWTimer = Def_MotorCWTime+Def_GuiTimeDelayCnt2s;
        // timeConsumeOperate.motorLaunch = bTRUE;
        ListInsert(&tXSeqList, MOTOR_POWER_SINGAL + 1, STATUS_2);
    }
}

void IOOutputStateAck(void){
    FaceTxdSingal();
    PirPwmSDASingal();
    PirPwmSCLSingal();
    CLRWDT();
    HostTxdSingal();
    WifiTxdSingal();
    WifiEndSingal();
    CLRWDT();
    OledCSSingal();
    OledDCSingal();
    OledResetSingal();
    CLRWDT();
    OledMOSISingal();
    OledSCKSingal();
    RGBRedSingal();
    CLRWDT();
    RGBGreenSingal();
    RGBBlueSingal();
    RGB1RedSingal();
    CLRWDT();
    RGB1GreenSingal();
    RGB1BlueSingal();
    VoicePowerSingal();
    CLRWDT();
    MotorPowerSingal();
}

void TouchSingalAck(void)
{
    uint8_t j,z;
    uint8_t k = 0;

    for (j = 0; j < SOCAPI_SET_TOUCHKEY_TOTAL*2; j++)
    {
        ListInsert(&tXSeqList, j+1, touchVarArr[j]);
    }


    for(z = SOCAPI_SET_TOUCHKEY_TOTAL; z < MAX_SOCAPI_SET_TOUCHKEY_TOTAL; z++){
        ListInsert(&tXSeqList, z*2+1, STATUS_RESERVE);
        ListInsert(&tXSeqList, z*2+2, STATUS_RESERVE);
    }
}

void ModelRunState(void)
{
    uint8_t i,k;
    uint8_t type = 0;
    uint8_t j = 0;
    uint8_t readBuff[2];
    uint8_t writeBuff[2] = {0xAA, 0xBB};
    status_t GetCardID;

    EEPROM_WriteSequential(TestModeStartAddr, writeBuff, 2);
    EEPROM_ReadSequential(TestModeStartAddr, readBuff, 2);

    for (i = 0; i < 2; i++)
    {
        if (writeBuff[i] == readBuff[i])
        {
            j++;
        }
    }

    if (j == 2)
    {
        ListInsert(&tXSeqList, type + 1, STATUS_1);
    }
    else
    {
        ListInsert(&tXSeqList, type + 1, STATUS_2);
    }

    for (k = 0; k < 3; k++)
    {
        CLRWDT();
        GetCardID = MFC_Auto_Reader(CardIdentifyMgr.CID);
        if (GetCardID == S_SUCCESS){
            break;
        }

    }

    if (GetCardID == S_SUCCESS)
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_1);
    }
    else
    {
        ListInsert(&tXSeqList, (++type) + 1, STATUS_2);
    }

    // Ԥ��
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
    ListInsert(&tXSeqList, (++type) + 1, STATUS_RESERVE);
    


}

void LcdOledControl(void)
{
#ifdef Function_ScreenDisplay
    if (ComQueue.testDadaQueueArray.dataBuf[LCD_OLED] == STATUS_1)
    {
        SPI0_DeInit();
        ListInsert(&tXSeqList, LCD_OLED + 1, STATUS_1);
    }
    else
    {
        MX_SPI0_Init();
        ListInsert(&tXSeqList, LCD_OLED + 1, STATUS_2);
    }
#else
    ListInsert(&tXSeqList, LCD_OLED + 1, STATUS_RESERVE);
#endif
}

void KeyLedControl(void)
{
    if (ComQueue.testDadaQueueArray.dataBuf[KEY_LED] == STATUS_1)
    {
        SYSPOWER_OFF;
        ListInsert(&tXSeqList, KEY_LED + 1, STATUS_1);
    }
    else
    {
        SYSPOWER_ON;
        ListInsert(&tXSeqList, KEY_LED + 1, STATUS_2);
    }
}

void DisplayControlAck(void){
    LcdOledControl();
    KeyLedControl();
}

void RestoryFactoryFun(void)
{
    RestoreFactoryDefaultMgr.Status = ConfirmedToRestoreFactoryDefault;
    while (RestoreFactoryDefaultMgr.Status != RestoreFactoryFail || RestoreFactoryDefaultMgr.Status != RestoreFactorySuccess)
    {
        ShowRestoreFactoryDefault();
        CLRWDT();
        if(RestoreFactoryDefaultMgr.Status == RestoreFactorySuccess || RestoreFactoryDefaultMgr.Status == RestoreFactoryFail)
            break;
    }
    if (RestoreFactoryDefaultMgr.Status == RestoreFactorySuccess)
    {
        LockBoardState.Lock_status = ENTER_TEST_MODE;
        CurrentScreen = SCREEN_TestMode;
        comTestMachine.ErrorCode = ERROR_NONE;
    }
    else
    {
        LockBoardState.Lock_status = ENTER_TEST_MODE;
        CurrentScreen = SCREEN_TestMode;
        comTestMachine.ErrorCode = ERROR_NONE;
    }
}

void SleepControlFun(void)
{
    SendAckData(0x0003, NULL, Exec_Success);
    Hardware_DelayMs(200);
    CLRWDT();
    System_PowerDown();
    
    System_Awake();

    RefreshSystemSleepTime();
    
    SystemPowerMgr.AwakeTimerCnt=0x0000;
    
}


void RxDataAckHandle()
{

    bool_t cmdNoSupport = bFALSE;

    CLRWDT();

    if (QueueEmpty(&(ComQueue.DataQueue)) == bFALSE)
    {
        GetHeadAndDequeue(&(ComQueue.DataQueue), &(ComQueue.testDadaQueueArray));
        if (ComQueue.testDadaQueueArray.cmd == TEST_MODE)
        {
            if (ComQueue.testDadaQueueArray.dataBuf[0] == ENTER_LOCK_BOARD_TEST_MODE)
            {
                EnterTestMode();
            }else if (ComQueue.testDadaQueueArray.dataBuf[0] == EXIT_LOCK_BOARD_TEST_MODE)
            {
                LockExitTestMode();
            }
            
        }

        if (LockBoardState.Lock_status == ENTER_TEST_MODE)
        {

            if (ComQueue.testDadaQueueArray.cmd == INPUT_VOLTAGE)
            {
                VoltageAck();
            }
            else if (ComQueue.testDadaQueueArray.cmd == OUTPUT_VOLTAGE)
            {
                OutVoltageAck();
            }
            else if (ComQueue.testDadaQueueArray.cmd == IO_INPUT_STATE)
            {
                InputIOState();
            }
            else if (ComQueue.testDadaQueueArray.cmd == IO_OUTPUT_STATE)
            {
                IOOutputStateAck();
            }
            else if (ComQueue.testDadaQueueArray.cmd == TOUCH_SIGNAL)
            {
                TouchSingalAck();
            }
            else if (ComQueue.testDadaQueueArray.cmd == MODEL_STATE)
            {
                ModelRunState();
            }
            else if (ComQueue.testDadaQueueArray.cmd == DISPLAY_CONTROL)
            {
               DisplayControlAck();
            }
			else if (ComQueue.testDadaQueueArray.cmd == RESTORYFACTORY)
            {
                RestoryFactoryFun();
            }
            else if (ComQueue.testDadaQueueArray.cmd == CMD_SLEEP)
            {
               SleepControlFun();
            }
            else
            {
                if (ComQueue.testDadaQueueArray.cmd != TEST_MODE)
                {
                    cmdNoSupport = bTRUE;
                    SendAckData(0x0003, NULL, Non_Support);
                }
            }

            if(cmdNoSupport == bFALSE){
                ReserveBytes();
                AckToTestMachine();
            }
            
        }
        // else
        // {
        //     if (ComQueue.testDadaQueueArray.dataBuf[0] == EXIT_LOCK_BOARD_TEST_MODE)
        //     {
        //         if (exitTestMode == bFALSE)
        //         {
        //             SendAckData(0x0003, NULL, Exec_Fail);
        //         }
        //     }
        // }
    }
}

void ExitFpEnterTestMode(void)
{
    uint8_t sendBuff[] = {0xEF,0x01,0xCC,0xCC,0xCC,0xCC,0xA0,0x00,0x03,0x00,0x00,0xA3};
    Uart2SendStr(sendBuff, 12);
    Test_ResetRX();
    LockBoardState.Lock_status = ENTER_TEST_MODE;
    CurrentScreen = SCREEN_TestMode;
    comTestMachine.ErrorCode = ERROR_NONE;
    // timeConsumeOperate.motorLaunch = bFALSE;
    // timeConsumeOperate.playWaterDrop = bFALSE;
}

void ExitTestModeReportError(void)
{
    uint8_t sendBuff[] = {0xEF,0x01,0xCC,0xCC,0xCC,0xCC,0xA0,0x00,0x03,0x01,0x00,0xA3};
    Uart2SendStr(sendBuff, 12);
    Test_ResetRX();
}

// void TimeConsumeOperation(void){
    
//     // if(timeConsumeOperate.playWaterDrop == bTRUE){
//     //     // PLAY_VOICE_ONESEGMENT(VOICE_WaterDrop);
//     //     PLAY_VOICE_THREESEGMENT(VOICE_Alarm,VOICE_Alarm,VOICE_Alarm);
//     //     timeConsumeOperate.playWaterDrop = bFALSE;
		
//     // }

//     // if(timeConsumeOperate.motorLaunch == bTRUE){
// 	// 	MotorMgr.MotorStatus = CW;
//     //     MotorMgr.CWTimer = Def_MotorCWTime+Hardware_MotorDriverTimeCompasention();
//     // }
// }

void TouchVar(void)
{
    uint8_t i;
    if (LockBoardState.Lock_status == ENTER_TEST_MODE)
    {
        for (i = 0; i < SOCAPI_SET_TOUCHKEY_TOTAL; i++)
        {
            CLRWDT();
            touchVarArr[i * 2] = RawData[i];
            touchVarArr[i * 2 + 1] = RawData[i] >> 8;
        }
    }
}


#endif
