#include "MFC.h"
#include "GUI_Function.h"
#include "Project.h"
#include "LCD.h"
#include "Font_Menu.h"
#include "Log.h"
#include "global_variable.h"
#include "Basic_Function.h"

#include "EEPROM.h"
#include "BeepMgr.h"
#include "MFC_WS1850.h"

extern DataInputMgr_t DataInputMgr;

#define Def_UserSwingCardTimeDelay	Def_GuiTimeDelayCnt5s

void ReadCardUserMemoryFromEEPROM(void)//��EEPROM��ȡ��Ƭ�û�
{
	EEPROM_ReadSequential(CardUserMemoryStartAddr,&CardMemoryMgr[0].UserID,(6*DEF_MAX_CARDUSER));
}

void WriteCardUserMemoryToEEPROM(void)//��EEPROMд�뿨Ƭ�û�
{
	EEPROM_WriteSequential(CardUserMemoryStartAddr,&CardMemoryMgr[0].UserID,(6*DEF_MAX_CARDUSER));
}

void CardUserIdentify(void)//��Ƭ�û���֤
{
	status_t GetCardID;
	uint8_t UserID;
	if (CardIdentifyMgr.Status == ReadingCardID)
	{
		GetCardID = MFC_Auto_Reader(CardIdentifyMgr.CID);
		if ( GetCardID == S_SUCCESS )
		{
			CardIdentifyMgr.Status = CheckCardIDifRegistered;
			RefreshSystemSleepTime();
		}
	}
	else if ( CardIdentifyMgr.Status == CheckCardIDifRegistered)
	{
		UserID = CompareCardIDwithMemory(CardIdentifyMgr.CID); 
		if ( UserID == 0x00 )		//Card ID is not registered
		{
			CardIdentifyMgr.Status = Fail;
			CardIdentifyMgr.TimeCnt = Def_IdendtifyFailScreenTimeDelay;
		}
		else
		{
			CardIdentifyMgr.UserID = UserID;
			CardIdentifyMgr.Status = Success;	
			CardIdentifyMgr.TimeCnt = Def_IdendtifySuccessScreenTimeDelay;
		}
	}
}

uint8_t CompareCardIDwithMemory(uint8_t *Point)//���¿�ƬID������ID���бȽ�
{
	uint8_t i;
	uint8_t CardUserID;

	for (i=0;i<DEF_MAX_CARDUSER;i++)
	{
		if ( CardMemoryMgr[i].Status == CIDisValid )
		{
			if (  (CardMemoryMgr[i].CID[0] == *Point)
				&&(CardMemoryMgr[i].CID[1] == *(Point+1))
				&&(CardMemoryMgr[i].CID[2] == *(Point+2))
				&&(CardMemoryMgr[i].CID[3] == *(Point+3))
				//&&(CardMemoryMgr[i].CID[4] == *(Point+4))
				 )
			{
				CardUserID = CardMemoryMgr[i].UserID;
				return CardUserID;
			}
		}
	}
	return 0;
}

uint8_t Get_Availabe_CardUserID(void)//��ȡ��ע��Ŀ�ƬID
{
	uint8_t i;
	for (i=0;i<DEF_MAX_CARDUSER;i++)
	{
		if ( CardMemoryMgr[i].Status != CIDisValid ){
			return (i+1);
		}
	}
	return 0;
}

status_t SaveCardUserToMemory(uint8_t *Point,uint8_t UserID)//���濨Ƭ�û���EEPROM
{
	uint8_t j;

	for (j=0;j<4;j++)
	{
		CardMemoryMgr[UserID-1].CID[j] = *(Point+j);
	}
	CardMemoryMgr[UserID-1].UserID = UserID;
	CardMemoryMgr[UserID-1].Status = CIDisValid;
	
	WriteCardUserMemoryToEEPROM();
	return S_SUCCESS;

}

void DeleteCardUserfromMemory(uint8_t UserID)//��EEPROM��ɾ����Ƭ�û�
{
	uint8_t j;

	CardMemoryMgr[UserID-1].Status = CIDisInvalid;
	CardMemoryMgr[UserID-1].UserID = 0xFF;
	for (j=0;j<4;j++)
	{
		CardMemoryMgr[UserID-1].CID[j] = 0xFF;
	}
	WriteCardUserMemoryToEEPROM();
}

void DeleteAllCardUserfromMemory(void)//��EEPROM��ɾ�����п�Ƭ�û�
{
	uint8_t i,j;

	for (i=0;i<DEF_MAX_CARDUSER;i++)
	{

		CardMemoryMgr[i].Status = CIDisInvalid;
		CardMemoryMgr[i].UserID = 0xFF;
		for (j=0;j<4;j++)
		{
			CardMemoryMgr[i].CID[j] = 0xFF;
		}

	}	
	WriteCardUserMemoryToEEPROM();
}

bool_t IfCardUserIDisRegistered(uint8_t CardUserID)//�жϿ�Ƭ�û�ID�Ƿ�ע��
{
	uint8_t i;

	for (i=0;i<DEF_MAX_CARDUSER;i++)
	{
		if ( CardMemoryMgr[i].Status == CIDisValid )
			{
				if (  CardMemoryMgr[i].UserID == CardUserID)
				{
					return bTRUE;
				}
			}
	}
	return bFALSE;
}

uint8_t CheckHowManyRegisteredCardUser( void )//�����ע�ῨƬ�û�����
{
	uint8_t i,UserNum;
	UserNum =0;
	for (i=0;i<DEF_MAX_CARDUSER;i++)
	{
		if ( CardMemoryMgr[i].Status == CIDisValid )
		{
			UserNum++;
		}
	}
	return UserNum;
}

void ShowRegisterCardUser(void)//���ӿ�Ƭ�û�
{
	status_t GetCardID;

	if ( CardUserRegisterMgr.Status == StartCardUserRegister )
	{
		if ((CheckMemoryMgr.FpMasterNum == 0x00 )
			&&(CheckMemoryMgr.PasscodeMasterNum == 0x00))
		{
			CardUserRegisterMgr.Status = Fail;
			CardUserRegisterMgr.ErrorType = SystemNoMaster;
			CardUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
			PLAY_VOICE_ONESEGMENT(VOICE_PleaseAddMasterFirst);
			#ifdef Function_ScreenDisplay
			Clear_Screen();
			DisHZ16x14Str(3,14,AddMasterStr,NormalDisplay);
			#endif
		}
		else
		{
			if ( CheckMemoryMgr.CardUserNum < DEF_MAX_CARDUSER )
			{
				CardUserRegisterMgr.Status = InputCardUserID;
				DataInputMgr.Status = InputIdle;
				PLAY_VOICE_ONESEGMENT(VOICE_PleaseInputID);
				#ifdef Function_ScreenDisplay
				Clear_Screen();
				DisHZ16x14Str(3,0,InputUserIDStr,NormalDisplay);
				#endif
			}
			else
			{
				CardUserRegisterMgr.Status = Fail;
				CardUserRegisterMgr.ErrorType = MemoryIsFull;
				CardUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;
				PLAY_VOICE_ONESEGMENT(VOICE_UsersAreFull);
				#ifdef Function_ScreenDisplay
				Clear_Screen();
				DisHZ16x14Str(3,36,UsersFullStr,NormalDisplay);
				#endif
			}
		}
	}
	if ( CardUserRegisterMgr.Status == InputCardUserID )
	{
		CardUserRegisterMgr.UserID = Get_Availabe_CardUserID();
		CardUserRegisterMgr.Status = ReadingCardID;	
		CardUserRegisterMgr.TimeCnt = Def_UserSwingCardTimeDelay; 	//set to 5s
		//GUI_Flag_RefreshLCD = bTRUE;
		PLAY_VOICE_ONESEGMENT(VOICE_PleaseSwingCard);
		#ifdef Function_ScreenDisplay
		Clear_Screen();
		DisHZ16x14Str(3,40,PleaseSwingCardStr,NormalDisplay);
		#endif
	}
	else if ( CardUserRegisterMgr.Status == ReadingCardID)
	{
		GetCardID = MFC_Auto_Reader(CardUserRegisterMgr.CID);
		if ( GetCardID == S_SUCCESS )
		{
			CardUserRegisterMgr.Status = SavedCardID;
		}
		if ( --CardUserRegisterMgr.TimeCnt < 1 )
		{
			CardUserRegisterMgr.Status = Fail;
			CardUserRegisterMgr.ErrorType = TimeOut;
			CardUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay; 	
			//GUI_Flag_RefreshLCD = bTRUE;
			PLAY_VOICE_TWOSEGMENT(VOICE_Operation,VOICE_Fail);
			#ifdef Function_ScreenDisplay
			Clear_Screen();
			DisHZ16x14Str(3,36,OperationFailStr,NormalDisplay);
			#endif
		}
	}
	else if ( CardUserRegisterMgr.Status ==  SavedCardID )
	{
		if (CompareCardIDwithMemory(CardUserRegisterMgr.CID) == 0x00 )		//card CID is not be used
		{
			if ( SaveCardUserToMemory(CardUserRegisterMgr.CID,CardUserRegisterMgr.UserID) == S_SUCCESS )
			{
				CardUserRegisterMgr.Status = Success;
				CardUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay; 	
				//GUI_Flag_RefreshLCD = bTRUE;
				PLAY_VOICE_TWOSEGMENT(VOICE_Operation,VOICE_Success);
				#ifdef Function_ScreenDisplay
				Clear_Screen();
				DisHZ16x14Str(3,36,OperationSuccessStr,NormalDisplay);
				#endif
				CheckMemoryMgr.CardUserNum+=1;
			}
			else
			{
				CardUserRegisterMgr.Status = Fail;
				CardUserRegisterMgr.ErrorType = MemoryIsFull;
				CardUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay; 	
				PLAY_VOICE_ONESEGMENT(VOICE_UsersAreFull);
				Hardware_DelayMs(100);
				#ifdef Function_ScreenDisplay
				Clear_Screen();
				DisHZ16x14Str(3,36,UsersFullStr,NormalDisplay);
				#endif
			}
		}
		else
		{
			CardUserRegisterMgr.Status = Fail;
			CardUserRegisterMgr.ErrorType = CardCIDisBeUsed;
			CardUserRegisterMgr.TimeCnt = Def_MessageBoxTimeDelay;	
			//GUI_Flag_RefreshLCD = bTRUE;
			PLAY_VOICE_TWOSEGMENT(VOICE_Duplicate,VOICE_Card);
			#ifdef Function_ScreenDisplay
			DisHZ16x14Str(3,36,CardCIDisBeUsedStr,NormalDisplay);
			#endif
		}
	}
	else if ( CardUserRegisterMgr.Status ==  Success )
		{
			if ( --CardUserRegisterMgr.TimeCnt < 1 )
			{
				//CardUserRegisterMgr.Status = StartCardUserRegister;
				GoToCardMenu();
				#ifdef Function_EventLog
				GUI_CreatAndSaveLog(AddCardUser);
				#endif
			}
		}
	else if ( CardUserRegisterMgr.Status == Fail )
		{
			if (CardUserRegisterMgr.ErrorType == UserIDisRegistered)
			{
			
			}
			else if ( CardUserRegisterMgr.ErrorType == SystemNoMaster )
			{
				
			}
			else if ( CardUserRegisterMgr.ErrorType == MemoryIsFull )
			{
			
			}
			else if ( CardUserRegisterMgr.ErrorType == CardCIDisBeUsed )
			{
				
			}
			else
			{
				
			}
			if ( CardUserRegisterMgr.TimeCnt-- < 1 )
			{
				GoToCardMenu();
			}
		}
}

