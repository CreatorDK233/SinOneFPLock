#ifndef _Battery_H_
#define _Battery_H_	

extern void HardwareBatteryMgr_Task(void);
extern void Hardware_Task_Analog(void);

#endif