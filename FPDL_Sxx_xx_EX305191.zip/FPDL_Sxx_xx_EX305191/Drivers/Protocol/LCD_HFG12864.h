#ifndef _LCD_HFG12864_H
#define _LCD_HFG12864_H

extern void Display_Init(void);
extern void Display_Task(void);

#endif


