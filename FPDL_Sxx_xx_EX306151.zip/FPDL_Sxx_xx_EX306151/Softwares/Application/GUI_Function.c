#include "gpio.h"
//Protocol layer
#include "MFC_WS1850.h"
#include "EEPROM.h"
#include "BeepMgr.h"
//Logic layer
#include "AppUnlock.h"
#include "Motor.h"
#include "FP.h"
#include "LCD.h"
#include "MFC.h"
//Application layer
#include "GUI_Function.h"
#include "global_variable.h"
#include "Font.h"
#include "Voice_Menu.h"
#include "Font_Menu.h"


extern screen_t CurrentScreen;
extern DataInputMgr_t DataInputMgr;
extern VoiceMenuMgr_t VoiceMenuMgr;
extern PasscodeInputMgr_t PasscodeInputMgr;
extern uint8_t LEDsCtrlSwitch;
extern uint8_t GUI_ToggleFlag_05s;
extern keycode_t gui_keycode;



void GoToMainMenu(void)//�������˵�
{
	VoiceMenuMgr.MenuPoint=0;
	VoiceMenuMgr.TotalMenuNum = 6;
	CurrentScreen = SCREEN_MainMenu;
}

void GoToFpMenu(void)//����ָ�Ʋ˵�
{
	VoiceMenuMgr.MenuPoint=0;
	VoiceMenuMgr.TotalMenuNum = 4;
	CurrentScreen = SCREEN_FpMenu;
}
void GoToPasswordMenu(void)//��������˵�
{
	VoiceMenuMgr.MenuPoint=0;
	VoiceMenuMgr.TotalMenuNum = 4;
	CurrentScreen = SCREEN_PasscodeMenu;
}
void GoToCardMenu(void)//���뿨Ƭ�˵�
{
	VoiceMenuMgr.MenuPoint=0;
	VoiceMenuMgr.TotalMenuNum = 3;
	CurrentScreen = SCREEN_CardUserMenu;
}
void GoToSystemConfigMenu(void)//����ϵͳ���ò˵�
{
	VoiceMenuMgr.MenuPoint=0;
	VoiceMenuMgr.TotalMenuNum = 7;
	CurrentScreen = SCREEN_SystemConfigMenu;
}
void GoToSystemVersion(void)//����ϵͳ�汾�Ų˵�
{
	VoiceMenuMgr.MenuPoint=0;
	VoiceMenuMgr.TotalMenuNum = 2;
	CurrentScreen = SCREEN_SystemVersion;
}

void GotoLogMenu(void)//������־�˵�
{
	VoiceMenuMgr.MenuPoint=0;
	VoiceMenuMgr.TotalMenuNum = 3;
	CurrentScreen = SCREEN_EventLogMenu;
}

bool_t IfSystemIsInFactoryDefaultStatus(void)//���ϵͳ���ڳ���Ĭ��״̬
{
	if ( ( CheckMemoryMgr.FpUserNum == 0x00 )
			&&(CheckMemoryMgr.FpMasterNum == 0x00 )
			&&(CheckMemoryMgr.CardUserNum == 0x00 )
			&&(CheckMemoryMgr.PasscodeMasterNum == 0x00 )
			&&(CheckMemoryMgr.PasscodeUserNum == 0x00 )	)
	{
		return bTRUE;
	}
	else
	{
		return bFALSE;
	}
}

bool_t IfSystemWithoutSecondIdentity(void)//���ϵͳû�еڶ�����
{
	if  ( (((CheckMemoryMgr.FpUserNum+CheckMemoryMgr.FpMasterNum) == 0x00 )&&((CheckMemoryMgr.PasscodeMasterNum + CheckMemoryMgr.PasscodeUserNum)== 0x00))
		||(((CheckMemoryMgr.FpUserNum+CheckMemoryMgr.FpMasterNum) == 0x00 )&&(CheckMemoryMgr.CardUserNum == 0x00 ))
		||(((CheckMemoryMgr.PasscodeMasterNum + CheckMemoryMgr.PasscodeUserNum)== 0x00)&&(CheckMemoryMgr.CardUserNum == 0x00 ))
		)
	{
		return bTRUE;
	}
	else
	{
		return bFALSE;
	}
}

bool_t CompareTwoArrayIsSame(uint8_t Point1[],uint8_t Point2[],uint8_t Lenth)//�Ƚ����������Ƿ���ͬ
{
	uint8_t i;
	for (i=0;i<Lenth;i++)
	{
		if (Point1[i]!=Point2[i]){
			return bFALSE;
		}
	}
	return bTRUE;
}

void UnlockModeJudgment(void)//����ģʽ��Ч���ж�
{
	if	( IfSystemWithoutSecondIdentity() == bTRUE )
	{
		UserIdentifyResultMgr.UnlockingMode = SingalMode;
		EEPROM_WriteSequential(UnlockModeStartAddr,&UserIdentifyResultMgr.UnlockingMode,1);
	}
}

bool_t is_valid_date(uint8_t year, uint8_t month, uint8_t date)//�ж��ǲ�����Ч����
{
    uint8_t monttbuffer[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
		uint16_t y;
		uint8_t m,d;
		y=((year/16)*10)+(year%16)+2000;
		m = ((month/16)*10)+(month%16);
		d = ((date/16)*10) + (date%16);
        if (((y % 4 == 0) && (y % 100 != 0)) 
			|| (y % 400 == 0)
			)
        {
                monttbuffer[1] = 29; 
		}
        if ( (m > 0) 
			&& (m < 13)
			&& (d > 0) 
			&& (d <= monttbuffer[m - 1])
			)
        {
			return bTRUE;
		}
		else{
			return bFALSE;
		}
}

void Config_AntiPrying_Interrupt(void)//���÷���
{
	if (PickAlarmEnableMgr.Enable == bTRUE)
	{
		EnableAntiPrying_Interrupt();
	}
	else{
		DisableAntiPrying_Interrupt();
	}
}

void UnlockSuccess(uint8_t UnlockType)//�����ɹ�
{
	UserIdentifyResultMgr.IdentifyType = UnlockType;
	GUI_SetMotorToOpenAndCloseDoor();
	//Enable_KEYLED_WATERLIGHT(); 
	CurrentScreen = SCREEN_IdentifySuccess;
	UserIdentifyResultMgr.TimeCnt = Def_MessageBoxTimeDelay;
}

void RefreshSystemSleepTime(void)//����ϵͳ����ʱ��
{
	if ( ( CurrentScreen == SCREEN_Main )
		 ||( CurrentScreen ==SCREEN_Initialization)
		 ||( CurrentScreen ==SCREEN_LowBattery )
		)
	{
		SystemPowerMgr.SleepDelayTimerCnt = DEF_SystemSleepDelayTime_MainScreen;
	}
	else
	{
		SystemPowerMgr.SleepDelayTimerCnt = DEF_SystemSleepDelayTime_MenuScreen;
	}
}

void SystemConfigSave(void)//ϵͳ���ñ���
{
    EEPROM_WriteSequential(SystemLanguageStartAddr, (uint8_t*)&SystemLanguage, 1);
    EEPROM_WriteSequential(UnlockModeStartAddr, (uint8_t*)&UserIdentifyResultMgr.UnlockingMode, 1);
    EEPROM_WriteSequential(VolumeSwitchStartAddr, (uint8_t*)&VoiceMgr.Enable, 1);
    EEPROM_WriteSequential(PickAlarmSwitchStartAddr, (uint8_t*)&PickAlarmEnableMgr.Enable, 1);
}

void SystemConfigLoad(void)//ϵͳ���ü���
{
	uint8_t temp;
	bool_t temp_BOOL;
	EEPROM_ReadSequential(UnlockModeStartAddr,&temp,1);
	if (temp == DoubleMode)
	{
		UserIdentifyResultMgr.UnlockingMode = DoubleMode;
	}
	else
	{
		UserIdentifyResultMgr.UnlockingMode = SingalMode;
	}
	
	EEPROM_ReadSequential(VolumeSwitchStartAddr,(uint8_t*)&temp_BOOL,1);

	if (temp_BOOL == bFALSE)
	{
    	VoiceMgr.Enable = bFALSE;
	}
	else
	{
			VoiceMgr.Enable = bTRUE;
	}
	
	EEPROM_ReadSequential(PickAlarmSwitchStartAddr,(uint8_t*)&temp_BOOL,1);
		
	#ifdef Function_AntiPryingDefaultDisabled
	if (temp_BOOL == bTRUE)
	{
    	PickAlarmEnableMgr.Enable = bTRUE;
	}
	else
	{
			PickAlarmEnableMgr.Enable = bFALSE;
	}
	#else
	if (temp_BOOL == bFALSE)
	{
    	PickAlarmEnableMgr.Enable = bFALSE;
	}
	else
	{
			PickAlarmEnableMgr.Enable = bTRUE;
	}
	#endif
		
	Config_AntiPrying_Interrupt();
	
}

/****************************************************************/
void ReadLockBrand(void)//��ȡ��Ʒ��
{
	uint8_t temp;
	
	EEPROM_ReadSequential(LockBrandStartAddr,&temp,1);
	if ( temp == 0x55 )
	{
		EEPROM_ReadSequential(LockBrandStartAddr+1,&LockBrand.LockBrandDisDataBuff[0],224);
		LockBrand.LockBrandDataValid = bTRUE;
	}
	else{
		LockBrand.LockBrandDataValid = bFALSE;
	}	
}

void WriteLockBrand(void)//д����Ʒ��
{	
	#ifdef Function_ScreenDisplay
	uint8_t temp;
	temp = 0x55;
	LockBrand.GotBrandData = bFALSE;
	if ( MFC_ReadLockBrandData(&LockBrand.LockBrandDisDataBuff[0]) == S_SUCCESS )
	{
		EEPROM_WriteSequential(LockBrandStartAddr,&temp,1);
		
//		if ( LockBrand.BrandType == SmallBrand )
//		{
			EEPROM_WriteSequential(LockBrandStartAddr+1,&LockBrand.LockBrandDisDataBuff[0],224);
//		}
//		else if ( LockBrand.BrandType == BigBrand )
//		{
//			EEPROM_WriteSequential(LockBrandStartAddr+1,&LockBrand.LockBrandDisDataBuff[0],512);
//		}
		LockBrand.GotBrandData = bTRUE;
		LockBrand.LockBrandDataValid = bTRUE;
	}
	#endif
}

void SystemConfigReset(void)//ϵͳ���ûָ�����
{
	UserIdentifyResultMgr.UnlockingMode = SingalMode;
	VoiceMgr.Enable = bTRUE;
	
	#ifdef Function_AntiPryingDefaultDisabled
		PickAlarmEnableMgr.Enable = bFALSE;
	#else
		PickAlarmEnableMgr.Enable = bTRUE;
	#endif
	
	Config_AntiPrying_Interrupt();

	SystemConfigSave();
}

//ID����Ч����ʾ����
void GUI_DataInputCreat(uint8_t StartPage,uint8_t StartColumn,uint8_t InputNum,uint16_t DefaultValue)
{
	uint8_t temp,i;
	uint16_t value;

	if( DataInputMgr.Status == InputIdle )
	{
		DataInputMgr.Status = InputStart;
		DataInputMgr.Value = DefaultValue;
		DataInputMgr.InputNum = InputNum;

		if ( DefaultValue == 0x0000 ){
			DataInputMgr.InputPoint = 0;
		}
		else{
			DataInputMgr.InputPoint = InputNum;
		}
	}
		
	else if ( DataInputMgr.Status == InputStart )
	{
		if (DataInputMgr.InputPoint > DataInputMgr.InputNum ){
			return;
		}

		value = DataInputMgr.Value;
		for (i=0;i<DataInputMgr.InputPoint;i++)
		{	
			temp = value%10;
			DisOneDigital16x8(StartPage,StartColumn+(8*(DataInputMgr.InputPoint-i-1)),temp,NormalDisplay);
			value/=10;
		}

		for (i=DataInputMgr.InputPoint;i<(DataInputMgr.InputNum+1);i++)		//"+1" for clear underline
		{
			DisZF16x8(StartPage,StartColumn+(8*i),ZF_kongge,NormalDisplay);
		}
		
		if ( GUI_ToggleFlag_05s == 1 )
		{
			DisZF16x8(StartPage,StartColumn+(8*DataInputMgr.InputPoint),ZF_kongge,NormalDisplay);
		}
		else{
			DisZF16x8(StartPage,StartColumn+(8*DataInputMgr.InputPoint),ZF_underline,NormalDisplay);
		}
	}

}


void GUI_UserIDinputButtonMonitor(keycode_t keycode)//GUI_�û�ID���밴ť������
{
	if ( (keycode < KEY_NINE)||(keycode == KEY_NINE) )
	{
		DEF_ButtonPress_Voice;
		PasscodeUserRegisterMgr.OverTimeCnt = Def_GuiTimeDelayCnt5s;
		if ( DataInputMgr.InputPoint < DataInputMgr.InputNum )
		{
			DataInputMgr.Value = DataInputMgr.Value*10+gui_keycode;
			DataInputMgr.InputPoint++;
		}
	}
	else if ( keycode == KEY_ASTERISK )
	{
		DEF_ButtonPress_Voice;
		PasscodeUserRegisterMgr.OverTimeCnt = Def_GuiTimeDelayCnt5s;
		if ( DataInputMgr.InputPoint > 0 )
		{
			DataInputMgr.InputPoint--;
			DataInputMgr.Value/=10;
		}
		else
		{
			DataInputMgr.Status = InputExit;
		}
	}
	else if ( keycode == KEY_POUNDSIGN )
	{
		//DEF_ButtonPress_Voice;
		PasscodeUserRegisterMgr.OverTimeCnt = Def_GuiTimeDelayCnt5s;
		if ( DataInputMgr.InputPoint == 0 )
		{
			DataInputMgr.Status = InputExit;
		}
		else
		{
			DataInputMgr.Status = InputEnd;
		}
	}
}

void GUI_PasscodeInputCreat(uint8_t StartPage,uint8_t StartColumn)//GUI����������ʾЧ������
{
	uint8_t i=0;
	StartColumn=0;//�����壬ע����Ӱ�죬�ᱨwarming
	if (PasscodeInputMgr.Point > 16)
	{
		return;
	}
	#ifdef Function_ScreenDisplay
	Clear_Screen_Page(StartPage);
	Clear_Screen_Page(StartPage+1);
	for (i=0;i<PasscodeInputMgr.Point;i++)
	{
		DisZF16x8(StartPage,(8*i)+(64-(PasscodeInputMgr.Point*4)),ZF_xinghao,NormalDisplay);
	}
	#endif
}

void GUI_PasscodeInputButtonMonitor(keycode_t keycode)//GUI�����������������
{
	if ( (keycode < KEY_NINE)||(keycode == KEY_NINE) )//0-9
	{
		PasscodeUserRegisterMgr.OverTimeCnt = Def_GuiTimeDelayCnt5s;
		if ( CurrentScreen != SCREEN_PickLockAlarm ){
			DEF_ButtonPress_Voice;
		}
		if ( PasscodeInputMgr.Point <  PasscodeInputMgr.PasscodeLen )
		{
			PasscodeInputMgr.InputBuff[PasscodeInputMgr.Point] = gui_keycode;
			PasscodeInputMgr.Point++;
		}
	}
	else if ( keycode == KEY_ASTERISK )
	{
		PasscodeUserRegisterMgr.OverTimeCnt = Def_GuiTimeDelayCnt5s;
		if ( CurrentScreen != SCREEN_PickLockAlarm && CurrentScreen != SCREEN_ManagerIdentify){
			DEF_ButtonPress_Voice;
		}
		
		if ( PasscodeInputMgr.Point > 0 )
		{
			PasscodeInputMgr.Status = PasscodeInputExit;	
		}
		else
		{
			PasscodeInputMgr.Status = PasscodeInputExit;
		}
	}
	else if ( keycode == KEY_POUNDSIGN )
	{
		PasscodeUserRegisterMgr.OverTimeCnt = Def_GuiTimeDelayCnt5s;
		if ( CurrentScreen != SCREEN_PickLockAlarm ){
			DEF_ButtonPress_Voice;
		}
		if ( PasscodeInputMgr.Point == 0 )
		{
			PasscodeInputMgr.Status = PasscodeInputExit;
		}
		else
		{
			PasscodeInputMgr.Status = PasscodeInputEnd;
		}
	}
}

void PasscodeUserIdentify(void)//�����û���֤
{
	if ( PasscodeUserIdentifyMgr.Status != PasscodeIdentifyIdle )
	{
		if (PasscodeUserIdentifyMgr.Status == PasscodeIdentifyStart )
		{
			//PasscodeUserIdentifyMgr.TimeCnt = 240;
			PasscodeUserIdentifyMgr.Status = PasscodeIdentifyPasscodeInput;
		}
		else if (PasscodeUserIdentifyMgr.Status == PasscodeIdentifyPasscodeInput)
		{
			Clear_Screen_Page(3);
			Clear_Screen_Page(6);
			Clear_Screen_Page(7);
			GUI_PasscodeInputCreat(4,0);
			if (PasscodeInputMgr.Status == PasscodeInputEnd)
			{
				if ( IfSystemIsInFactoryDefaultStatus()==bTRUE )
				{
					if( (PasscodeInputMgr.InputBuff[0]==0x01)
						&&(PasscodeInputMgr.InputBuff[1]==0x01)
						&&(PasscodeInputMgr.InputBuff[2]==0x01)
						&&(PasscodeInputMgr.InputBuff[3]==0x01)
						&&(PasscodeInputMgr.InputBuff[4]==0x01)
						&&(PasscodeInputMgr.InputBuff[5]==0x01)
						&&(PasscodeInputMgr.InputBuff[6]==0x01)
						&&(PasscodeInputMgr.InputBuff[8]==0x01)
						&&(PasscodeInputMgr.InputBuff[9]==0x01)
					  )
					{
						PasscodeUserIdentifyMgr.Status = PasscodeIdentifyAgingTestSuccess;
					}
					else if ((PasscodeInputMgr.InputBuff[0]==0x01)
							&&(PasscodeInputMgr.InputBuff[1]==0x03)
							&&(PasscodeInputMgr.InputBuff[2]==0x05)
							&&(PasscodeInputMgr.InputBuff[3]==0x07)
							&&(PasscodeInputMgr.Point == 4)
							)
					{
						PasscodeUserIdentifyMgr.Status = PasscodeIdentifyCheckVersionSuccess;
					}
					else
					{
						PasscodeUserIdentifyMgr.Status = PasscodeIdentifyFail;
					}
				}
				else
				{
					PasscodeUserIdentifyMgr.UserID = PasscodeIdendify(PasscodeInputMgr.InputBuff);
					if ( PasscodeUserIdentifyMgr.UserID != 0x00 )//Identify success
					{
						PasscodeUserIdentifyMgr.Status = PasscodeIdentifySuccess;
						//PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifySuccessScreenTimeDelay;
						UserIdentifyResultMgr.PasscodeType = LocalPasscode;
						//GUI_Flag_RefreshLCD = bTRUE;
					}
				#ifdef Function_AppUnlock
					else
					{
						if ((PasscodeInputMgr.Point == 12)||( PasscodeInputMgr.Point == 13 ))
						{
 							 PasscodeUserIdentifyMgr.UserID = AppPasscodeIdentify(PasscodeInputMgr.InputBuff);
							if ( PasscodeUserIdentifyMgr.UserID != 0x00 )//App unlock success
							{
								PasscodeUserIdentifyMgr.Status = PasscodeIdentifySuccess;
								//PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifySuccessScreenTimeDelay;
								UserIdentifyResultMgr.PasscodeType = AppPasscode;
								//GUI_Flag_RefreshLCD = bTRUE;
							}
							else
							{
								PasscodeUserIdentifyMgr.Status = PasscodeIdentifyFail;
								//PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifyFailScreenTimeDelay;
								//GUI_Flag_RefreshLCD = bTRUE;
							}
						}
						else
						{
							PasscodeUserIdentifyMgr.Status = PasscodeIdentifyFail;
							//PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifyFailScreenTimeDelay;
							//GUI_Flag_RefreshLCD = bTRUE;
						}
					}
				#else
					else
					{
						PasscodeUserIdentifyMgr.Status = PasscodeIdentifyFail;
						//PasscodeUserIdentifyMgr.TimeCnt =Def_IdendtifyFailScreenTimeDelay;
						//GUI_Flag_RefreshLCD = bTRUE;
					}
				#endif
				}
			}
			else if (PasscodeInputMgr.Status == PasscodeInputExit)
			{
				PasscodeUserIdentifyMgr.Status = PasscodeIdentifyIdle;
				PasscodeUserRegisterMgr.TimeCnt = 0;	
				//GUI_Flag_RefreshLCD = bTRUE;
			}
		}
	}
}

uint8_t PasscodeIdendify(uint8_t *BUFF1)//������֤
{
		uint8_t i,k;
	int j;
	uint8_t PasscodeLen;
	for (i=0;i<(DEF_MAX_PASSCODEMASTER+DEF_MAX_PASSCODEUSER);i++)
	{
		if ( PasscodeMemoryMgr[i].Status != PasscodeIsValid ){
			continue;
		}

		PasscodeLen = 0;
		for (j=11;j>=0;j--)
		{
			if(j%2==1)
			{
				if ( (PasscodeMemoryMgr[i].PasscodeBuff[j/2]&0xf) != 0xF )
				{
					PasscodeLen = j+1;
					break;
				}
			}
			else
			{
				if ( ((PasscodeMemoryMgr[i].PasscodeBuff[j/2]>>4)&0xf) != 0xF )
				{
					PasscodeLen = j+1;
					break;
				}
			}
		}
		
		for (j=0;j<(16-PasscodeLen+1);j++)
		{
			for (k=0;k<PasscodeLen;k++)
			{
				if(k%2==1)
				{
					if (((PasscodeMemoryMgr[i].PasscodeBuff[k/2]&0xf) != *(BUFF1+k+j)))
					{
						break;
					}
				}
			    else
				{
					if ((((PasscodeMemoryMgr[i].PasscodeBuff[k/2]>>4)&0xf) != *(BUFF1+k+j)))
					{
						break;
					}
				}
			}
			if (k == PasscodeLen){
				return PasscodeMemoryMgr[i].UserID;
			}
		}
	}
	return 0;
}

uint8_t AppPasscodeIdentify(uint8_t BUFF[])//APP����ʶ��
{
	uint8_t i,j;
	uint8_t UserPasscodeLen;
	uint8_t temp[12];
	for (i=0;i<DEF_MAX_PASSCODEMASTER;i++){
		UserPasscodeLen = 0;
		for(j=0;j<6;j++)
		{
			temp[2*j]=PasscodeMemoryMgr[i].PasscodeBuff[j]>>4;
			temp[2*j+1]=PasscodeMemoryMgr[i].PasscodeBuff[j]&0x0f;
		}
		for (j=0;j<12;j++){
	     if ( temp[j] < 10){
	          UserPasscodeLen++;
	     }
	     else{
	         break;
	     }
		}
		if(UserPasscodeLen<6){
				continue;
		}
		if ( pwd_decrypt_checkmode(temp,UserPasscodeLen,BUFF,12) > 0 ){
       return i+1;
		}
	}
	return 0;
}

void ShowLockBrand(void)//��ʾ��Ʒ��
{
	#ifdef Function_ScreenDisplay
	code uint8_t Welcome_Str[8]={HZ_huan,HZ_yingjie,HZ_shiyong,HZ_yong,HZ_zhineng,HZ_neng,HZ_suomen,HZ_end};

	if ( LockBrand.LockBrandDataValid == bTRUE )
	{
		DisImage_RAM(6,8,112,16,&LockBrand.LockBrandDisDataBuff[0],NormalDisplay);
	}
	else if( LockBrand.LockBrandDataValid == bFALSE )
	{
		DisHZ16x14Str(6,16,Welcome_Str,NormalDisplay);
	}
	#endif
}

void GUI_Update_Version(void)//���°汾��
{
	#ifdef Function_ScreenDisplay
	 code uint8_t SystemVersionStr[]={HZ_xi,HZ_tong,HZ_ban,HZ_ben,HZ_end};
	//code uint8_t FPM_Version[]={"FPM:126"};
	uint8_t ModelStr[]={"Sxxx-xxx"};
	uint8_t VersionStr[]={"100.100"};
	#endif

	if ( VoiceDataTransferMgr.VoicePlayEnd == bTRUE )
	{
		if (VoiceMenuMgr.MenuPoint < VoiceMenuMgr.TotalMenuNum )
		{
			PLAY_VOICE_MULTISEGMENTS(SystemVersionVoiceBuff[VoiceMenuMgr.MenuPoint]);
			VoiceMenuMgr.MenuPoint++;
		}
	}
	
	#ifdef Function_ScreenDisplay
	DisHZ16x14Str(0,32,SystemVersionStr,NormalDisplay);
	ModelStr[1]=DEF_CustomerNumber/100+0x30;
	ModelStr[2]=DEF_CustomerNumber%100/10+0x30;
	ModelStr[3]=DEF_CustomerNumber%10+0x30;
	ModelStr[5]=DEF_ModelNumber/100+0x30;
	ModelStr[6]=DEF_ModelNumber%100/10+0x30;
	ModelStr[7]=DEF_ModelNumber%10+0x30;	
	DisEN16x8Str(3,20,ModelStr,NormalDisplay);
	//Main Board Hardware Version
	VersionStr[0]=DEF_HardwareVerion/100+0x30;
	VersionStr[1]=DEF_HardwareVerion%100/10+0x30;
	VersionStr[2]=DEF_HardwareVerion%10+0x30;
	//Main Board Firmware Version
	VersionStr[4]=DEF_FirmwareVerion/100+0x30;
	VersionStr[5]=DEF_FirmwareVerion%100/10+0x30;
	VersionStr[6]=DEF_FirmwareVerion%10+0x30;

	DisEN16x8Str(5,20,VersionStr,NormalDisplay);
	#endif
}

void ReadPasscodeUserMemoryFromEEPROM(void)//��EEPROM�ڴ��ȡ�����û�
{
	EEPROM_ReadSequential(PasscodeUserMemoryStartAddr,&PasscodeMemoryMgr[0].UserID,(8*(DEF_MAX_PASSCODEUSER+DEF_MAX_PASSCODEMASTER)));
}

void WritePasscodeUserMemoryToEEPROM(void)//��EEPROM�ڴ�д�������û�
{
	EEPROM_WriteSequential(PasscodeUserMemoryStartAddr,&PasscodeMemoryMgr[0].UserID,(8*(DEF_MAX_PASSCODEUSER+DEF_MAX_PASSCODEMASTER)));
}

bool_t GUI_CompareTwoPasscodes(uint8_t *BUFF1,uint8_t *BUFF2)//�Ƚ����������Ƿ����
{
	if (  ( *BUFF1 == *BUFF2)
		&&(*(BUFF1+1) == *(BUFF2+1))
		&&(*(BUFF1+2) == *(BUFF2+2))
		&&(*(BUFF1+3) == *(BUFF2+3))
		&&(*(BUFF1+4) == *(BUFF2+4))
		&&(*(BUFF1+5) == *(BUFF2+5))
		&&(*(BUFF1+6) == *(BUFF2+6))
		&&(*(BUFF1+7) == *(BUFF2+7))
		&&(*(BUFF1+8) == *(BUFF2+8))
		&&(*(BUFF1+9) == *(BUFF2+9))
		&&(*(BUFF1+10) == *(BUFF2+10))
		&&(*(BUFF1+11) == *(BUFF2+11))
	   )
	{
		return bTRUE;
	}
	else
	{
		return bFALSE;
	}
}

bool_t IfPasscodeUserIDisRegistered(uint8_t UserID)//��������û�ID��ע��
{
	uint8_t i;
	for (i=0;i<(DEF_MAX_PASSCODEUSER+DEF_MAX_PASSCODEMASTER);i++)
	{
		if (PasscodeMemoryMgr[i].UserID == UserID )
		{
			return bTRUE;
		}
	}	
	return bFALSE;
}

uint8_t CheckHowManyRegisteredPasscodeMaster( void )//���ע���������Ա����
{
	uint8_t i,MasterNum;
	MasterNum =0;
	for (i=0;i<(DEF_MAX_PASSCODEMASTER);i++)
	{
		if ( IfPasscodeUserIDisRegistered(i+1) == bTRUE )
		{
			MasterNum++;
		}
	}
	return MasterNum;
}

uint8_t CheckHowManyRegisteredPasscodeUser( void )//���ע�������û�����
{
	uint8_t i,UserNum;
	UserNum =0;
	for (i=DEF_MAX_PASSCODEMASTER;i<(DEF_MAX_PASSCODEUSER+DEF_MAX_PASSCODEMASTER);i++)
	{
		if ( IfPasscodeUserIDisRegistered(i+1) == bTRUE )
		{
				UserNum++;
		}
	}
	return UserNum;
}

void DeletePasscodeUserfromMemory(uint8_t UserID)//��EEPROM�ڴ���ɾ�������û�
{
	uint8_t i,j;

	for (i=0;i<(DEF_MAX_PASSCODEUSER+DEF_MAX_PASSCODEMASTER);i++)
	{
		if (PasscodeMemoryMgr[i].UserID == UserID )
		{
			PasscodeMemoryMgr[i].Status = PasscodeIsInvalid;
			PasscodeMemoryMgr[i].UserID = 0xFF;
			for (j=0;j<6;j++)
			{
				PasscodeMemoryMgr[i].PasscodeBuff[j] = 0xFF;
			}
			break;
		}
	}	

	WritePasscodeUserMemoryToEEPROM();
}

void DeleteAllPasscodeMasterfromMemory(void)//��EEPROM�ڴ���ɾ��ȫ���������Ա
{
	uint8_t i,j;

	for (i=0;i<DEF_MAX_PASSCODEMASTER;i++)
	{

		PasscodeMemoryMgr[i].Status = PasscodeIsInvalid;
		PasscodeMemoryMgr[i].UserID = 0xFF;
		for (j=0;j<6;j++)
		{
			PasscodeMemoryMgr[i].PasscodeBuff[j] = 0xFF;
		}

	}	
	WritePasscodeUserMemoryToEEPROM();
}

void DeleteAllPasscodeUserfromMemory(void)//��EEPROM�ڴ���ɾ��ȫ�������û�
{
	uint8_t i,j;

	for (i=DEF_MAX_PASSCODEMASTER;i<(DEF_MAX_PASSCODEMASTER+DEF_MAX_PASSCODEUSER);i++)
	{

		PasscodeMemoryMgr[i].Status = PasscodeIsInvalid;
		PasscodeMemoryMgr[i].UserID = 0xFF;
		for (j=0;j<6;j++)
		{
			PasscodeMemoryMgr[i].PasscodeBuff[j] = 0xFF;
		}

	}	
	WritePasscodeUserMemoryToEEPROM();
}

status_t SavePasscodeUserToMemory(uint8_t *Point,uint8_t UserID)//���������û����ڴ�
{
	uint8_t j;
	for (j=0;j<6;j++)
	{
		PasscodeMemoryMgr[UserID-1].PasscodeBuff[j] = (*(Point+2*j))<<4|((*(Point+2*j+1)&0X0f));
	}
	PasscodeMemoryMgr[UserID-1].UserID = UserID;
	PasscodeMemoryMgr[UserID-1].Status = PasscodeIsValid;
	WritePasscodeUserMemoryToEEPROM();
	return S_SUCCESS;
}

uint8_t Get_Availabe_PasscodeMasterID(void)//��ȡ��ע���������ԱID
{
	uint8_t i;
	for (i=0;i<DEF_MAX_PASSCODEMASTER;i++)
	{
		if ( PasscodeMemoryMgr[i].Status != PasscodeIsValid ){
			return (i+1);
		}
	}
	return 0;
}

uint8_t Get_Availabe_PasscodeUserID(void)//��ȡ��ע�������û�ID
{
	uint8_t i;
	for (i=DEF_MAX_PASSCODEMASTER;i<(DEF_MAX_PASSCODEMASTER+DEF_MAX_PASSCODEUSER);i++)
	{
		if ( PasscodeMemoryMgr[i].Status != PasscodeIsValid ){
			return (i+1);
		}
	}
	return 0;
}

void GUI_GetUserNumList(void)//��ȡ�û�����
{

	if ( CheckMemoryMgr.Status == StartCheckMemory)
	{
		CheckHomManyRegisteredFPuser.Status = StartCheckHowManyRegisteredFPuser;
		CheckHomManyRegisteredFPuser.FailTimes = 0x00;
		CheckMemoryMgr.Status = WaitForReadFPuserNum;
	}
	else if ( CheckMemoryMgr.Status == WaitForReadFPuserNum )
	{
		CheckHowManyRegistereFPuser();
		if ( CheckHomManyRegisteredFPuser.Status == CheckHomManyRegisteredFPuserSuccess )
		{
			CheckMemoryMgr.FpUserNum = CheckHomManyRegisteredFPuser.UserNum;
			CheckMemoryMgr.FpMasterNum = CheckHomManyRegisteredFPuser.MasterNum;
			CheckMemoryMgr.CardUserNum = CheckHowManyRegisteredCardUser();
			CheckMemoryMgr.PasscodeMasterNum = CheckHowManyRegisteredPasscodeMaster();
			CheckMemoryMgr.PasscodeUserNum = CheckHowManyRegisteredPasscodeUser();
			CheckMemoryMgr.Status = CheckMemorySuccess;
		}
		else if ( CheckHomManyRegisteredFPuser.Status == CheckHomManyRegisteredFPuserFail )
		{
			if ( CheckHomManyRegisteredFPuser.FailTimes++ < 4 )
			{
				CheckHomManyRegisteredFPuser.Status = StartCheckHowManyRegisteredFPuser;//retry
			}
			else
			{
				CheckMemoryMgr.Status = CheckMemoryFail;
				CheckMemoryMgr.FpUserNum = 1;//CheckHomManyRegisteredFPuser.UserNum;
				CheckMemoryMgr.FpMasterNum = 1;//CheckHomManyRegisteredFPuser.MasterNum;
				CheckMemoryMgr.CardUserNum = CheckHowManyRegisteredCardUser();
				CheckMemoryMgr.PasscodeMasterNum = CheckHowManyRegisteredPasscodeMaster();
				CheckMemoryMgr.PasscodeUserNum = CheckHowManyRegisteredPasscodeUser();
			}
		}
	}
	
}

uint8_t TranslateNumberToVoice(uint8_t value)//������ת��Ϊ����
{
	return 12+(2*value);
}

void SaveSystemTime( void )
{
	SystemTime.year   =		TempSystemTime.year;
	SystemTime.month 	= 	TempSystemTime.month;
	SystemTime.date   = 	TempSystemTime.date;
	//SystemTime.day		= 	TempSystemTime.day;
	SystemTime.hour   = 	TempSystemTime.hour;
	SystemTime.minute = 	TempSystemTime.minute;
	SystemTime.second = 	TempSystemTime.second;
}

void GotSystemTime( void )
{
	TempSystemTime.year		=	SystemTime.year;
	TempSystemTime.month	= SystemTime.month;
	TempSystemTime.date 	= SystemTime.date;
	//TempSystemTime.day		= SystemTime.day;
	TempSystemTime.hour		= SystemTime.hour;
	TempSystemTime.minute	= SystemTime.minute;
	TempSystemTime.second	= SystemTime.second;
}





