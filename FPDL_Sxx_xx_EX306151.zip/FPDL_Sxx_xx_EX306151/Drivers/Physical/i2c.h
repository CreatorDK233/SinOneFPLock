#ifndef __i2c_H
#define __i2c_H

extern void MX_I2C_Init(void);

#endif /*__ i2c_H */
