#ifndef _KeyScanDrive_h
#define _KeyScanDrive_h

#define uint32_t unsigned long int

extern uint32_t KeyScanDrive(void);
extern void KeyPressedJudge(uint32_t InputKeyValue);
extern void Touch_Init(void);

#endif
